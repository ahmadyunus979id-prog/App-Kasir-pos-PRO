# Peningkatan Fitur Kasir, Scanner Kamera, Poin Loyalitas & Link Nota Pendek

Pembaruan ini menyempurnakan alur kasir dan manajemen produk dengan menambahkan kontrol aktif/nonaktif nominal perolehan poin, pemindai SKU & barcode langsung dari kamera perangkat HP, tautan struk WhatsApp yang ringkas (`NamaToko/NomorInvoice`) dan dapat dibuka di browser mana saja, serta formulir tambah produk yang bersih dengan hanya SKU terisi otomatis.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Pertanyaan klarifikasi sebelumnya dilewati, sehingga rencana ini menggunakan pendekatan default yang direkomendasikan agar seluruh fitur langsung bekerja di perangkat HP dan browser mana saja. Anda tetap dapat meminta penyesuaian sebelum eksekusi dimulai.

- **Penyimpanan Link Nota Pendek Lintas Browser**: Menggunakan backend aplikasi ringan (Express API + penyimpanan JSON persisten di server) agar tautan pendek yang dikirim ke WhatsApp dapat dibuka dari HP dan browser mana saja tanpa harus memiliki data lokal toko.
- **Format Tautan WhatsApp**: Menggunakan format ringkas `https://<domain-aplikasi>/<NamaToko>/<NomorInvoice>` (tanpa spasi agar seluruh URL otomatis bisa diklik di WhatsApp), serta tetap mengenali variasi garis miring ganda (`NamaToko//NomorInvoice`) maupun tautan lama berbasis token.
- **Cakupan Scanner Kamera HP**: Aktif di **Kasir (POS)**, **Form Tambah/Edit Produk** (untuk mengisi barcode), dan **Stok Opname**.
- **Aturan Tambah Produk Baru**: Semua kolom input dimulai dalam keadaan kosong (`""`) kecuali kolom **SKU** yang terisi otomatis.

---

### 1. Overview & Core Concept

- **What It Does**:
  1. **Toggle Poin Loyalitas**: Pemilik/Admin dapat mengaktifkan atau menonaktifkan perhitungan *Nominal per 1 Poin* kapan saja dari Pengaturan.
  2. **Scanner Kamera HP**: Kasir dan staf gudang dapat memindai barcode 1D maupun QR code SKU menggunakan kamera belakang HP secara real-time.
  3. **Link Nota WhatsApp Pendek**: Setiap transaksi menyimpan salinan struk ringkas ke server sehingga tautan WhatsApp berubah dari kode panjang menjadi `<NamaToko>/<NomorInvoice>` dan dapat dibuka di browser apa saja.
  4. **Form Produk Bersih**: Saat menambah produk baru, hanya SKU yang dibuat otomatis; seluruh kolom lain kosong siap diisi tanpa harus menghapus nilai bawaan.
- **Target Audience / Persona**: Pemilik toko, Admin, Kasir di konter HP/tablet, Staf Gudang saat stok opname, serta Pelanggan yang menerima struk digital via WhatsApp.
- **Key Value**: Mengurangi kesalahan input data produk, mempercepat checkout dan opname dengan kamera HP tanpa alat scanner eksternal, memberi fleksibilitas promo poin, dan menyajikan tautan nota WhatsApp yang rapi serta profesional.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Pengaturan Poin Loyalitas**:
     - Buka *Pengaturan* → bagian *Pajak PPN & Aturan Poin Loyalitas*.
     - Aktif/nonaktifkan sakelar *Aktifkan perolehan poin loyalitas*. Saat nonaktif, input *Nominal per 1 Poin (Rp)* tampak redup (disabled) dan transaksi baru di kasir tidak menambah poin otomatis.
  2. **Pemindaian Kamera HP (Kasir, Produk, Opname)**:
     - Tekan tombol *Scan Barcode / Kamera* → modal pemindai membuka umpan kamera belakang secara langsung dengan bingkai bidik (*viewfinder*) yang jelas dan tombol ganti kamera / lampu kilat (*torch*) bila didukung perangkat.
     - Begitu barcode/SKU terbaca, modal menutup otomatis (atau memberi umpan balik instan) dan langsung memasukkan barang ke keranjang kasir, mengisi kolom barcode produk, atau memilih produk pada stok opname.
     - Tetap tersedia input manual dan pesan panduan ramah jika izin kamera ditolak atau dibuka dalam pratinjau *iframe* terbatas.
  3. **Kirim & Buka Link Nota WhatsApp Pendek**:
     - Setelah checkout berhasil, aplikasi langsung menerbitkan data struk publik ke server dan menampilkan URL pendek `https://<domain>/<NamaToko>/<NomorInvoice>` di modal struk serta di pesan WhatsApp.
     - Saat pelanggan mengetuk tautan di WhatsApp menggunakan browser mana saja, halaman Nota Digital Publik memuat rincian belanja, status lunas/void/retur, tombol unduh PDF, dan cetak struk dengan indikator *loading* lalu tampilan struk bersih.
  4. **Tambah Produk Baru**:
     - Klik *Tambah Baru* di tab Produk → formulir terbuka dengan hanya kolom *SKU* terisi (`SKU-XXXX`). Nama, barcode, kategori, merek, harga beli, harga jual, satuan, stok, dan minimum stok kosong dengan *placeholder* deskriptif.
- **Visual Identity & Theme**:
  - Mempertahankan sistem visual aplikasi saat ini (`Plus Jakarta Sans` + `JetBrains Mono` / `tabular-nums`, kanvas netral `slate-50` / `slate-950`, aksen `teal-700`, dan dukungan penuh mode Cerah/Gelap via kelas `.dark`).
  - Mematuhi kepadatan dashboard operasional: permukaan datar dengan garis tepi tipis `border-slate-200 dark:border-slate-800`, tanpa *pill* metadata statis, angka monospasi rata kanan pada kolom nominal, dan kontrol satu baris dengan target sentuh mobile minimal `44px`.
- **Interactive Feedback & Motion**:
  - Umpan balik mikro cepat (`<= 200ms`), skeleton/spinner pemuatan saat nota publik diambil dari server, pesan sukses/galat eksplisit saat scan kamera, dan fallback otomatis bila data struk tidak ditemukan.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Backend Ringan untuk Link Nota Pendek Lintas Browser**
  - *Chosen Approach*: Menambahkan entry server Express yang menyajikan aplikasi Vite/dist sekaligus menyediakan API publikasi dan pembacaan nota (`/api/receipts`), dengan penyimpanan file JSON terstruktur di server.
  - *Why*: Tautan pendek tanpa payload data panjang tidak mungkin dibuka oleh perangkat pelanggan lain jika hanya mengandalkan `localStorage` perangkat kasir. Pendekatan ini bekerja langsung tanpa memerlukan login atau konfigurasi database eksternal tambahan.
  - *Alternatives Considered*: Firebase Firestore memerlukan proses provisi & otorisasi terpisah; menyematkan seluruh data di URL menghasilkan link sangat panjang yang kurang rapi di WhatsApp.
- **Decision 2: Mesin Pemindai Kamera Lintas Browser**
  - *Chosen Approach*: Menggunakan kombinasi `BarcodeDetector` bawaan browser (akselerasi perangkat keras) dengan pustaka fallback JS/WebRTC (`@zxing/browser`) secara otomatis.
  - *Why*: `BarcodeDetector` sangat cepat di Android Chrome, tetapi belum tersedia di iOS Safari atau Firefox. Fallback `@zxing/browser` memastikan kamera HP tetap bisa memindai di iOS maupun Android.
  - *Alternatives Considered*: Hanya mengandalkan `BarcodeDetector` akan gagal di perangkat iOS/Safari.
- **Decision 3: Format URL Pendek `NamaToko/NomorInvoice` yang Ramah WhatsApp**
  - *Chosen Approach*: Membentuk slug URL bebas spasi dari nama toko (misalnya `TokoBaru/INV-20261123-0001`), serta mendukung pembacaan pola `NamaToko/NomorInvoice`, `NamaToko//NomorInvoice`, hash `#/NamaToko//NomorInvoice`, dan token lama `?nota=...` secara bersamaan.
  - *Why*: Spasi dan karakter khusus memutus deteksi klik otomatis tautan di WhatsApp. Mendukung variasi `/` maupun `//` menjamin tautan tetap terbuka dengan andal.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                        Express Server (Port 3000)                         │
│  ┌───────────────────────────┐   ┌─────────────────────────────────────┐  │
│  │ Vite Middleware / Static  │   │ Receipt API & Store (/api/receipts) │  │
│  │ SPA Fallback Routing      │   │ Validated JSON Persistence          │  │
│  └─────────────┬─────────────┘   └──────────────────┬──────────────────┘  │
└────────────────┼────────────────────────────────────┼─────────────────────┘
                 │                                    │
                 ▼                                    ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                         React Client Application                          │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │ URL Resolver: /:storeSlug/:invoice | /:storeSlug//:invoice | ?nota= │  │
│  └───────────────┬───────────────────────────────────┬─────────────────┘  │
│                  │ (Public Receipt Link)             │ (Staff App)        │
│                  ▼                                   ▼                    │
│  ┌───────────────────────────────┐   ┌─────────────────────────────────┐  │
│  │ PublicReceiptView             │   │ POS / Master / Inventory /      │  │
│  │ (Fetch API + Local + Token)   │   │ Settings Store (usePosStore)    │  │
│  └───────────────────────────────┘   └──────────┬─────────────┬────────┘  │
│                                                 │             │           │
│                                                 ▼             ▼           │
│                                  ┌───────────────────┐ ┌───────────────┐  │
│                                  │ CameraScannerModal│ │ ReceiptModal  │  │
│                                  │ (WebRTC + ZXing)  │ │ (Short WA URL)│  │
│                                  └───────────────────┘ └───────────────┘  │
└───────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `StoreSettings` menambah properti `pointsEnabled: boolean` (default `true`, dengan fallback aman bagi data tersimpan lama).
  - Entitas `PublicReceiptRecord` di server menyimpan salinan data struk publik (tanpa data sensitif internal seperti harga modal/HPP) yang diindeks berdasarkan pasangan `storeSlug` + `invoiceNumber`.
- **Interactive Component & State Mapping**:
  - **Settings Loyalitas**: Sakelar `pointsEnabled` langsung memperbarui `StoreSettings`. Pada `completeSale`, perhitungan poin baru hanya berjalan jika `pointsEnabled === true`. Pada POS, info estimasi poin menyesuaikan status aktif/nonaktif.
  - **CameraScannerModal**: Mengelola siklus hidup `MediaStream` kamera (mulai, pilih kamera belakang, hentikan stream bersih saat modal ditutup/berhasil scan), meneruskan hasil kode SKU/barcode ke handler pemanggil:
    - *Kasir POS*: mencocokkan SKU/barcode produk lalu memasukkan ke keranjang.
    - *Form Produk*: mengisi nilai input *Barcode* (atau *SKU* sesuai tombol pemicu).
    - *Stok Opname*: memilih produk yang cocok pada dropdown opname dan memperbarui stok sistem acuan.
  - **Form Tambah Produk**: Saat mode tambah baru (`existing === null`), seluruh state field diinisialisasi ke `""` kecuali `sku` yang otomatis dibuat unik.
  - **Short Receipt Link & Safeguards**:
    - Saat transaksi selesai atau modal struk dibuka, klien mengirim payload struk publik (HPP dan data internal tetap disaring) ke `POST /api/receipts`.
    - Server memvalidasi tipe data, panjang string, serta karakter slug/invoice, dan mengonfinasikan jalur file penyimpanan secara ketat di dalam direktori data server.
    - `PublicReceiptView` melakukan pembacaan dari URL jalur pendek, melakukan permintaan `GET /api/receipts/:storeSlug/:invoice`, dan merender seluruh teks melalui binding React yang aman (tanpa injeksi HTML mentah).
