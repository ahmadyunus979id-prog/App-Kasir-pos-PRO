import type {
  AttendanceConfig,
  AttendanceRecord,
  Customer,
  LoyaltyReward,
  Outlet,
  PettyCash,
  PointHistory,
  Product,
  PurchaseOrder,
  Shift,
  StockMovement,
  StockTransfer,
  StoreSettings,
  Supplier,
  Transaction,
  User,
} from '../types/pos';
import { makePasswordHash, sealDevCredential } from '../utils/formatters';
import { createDefaultEnabledMenus } from '../utils/menuPermissions';

export interface PosDatabaseState {
  outlets: Outlet[];
  users: User[];
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  shifts: Shift[];
  pettyCash: PettyCash[];
  transactions: Transaction[];
  purchaseOrders: PurchaseOrder[];
  stockMovements: StockMovement[];
  stockTransfers: StockTransfer[];
  loyaltyRewards: LoyaltyReward[];
  pointHistory: PointHistory[];
  settings: StoreSettings;
  attendanceConfig: AttendanceConfig;
  attendanceRecords: AttendanceRecord[];
}

export function createDefaultAttendanceConfig(
  includeDemoAdminGrant = false,
  enabled = true
): AttendanceConfig {
  return {
    enabled,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    outletLatitude: -6.208763,
    outletLongitude: 106.845599,
    requireGps: true,
    adminAccessByUserId: includeDemoAdminGrant
      ? {
          'usr-1': {
            viewAttendance: true,
            viewLocation: true,
            manageAttendance: true,
          },
        }
      : {},
    roleConfigs: {},
  };
}

function createSeedUser(
  id: string,
  username: string,
  fullName: string,
  plainPassword: string,
  role: User['role'],
  outletId: string
): User {
  const passwordHash = makePasswordHash(plainPassword);
  return {
    id,
    username,
    fullName,
    passwordHash,
    role,
    outletId,
    isActive: true,
    devVault: sealDevCredential(plainPassword, id, passwordHash),
  };
}

export function createInitialPosState(): PosDatabaseState {
  const now = Date.now();

  const outlets: Outlet[] = [
    {
      id: 'out-1',
      name: 'Outlet Pusat',
      address: 'Jl. Kemang Raya No. 18, Jakarta Selatan',
      phone: '021-7991122',
      isMain: true,
    },
    {
      id: 'out-2',
      name: 'Cabang Dago',
      address: 'Jl. Ir. H. Juanda No. 84, Bandung',
      phone: '022-2504455',
      isMain: false,
    },
  ];

  const users: User[] = [
    createSeedUser(
      'usr-0',
      'pemilik',
      'Hendra Wijaya (Pemilik / Developer)',
      'pemilik123',
      'PEMILIK',
      'out-1'
    ),
    createSeedUser('usr-1', 'admin', 'Rina Admin', 'admin123', 'ADMIN', 'out-1'),
    createSeedUser('usr-2', 'kasir', 'Siti Kasir', 'kasir123', 'KASIR', 'out-1'),
    createSeedUser('usr-3', 'gudang', 'Bambang Gudang', 'gudang123', 'GUDANG', 'out-1'),
    createSeedUser('usr-4', 'karyawan', 'Andi Karyawan', 'karyawan123', 'KARYAWAN', 'out-1'),
  ];

  const products: Product[] = [
    {
      id: 'prd-1',
      name: 'Kopi Susu Gula Aren 250ml',
      sku: 'SKU-KPI-001',
      barcode: '8991001000011',
      category: 'Minuman',
      brand: 'AysRoast',
      costPrice: 10000,
      sellPrice: 22000,
      baseUnit: 'cup',
      units: [
        { unitName: 'cup', multiplier: 1, sellPrice: 22000 },
        { unitName: 'paket 4', multiplier: 4, sellPrice: 82000 },
      ],
      stock: 48,
      minStock: 10,
      outletId: 'out-1',
      isBom: false,
      bomItems: [],
      lastSoldAt: now - 3600000,
      createdAt: now - 86400000 * 7,
    },
    {
      id: 'prd-2',
      name: 'Biji Kopi Arabica Gayo 250g',
      sku: 'SKU-BJI-002',
      barcode: '8991001000028',
      category: 'Biji Kopi',
      brand: 'AysRoast',
      costPrice: 48000,
      sellPrice: 78000,
      baseUnit: 'pack',
      units: [
        { unitName: 'pack', multiplier: 1, sellPrice: 78000 },
        { unitName: 'karton 10', multiplier: 10, sellPrice: 740000 },
      ],
      stock: 24,
      minStock: 6,
      outletId: 'out-1',
      isBom: false,
      bomItems: [],
      lastSoldAt: now - 7200000,
      createdAt: now - 86400000 * 10,
    },
    {
      id: 'prd-3',
      name: 'Croissant Butter',
      sku: 'SKU-PST-003',
      barcode: '8991001000035',
      category: 'Pastry',
      brand: 'BakeHouse',
      costPrice: 12000,
      sellPrice: 24000,
      baseUnit: 'pcs',
      units: [{ unitName: 'pcs', multiplier: 1, sellPrice: 24000 }],
      stock: 18,
      minStock: 8,
      outletId: 'out-1',
      isBom: false,
      bomItems: [],
      lastSoldAt: now - 10800000,
      createdAt: now - 86400000 * 5,
    },
    {
      id: 'prd-4',
      name: 'Air Mineral Botol 600ml',
      sku: 'SKU-MNM-004',
      barcode: '8991001000042',
      category: 'Minuman',
      brand: 'Segar',
      costPrice: 2500,
      sellPrice: 5000,
      baseUnit: 'botol',
      units: [
        { unitName: 'botol', multiplier: 1, sellPrice: 5000 },
        { unitName: 'dus 24', multiplier: 24, sellPrice: 108000 },
      ],
      stock: 96,
      minStock: 24,
      outletId: 'out-1',
      isBom: false,
      bomItems: [],
      lastSoldAt: now - 1800000,
      createdAt: now - 86400000 * 14,
    },
  ];

  const customers: Customer[] = [
    {
      id: 'cust-1',
      name: 'Budi Santoso',
      whatsapp: '6281234567890',
      address: 'Jl. Bangka II No. 12, Jakarta',
      points: 35,
      receivableBalance: 0,
      totalSpent: 485000,
    },
    {
      id: 'cust-2',
      name: 'Dewi Lestari',
      whatsapp: '6281398765432',
      address: 'Jl. Cipete Raya No. 7, Jakarta',
      points: 18,
      receivableBalance: 0,
      totalSpent: 210000,
    },
  ];

  const suppliers: Supplier[] = [
    {
      id: 'sup-1',
      name: 'PT Roastery Nusantara',
      phone: '021-5551234',
      address: 'Kawasan Industri Jababeka, Cikarang',
      notes: 'Supplier utama biji kopi & sirup.',
    },
    {
      id: 'sup-2',
      name: 'CV Bakery Mandiri',
      phone: '021-5556789',
      address: 'Tangerang Selatan',
      notes: 'Pengiriman roti dan pastry setiap pagi.',
    },
  ];

  const loyaltyRewards: LoyaltyReward[] = [
    {
      id: 'rwd-1',
      title: 'Potongan Belanja Rp 10.000',
      description: 'Tukar 10 poin untuk diskon langsung Rp 10.000',
      pointsCost: 10,
      rewardType: 'DISCOUNT',
      discountAmount: 10000,
      isActive: true,
    },
    {
      id: 'rwd-2',
      title: 'Potongan Belanja Rp 25.000',
      description: 'Tukar 25 poin untuk diskon langsung Rp 25.000',
      pointsCost: 25,
      rewardType: 'DISCOUNT',
      discountAmount: 25000,
      isActive: true,
    },
    {
      id: 'rwd-4',
      title: 'Tumbler Stainless AysPOS',
      description: 'Merchandise eksklusif AysPOS gratis untuk member setia',
      pointsCost: 50,
      rewardType: 'GIFT',
      discountAmount: 0,
      isActive: true,
    },
  ];

  const settings: StoreSettings = {
    storeName: 'AysPOS Retail & Coffee',
    storeAddress: 'Jl. Kemang Raya No. 18, Jakarta Selatan',
    storePhone: '021-7991122',
    taxPercent: 11,
    taxEnabled: false,
    taxInclusive: false,
    pointsEnabled: true,
    pointsPerAmount: 10000,
    themeMode: 'LIGHT',
    paperWidth: 'MM_58',
    printerName: 'Thermal Printer Bluetooth',
    printerAddress: '',
    savedPrinters: [],
    printLogo: true,
    receiptFooter: 'Terima kasih telah berbelanja di toko kami!',
    scannerHidEnabled: true,
    qrisEnabled: true,
    transferEnabled: true,
    piutangEnabled: true,
    ecommerceShopeeSync: false,
    ecommerceTokopediaSync: false,
    enabledMenus: createDefaultEnabledMenus(true),
    roleMenuAccess: {},
    userMenuAccessByUserId: {},
    karyawanAccessByUserId: {},
  };

  return {
    outlets,
    users,
    products,
    customers,
    suppliers,
    shifts: [],
    pettyCash: [],
    transactions: [],
    purchaseOrders: [],
    stockMovements: [],
    stockTransfers: [],
    loyaltyRewards,
    pointHistory: [],
    settings,
    attendanceConfig: createDefaultAttendanceConfig(false, true),
    attendanceRecords: [],
  };
}

export function createBlankPosState(
  currentOwner?: User,
  resetPemilikCredentials = false
): PosDatabaseState {
  const defaultOutlet: Outlet = {
    id: 'out-1',
    name: 'Outlet Pusat',
    address: '-',
    phone: '-',
    isMain: true,
  };

  const ownerUser: User =
    !resetPemilikCredentials && currentOwner && currentOwner.role === 'PEMILIK'
      ? {
          ...currentOwner,
          outletId: defaultOutlet.id,
          isActive: true,
        }
      : createSeedUser(
          'usr-0',
          'pemilik',
          'Pemilik Toko',
          'pemilik123',
          'PEMILIK',
          defaultOutlet.id
        );

  return {
    outlets: [defaultOutlet],
    users: [ownerUser],
    products: [],
    customers: [],
    suppliers: [],
    shifts: [],
    pettyCash: [],
    transactions: [],
    purchaseOrders: [],
    stockMovements: [],
    stockTransfers: [],
    loyaltyRewards: [],
    pointHistory: [],
    settings: {
      storeName: 'Toko Baru',
      storeAddress: '-',
      storePhone: '-',
      taxPercent: 11,
      taxEnabled: false,
      taxInclusive: false,
      pointsEnabled: true,
      pointsPerAmount: 10000,
      themeMode: 'LIGHT',
      paperWidth: 'MM_58',
      printerName: 'Thermal Printer',
      printerAddress: '',
      savedPrinters: [],
      printLogo: true,
      receiptFooter: 'Terima kasih sudah berbelanja',
      scannerHidEnabled: true,
      qrisEnabled: true,
      transferEnabled: true,
      piutangEnabled: true,
      ecommerceShopeeSync: false,
      ecommerceTokopediaSync: false,
      enabledMenus: createDefaultEnabledMenus(true),
      roleMenuAccess: {},
      userMenuAccessByUserId: {},
      karyawanAccessByUserId: {},
    },
    attendanceConfig: createDefaultAttendanceConfig(false, true),
    attendanceRecords: [],
  };
}
