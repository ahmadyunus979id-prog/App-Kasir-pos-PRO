import type {
  AppMenuId,
  AttendanceConfig,
  ConfigurableRole,
  KaryawanMenuAccess,
  StoreSettings,
  User,
  UserRole,
} from '../types/pos';

export interface ToggleableMenuDescriptor {
  id: AppMenuId;
  label: string;
  shortLabel: string;
  description: string;
}

export const ALL_TOGGLEABLE_MENUS: ToggleableMenuDescriptor[] = [
  {
    id: 'DASHBOARD',
    label: 'Dashboard & Laporan',
    shortLabel: 'Dashboard',
    description: 'Ringkasan omzet, laba bersih, dan laporan grafik toko.',
  },
  {
    id: 'POS',
    label: 'Kasir (POS)',
    shortLabel: 'Kasir',
    description: 'Penjualan kasir, kelola shift, cetak struk, dan daftar piutang.',
  },
  {
    id: 'ATTENDANCE',
    label: 'Absensi Karyawan',
    shortLabel: 'Absensi',
    description: 'Absen selfie kamera langsung, lokasi GPS, dan rekap kehadiran.',
  },
  {
    id: 'MASTER',
    label: 'Master Data / Pelanggan',
    shortLabel: 'Master Data',
    description: 'Daftar produk, pelanggan, poin loyalitas, supplier, dan pengguna.',
  },
  {
    id: 'INVENTORY',
    label: 'Stok & Inventory',
    shortLabel: 'Gudang / Stok',
    description: 'Purchase order, stok opname, mutasi, dan transfer cabang.',
  },
  {
    id: 'DEVELOPER',
    label: 'Developer & Akun',
    shortLabel: 'Developer & Akun',
    description: 'Cek & ubah semua user dan sandi, akses akun staf, serta kontrol sistem.',
  },
  {
    id: 'SETTINGS',
    label: 'Pengaturan',
    shortLabel: 'Pengaturan',
    description: 'Profil toko, printer thermal, tampilan tema, dan ganti sandi.',
  },
];

export const KARYAWAN_GRANTABLE_MENUS: ToggleableMenuDescriptor[] = ALL_TOGGLEABLE_MENUS;

export const CONFIGURABLE_ROLES: {
  id: ConfigurableRole;
  label: string;
  description: string;
}[] = [
  {
    id: 'ADMIN',
    label: 'Admin',
    description: 'Pengelola operasional toko (standar: semua modul utama kecuali Developer).',
  },
  {
    id: 'KASIR',
    label: 'Kasir',
    description: 'Petugas penjualan kasir (standar: Kasir, Absensi, Pelanggan, Pengaturan).',
  },
  {
    id: 'GUDANG',
    label: 'Staf Gudang',
    description: 'Pengelola stok & PO (standar: Gudang, Absensi, Master, Pengaturan).',
  },
  {
    id: 'KARYAWAN',
    label: 'Karyawan',
    description: 'Staf umum (standar: hanya Absensi, bisa ditambah Kasir/Gudang/dll).',
  },
];

export function createDefaultEnabledMenus(
  attendanceEnabled = true
): Record<AppMenuId, boolean> {
  return {
    DASHBOARD: true,
    POS: true,
    ATTENDANCE: attendanceEnabled,
    MASTER: true,
    INVENTORY: true,
    DEVELOPER: true,
    SETTINGS: true,
  };
}

export function createAllMenusAccess(enabled = true): Required<KaryawanMenuAccess> {
  return {
    DASHBOARD: enabled,
    POS: enabled,
    ATTENDANCE: enabled,
    MASTER: enabled,
    INVENTORY: enabled,
    DEVELOPER: enabled,
    SETTINGS: enabled,
  };
}

export function createDefaultKaryawanAccess(): Required<KaryawanMenuAccess> {
  return {
    ATTENDANCE: true,
    POS: false,
    INVENTORY: false,
    MASTER: false,
    DASHBOARD: false,
    DEVELOPER: false,
    SETTINGS: false,
  };
}

const DEFAULT_ROLE_MENUS: Record<UserRole, AppMenuId[]> = {
  PEMILIK: ['DASHBOARD', 'POS', 'ATTENDANCE', 'MASTER', 'INVENTORY', 'DEVELOPER', 'SETTINGS'],
  ADMIN: ['DASHBOARD', 'POS', 'ATTENDANCE', 'MASTER', 'INVENTORY', 'SETTINGS'],
  KASIR: ['POS', 'ATTENDANCE', 'MASTER', 'SETTINGS'],
  GUDANG: ['ATTENDANCE', 'MASTER', 'INVENTORY', 'SETTINGS'],
  KARYAWAN: ['ATTENDANCE'],
};

export function getDefaultMenusForRole(role: UserRole): Required<KaryawanMenuAccess> {
  const list = DEFAULT_ROLE_MENUS[role] || [];
  return {
    DASHBOARD: list.includes('DASHBOARD'),
    POS: list.includes('POS'),
    ATTENDANCE: list.includes('ATTENDANCE'),
    MASTER: list.includes('MASTER'),
    INVENTORY: list.includes('INVENTORY'),
    DEVELOPER: list.includes('DEVELOPER'),
    SETTINGS: list.includes('SETTINGS'),
  };
}

export function getEffectiveRoleMenuAccess(
  role: ConfigurableRole,
  settings: Pick<StoreSettings, 'roleMenuAccess'>
): Required<KaryawanMenuAccess> {
  const defaults = getDefaultMenusForRole(role);
  const saved = settings.roleMenuAccess?.[role];
  if (!saved) return defaults;
  return {
    DASHBOARD: typeof saved.DASHBOARD === 'boolean' ? saved.DASHBOARD : defaults.DASHBOARD,
    POS: typeof saved.POS === 'boolean' ? saved.POS : defaults.POS,
    ATTENDANCE: typeof saved.ATTENDANCE === 'boolean' ? saved.ATTENDANCE : defaults.ATTENDANCE,
    MASTER: typeof saved.MASTER === 'boolean' ? saved.MASTER : defaults.MASTER,
    INVENTORY: typeof saved.INVENTORY === 'boolean' ? saved.INVENTORY : defaults.INVENTORY,
    DEVELOPER: typeof saved.DEVELOPER === 'boolean' ? saved.DEVELOPER : defaults.DEVELOPER,
    SETTINGS: typeof saved.SETTINGS === 'boolean' ? saved.SETTINGS : defaults.SETTINGS,
  };
}

export function hasCustomUserMenuOverride(
  userId: string,
  settings: Pick<StoreSettings, 'userMenuAccessByUserId' | 'karyawanAccessByUserId'>
): boolean {
  const mapA = settings.userMenuAccessByUserId?.[userId];
  const mapB = settings.karyawanAccessByUserId?.[userId];
  return Boolean(
    (mapA && Object.keys(mapA).length > 0) || (mapB && Object.keys(mapB).length > 0)
  );
}

export function getEffectiveUserMenuAccess(
  user: Pick<User, 'id' | 'role'>,
  settings: Pick<
    StoreSettings,
    'roleMenuAccess' | 'userMenuAccessByUserId' | 'karyawanAccessByUserId'
  >
): Required<KaryawanMenuAccess> {
  if (user.role === 'PEMILIK') {
    return getDefaultMenusForRole('PEMILIK');
  }
  const roleDefaults = getEffectiveRoleMenuAccess(user.role, settings);
  const override =
    settings.userMenuAccessByUserId?.[user.id] || settings.karyawanAccessByUserId?.[user.id];
  if (!override) return roleDefaults;
  return {
    DASHBOARD:
      typeof override.DASHBOARD === 'boolean' ? override.DASHBOARD : roleDefaults.DASHBOARD,
    POS: typeof override.POS === 'boolean' ? override.POS : roleDefaults.POS,
    ATTENDANCE:
      typeof override.ATTENDANCE === 'boolean' ? override.ATTENDANCE : roleDefaults.ATTENDANCE,
    MASTER: typeof override.MASTER === 'boolean' ? override.MASTER : roleDefaults.MASTER,
    INVENTORY:
      typeof override.INVENTORY === 'boolean' ? override.INVENTORY : roleDefaults.INVENTORY,
    DEVELOPER:
      typeof override.DEVELOPER === 'boolean' ? override.DEVELOPER : roleDefaults.DEVELOPER,
    SETTINGS:
      typeof override.SETTINGS === 'boolean' ? override.SETTINGS : roleDefaults.SETTINGS,
  };
}

export function isMenuGloballyEnabled(
  menuId: AppMenuId,
  settings: Pick<StoreSettings, 'enabledMenus'>,
  attendanceConfig?: Pick<AttendanceConfig, 'enabled'>
): boolean {
  if (menuId === 'ATTENDANCE' && attendanceConfig?.enabled === false) {
    return false;
  }
  if (settings.enabledMenus && typeof settings.enabledMenus[menuId] === 'boolean') {
    return settings.enabledMenus[menuId];
  }
  return true;
}

export function getEffectiveKaryawanAccess(
  userId: string,
  settings: Pick<
    StoreSettings,
    'roleMenuAccess' | 'userMenuAccessByUserId' | 'karyawanAccessByUserId'
  >
): Required<KaryawanMenuAccess> {
  return getEffectiveUserMenuAccess({ id: userId, role: 'KARYAWAN' }, settings);
}

export function canUserAccessMenu(
  user: Pick<User, 'id' | 'role'> | null | undefined,
  menuId: AppMenuId,
  settings: Pick<
    StoreSettings,
    'enabledMenus' | 'roleMenuAccess' | 'userMenuAccessByUserId' | 'karyawanAccessByUserId'
  >,
  attendanceConfig?: Pick<AttendanceConfig, 'enabled'>
): boolean {
  if (!user) return false;
  // Pemilik always has full access and controls enable/disable for every menu & role
  if (user.role === 'PEMILIK') return true;

  if (!isMenuGloballyEnabled(menuId, settings, attendanceConfig)) {
    return false;
  }

  const effective = getEffectiveUserMenuAccess(user, settings);
  return Boolean(effective[menuId]);
}
