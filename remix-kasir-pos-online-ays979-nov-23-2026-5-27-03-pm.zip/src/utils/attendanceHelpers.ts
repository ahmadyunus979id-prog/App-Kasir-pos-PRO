import type {
  AttendanceConfig,
  AttendanceLocationSnapshot,
  AttendanceRecord,
  AttendanceStatus,
  User,
  UserRole,
} from '../types/pos';

export const ATTENDANCE_STATUS_LABELS: Record<AttendanceStatus, string> = {
  TEPAT_WAKTU: 'Tepat Waktu',
  TERLAMBAT: 'Terlambat',
  PULANG_AWAL: 'Pulang Awal',
  IZIN: 'Izin',
  SAKIT: 'Sakit',
  CUTI: 'Cuti',
};

export interface EffectiveAttendancePermissions {
  isOwner: boolean;
  canViewAll: boolean;
  canViewLocation: boolean;
  canManage: boolean;
}

export function getLocalDateKey(timestamp: number): string {
  const d = new Date(timestamp);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export function getLocalMonthKey(timestamp: number): string {
  return getLocalDateKey(timestamp).slice(0, 7);
}

export function parseTimeToMinutes(hhmm: string, fallbackMinutes: number): number {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '').trim());
  if (!match) return fallbackMinutes;
  const h = Number(match[1]);
  const m = Number(match[2]);
  if (!Number.isFinite(h) || !Number.isFinite(m) || h < 0 || h > 23 || m < 0 || m > 59) {
    return fallbackMinutes;
  }
  return h * 60 + m;
}

export function calculateDistanceMeters(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371000;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export function hasCustomRoleAttendanceConfig(
  config: AttendanceConfig,
  role: UserRole
): boolean {
  const saved = config.roleConfigs?.[role];
  return Boolean(saved && Object.keys(saved).length > 0);
}

export function getEffectiveAttendanceConfigForRole(
  config: AttendanceConfig,
  userRole?: UserRole
): AttendanceConfig {
  if (!userRole) return config;
  const roleOverride = config.roleConfigs?.[userRole];
  if (!roleOverride) return config;
  return {
    ...config,
    workStartTime: roleOverride.workStartTime ?? config.workStartTime,
    workEndTime: roleOverride.workEndTime ?? config.workEndTime,
    lateToleranceMinutes:
      typeof roleOverride.lateToleranceMinutes === 'number'
        ? roleOverride.lateToleranceMinutes
        : config.lateToleranceMinutes,
    geofenceRadiusMeters:
      typeof roleOverride.geofenceRadiusMeters === 'number'
        ? roleOverride.geofenceRadiusMeters
        : config.geofenceRadiusMeters,
    outletLatitude:
      typeof roleOverride.outletLatitude === 'number' && Number.isFinite(roleOverride.outletLatitude)
        ? roleOverride.outletLatitude
        : config.outletLatitude,
    outletLongitude:
      typeof roleOverride.outletLongitude === 'number' && Number.isFinite(roleOverride.outletLongitude)
        ? roleOverride.outletLongitude
        : config.outletLongitude,
    requireGps:
      typeof roleOverride.requireGps === 'boolean' ? roleOverride.requireGps : config.requireGps,
  };
}

export function evaluateClockInStatus(
  clockInAt: number,
  config: AttendanceConfig,
  userRole?: UserRole
): { status: 'TEPAT_WAKTU' | 'TERLAMBAT'; lateMinutes: number } {
  const effective = getEffectiveAttendanceConfigForRole(config, userRole);
  const d = new Date(clockInAt);
  const currentMinutes = d.getHours() * 60 + d.getMinutes();
  const startMinutes = parseTimeToMinutes(effective.workStartTime, 8 * 60);
  const tolerance = Math.max(0, Math.round(effective.lateToleranceMinutes || 0));
  const diff = currentMinutes - startMinutes;
  if (diff > tolerance) {
    return { status: 'TERLAMBAT', lateMinutes: diff };
  }
  return { status: 'TEPAT_WAKTU', lateMinutes: 0 };
}

export function evaluateClockOutMetrics(
  clockInAt: number,
  clockOutAt: number,
  config: AttendanceConfig,
  userRole?: UserRole
): { workDurationMinutes: number; earlyLeaveMinutes: number; overtimeMinutes: number } {
  const effective = getEffectiveAttendanceConfigForRole(config, userRole);
  const workDurationMinutes = Math.max(0, Math.round((clockOutAt - clockInAt) / 60000));
  const outDate = new Date(clockOutAt);
  const outMinutes = outDate.getHours() * 60 + outDate.getMinutes();
  const endMinutes = parseTimeToMinutes(effective.workEndTime, 17 * 60);

  const earlyLeaveMinutes = outMinutes < endMinutes ? endMinutes - outMinutes : 0;
  const overtimeRaw = outMinutes - endMinutes;
  const overtimeMinutes = overtimeRaw >= 30 ? overtimeRaw : 0;

  return { workDurationMinutes, earlyLeaveMinutes, overtimeMinutes };
}

export function formatDurationMinutes(minutes: number): string {
  const clean = Math.max(0, Math.round(minutes || 0));
  const h = Math.floor(clean / 60);
  const m = clean % 60;
  if (h === 0) return `${m} mnt`;
  if (m === 0) return `${h} jam`;
  return `${h}j ${m}m`;
}

export function canAccessAttendanceMenu(
  user: User | null | undefined,
  config: AttendanceConfig
): boolean {
  if (!user) return false;
  if (user.role === 'PEMILIK') return true;
  return config.enabled !== false;
}

export function getAttendancePermissions(
  user: User | null | undefined,
  config: AttendanceConfig
): EffectiveAttendancePermissions {
  if (!user) {
    return {
      isOwner: false,
      canViewAll: false,
      canViewLocation: false,
      canManage: false,
    };
  }
  if (user.role === 'PEMILIK') {
    return {
      isOwner: true,
      canViewAll: true,
      canViewLocation: true,
      canManage: true,
    };
  }
  if (config.enabled === false) {
    return {
      isOwner: false,
      canViewAll: false,
      canViewLocation: false,
      canManage: false,
    };
  }
  const perm = config.adminAccessByUserId?.[user.id];
  if (perm) {
    const canViewLocation = Boolean(perm.viewLocation);
    const canManage = Boolean(perm.manageAttendance);
    const canViewAll = Boolean(perm.viewAttendance) || canViewLocation || canManage;
    return {
      isOwner: false,
      canViewAll,
      canViewLocation,
      canManage,
    };
  }
  return {
    isOwner: false,
    canViewAll: false,
    canViewLocation: false,
    canManage: false,
  };
}

export function buildGoogleMapsLink(lat: number, lng: number): string {
  return `https://www.google.com/maps?q=${lat.toFixed(6)},${lng.toFixed(6)}`;
}

export function enrichLocationWithGeofence(
  raw: {
    latitude: number;
    longitude: number;
    accuracyMeters?: number;
    addressLabel?: string;
    capturedAt?: number;
  },
  config: AttendanceConfig,
  userRole?: UserRole
): AttendanceLocationSnapshot {
  const effective = getEffectiveAttendanceConfigForRole(config, userRole);
  let distanceMeters: number | undefined;
  let withinGeofence: boolean | undefined;

  if (
    typeof effective.outletLatitude === 'number' &&
    Number.isFinite(effective.outletLatitude) &&
    typeof effective.outletLongitude === 'number' &&
    Number.isFinite(effective.outletLongitude)
  ) {
    distanceMeters = calculateDistanceMeters(
      raw.latitude,
      raw.longitude,
      effective.outletLatitude,
      effective.outletLongitude
    );
    withinGeofence = distanceMeters <= Math.max(10, effective.geofenceRadiusMeters || 150);
  }

  return {
    latitude: raw.latitude,
    longitude: raw.longitude,
    accuracyMeters: raw.accuracyMeters,
    distanceMeters,
    withinGeofence,
    addressLabel:
      raw.addressLabel || `${raw.latitude.toFixed(5)}, ${raw.longitude.toFixed(5)}`,
    capturedAt: raw.capturedAt ?? Date.now(),
  };
}

async function tryReverseGeocode(lat: number, lng: number): Promise<string | undefined> {
  try {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 3000);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(
        lat
      )}&lon=${encodeURIComponent(lng)}&zoom=16&addressdetails=1`,
      {
        signal: controller.signal,
        headers: { Accept: 'application/json' },
      }
    );
    window.clearTimeout(timer);
    if (!res.ok) return undefined;
    const json = (await res.json()) as {
      display_name?: string;
      address?: {
        road?: string;
        suburb?: string;
        village?: string;
        city?: string;
        town?: string;
        municipality?: string;
      };
    };
    const addr = json.address;
    if (addr) {
      const parts = [
        addr.road,
        addr.suburb || addr.village,
        addr.city || addr.town || addr.municipality,
      ].filter(Boolean);
      if (parts.length > 0) return parts.join(', ');
    }
    if (typeof json.display_name === 'string' && json.display_name.trim()) {
      return json.display_name.split(',').slice(0, 3).join(',').trim();
    }
  } catch {
    // ignore offline / blocked reverse geocoding
  }
  return undefined;
}

export async function captureCurrentDeviceLocation(
  config: AttendanceConfig,
  userRole?: UserRole
): Promise<{ ok: true; location: AttendanceLocationSnapshot } | { ok: false; error: string }> {
  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    return {
      ok: false,
      error: 'Perangkat atau browser ini tidak mendukung GPS / Geolocation.',
    };
  }

  try {
    const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0,
      });
    });

    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    const accuracyMeters = Number.isFinite(pos.coords.accuracy)
      ? Math.round(pos.coords.accuracy)
      : undefined;
    const addressLabel = await tryReverseGeocode(lat, lng);

    return {
      ok: true,
      location: enrichLocationWithGeofence(
        {
          latitude: lat,
          longitude: lng,
          accuracyMeters,
          addressLabel,
          capturedAt: Date.now(),
        },
        config,
        userRole
      ),
    };
  } catch (err) {
    const geoErr = err as GeolocationPositionError | undefined;
    if (geoErr?.code === 1) {
      return {
        ok: false,
        error:
          'Izin akses lokasi GPS ditolak. Aktifkan izin Lokasi pada browser/HP lalu coba lagi.',
      };
    }
    if (geoErr?.code === 2) {
      return {
        ok: false,
        error: 'Sinyal GPS tidak tersedia. Pastikan GPS perangkat dalam keadaan aktif.',
      };
    }
    if (geoErr?.code === 3) {
      return {
        ok: false,
        error: 'Pengambilan koordinat GPS timeout. Coba di area terbuka atau ulangi.',
      };
    }
    return {
      ok: false,
      error: 'Gagal membaca lokasi GPS perangkat.',
    };
  }
}

export function buildAttendanceCsv(
  records: AttendanceRecord[],
  includeLocation: boolean
): string {
  const headers = [
    'Tanggal',
    'Nama Karyawan',
    'Peran',
    'Outlet',
    'Status',
    'Jam Masuk',
    'Jam Pulang',
    'Durasi Kerja (Menit)',
    'Terlambat (Menit)',
    'Pulang Awal (Menit)',
    'Lembur (Menit)',
    ...(includeLocation
      ? ['Koordinat Masuk', 'Jarak Masuk (m)', 'Alamat Masuk', 'Koordinat Pulang']
      : []),
    'Catatan',
    'Diverifikasi Oleh',
  ];

  const escapeCsv = (val: unknown) => {
    const s = String(val ?? '').replace(/"/g, '""');
    return `"${s}"`;
  };

  const fmtClock = (ts?: number) =>
    ts
      ? new Date(ts).toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      : '-';

  const rows = records.map((r) => [
    r.dateKey,
    r.userName,
    r.userRole,
    r.outletName,
    ATTENDANCE_STATUS_LABELS[r.status] || r.status,
    fmtClock(r.clockInAt),
    fmtClock(r.clockOutAt),
    r.workDurationMinutes,
    r.lateMinutes,
    r.earlyLeaveMinutes,
    r.overtimeMinutes,
    ...(includeLocation
      ? [
          r.clockInLocation
            ? `${r.clockInLocation.latitude.toFixed(6)}, ${r.clockInLocation.longitude.toFixed(6)}`
            : '-',
          r.clockInLocation?.distanceMeters ?? '-',
          r.clockInLocation?.addressLabel || '-',
          r.clockOutLocation
            ? `${r.clockOutLocation.latitude.toFixed(6)}, ${r.clockOutLocation.longitude.toFixed(6)}`
            : '-',
        ]
      : []),
    r.notes || '',
    r.verifiedBy || '-',
  ]);

  return [headers.map(escapeCsv).join(','), ...rows.map((row) => row.map(escapeCsv).join(','))].join(
    '\n'
  );
}
