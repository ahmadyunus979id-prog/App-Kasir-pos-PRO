export function formatRupiah(amount: number): string {
  const formatted = new Intl.NumberFormat('id-ID').format(Math.round(amount));
  return `Rp ${formatted}`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('id-ID', {
    maximumFractionDigits: 2,
  }).format(value);
}

export function formatDateTime(millis: number): string {
  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(millis));
}

export function simpleHash(input: string): string {
  let h1 = 0xdeadbeef ^ input.length;
  let h2 = 0x41c6ce57 ^ input.length;
  for (let i = 0; i < input.length; i++) {
    const ch = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

export function makePasswordHash(password: string, salt?: string): string {
  const s = salt || Math.random().toString(36).slice(2, 10);
  return `${s}:${simpleHash(`${s}:${password}`)}`;
}

export function verifyPasswordHash(password: string, stored: string): boolean {
  const [salt] = stored.split(':');
  if (!salt) return false;
  return makePasswordHash(password, salt) === stored;
}

export const DEMO_DEFAULT_PASSWORDS: readonly string[] = [
  'pemilik123',
  'admin123',
  'kasir123',
  'gudang123',
  'karyawan123',
];

export function detectKnownDemoPassword(
  passwordHash: string,
  candidates: readonly string[] = DEMO_DEFAULT_PASSWORDS
): string | null {
  for (const cand of candidates) {
    if (verifyPasswordHash(cand, passwordHash)) {
      return cand;
    }
  }
  return null;
}

export function checkUserPassword(
  candidate: string,
  passwordHash: string
): { matched: boolean; matchedDefault: string | null } {
  const matchedDefault = detectKnownDemoPassword(passwordHash);
  const matched = candidate.length > 0 && verifyPasswordHash(candidate, passwordHash);
  return { matched, matchedDefault };
}

export function generateTempPassword(length = 8): string {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const targetLen = Math.max(6, Math.min(24, length));
  let out = '';
  if (typeof globalThis.crypto !== 'undefined' && typeof globalThis.crypto.getRandomValues === 'function') {
    const arr = new Uint32Array(targetLen);
    globalThis.crypto.getRandomValues(arr);
    for (let i = 0; i < targetLen; i++) {
      out += chars[arr[i] % chars.length];
    }
    return out;
  }
  for (let i = 0; i < targetLen; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

const VAULT_PREFIX = 'npv1:';

function deriveVaultMask(userId: string, hashSalt: string): Uint8Array {
  const seed = simpleHash(`nusa:${userId}:${hashSalt}:dev`);
  const encoder = new TextEncoder();
  return encoder.encode(seed.padEnd(16, '7'));
}

function toBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin);
}

function fromBase64(b64: string): Uint8Array {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return bytes;
}

export function sealDevCredential(password: string, userId: string, passwordHash: string): string {
  const [hashSalt = '0'] = passwordHash.split(':');
  const mask = deriveVaultMask(userId, hashSalt);
  const plainBytes = new TextEncoder().encode(password);
  const cipher = new Uint8Array(plainBytes.length);
  for (let i = 0; i < plainBytes.length; i++) {
    cipher[i] = plainBytes[i] ^ mask[i % mask.length];
  }
  return `${VAULT_PREFIX}${toBase64(cipher)}`;
}

export function revealDevCredential(user: {
  id: string;
  passwordHash: string;
  devVault?: string;
}): string | null {
  if (user.devVault && user.devVault.startsWith(VAULT_PREFIX)) {
    try {
      const [hashSalt = '0'] = user.passwordHash.split(':');
      const mask = deriveVaultMask(user.id, hashSalt);
      const cipher = fromBase64(user.devVault.slice(VAULT_PREFIX.length));
      const plainBytes = new Uint8Array(cipher.length);
      for (let i = 0; i < cipher.length; i++) {
        plainBytes[i] = cipher[i] ^ mask[i % mask.length];
      }
      const decoded = new TextDecoder().decode(plainBytes);
      if (verifyPasswordHash(decoded, user.passwordHash)) {
        return decoded;
      }
    } catch {
      // fall through to known demo password check
    }
  }
  return detectKnownDemoPassword(user.passwordHash);
}
