import test from 'node:test';
import assert from 'node:assert/strict';
import {
  checkUserPassword,
  detectKnownDemoPassword,
  formatNumber,
  formatRupiah,
  generateTempPassword,
  makePasswordHash,
  revealDevCredential,
  sealDevCredential,
  verifyPasswordHash,
} from './formatters';
import {
  buildEscPosBytes,
  buildFallbackTokenReceiptUrl,
  buildOnlineReceiptUrl,
  buildPublicReceiptPayload,
  buildReceiptPreviewLines,
  buildThermalPrintHtml,
  buildWhatsAppReceiptText,
  decodeOnlineReceiptData,
  encodeOnlineReceiptData,
  getPaperCharWidth,
  getTransactionDebtInfo,
  parseReceiptRouteFromLocation,
  slugifyStoreName,
  upsertSavedPrinter,
} from './receiptExport';
import { createBlankPosState } from '../data/seedData';
import {
  buildAttendanceCsv,
  calculateDistanceMeters,
  canAccessAttendanceMenu,
  enrichLocationWithGeofence,
  evaluateClockInStatus,
  evaluateClockOutMetrics,
  getAttendancePermissions,
  getEffectiveAttendanceConfigForRole,
  hasCustomRoleAttendanceConfig,
} from './attendanceHelpers';
import {
  ALL_TOGGLEABLE_MENUS,
  canUserAccessMenu,
  createDefaultEnabledMenus,
  getEffectiveKaryawanAccess,
  getEffectiveRoleMenuAccess,
  getEffectiveUserMenuAccess,
  hasCustomUserMenuOverride,
} from './menuPermissions';
import type {
  AttendanceConfig,
  AttendanceRecord,
  SavedPrinter,
  StoreSettings,
  Transaction,
  User,
} from '../types/pos';

const sampleSettings: StoreSettings = {
  storeName: 'AysPOS Roastery',
  storeAddress: 'Jl. Senopati No. 45, Jakarta Selatan',
  storePhone: '021-5558899',
  taxPercent: 11,
  taxEnabled: true,
  taxInclusive: false,
  pointsEnabled: true,
  pointsPerAmount: 10000,
  themeMode: 'LIGHT',
  paperWidth: 'MM_58',
  printerName: 'Epson TM-T82',
  printerAddress: '00:11:22:33:44:55',
  printLogo: true,
  receiptFooter: 'Terima kasih sudah berbelanja',
  scannerHidEnabled: true,
  qrisEnabled: true,
  transferEnabled: true,
  piutangEnabled: true,
  ecommerceShopeeSync: true,
  ecommerceTokopediaSync: false,
};

const sampleTx: Transaction = {
  id: 'tx-1',
  invoiceNumber: 'INV-20261122-0001',
  shiftId: 'shf-1',
  outletId: 'out-1',
  outletName: 'Outlet Pusat',
  cashierId: 'usr-2',
  cashierName: 'Siti Kasir',
  customerId: 'cust-1',
  customerName: 'Budi Santoso',
  customerWhatsapp: '628123456789',
  subtotal: 50000,
  discountAmount: 5000,
  taxPercent: 11,
  taxAmount: 4950,
  totalAmount: 49950,
  totalCost: 25000,
  paymentMethod: 'TUNAI',
  paidAmount: 50000,
  changeAmount: 50,
  status: 'COMPLETED',
  items: [
    {
      productId: 'prd-1',
      productName: 'Kopi Susu Gula Aren',
      sku: 'KPI-001',
      unitName: 'cup',
      unitMultiplier: 1,
      quantity: 2,
      unitPrice: 25000,
      costPrice: 12000,
      discountAmount: 0,
      subtotal: 50000,
      returnedQty: 0,
    },
  ],
  createdAt: Date.UTC(2026, 10, 22, 10, 0, 0),
};

test('formatRupiah and formatNumber format Indonesian locale numbers', () => {
  assert.equal(formatRupiah(25000), 'Rp 25.000');
  assert.equal(formatRupiah(0), 'Rp 0');
  assert.equal(formatNumber(1250), '1.250');
});

test('password hashing verifies valid and rejects invalid passwords', () => {
  const hash = makePasswordHash('admin123');
  assert.equal(verifyPasswordHash('admin123', hash), true);
  assert.equal(verifyPasswordHash('wrongpass', hash), false);
  assert.equal(verifyPasswordHash('admin123', 'malformed'), false);
});

test('receipt preview supports 58mm (32 chars) and 80mm (48 chars)', () => {
  assert.equal(getPaperCharWidth('MM_58'), 32);
  assert.equal(getPaperCharWidth('MM_80'), 48);

  const lines58 = buildReceiptPreviewLines(sampleTx, { ...sampleSettings, paperWidth: 'MM_58' });
  assert.ok(lines58.some((l) => l.includes('INV-20261122-0001')));
  assert.ok(lines58.some((l) => l.includes('Thermal 58mm')));
  assert.ok(lines58.every((l) => l.length <= 32));

  const lines80 = buildReceiptPreviewLines(sampleTx, { ...sampleSettings, paperWidth: 'MM_80' });
  assert.ok(lines80.some((l) => l.includes('Thermal 80mm')));
  assert.ok(lines80.every((l) => l.length <= 48));
});

test('ESC/POS byte generator includes init and partial cut commands', () => {
  const bytes = buildEscPosBytes(['AYSPOS', 'TOTAL Rp 50.000']);
  assert.equal(bytes[0], 0x1b);
  assert.equal(bytes[1], 0x40);
  const tail = Array.from(bytes.slice(-4));
  assert.deepEqual(tail, [0x1d, 0x56, 0x42, 0x00]);
});

test('buildThermalPrintHtml produces isolated 58mm and 80mm thermal pages', () => {
  const html58 = buildThermalPrintHtml(['AYSPOS <Test>', 'TOTAL Rp 50.000'], {
    ...sampleSettings,
    paperWidth: 'MM_58',
  });
  assert.ok(html58.includes('size: 58mm auto'));
  assert.ok(html58.includes('AYSPOS &lt;Test&gt;'));

  const html80 = buildThermalPrintHtml(['AYSPOS', 'TOTAL Rp 50.000'], {
    ...sampleSettings,
    paperWidth: 'MM_80',
  });
  assert.ok(html80.includes('size: 80mm auto'));
});

test('upsertSavedPrinter inserts new printers and updates duplicates cleanly', () => {
  const p1: SavedPrinter = {
    id: 'ble-1',
    name: 'RPP02N',
    address: 'AA:BB:CC:11:22:33',
    connectionType: 'BLE',
    paperWidth: 'MM_58',
    lastConnectedAt: 1000,
  };
  const first = upsertSavedPrinter(undefined, p1);
  assert.equal(first.length, 1);

  const updated = upsertSavedPrinter(first, {
    ...p1,
    name: 'RPP02N Kasir 1',
    lastConnectedAt: 2000,
  });
  assert.equal(updated.length, 1);
  assert.equal(updated[0].name, 'RPP02N Kasir 1');
});

test('developer password helpers detect demo passwords, check candidate match, and generate random passwords', () => {
  const kasirDemoHash = makePasswordHash('kasir123');
  assert.equal(detectKnownDemoPassword(kasirDemoHash), 'kasir123');
  assert.deepEqual(checkUserPassword('kasir123', kasirDemoHash), {
    matched: true,
    matchedDefault: 'kasir123',
  });
  assert.deepEqual(checkUserPassword('salah', kasirDemoHash), {
    matched: false,
    matchedDefault: 'kasir123',
  });

  const customHash = makePasswordHash('rahasiaKuat99');
  assert.equal(detectKnownDemoPassword(customHash), null);
  assert.deepEqual(checkUserPassword('rahasiaKuat99', customHash), {
    matched: true,
    matchedDefault: null,
  });

  const generated = generateTempPassword(10);
  assert.equal(generated.length, 10);
  assert.match(generated, /^[A-Za-z0-9]+$/);
});

test('sealDevCredential and revealDevCredential seal custom passwords and verify against passwordHash', () => {
  const customPass = 'SandiBaru#2026';
  const hash = makePasswordHash(customPass);
  const vault = sealDevCredential(customPass, 'usr-99', hash);
  assert.ok(vault.startsWith('npv1:'));
  assert.ok(!vault.includes(customPass));

  const revealed = revealDevCredential({ id: 'usr-99', passwordHash: hash, devVault: vault });
  assert.equal(revealed, customPass);

  // If passwordHash was changed without updating devVault, revealDevCredential rejects stale vault
  const changedHash = makePasswordHash('LainLagi99');
  assert.equal(
    revealDevCredential({ id: 'usr-99', passwordHash: changedHash, devVault: vault }),
    null
  );
});

test('encodeOnlineReceiptData and decodeOnlineReceiptData round-trip public fields safely and scrub internal cost', () => {
  const unicodeTx: Transaction = {
    ...sampleTx,
    customerName: 'Ibu Susi — Café',
    items: [
      {
        ...sampleTx.items[0],
        productName: 'Kopi Tubruk® Spesial Café',
        costPrice: 12000,
      },
    ],
  };

  const token = encodeOnlineReceiptData(unicodeTx, sampleSettings);
  assert.ok(token.startsWith('np2'));
  assert.match(token, /^[0-9A-Za-z]+$/);

  const decoded = decodeOnlineReceiptData(token);
  assert.ok(decoded !== null);
  assert.equal(decoded.tx.invoiceNumber, unicodeTx.invoiceNumber);
  assert.equal(decoded.tx.customerName, 'Ibu Susi — Café');
  assert.equal(decoded.tx.items[0].productName, 'Kopi Tubruk® Spesial Café');
  assert.equal(decoded.tx.totalAmount, unicodeTx.totalAmount);
  assert.equal(decoded.tx.totalCost, 0);
  assert.equal(decoded.tx.items[0].costPrice, 0);
  assert.equal(decoded.settings.storeName, sampleSettings.storeName);

  // Recover cleanly even if Android Share glued another URL or punctuation onto the end
  const withDuplicatedUrl = decodeOnlineReceiptData(
    `${token}https://ais-dev.example.run.app/?nota=extra`
  );
  assert.ok(withDuplicatedUrl !== null);
  assert.equal(withDuplicatedUrl.tx.invoiceNumber, unicodeTx.invoiceNumber);

  const withTrailingPunctuation = decodeOnlineReceiptData(`${token}.)`);
  assert.ok(withTrailingPunctuation !== null);
  assert.equal(withTrailingPunctuation.tx.invoiceNumber, unicodeTx.invoiceNumber);

  // Reject malformed / invalid tokens cleanly
  assert.equal(decodeOnlineReceiptData(''), null);
  assert.equal(decodeOnlineReceiptData('not-a-valid-token'), null);
  assert.equal(decodeOnlineReceiptData('e30'), null);
});

test('buildOnlineReceiptUrl produces clean shortened URL and buildWhatsAppReceiptText embeds it', () => {
  assert.equal(slugifyStoreName('AysPOS Roastery & Café'), 'AysPOS-Roastery-Caf');
  const url = buildOnlineReceiptUrl(
    sampleTx,
    sampleSettings,
    'https://ayspos.example.com/?autostart=1#cashier'
  );
  assert.equal(url, 'https://ayspos.example.com/AysPOS-Roastery/INV-20261122-0001');

  const { text, receiptUrl } = buildWhatsAppReceiptText(
    sampleTx,
    sampleSettings,
    'https://ayspos.example.com/'
  );
  assert.equal(receiptUrl, 'https://ayspos.example.com/AysPOS-Roastery/INV-20261122-0001');
  assert.ok(text.includes('Link Nota Online (Buka di Browser):'));
  assert.ok(text.includes(receiptUrl));

  const fallbackUrl = buildFallbackTokenReceiptUrl(
    sampleTx,
    sampleSettings,
    'https://ayspos.example.com/'
  );
  assert.equal(fallbackUrl.startsWith('https://ayspos.example.com/?nota=np2'), true);
  const parsedToken = new URL(fallbackUrl).searchParams.get('nota') || '';
  const roundTrip = decodeOnlineReceiptData(parsedToken);
  assert.ok(roundTrip !== null);
  assert.equal(roundTrip.tx.invoiceNumber, sampleTx.invoiceNumber);

  const payload = buildPublicReceiptPayload(sampleTx, sampleSettings);
  assert.equal(payload.storeSlug, 'AysPOS-Roastery');
  assert.equal(payload.inv, sampleTx.invoiceNumber);
  assert.equal('totalCost' in payload, false);
});

test('parseReceiptRouteFromLocation supports shortened paths, double-slash, hash, and token formats', () => {
  assert.deepEqual(
    parseReceiptRouteFromLocation('/TokoBerkah/INV-20261123-0001', '', ''),
    { kind: 'short', storeSlug: 'TokoBerkah', invoiceNumber: 'INV-20261123-0001' }
  );
  assert.deepEqual(
    parseReceiptRouteFromLocation('/TokoBerkah//INV-20261123-0001', '', ''),
    { kind: 'short', storeSlug: 'TokoBerkah', invoiceNumber: 'INV-20261123-0001' }
  );
  assert.deepEqual(
    parseReceiptRouteFromLocation('/', '', '#/TokoBerkah//INV-20261123-0001'),
    { kind: 'short', storeSlug: 'TokoBerkah', invoiceNumber: 'INV-20261123-0001' }
  );
  assert.deepEqual(
    parseReceiptRouteFromLocation('/', '?nota=TokoBerkah//INV-20261123-0001', ''),
    { kind: 'short', storeSlug: 'TokoBerkah', invoiceNumber: 'INV-20261123-0001' }
  );
  assert.deepEqual(
    parseReceiptRouteFromLocation('/', '?nota=np2abc123', ''),
    { kind: 'token', token: 'np2abc123' }
  );
  assert.equal(parseReceiptRouteFromLocation('/', '', ''), null);
  assert.equal(parseReceiptRouteFromLocation('/api/receipts', '', ''), null);
});

test('createBlankPosState wipes operational data to 0 and preserves Pemilik account by default', () => {
  const customHash = makePasswordHash('SandiPemilik88');
  const customOwner: User = {
    id: 'usr-0',
    username: 'bos_utama',
    fullName: 'Bos Utama',
    passwordHash: customHash,
    role: 'PEMILIK',
    outletId: 'out-2',
    isActive: true,
    passwordUpdatedAt: 1000,
    lastLoginAt: 2000,
    devVault: sealDevCredential('SandiPemilik88', 'usr-0', customHash),
  };

  const blank = createBlankPosState(customOwner, false);

  assert.equal(blank.products.length, 0);
  assert.equal(blank.customers.length, 0);
  assert.equal(blank.suppliers.length, 0);
  assert.equal(blank.shifts.length, 0);
  assert.equal(blank.pettyCash.length, 0);
  assert.equal(blank.transactions.length, 0);
  assert.equal(blank.purchaseOrders.length, 0);
  assert.equal(blank.stockMovements.length, 0);
  assert.equal(blank.stockTransfers.length, 0);
  assert.equal(blank.loyaltyRewards.length, 0);
  assert.equal(blank.pointHistory.length, 0);

  assert.equal(blank.outlets.length, 1);
  assert.equal(blank.outlets[0].id, 'out-1');
  assert.equal(blank.outlets[0].isMain, true);

  assert.equal(blank.users.length, 1);
  assert.equal(blank.users[0].role, 'PEMILIK');
  assert.equal(blank.users[0].username, 'bos_utama');
  assert.equal(blank.users[0].outletId, 'out-1');
  assert.equal(verifyPasswordHash('SandiPemilik88', blank.users[0].passwordHash), true);
  assert.equal(revealDevCredential(blank.users[0]), 'SandiPemilik88');

  assert.equal(blank.settings.storeName, 'Toko Baru');
  assert.equal(blank.settings.taxEnabled, false);
  assert.deepEqual(blank.settings.savedPrinters, []);
});

test('createBlankPosState resets Pemilik credentials to default when requested', () => {
  const customHash = makePasswordHash('SandiPemilik88');
  const customOwner: User = {
    id: 'usr-99',
    username: 'bos_utama',
    fullName: 'Bos Utama',
    passwordHash: customHash,
    role: 'PEMILIK',
    outletId: 'out-2',
    isActive: true,
  };

  const blankReset = createBlankPosState(customOwner, true);
  assert.equal(blankReset.users.length, 1);
  assert.equal(blankReset.users[0].id, 'usr-0');
  assert.equal(blankReset.users[0].username, 'pemilik');
  assert.equal(blankReset.users[0].role, 'PEMILIK');
  assert.equal(verifyPasswordHash('pemilik123', blankReset.users[0].passwordHash), true);
  assert.equal(revealDevCredential(blankReset.users[0]), 'pemilik123');
});

test('getTransactionDebtInfo handles unpaid, partial, settled, and legacy PIUTANG transactions', () => {
  const unpaidDebt: Transaction = {
    ...sampleTx,
    paymentMethod: 'PIUTANG',
    totalAmount: 100000,
    paidAmount: 0,
    debtPaidAmount: 0,
  };
  assert.deepEqual(getTransactionDebtInfo(unpaidDebt), {
    isDebt: true,
    total: 100000,
    paid: 0,
    remaining: 100000,
    isSettled: false,
    paidAt: undefined,
  });

  const partialDebt: Transaction = {
    ...sampleTx,
    paymentMethod: 'PIUTANG',
    totalAmount: 100000,
    paidAmount: 40000,
    debtPaidAmount: 40000,
  };
  const partialInfo = getTransactionDebtInfo(partialDebt);
  assert.equal(partialInfo.paid, 40000);
  assert.equal(partialInfo.remaining, 60000);
  assert.equal(partialInfo.isSettled, false);

  const settledAt = Date.UTC(2026, 10, 23, 8, 0, 0);
  const settledDebt: Transaction = {
    ...sampleTx,
    paymentMethod: 'PIUTANG',
    totalAmount: 100000,
    paidAmount: 100000,
    debtPaidAmount: 100000,
    debtPaidAt: settledAt,
  };
  assert.deepEqual(getTransactionDebtInfo(settledDebt), {
    isDebt: true,
    total: 100000,
    paid: 100000,
    remaining: 0,
    isSettled: true,
    paidAt: settledAt,
  });

  const legacyUnmarkedDebt: Transaction = {
    ...sampleTx,
    paymentMethod: 'PIUTANG',
    totalAmount: 100000,
    paidAmount: 100000,
  };
  assert.equal(getTransactionDebtInfo(legacyUnmarkedDebt).remaining, 100000);
  assert.equal(getTransactionDebtInfo(legacyUnmarkedDebt).isSettled, false);
});

test('debt receipts render status and remaining debt in preview, WhatsApp text, and online token', () => {
  const unpaidDebt: Transaction = {
    ...sampleTx,
    paymentMethod: 'PIUTANG',
    totalAmount: 100000,
    paidAmount: 25000,
    debtPaidAmount: 25000,
  };

  const previewLines = buildReceiptPreviewLines(unpaidDebt, sampleSettings);
  assert.ok(previewLines.some((l) => l.includes('Sisa Hutang') && l.includes('Rp 75.000')));
  assert.ok(previewLines.some((l) => l.includes('BELUM TERBAYAR')));

  const { text } = buildWhatsAppReceiptText(unpaidDebt, sampleSettings, 'https://ayspos.example.com/');
  assert.ok(text.includes('Sisa Hutang : Rp 75.000'));
  assert.ok(text.includes('BELUM TERBAYAR'));

  const token = encodeOnlineReceiptData(unpaidDebt, sampleSettings);
  const decoded = decodeOnlineReceiptData(token);
  assert.ok(decoded !== null);
  const decodedInfo = getTransactionDebtInfo(decoded.tx);
  assert.equal(decodedInfo.isDebt, true);
  assert.equal(decodedInfo.paid, 25000);
  assert.equal(decodedInfo.remaining, 75000);
  assert.equal(decodedInfo.isSettled, false);
});

test('attendance clock-in and clock-out evaluate lateness, duration, early leave, and overtime', () => {
  const cfg: AttendanceConfig = {
    enabled: true,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    outletLatitude: -6.208763,
    outletLongitude: 106.845599,
    requireGps: true,
    adminAccessByUserId: {},
  };

  const onTimeTs = new Date(2026, 10, 23, 8, 12, 0).getTime();
  assert.deepEqual(evaluateClockInStatus(onTimeTs, cfg), {
    status: 'TEPAT_WAKTU',
    lateMinutes: 0,
  });

  const lateTs = new Date(2026, 10, 23, 8, 35, 0).getTime();
  assert.deepEqual(evaluateClockInStatus(lateTs, cfg), {
    status: 'TERLAMBAT',
    lateMinutes: 35,
  });

  const inTs = new Date(2026, 10, 23, 8, 0, 0).getTime();
  const outEarlyTs = new Date(2026, 10, 23, 16, 15, 0).getTime();
  assert.deepEqual(evaluateClockOutMetrics(inTs, outEarlyTs, cfg), {
    workDurationMinutes: 495,
    earlyLeaveMinutes: 45,
    overtimeMinutes: 0,
  });

  const outOvertimeTs = new Date(2026, 10, 23, 18, 10, 0).getTime();
  assert.deepEqual(evaluateClockOutMetrics(inTs, outOvertimeTs, cfg), {
    workDurationMinutes: 610,
    earlyLeaveMinutes: 0,
    overtimeMinutes: 70,
  });
});

test('attendance geofence distance and Owner-to-Admin access permissions work strictly as configured', () => {
  const cfg: AttendanceConfig = {
    enabled: true,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    outletLatitude: -6.208763,
    outletLongitude: 106.845599,
    requireGps: true,
    adminAccessByUserId: {
      'usr-admin-view-only': {
        viewAttendance: true,
        viewLocation: false,
        manageAttendance: false,
      },
      'usr-admin-loc': {
        viewAttendance: false,
        viewLocation: true,
        manageAttendance: false,
      },
    },
  };

  const distSame = calculateDistanceMeters(-6.208763, 106.845599, -6.208763, 106.845599);
  assert.equal(distSame, 0);

  const nearLoc = enrichLocationWithGeofence(
    { latitude: -6.209, longitude: 106.8458, accuracyMeters: 12 },
    cfg
  );
  assert.equal(nearLoc.withinGeofence, true);

  const farLoc = enrichLocationWithGeofence(
    { latitude: -6.22, longitude: 106.86, accuracyMeters: 15 },
    cfg
  );
  assert.equal(farLoc.withinGeofence, false);

  const mkUser = (id: string, role: User['role']): User => ({
    id,
    username: id,
    fullName: id,
    passwordHash: 'h',
    role,
    outletId: 'out-1',
    isActive: true,
  });

  assert.deepEqual(getAttendancePermissions(mkUser('usr-0', 'PEMILIK'), cfg), {
    isOwner: true,
    canViewAll: true,
    canViewLocation: true,
    canManage: true,
  });

  assert.deepEqual(getAttendancePermissions(mkUser('usr-admin-default', 'ADMIN'), cfg), {
    isOwner: false,
    canViewAll: false,
    canViewLocation: false,
    canManage: false,
  });

  assert.deepEqual(getAttendancePermissions(mkUser('usr-admin-view-only', 'ADMIN'), cfg), {
    isOwner: false,
    canViewAll: true,
    canViewLocation: false,
    canManage: false,
  });

  assert.deepEqual(getAttendancePermissions(mkUser('usr-admin-loc', 'ADMIN'), cfg), {
    isOwner: false,
    canViewAll: true,
    canViewLocation: true,
    canManage: false,
  });

  assert.deepEqual(getAttendancePermissions(mkUser('usr-2', 'KASIR'), cfg), {
    isOwner: false,
    canViewAll: false,
    canViewLocation: false,
    canManage: false,
  });
});

test('buildAttendanceCsv masks GPS columns when includeLocation is false', () => {
  const rec: AttendanceRecord = {
    id: 'att-1',
    userId: 'usr-2',
    userName: 'Siti Kasir',
    userRole: 'KASIR',
    outletId: 'out-1',
    outletName: 'Outlet Pusat',
    dateKey: '2026-11-23',
    clockInAt: Date.UTC(2026, 10, 23, 1, 0, 0),
    clockInPhoto: 'data:image/jpeg;base64,xxx',
    clockInLocation: {
      latitude: -6.208763,
      longitude: 106.845599,
      distanceMeters: 20,
      withinGeofence: true,
      addressLabel: 'Jl. Sudirman Jakarta',
      capturedAt: Date.UTC(2026, 10, 23, 1, 0, 0),
    },
    status: 'TEPAT_WAKTU',
    lateMinutes: 0,
    earlyLeaveMinutes: 0,
    overtimeMinutes: 0,
    workDurationMinutes: 480,
  };

  const withLoc = buildAttendanceCsv([rec], true);
  assert.ok(withLoc.includes('Koordinat Masuk'));
  assert.ok(withLoc.includes('-6.208763, 106.845599'));
  assert.ok(withLoc.includes('Jl. Sudirman Jakarta'));

  const withoutLoc = buildAttendanceCsv([rec], false);
  assert.equal(withoutLoc.includes('Koordinat Masuk'), false);
  assert.equal(withoutLoc.includes('-6.208763'), false);
  assert.ok(withoutLoc.includes('Siti Kasir'));
});

test('disabling Attendance menu blocks all non-Pemilik roles while keeping Pemilik control active', () => {
  const disabledCfg: AttendanceConfig = {
    enabled: false,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    requireGps: true,
    adminAccessByUserId: {
      'usr-admin': {
        viewAttendance: true,
        viewLocation: true,
        manageAttendance: true,
      },
    },
  };

  const mkUser = (id: string, role: User['role']): User => ({
    id,
    username: id,
    fullName: id,
    passwordHash: 'h',
    role,
    outletId: 'out-1',
    isActive: true,
  });

  const owner = mkUser('usr-0', 'PEMILIK');
  const admin = mkUser('usr-admin', 'ADMIN');
  const kasir = mkUser('usr-2', 'KASIR');
  const gudang = mkUser('usr-3', 'GUDANG');

  assert.equal(canAccessAttendanceMenu(owner, disabledCfg), true);
  assert.equal(canAccessAttendanceMenu(admin, disabledCfg), false);
  assert.equal(canAccessAttendanceMenu(kasir, disabledCfg), false);
  assert.equal(canAccessAttendanceMenu(gudang, disabledCfg), false);

  assert.deepEqual(getAttendancePermissions(admin, disabledCfg), {
    isOwner: false,
    canViewAll: false,
    canViewLocation: false,
    canManage: false,
  });

  const enabledCfg = { ...disabledCfg, enabled: true };
  assert.equal(canAccessAttendanceMenu(admin, enabledCfg), true);
  assert.equal(canAccessAttendanceMenu(kasir, enabledCfg), true);
  assert.equal(canAccessAttendanceMenu(gudang, enabledCfg), true);
});

test('Pemilik can enable/disable any menu and KARYAWAN defaults to Attendance only with optional extra grants', () => {
  const mkUser = (id: string, role: User['role']): User => ({
    id,
    username: id,
    fullName: id,
    passwordHash: 'h',
    role,
    outletId: 'out-1',
    isActive: true,
  });

  const owner = mkUser('usr-0', 'PEMILIK');
  const kasir = mkUser('usr-2', 'KASIR');
  const gudang = mkUser('usr-3', 'GUDANG');
  const karyawanA = mkUser('usr-4', 'KARYAWAN');
  const karyawanB = mkUser('usr-5', 'KARYAWAN');

  const attCfg: AttendanceConfig = {
    enabled: true,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    requireGps: true,
    adminAccessByUserId: {},
  };

  const baseSettings: StoreSettings = {
    ...sampleSettings,
    enabledMenus: createDefaultEnabledMenus(true),
    karyawanAccessByUserId: {
      'usr-5': {
        ATTENDANCE: true,
        POS: true,
        INVENTORY: true,
      },
    },
  };

  // Default KARYAWAN (karyawanA) only has ATTENDANCE
  assert.equal(canUserAccessMenu(karyawanA, 'ATTENDANCE', baseSettings, attCfg), true);
  assert.equal(canUserAccessMenu(karyawanA, 'POS', baseSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanA, 'INVENTORY', baseSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanA, 'MASTER', baseSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanA, 'DASHBOARD', baseSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanA, 'SETTINGS', baseSettings, attCfg), false);

  // KARYAWAN granted POS & INVENTORY by Pemilik
  assert.equal(canUserAccessMenu(karyawanB, 'ATTENDANCE', baseSettings, attCfg), true);
  assert.equal(canUserAccessMenu(karyawanB, 'POS', baseSettings, attCfg), true);
  assert.equal(canUserAccessMenu(karyawanB, 'INVENTORY', baseSettings, attCfg), true);
  assert.equal(canUserAccessMenu(karyawanB, 'DASHBOARD', baseSettings, attCfg), false);

  assert.deepEqual(getEffectiveKaryawanAccess('usr-4', baseSettings), {
    ATTENDANCE: true,
    POS: false,
    INVENTORY: false,
    MASTER: false,
    DASHBOARD: false,
    DEVELOPER: false,
    SETTINGS: false,
  });

  // Global disable of POS and INVENTORY blocks KASIR, GUDANG, and granted KARYAWAN while PEMILIK retains access
  const restrictedSettings: StoreSettings = {
    ...baseSettings,
    enabledMenus: {
      ...createDefaultEnabledMenus(true),
      POS: false,
      INVENTORY: false,
    },
  };

  assert.equal(canUserAccessMenu(owner, 'POS', restrictedSettings, attCfg), true);
  assert.equal(canUserAccessMenu(owner, 'INVENTORY', restrictedSettings, attCfg), true);
  assert.equal(canUserAccessMenu(kasir, 'POS', restrictedSettings, attCfg), false);
  assert.equal(canUserAccessMenu(gudang, 'INVENTORY', restrictedSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanB, 'POS', restrictedSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanB, 'INVENTORY', restrictedSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawanB, 'ATTENDANCE', restrictedSettings, attCfg), true);
});

test('Pemilik can configure menu access per role and per account across ADMIN, KASIR, GUDANG, and KARYAWAN', () => {
  const mkUser = (id: string, role: User['role']): User => ({
    id,
    username: id,
    fullName: id,
    passwordHash: 'h',
    role,
    outletId: 'out-1',
    isActive: true,
  });

  const owner = mkUser('usr-0', 'PEMILIK');
  const admin = mkUser('usr-1', 'ADMIN');
  const kasirA = mkUser('usr-2', 'KASIR');
  const kasirB = mkUser('usr-2b', 'KASIR');
  const gudang = mkUser('usr-3', 'GUDANG');
  const karyawan = mkUser('usr-4', 'KARYAWAN');

  const attCfg: AttendanceConfig = {
    enabled: true,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    requireGps: true,
    adminAccessByUserId: {
      'usr-2': {
        viewAttendance: true,
        viewLocation: true,
        manageAttendance: false,
      },
      'usr-3': {
        viewAttendance: true,
        viewLocation: false,
        manageAttendance: true,
      },
    },
  };

  const roleConfiguredSettings: StoreSettings = {
    ...sampleSettings,
    enabledMenus: createDefaultEnabledMenus(true),
    roleMenuAccess: {
      ADMIN: {
        DASHBOARD: true,
        POS: true,
        ATTENDANCE: true,
        MASTER: true,
        INVENTORY: true,
        SETTINGS: false,
      },
      KASIR: {
        DASHBOARD: true,
        POS: true,
        ATTENDANCE: true,
        MASTER: true,
        INVENTORY: false,
        SETTINGS: true,
      },
      GUDANG: {
        DASHBOARD: false,
        POS: false,
        ATTENDANCE: true,
        MASTER: false,
        INVENTORY: true,
        SETTINGS: true,
      },
      KARYAWAN: {
        DASHBOARD: false,
        POS: true,
        ATTENDANCE: true,
        MASTER: false,
        INVENTORY: false,
        SETTINGS: false,
      },
    },
    userMenuAccessByUserId: {
      'usr-2b': {
        DASHBOARD: false,
        POS: true,
        ATTENDANCE: true,
        MASTER: false,
        INVENTORY: true,
        SETTINGS: false,
      },
    },
    karyawanAccessByUserId: {},
  };

  // Role-level customization applied to ADMIN, KASIR, GUDANG, KARYAWAN
  assert.equal(canUserAccessMenu(admin, 'SETTINGS', roleConfiguredSettings, attCfg), false);
  assert.equal(canUserAccessMenu(kasirA, 'DASHBOARD', roleConfiguredSettings, attCfg), true);
  assert.equal(canUserAccessMenu(gudang, 'MASTER', roleConfiguredSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawan, 'POS', roleConfiguredSettings, attCfg), true);

  // Per-account override takes precedence over role setting for kasirB
  assert.equal(hasCustomUserMenuOverride('usr-2', roleConfiguredSettings), false);
  assert.equal(hasCustomUserMenuOverride('usr-2b', roleConfiguredSettings), true);
  assert.equal(canUserAccessMenu(kasirB, 'DASHBOARD', roleConfiguredSettings, attCfg), false);
  assert.equal(canUserAccessMenu(kasirB, 'INVENTORY', roleConfiguredSettings, attCfg), true);
  assert.deepEqual(getEffectiveUserMenuAccess(kasirB, roleConfiguredSettings), {
    DASHBOARD: false,
    POS: true,
    ATTENDANCE: true,
    MASTER: false,
    INVENTORY: true,
    DEVELOPER: false,
    SETTINGS: false,
  });

  // Clearing per-account override restores role inheritance
  const afterResetOverride: StoreSettings = {
    ...roleConfiguredSettings,
    userMenuAccessByUserId: {},
  };
  assert.equal(hasCustomUserMenuOverride('usr-2b', afterResetOverride), false);
  assert.equal(canUserAccessMenu(kasirB, 'DASHBOARD', afterResetOverride, attCfg), true);
  assert.equal(canUserAccessMenu(kasirB, 'INVENTORY', afterResetOverride, attCfg), false);
  assert.equal(getEffectiveRoleMenuAccess('KASIR', afterResetOverride).DASHBOARD, true);

  // Global disable overrides role/user permissions for non-Pemilik, while Pemilik keeps access
  const globallyBlocked: StoreSettings = {
    ...roleConfiguredSettings,
    enabledMenus: {
      ...createDefaultEnabledMenus(true),
      POS: false,
    },
  };
  assert.equal(canUserAccessMenu(owner, 'POS', globallyBlocked, attCfg), true);
  assert.equal(canUserAccessMenu(kasirA, 'POS', globallyBlocked, attCfg), false);
  assert.equal(canUserAccessMenu(kasirB, 'POS', globallyBlocked, attCfg), false);
  assert.equal(canUserAccessMenu(karyawan, 'POS', globallyBlocked, attCfg), false);

  // Attendance monitor / GPS / management permissions work for any non-Pemilik staff granted by Pemilik
  assert.deepEqual(getAttendancePermissions(kasirA, attCfg), {
    isOwner: false,
    canViewAll: true,
    canViewLocation: true,
    canManage: false,
  });
  assert.deepEqual(getAttendancePermissions(gudang, attCfg), {
    isOwner: false,
    canViewAll: true,
    canViewLocation: false,
    canManage: true,
  });
  assert.deepEqual(getAttendancePermissions(karyawan, attCfg), {
    isOwner: false,
    canViewAll: false,
    canViewLocation: false,
    canManage: false,
  });
});

test('Work schedule & geofence radius apply per-role and Admin needs Pemilik permission to manage schedule', () => {
  const mkUser = (id: string, role: User['role']): User => ({
    id,
    username: id,
    fullName: id,
    passwordHash: 'h',
    role,
    outletId: 'out-1',
    isActive: true,
  });

  const owner = mkUser('usr-0', 'PEMILIK');
  const adminUnprivileged = mkUser('usr-1', 'ADMIN');
  const adminGranted = mkUser('usr-1b', 'ADMIN');

  const cfg: AttendanceConfig = {
    enabled: true,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    outletLatitude: -6.208763,
    outletLongitude: 106.845599,
    requireGps: true,
    adminAccessByUserId: {
      'usr-1b': {
        viewAttendance: true,
        viewLocation: true,
        manageAttendance: true,
      },
    },
    roleConfigs: {
      KASIR: {
        workStartTime: '09:00',
        workEndTime: '18:00',
        lateToleranceMinutes: 10,
        geofenceRadiusMeters: 80,
        requireGps: true,
      },
      GUDANG: {
        workStartTime: '07:00',
        workEndTime: '16:00',
        lateToleranceMinutes: 5,
        geofenceRadiusMeters: 400,
        requireGps: false,
      },
    },
  };

  assert.equal(hasCustomRoleAttendanceConfig(cfg, 'KASIR'), true);
  assert.equal(hasCustomRoleAttendanceConfig(cfg, 'GUDANG'), true);
  assert.equal(hasCustomRoleAttendanceConfig(cfg, 'KARYAWAN'), false);

  // At 08:40: Default/Karyawan (08:00 + 15m) is TERLAMBAT, Kasir (09:00 + 10m) is TEPAT_WAKTU
  const ts0840 = new Date(2026, 10, 23, 8, 40, 0).getTime();
  assert.equal(evaluateClockInStatus(ts0840, cfg, 'KARYAWAN').status, 'TERLAMBAT');
  assert.equal(evaluateClockInStatus(ts0840, cfg, 'KASIR').status, 'TEPAT_WAKTU');
  assert.equal(evaluateClockInStatus(ts0840, cfg, 'GUDANG').status, 'TERLAMBAT');

  // Clock-out at 16:30: GUDANG (16:00) has 30m overtime, KASIR (18:00) has 90m earlyLeave
  const ts0800 = new Date(2026, 10, 23, 8, 0, 0).getTime();
  const ts1630 = new Date(2026, 10, 23, 16, 30, 0).getTime();
  assert.equal(evaluateClockOutMetrics(ts0800, ts1630, cfg, 'GUDANG').overtimeMinutes, 30);
  assert.equal(evaluateClockOutMetrics(ts0800, ts1630, cfg, 'KASIR').earlyLeaveMinutes, 90);

  // Geofence radius per role (~220m away: outside KASIR 80m & default 150m, inside GUDANG 400m)
  const sampleCoord = { latitude: -6.2107, longitude: 106.8456, accuracyMeters: 10 };
  const kasirLoc = enrichLocationWithGeofence(sampleCoord, cfg, 'KASIR');
  const gudangLoc = enrichLocationWithGeofence(sampleCoord, cfg, 'GUDANG');
  const karyawanLoc = enrichLocationWithGeofence(sampleCoord, cfg, 'KARYAWAN');
  assert.equal(kasirLoc.withinGeofence, false);
  assert.equal(karyawanLoc.withinGeofence, false);
  assert.equal(gudangLoc.withinGeofence, true);
  assert.equal(getEffectiveAttendanceConfigForRole(cfg, 'GUDANG').requireGps, false);

  // Only Pemilik always has manage permission; Admin cannot open schedule settings unless granted by Pemilik
  assert.equal(getAttendancePermissions(owner, cfg).canManage, true);
  assert.equal(getAttendancePermissions(adminUnprivileged, cfg).canManage, false);
  assert.equal(getAttendancePermissions(adminGranted, cfg).canManage, true);
});

test('Developer & Akun menu is listed in ALL_TOGGLEABLE_MENUS and restricted by default for non-Pemilik roles', () => {
  assert.ok(ALL_TOGGLEABLE_MENUS.some((m) => m.id === 'DEVELOPER'));

  const mkUser = (id: string, role: User['role']): User => ({
    id,
    username: id,
    fullName: id,
    passwordHash: 'h',
    role,
    outletId: 'out-1',
    isActive: true,
  });

  const owner = mkUser('usr-0', 'PEMILIK');
  const admin = mkUser('usr-1', 'ADMIN');
  const kasir = mkUser('usr-2', 'KASIR');
  const gudang = mkUser('usr-3', 'GUDANG');
  const karyawan = mkUser('usr-4', 'KARYAWAN');

  const attCfg: AttendanceConfig = {
    enabled: true,
    workStartTime: '08:00',
    workEndTime: '17:00',
    lateToleranceMinutes: 15,
    geofenceRadiusMeters: 150,
    requireGps: true,
    adminAccessByUserId: {},
  };

  const defaultSettings: StoreSettings = {
    ...sampleSettings,
    enabledMenus: createDefaultEnabledMenus(true),
    roleMenuAccess: {},
    userMenuAccessByUserId: {},
  };

  // Default: only PEMILIK can access DEVELOPER
  assert.equal(canUserAccessMenu(owner, 'DEVELOPER', defaultSettings, attCfg), true);
  assert.equal(canUserAccessMenu(admin, 'DEVELOPER', defaultSettings, attCfg), false);
  assert.equal(canUserAccessMenu(kasir, 'DEVELOPER', defaultSettings, attCfg), false);
  assert.equal(canUserAccessMenu(gudang, 'DEVELOPER', defaultSettings, attCfg), false);
  assert.equal(canUserAccessMenu(karyawan, 'DEVELOPER', defaultSettings, attCfg), false);

  // Granting DEVELOPER per role or per account enables it, while global disable blocks non-Pemilik
  const grantedSettings: StoreSettings = {
    ...defaultSettings,
    roleMenuAccess: {
      ADMIN: { DEVELOPER: true },
    },
    userMenuAccessByUserId: {
      'usr-2': { DEVELOPER: true },
    },
  };
  assert.equal(canUserAccessMenu(admin, 'DEVELOPER', grantedSettings, attCfg), true);
  assert.equal(canUserAccessMenu(kasir, 'DEVELOPER', grantedSettings, attCfg), true);
  assert.equal(canUserAccessMenu(gudang, 'DEVELOPER', grantedSettings, attCfg), false);

  const globallyDisabledSettings: StoreSettings = {
    ...grantedSettings,
    enabledMenus: {
      ...createDefaultEnabledMenus(true),
      DEVELOPER: false,
    },
  };
  assert.equal(canUserAccessMenu(owner, 'DEVELOPER', globallyDisabledSettings, attCfg), true);
  assert.equal(canUserAccessMenu(admin, 'DEVELOPER', globallyDisabledSettings, attCfg), false);
  assert.equal(canUserAccessMenu(kasir, 'DEVELOPER', globallyDisabledSettings, attCfg), false);
});




