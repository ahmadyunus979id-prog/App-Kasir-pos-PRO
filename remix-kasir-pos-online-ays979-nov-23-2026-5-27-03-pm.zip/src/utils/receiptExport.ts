import type {
  PaperWidth,
  PaymentMethod,
  SavedPrinter,
  StoreSettings,
  Transaction,
  TransactionStatus,
} from '../types/pos';
import { formatDateTime, formatNumber, formatRupiah } from './formatters';

export const PAYMENT_LABELS: Record<string, string> = {
  TUNAI: 'Tunai',
  QRIS: 'QRIS',
  TRANSFER: 'Transfer / Kartu',
  PIUTANG: 'Piutang / Tempo',
};

export interface ThermalPrintResult {
  ok: boolean;
  message: string;
  blockedInIframe?: boolean;
  printer?: SavedPrinter;
}

export interface WhatsAppShareResult {
  receiptUrl: string;
  text: string;
  mode: 'wa' | 'share' | 'clipboard';
}

interface OnlineReceiptPayload {
  v: 1;
  sn: string;
  sa: string;
  sp: string;
  ft: string;
  inv: string;
  dt: number;
  out: string;
  ks: string;
  plg: string;
  sub: number;
  dsc: number;
  txp: number;
  txa: number;
  tot: number;
  pm: PaymentMethod;
  pd: number;
  ch: number;
  st: TransactionStatus;
  vr?: string;
  it: Array<[string, string, number, number, number, number]>;
}

const BLE_THERMAL_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000ae30-0000-1000-8000-00805f9b34fb',
  '0000fee7-0000-1000-8000-00805f9b34fb',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
];

interface BleWritableCharacteristic {
  properties: { write?: boolean; writeWithoutResponse?: boolean };
  writeValue: (data: BufferSource) => Promise<void>;
  writeValueWithoutResponse?: (data: BufferSource) => Promise<void>;
  writeValueWithResponse?: (data: BufferSource) => Promise<void>;
}

interface BleDeviceLike {
  id: string;
  name?: string;
  gatt?: {
    connected?: boolean;
    connect: () => Promise<{
      getPrimaryServices: () => Promise<Array<{
        getCharacteristics: () => Promise<BleWritableCharacteristic[]>;
      }>>;
    }>;
  };
}

interface SerialPortLike {
  getInfo?: () => { usbVendorId?: number; usbProductId?: number };
  open: (options: { baudRate: number }) => Promise<void>;
  close?: () => Promise<void>;
  writable: WritableStream<Uint8Array> | null;
}

let cachedBleDeviceId = '';
let cachedBleDeviceName = '';
let cachedBleChar: BleWritableCharacteristic | null = null;
let cachedSerialPort: SerialPortLike | null = null;

export function isRunningInIframe(): boolean {
  try {
    return typeof window !== 'undefined' && window.self !== window.top;
  } catch {
    return true;
  }
}

export function upsertSavedPrinter(
  existing: SavedPrinter[] | undefined,
  incoming: SavedPrinter
): SavedPrinter[] {
  const list = existing ? [...existing] : [];
  const idx = list.findIndex(
    (p) =>
      p.id === incoming.id ||
      (p.address && incoming.address && p.address.toLowerCase() === incoming.address.toLowerCase())
  );
  if (idx >= 0) {
    list[idx] = { ...list[idx], ...incoming };
    return list;
  }
  return [incoming, ...list];
}

export interface TransactionDebtInfo {
  isDebt: boolean;
  total: number;
  paid: number;
  remaining: number;
  isSettled: boolean;
  paidAt?: number;
}

export function getTransactionDebtInfo(tx: Transaction): TransactionDebtInfo {
  const total = Math.max(0, tx.totalAmount || 0);
  if (tx.paymentMethod !== 'PIUTANG') {
    return {
      isDebt: false,
      total,
      paid: tx.paidAmount,
      remaining: 0,
      isSettled: true,
    };
  }
  const rawPaid =
    typeof tx.debtPaidAmount === 'number'
      ? tx.debtPaidAmount
      : tx.id.startsWith('online-')
      ? tx.paidAmount
      : tx.debtPaidAt
      ? total
      : tx.paidAmount < total
      ? tx.paidAmount
      : 0;
  const paid = Math.min(total, Math.max(0, rawPaid));
  const remaining = tx.status === 'COMPLETED' ? Math.max(0, total - paid) : 0;
  return {
    isDebt: true,
    total,
    paid,
    remaining,
    isSettled: remaining === 0,
    paidAt: tx.debtPaidAt,
  };
}

export function getPaperCharWidth(width: PaperWidth): number {
  return width === 'MM_58' ? 32 : 48;
}

export function buildReceiptPreviewLines(
  tx: Transaction,
  settings: StoreSettings
): string[] {
  const w = getPaperCharWidth(settings.paperWidth);
  const sep = '-'.repeat(w);
  const lines: string[] = [];
  const debtInfo = getTransactionDebtInfo(tx);

  const center = (text: string) => {
    const t = text.slice(0, w);
    const pad = Math.max(0, Math.floor((w - t.length) / 2));
    return ' '.repeat(pad) + t;
  };

  const leftRight = (left: string, right: string) => {
    const maxL = Math.max(1, w - right.length - 1);
    const l = left.slice(0, maxL);
    const spaces = Math.max(1, w - l.length - right.length);
    return l + ' '.repeat(spaces) + right;
  };

  const chunk = (str: string) => {
    const res: string[] = [];
    for (let i = 0; i < str.length; i += w) {
      res.push(str.slice(i, i + w));
    }
    return res;
  };

  lines.push(center(settings.storeName.toUpperCase()));
  if (settings.storeAddress) {
    chunk(settings.storeAddress).forEach((c) => lines.push(center(c)));
  }
  if (settings.storePhone) {
    lines.push(center(`Telp: ${settings.storePhone}`));
  }
  lines.push(sep);
  lines.push(leftRight('Nota', tx.invoiceNumber));
  lines.push(leftRight('Tgl', formatDateTime(tx.createdAt)));
  lines.push(leftRight('Outlet', tx.outletName));
  lines.push(leftRight('Kasir', tx.cashierName));
  lines.push(leftRight('Plg', tx.customerName));
  lines.push(sep);

  tx.items.forEach((item) => {
    lines.push(item.productName.slice(0, w));
    const qtyStr = `${item.quantity} ${item.unitName} x ${formatRupiah(item.unitPrice)}`;
    lines.push(leftRight(qtyStr, formatRupiah(item.subtotal)));
    if (item.discountAmount > 0) {
      lines.push(leftRight('  Diskon Item', `-${formatRupiah(item.discountAmount)}`));
    }
  });

  lines.push(sep);
  lines.push(leftRight('Subtotal', formatRupiah(tx.subtotal)));
  if (tx.discountAmount > 0) {
    lines.push(leftRight('Diskon', `-${formatRupiah(tx.discountAmount)}`));
  }
  if (tx.taxAmount > 0) {
    lines.push(leftRight(`PPN (${formatNumber(tx.taxPercent)}%)`, formatRupiah(tx.taxAmount)));
  }
  lines.push(leftRight('TOTAL', formatRupiah(tx.totalAmount)));
  if (debtInfo.isDebt) {
    lines.push(leftRight('Bayar (Piutang)', formatRupiah(debtInfo.paid)));
    lines.push(leftRight('Sisa Hutang', formatRupiah(debtInfo.remaining)));
    lines.push(
      leftRight('Status Hutang', debtInfo.isSettled ? 'LUNAS' : 'BELUM TERBAYAR')
    );
    if (debtInfo.paidAt) {
      lines.push(leftRight('Tgl Lunas', formatDateTime(debtInfo.paidAt)));
    }
  } else {
    lines.push(
      leftRight(
        `Bayar (${PAYMENT_LABELS[tx.paymentMethod] || tx.paymentMethod})`,
        formatRupiah(tx.paidAmount)
      )
    );
    if (tx.changeAmount > 0) {
      lines.push(leftRight('Kembali', formatRupiah(tx.changeAmount)));
    }
  }
  if (tx.status !== 'COMPLETED') {
    lines.push(center(`*** STATUS: ${tx.status} ***`));
  }
  lines.push(sep);
  if (settings.receiptFooter) {
    chunk(settings.receiptFooter).forEach((c) => lines.push(center(c)));
  }
  lines.push(center(`=== ${settings.paperWidth === 'MM_58' ? 'Thermal 58mm' : 'Thermal 80mm'} ===`));
  return lines;
}

export function buildEscPosBytes(lines: string[]): Uint8Array {
  const encoder = new TextEncoder();
  const chunks: number[] = [0x1b, 0x40]; // ESC @ Initialize
  lines.forEach((line) => {
    const asciiSafe = line.replace(/[^\x20-\x7E]/g, ' ');
    const encoded = encoder.encode(asciiSafe);
    encoded.forEach((b) => chunks.push(b));
    chunks.push(0x0a);
  });
  chunks.push(0x1b, 0x64, 0x03); // Feed 3 lines
  chunks.push(0x1d, 0x56, 0x42, 0x00); // Partial cut
  return new Uint8Array(chunks);
}

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function buildThermalPrintHtml(lines: string[], settings: StoreSettings): string {
  const paperMm = settings.paperWidth === 'MM_58' ? '58mm' : '80mm';
  const bodyWidthMm = settings.paperWidth === 'MM_58' ? '52mm' : '74mm';
  const fontSize = settings.paperWidth === 'MM_58' ? '10px' : '11px';
  const logoHtml =
    settings.printLogo && settings.logoUrl
      ? `<div class="logo-wrap"><img src="${escapeHtml(settings.logoUrl)}" alt="Logo" /></div>`
      : '';

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>Struk Thermal ${paperMm}</title>
<style>
  @page {
    size: ${paperMm} auto;
    margin: 2mm 1mm;
  }
  * { box-sizing: border-box; }
  html, body {
    margin: 0;
    padding: 0;
    background: #ffffff;
    color: #000000;
    font-family: 'Courier New', Courier, monospace;
    width: ${bodyWidthMm};
  }
  .receipt {
    width: ${bodyWidthMm};
    padding: 2mm 1mm;
  }
  .logo-wrap {
    text-align: center;
    margin-bottom: 4px;
  }
  .logo-wrap img {
    width: 38px;
    height: 38px;
    object-fit: cover;
    border-radius: 4px;
  }
  pre {
    margin: 0;
    font-family: 'Courier New', Courier, monospace;
    font-size: ${fontSize};
    line-height: 1.32;
    white-space: pre;
    color: #000000;
  }
</style>
</head>
<body>
  <div class="receipt">
    ${logoHtml}
    <pre>${escapeHtml(lines.join('\n'))}</pre>
  </div>
</body>
</html>`;
}

export function printThermalBrowserDialog(
  lines: string[],
  settings: StoreSettings
): ThermalPrintResult {
  const html = buildThermalPrintHtml(lines, settings);
  try {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    iframe.setAttribute('aria-hidden', 'true');
    document.body.appendChild(iframe);

    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!doc || !iframe.contentWindow) {
      document.body.removeChild(iframe);
      throw new Error('Iframe cetak tidak tersedia');
    }

    doc.open();
    doc.write(html);
    doc.close();

    const win = iframe.contentWindow;
    setTimeout(() => {
      try {
        win.focus();
        win.print();
      } catch {
        document.body.classList.add('printing-receipt');
        window.print();
        setTimeout(() => document.body.classList.remove('printing-receipt'), 800);
      } finally {
        setTimeout(() => {
          if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
        }, 2000);
      }
    }, 150);

    return {
      ok: true,
      message: `Dialog cetak thermal ${settings.paperWidth === 'MM_58' ? '58mm' : '80mm'} dibuka.`,
    };
  } catch {
    try {
      document.body.classList.add('printing-receipt');
      window.print();
      setTimeout(() => document.body.classList.remove('printing-receipt'), 800);
      return {
        ok: true,
        message: 'Dialog cetak browser dibuka.',
      };
    } catch {
      return {
        ok: false,
        message: 'Gagal membuka dialog cetak browser di environment ini. Gunakan Download PDF atau ESC/POS (.bin).',
      };
    }
  }
}

async function writeBleBytesChunked(
  char: BleWritableCharacteristic,
  data: Uint8Array
): Promise<void> {
  const chunkSize = 20;
  for (let i = 0; i < data.length; i += chunkSize) {
    const chunk = data.slice(i, i + chunkSize);
    if (char.properties.writeWithoutResponse && char.writeValueWithoutResponse) {
      await char.writeValueWithoutResponse(chunk);
    } else if (char.writeValueWithResponse) {
      await char.writeValueWithResponse(chunk);
    } else {
      await char.writeValue(chunk);
    }
    await new Promise((r) => setTimeout(r, 15));
  }
}

async function connectBleDevice(device: BleDeviceLike): Promise<BleWritableCharacteristic | null> {
  const server = await device.gatt?.connect();
  if (!server) return null;
  const services = await server.getPrimaryServices();
  for (const service of services) {
    const chars = await service.getCharacteristics();
    const writable = chars.find(
      (c) => Boolean(c.properties.writeWithoutResponse || c.properties.write)
    );
    if (writable) {
      cachedBleChar = writable;
      cachedBleDeviceId = device.id;
      cachedBleDeviceName = device.name || 'Printer Thermal BLE';
      return writable;
    }
  }
  return null;
}

export async function getAuthorizedBluetoothPrinters(): Promise<Array<{ id: string; name: string }>> {
  const nav = navigator as Navigator & {
    bluetooth?: {
      getDevices?: () => Promise<BleDeviceLike[]>;
    };
  };
  if (!nav.bluetooth?.getDevices) return [];
  try {
    const devices = await nav.bluetooth.getDevices();
    return devices.map((d) => ({
      id: d.id,
      name: d.name || 'Printer Bluetooth',
    }));
  } catch {
    return [];
  }
}

export async function scanAndPairBluetoothPrinter(
  paperWidth: PaperWidth
): Promise<ThermalPrintResult> {
  const nav = navigator as Navigator & {
    bluetooth?: {
      requestDevice: (opts: unknown) => Promise<BleDeviceLike>;
    };
  };

  if (!nav.bluetooth) {
    return {
      ok: false,
      message:
        'Browser ini belum mendukung Web Bluetooth. Gunakan Chrome/Edge di Android atau Desktop, atau cetak lewat "Cetak Driver Thermal" / "RawBT Android".',
    };
  }

  try {
    const device = await nav.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: BLE_THERMAL_SERVICES,
    });

    const writable = await connectBleDevice(device);
    const printer: SavedPrinter = {
      id: device.id,
      name: device.name || 'Printer Thermal Bluetooth',
      address: device.id,
      connectionType: 'BLE',
      paperWidth,
      lastConnectedAt: Date.now(),
    };

    if (!writable) {
      return {
        ok: true,
        printer,
        message: `Perangkat "${printer.name}" ditemukan & disimpan. Jika printer memakai Bluetooth Classic SPP (non-BLE), cetak melalui "RawBT Android" atau "USB / Serial SPP".`,
      };
    }

    return {
      ok: true,
      printer,
      message: `Printer "${printer.name}" terhubung & tersimpan otomatis.`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const lower = msg.toLowerCase();
    if (
      lower.includes('permissions policy') ||
      lower.includes('disallowed') ||
      lower.includes('securityerror')
    ) {
      return {
        ok: false,
        blockedInIframe: true,
        message:
          'Akses scan Bluetooth terdekat diblokir oleh iframe preview. Klik "Buka di Tab Baru" di bawah agar browser mengizinkan pencarian & penyimpanan printer Bluetooth.',
      };
    }
    if (lower.includes('cancel') || lower.includes('no device')) {
      return {
        ok: false,
        message:
          'Pencarian perangkat Bluetooth dibatalkan atau belum ada printer aktif di sekitar. Pastikan Bluetooth & Lokasi HP/perangkat menyala.',
      };
    }
    return { ok: false, message: `Gagal mencari printer Bluetooth: ${msg}` };
  }
}

export async function scanAndPairSerialPrinter(
  paperWidth: PaperWidth
): Promise<ThermalPrintResult> {
  const nav = navigator as Navigator & {
    serial?: {
      requestPort: () => Promise<SerialPortLike>;
    };
  };

  if (!nav.serial) {
    return {
      ok: false,
      message:
        'Web Serial tidak tersedia di browser ini (khusus Chrome/Edge Desktop untuk USB/Bluetooth SPP COM).',
    };
  }

  try {
    const port = await nav.serial.requestPort();
    cachedSerialPort = port;
    const info = port.getInfo?.();
    const idLabel =
      info?.usbVendorId !== undefined
        ? `USB-${info.usbVendorId.toString(16).toUpperCase()}:${(info.usbProductId || 0).toString(16).toUpperCase()}`
        : `COM-${String(Date.now()).slice(-4)}`;

    const printer: SavedPrinter = {
      id: `serial-${idLabel}`,
      name: `Printer Serial/USB (${idLabel})`,
      address: idLabel,
      connectionType: 'SERIAL',
      paperWidth,
      lastConnectedAt: Date.now(),
    };

    return {
      ok: true,
      printer,
      message: `Port printer "${printer.name}" dipilih & tersimpan.`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const lower = msg.toLowerCase();
    if (lower.includes('permissions policy') || lower.includes('disallowed')) {
      return {
        ok: false,
        blockedInIframe: true,
        message:
          'Akses USB/Serial diblokir oleh iframe preview. Klik "Buka di Tab Baru" untuk menghubungkan port printer.',
      };
    }
    return { ok: false, message: `Pemilihan port dibatalkan: ${msg}` };
  }
}

export async function printThermalBluetoothWeb(
  lines: string[],
  preferredDeviceId?: string,
  paperWidth: PaperWidth = 'MM_58'
): Promise<ThermalPrintResult> {
  const nav = navigator as Navigator & {
    bluetooth?: {
      getDevices?: () => Promise<BleDeviceLike[]>;
      requestDevice: (opts: unknown) => Promise<BleDeviceLike>;
    };
  };

  if (!nav.bluetooth) {
    return {
      ok: false,
      message:
        'Web Bluetooth BLE tidak didukung di browser ini. Gunakan "Cetak Driver Thermal" atau "RawBT Android".',
    };
  }

  const data = buildEscPosBytes(lines);

  if (cachedBleChar && (!preferredDeviceId || cachedBleDeviceId === preferredDeviceId)) {
    try {
      await writeBleBytesChunked(cachedBleChar, data);
      return {
        ok: true,
        message: `Struk terkirim ke ${cachedBleDeviceName || 'Printer Bluetooth'}`,
      };
    } catch {
      cachedBleChar = null;
      cachedBleDeviceName = '';
      cachedBleDeviceId = '';
    }
  }

  // Try silent reconnect to previously saved & authorized BLE device
  if (preferredDeviceId && nav.bluetooth.getDevices) {
    try {
      const devices = await nav.bluetooth.getDevices();
      const matched = devices.find((d) => d.id === preferredDeviceId);
      if (matched) {
        const writable = await connectBleDevice(matched);
        if (writable) {
          await writeBleBytesChunked(writable, data);
          return {
            ok: true,
            message: `Terhubung otomatis & struk terkirim ke ${matched.name || 'Printer Tersimpan'}`,
          };
        }
      }
    } catch {
      // fall through to interactive requestDevice
    }
  }

  try {
    const device = await nav.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: BLE_THERMAL_SERVICES,
    });
    const writable = await connectBleDevice(device);
    const printer: SavedPrinter = {
      id: device.id,
      name: device.name || 'Printer Thermal Bluetooth',
      address: device.id,
      connectionType: 'BLE',
      paperWidth,
      lastConnectedAt: Date.now(),
    };
    if (writable) {
      await writeBleBytesChunked(writable, data);
      return {
        ok: true,
        printer,
        message: `Struk terkirim ke ${printer.name} & printer tersimpan.`,
      };
    }
    return {
      ok: false,
      printer,
      message:
        'Printer terhubung tapi tidak memakai layanan BLE GATT (printer Bluetooth Classic SPP gunakan "USB / Serial SPP" atau "RawBT Android").',
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const lower = msg.toLowerCase();
    if (
      lower.includes('permissions policy') ||
      lower.includes('disallowed') ||
      lower.includes('securityerror')
    ) {
      return {
        ok: false,
        blockedInIframe: true,
        message:
          'Akses Bluetooth diblokir oleh iframe preview. Buka aplikasi di Tab Baru untuk scan & cetak Bluetooth langsung, atau gunakan "Cetak Driver Thermal".',
      };
    }
    if (lower.includes('cancel') || lower.includes('no device')) {
      return {
        ok: false,
        message:
          'Pemilihan printer Bluetooth dibatalkan atau perangkat tidak ditemukan.',
      };
    }
    return { ok: false, message: `Gagal cetak Bluetooth: ${msg}` };
  }
}

export async function printThermalSerialWeb(
  lines: string[],
  baudRate = 9600
): Promise<ThermalPrintResult> {
  const nav = navigator as Navigator & {
    serial?: {
      requestPort: () => Promise<SerialPortLike>;
    };
  };

  if (!nav.serial) {
    return {
      ok: false,
      message:
        'Web Serial tidak didukung di browser ini. Gunakan Chrome/Edge Desktop untuk printer USB/COM, atau gunakan "Cetak Driver Thermal".',
    };
  }

  const data = buildEscPosBytes(lines);

  const sendToPort = async (port: SerialPortLike) => {
    if (!port.writable) {
      try {
        await port.open({ baudRate });
      } catch (err) {
        const msg = err instanceof Error ? err.message : '';
        if (!msg.toLowerCase().includes('already open')) {
          throw err;
        }
      }
    }
    if (!port.writable) {
      throw new Error('Port serial tidak dapat ditulisi.');
    }
    const writer = port.writable.getWriter();
    try {
      await writer.write(data);
    } finally {
      writer.releaseLock();
    }
  };

  try {
    if (cachedSerialPort) {
      try {
        await sendToPort(cachedSerialPort);
        return { ok: true, message: 'Struk ESC/POS terkirim ke port Serial/USB printer.' };
      } catch {
        cachedSerialPort = null;
      }
    }

    const port = await nav.serial.requestPort();
    cachedSerialPort = port;
    await sendToPort(port);
    return { ok: true, message: 'Struk ESC/POS terkirim ke port Serial/USB printer.' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const lower = msg.toLowerCase();
    if (lower.includes('permissions policy') || lower.includes('disallowed')) {
      return {
        ok: false,
        blockedInIframe: true,
        message:
          'Akses Serial/USB diblokir oleh iframe preview. Buka aplikasi di Tab Baru atau gunakan "Cetak Driver Thermal".',
      };
    }
    return { ok: false, message: `Serial/USB Printer: ${msg}` };
  }
}

export function printThermalRawBtAndroid(lines: string[]): ThermalPrintResult {
  try {
    const bytes = buildEscPosBytes(lines);
    let binary = '';
    bytes.forEach((b) => {
      binary += String.fromCharCode(b);
    });
    const base64 = btoa(binary);
    const link = document.createElement('a');
    link.href = `rawbt:base64,${base64}`;
    link.click();
    return {
      ok: true,
      message: 'Mengirim perintah ESC/POS ke aplikasi RawBT (Android Bluetooth Printer).',
    };
  } catch {
    return {
      ok: false,
      message: 'Gagal membuat perintah RawBT.',
    };
  }
}

export function downloadEscPosFile(lines: string[], filename: string): void {
  const bytes = buildEscPosBytes(lines);
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  const blob = new Blob([copy.buffer], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.bin`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const VALID_PAYMENT_METHODS: PaymentMethod[] = ['TUNAI', 'QRIS', 'TRANSFER', 'PIUTANG'];
const VALID_TX_STATUSES: TransactionStatus[] = ['COMPLETED', 'VOID', 'RETURNED'];
const BASE62_ALPHABET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

function safeFinite(val: unknown, fallback = 0): number {
  const num = typeof val === 'number' ? val : Number(val);
  return Number.isFinite(num) ? num : fallback;
}

function bytesToBase62(bytes: Uint8Array): string {
  let num = BigInt(1); // sentinel 0x01 preserves leading zero bytes
  for (let i = 0; i < bytes.length; i += 1) {
    num = (num << BigInt(8)) | BigInt(bytes[i]);
  }
  const base = BigInt(62);
  let out = '';
  while (num > BigInt(0)) {
    const rem = Number(num % base);
    out = BASE62_ALPHABET[rem] + out;
    num /= base;
  }
  return out;
}

function base62ToBytes(encoded: string): Uint8Array | null {
  if (!encoded || !/^[0-9A-Za-z]+$/.test(encoded)) return null;
  try {
    const base = BigInt(62);
    let num = BigInt(0);
    for (let i = 0; i < encoded.length; i += 1) {
      const idx = BASE62_ALPHABET.indexOf(encoded[i]);
      if (idx < 0) return null;
      num = num * base + BigInt(idx);
    }
    const reversed: number[] = [];
    const mask = BigInt(0xff);
    const shift = BigInt(8);
    while (num > BigInt(0)) {
      reversed.push(Number(num & mask));
      num >>= shift;
    }
    if (reversed.length < 2) return null;
    reversed.reverse();
    if (reversed[0] !== 1) return null;
    return new Uint8Array(reversed.slice(1));
  } catch {
    return null;
  }
}

function encodeBase64Url(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function decodeBase64Url(token: string): string | null {
  try {
    const normalized = token.replace(/ /g, '+').replace(/-/g, '+').replace(/_/g, '/');
    const padLen = (4 - (normalized.length % 4)) % 4;
    const padded = normalized + '='.repeat(padLen);
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  } catch {
    return null;
  }
}

export function encodeOnlineReceiptData(tx: Transaction, settings: StoreSettings): string {
  const pmIdx = Math.max(0, VALID_PAYMENT_METHODS.indexOf(tx.paymentMethod));
  const stIdx = Math.max(0, VALID_TX_STATUSES.indexOf(tx.status));
  const debtInfo = getTransactionDebtInfo(tx);
  const effectivePaid = debtInfo.isDebt ? debtInfo.paid : safeFinite(tx.paidAmount, 0);

  const compactTuple = [
    2,
    String(settings.storeName || 'AysPOS'),
    String(settings.storeAddress || ''),
    String(settings.storePhone || ''),
    String(settings.receiptFooter || ''),
    String(tx.invoiceNumber || ''),
    safeFinite(tx.createdAt, Date.now()),
    String(tx.outletName || ''),
    String(tx.cashierName || ''),
    String(tx.customerName || 'Pelanggan Umum'),
    safeFinite(tx.subtotal, 0),
    safeFinite(tx.discountAmount, 0),
    safeFinite(tx.taxPercent, 0),
    safeFinite(tx.taxAmount, 0),
    safeFinite(tx.totalAmount, 0),
    pmIdx,
    effectivePaid,
    safeFinite(tx.changeAmount, 0),
    stIdx,
    String(tx.voidReason || ''),
    (tx.items || []).map((item) => [
      String(item.productName || ''),
      String(item.unitName || 'pcs'),
      safeFinite(item.quantity, 1),
      safeFinite(item.unitPrice, 0),
      safeFinite(item.discountAmount, 0),
      safeFinite(item.subtotal, 0),
    ]),
  ];

  const jsonBytes = new TextEncoder().encode(JSON.stringify(compactTuple));
  return `np2${bytesToBase62(jsonBytes)}`;
}

function sanitizeNotaToken(raw: string): string {
  let clean = raw.trim();
  // Handle double-URL-encoded proxies
  if (clean.includes('%')) {
    try {
      clean = decodeURIComponent(clean).trim();
    } catch {
      // keep raw
    }
  }
  // Guard against Android Web Share or copy-paste appending another URL after the token
  clean = clean.split(/https?:\/\//i)[0].trim();
  // Strip any trailing whitespace or stray punctuation copied from chat
  clean = clean.split(/\s+/)[0].replace(/[.,;)>\]"']+$/g, '');
  return clean;
}

function buildDecodedResult(fields: {
  sn: string;
  sa: string;
  sp: string;
  ft: string;
  inv: string;
  dt: number;
  out: string;
  ks: string;
  plg: string;
  sub: number;
  dsc: number;
  txp: number;
  txa: number;
  tot: number;
  pm: PaymentMethod;
  pd: number;
  ch: number;
  st: TransactionStatus;
  vr?: string;
  it: Array<[string, string, number, number, number, number]>;
}): { tx: Transaction; settings: StoreSettings } {
  const items = fields.it.map((row, idx) => ({
    productId: `online-item-${idx + 1}`,
    productName: row[0],
    sku: '',
    unitName: row[1],
    unitMultiplier: 1,
    quantity: row[2],
    unitPrice: row[3],
    costPrice: 0,
    discountAmount: row[4],
    subtotal: row[5],
    returnedQty: 0,
  }));

  const tx: Transaction = {
    id: `online-${fields.inv}`,
    invoiceNumber: fields.inv,
    shiftId: '',
    outletId: '',
    outletName: fields.out,
    cashierId: '',
    cashierName: fields.ks,
    customerName: fields.plg,
    customerWhatsapp: '',
    subtotal: fields.sub,
    discountAmount: fields.dsc,
    taxPercent: fields.txp,
    taxAmount: fields.txa,
    totalAmount: fields.tot,
    totalCost: 0,
    paymentMethod: fields.pm,
    paidAmount: fields.pd,
    changeAmount: fields.ch,
    status: fields.st,
    ...(fields.pm === 'PIUTANG' ? { debtPaidAmount: fields.pd } : {}),
    ...(fields.vr ? { voidReason: fields.vr } : {}),
    items,
    createdAt: fields.dt,
  };

  const settings: StoreSettings = {
    storeName: fields.sn,
    storeAddress: fields.sa,
    storePhone: fields.sp,
    taxPercent: fields.txp,
    taxEnabled: fields.txa > 0,
    taxInclusive: false,
    pointsEnabled: true,
    pointsPerAmount: 10000,
    themeMode: 'LIGHT',
    paperWidth: 'MM_58',
    printerName: '',
    printerAddress: '',
    printLogo: false,
    receiptFooter: fields.ft,
    scannerHidEnabled: false,
    qrisEnabled: true,
    transferEnabled: true,
    piutangEnabled: true,
    ecommerceShopeeSync: false,
    ecommerceTokopediaSync: false,
  };

  return { tx, settings };
}

export function decodeOnlineReceiptData(
  token: string
): { tx: Transaction; settings: StoreSettings } | null {
  if (!token || typeof token !== 'string' || token.length > 24000) return null;
  const clean = sanitizeNotaToken(token);
  if (!clean) return null;

  // Format v2: np2 + pure Base62 compact array
  if (clean.startsWith('np2')) {
    const bytes = base62ToBytes(clean.slice(3));
    if (!bytes) return null;
    try {
      const arr = JSON.parse(new TextDecoder().decode(bytes)) as unknown[];
      if (!Array.isArray(arr) || arr.length < 21 || arr[0] !== 2) return null;
      const pmIdx = Number(arr[15]);
      const stIdx = Number(arr[18]);
      const pm = VALID_PAYMENT_METHODS[pmIdx];
      const st = VALID_TX_STATUSES[stIdx];
      if (!pm || !st || !Array.isArray(arr[20])) return null;
      if (typeof arr[1] !== 'string' || typeof arr[5] !== 'string') return null;

      const items: Array<[string, string, number, number, number, number]> = [];
      for (const row of arr[20]) {
        if (!Array.isArray(row) || row.length < 6) return null;
        const qty = Number(row[2]);
        const price = Number(row[3]);
        const disc = Number(row[4]);
        const sub = Number(row[5]);
        if (
          typeof row[0] !== 'string' ||
          typeof row[1] !== 'string' ||
          !Number.isFinite(qty) ||
          !Number.isFinite(price) ||
          !Number.isFinite(disc) ||
          !Number.isFinite(sub)
        ) {
          return null;
        }
        items.push([row[0], row[1], qty, price, disc, sub]);
      }

      const dt = Number(arr[6]);
      const sub = Number(arr[10]);
      const dsc = Number(arr[11]);
      const txp = Number(arr[12]);
      const txa = Number(arr[13]);
      const tot = Number(arr[14]);
      const pd = Number(arr[16]);
      const ch = Number(arr[17]);
      if (
        ![dt, sub, dsc, txp, txa, tot, pd, ch].every((n) => Number.isFinite(n))
      ) {
        return null;
      }

      return buildDecodedResult({
        sn: arr[1],
        sa: typeof arr[2] === 'string' ? arr[2] : '',
        sp: typeof arr[3] === 'string' ? arr[3] : '',
        ft: typeof arr[4] === 'string' ? arr[4] : '',
        inv: arr[5],
        dt,
        out: typeof arr[7] === 'string' ? arr[7] : '',
        ks: typeof arr[8] === 'string' ? arr[8] : '',
        plg: typeof arr[9] === 'string' ? arr[9] : 'Pelanggan Umum',
        sub,
        dsc,
        txp,
        txa,
        tot,
        pm,
        pd,
        ch,
        st,
        ...(typeof arr[19] === 'string' && arr[19] ? { vr: arr[19] } : {}),
        it: items,
      });
    } catch {
      return null;
    }
  }

  // Legacy Format v1: Base64URL JSON object
  const jsonStr = decodeBase64Url(clean);
  if (!jsonStr) return null;

  try {
    const parsed = JSON.parse(jsonStr) as Partial<OnlineReceiptPayload>;
    if (!parsed || typeof parsed !== 'object' || parsed.v !== 1) return null;
    if (
      typeof parsed.sn !== 'string' ||
      typeof parsed.inv !== 'string' ||
      typeof parsed.out !== 'string' ||
      typeof parsed.ks !== 'string' ||
      typeof parsed.plg !== 'string' ||
      typeof parsed.dt !== 'number' ||
      !Number.isFinite(parsed.dt) ||
      typeof parsed.sub !== 'number' ||
      !Number.isFinite(parsed.sub) ||
      typeof parsed.dsc !== 'number' ||
      !Number.isFinite(parsed.dsc) ||
      typeof parsed.txp !== 'number' ||
      !Number.isFinite(parsed.txp) ||
      typeof parsed.txa !== 'number' ||
      !Number.isFinite(parsed.txa) ||
      typeof parsed.tot !== 'number' ||
      !Number.isFinite(parsed.tot) ||
      typeof parsed.pd !== 'number' ||
      !Number.isFinite(parsed.pd) ||
      typeof parsed.ch !== 'number' ||
      !Number.isFinite(parsed.ch) ||
      !VALID_PAYMENT_METHODS.includes(parsed.pm as PaymentMethod) ||
      !VALID_TX_STATUSES.includes(parsed.st as TransactionStatus) ||
      !Array.isArray(parsed.it)
    ) {
      return null;
    }

    const items: Array<[string, string, number, number, number, number]> = [];
    for (let idx = 0; idx < parsed.it.length; idx += 1) {
      const row = parsed.it[idx];
      if (
        !Array.isArray(row) ||
        row.length < 6 ||
        typeof row[0] !== 'string' ||
        typeof row[1] !== 'string' ||
        typeof row[2] !== 'number' ||
        !Number.isFinite(row[2]) ||
        typeof row[3] !== 'number' ||
        !Number.isFinite(row[3]) ||
        typeof row[4] !== 'number' ||
        !Number.isFinite(row[4]) ||
        typeof row[5] !== 'number' ||
        !Number.isFinite(row[5])
      ) {
        return null;
      }
      items.push([row[0], row[1], row[2], row[3], row[4], row[5]]);
    }

    return buildDecodedResult({
      sn: parsed.sn,
      sa: typeof parsed.sa === 'string' ? parsed.sa : '',
      sp: typeof parsed.sp === 'string' ? parsed.sp : '',
      ft: typeof parsed.ft === 'string' ? parsed.ft : '',
      inv: parsed.inv,
      dt: parsed.dt,
      out: parsed.out,
      ks: parsed.ks,
      plg: parsed.plg,
      sub: parsed.sub,
      dsc: parsed.dsc,
      txp: parsed.txp,
      txa: parsed.txa,
      tot: parsed.tot,
      pm: parsed.pm as PaymentMethod,
      pd: parsed.pd,
      ch: parsed.ch,
      st: parsed.st as TransactionStatus,
      ...(typeof parsed.vr === 'string' && parsed.vr ? { vr: parsed.vr } : {}),
      it: items,
    });
  } catch {
    return null;
  }
}

export type ParsedReceiptRoute =
  | { kind: 'token'; token: string }
  | { kind: 'short'; storeSlug: string; invoiceNumber: string };

export function slugifyStoreName(storeName: string): string {
  const cleaned = String(storeName || '')
    .trim()
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return cleaned || 'Toko';
}

function toSafeInvoiceSlug(invoiceNumber: string): string {
  return String(invoiceNumber || '')
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
}

export function getAppBaseUrl(): string {
  if (typeof window === 'undefined') return '';
  return `${window.location.origin}${window.location.pathname}`;
}

export function getAppOriginUrl(baseUrl?: string): string {
  const raw = baseUrl ?? (typeof window !== 'undefined' ? window.location.origin : '');
  const noQueryOrHash = raw.split('?')[0].split('#')[0];
  try {
    const parsed = new URL(noQueryOrHash);
    return parsed.origin;
  } catch {
    return noQueryOrHash.replace(/\/+$/, '');
  }
}

export function buildFallbackTokenReceiptUrl(
  tx: Transaction,
  settings: StoreSettings,
  baseUrl?: string
): string {
  const origin = getAppOriginUrl(baseUrl);
  const token = encodeOnlineReceiptData(tx, settings);
  return `${origin}/?nota=${token}`;
}

export function buildOnlineReceiptUrl(
  tx: Transaction,
  settings: StoreSettings,
  baseUrl?: string
): string {
  const origin = getAppOriginUrl(baseUrl);
  const storeSlug = slugifyStoreName(settings.storeName);
  const invoiceSlug = toSafeInvoiceSlug(tx.invoiceNumber) || encodeURIComponent(tx.invoiceNumber);
  return `${origin}/${storeSlug}/${invoiceSlug}`;
}

export function buildPublicReceiptPayload(tx: Transaction, settings: StoreSettings) {
  const debtInfo = getTransactionDebtInfo(tx);
  return {
    storeSlug: slugifyStoreName(settings.storeName),
    sn: String(settings.storeName || 'AysPOS'),
    sa: String(settings.storeAddress || ''),
    sp: String(settings.storePhone || ''),
    ft: String(settings.receiptFooter || ''),
    inv: String(tx.invoiceNumber || ''),
    dt: safeFinite(tx.createdAt, Date.now()),
    out: String(tx.outletName || ''),
    ks: String(tx.cashierName || ''),
    plg: String(tx.customerName || 'Pelanggan Umum'),
    sub: safeFinite(tx.subtotal, 0),
    dsc: safeFinite(tx.discountAmount, 0),
    txp: safeFinite(tx.taxPercent, 0),
    txa: safeFinite(tx.taxAmount, 0),
    tot: safeFinite(tx.totalAmount, 0),
    pm: tx.paymentMethod,
    pd: debtInfo.isDebt ? debtInfo.paid : safeFinite(tx.paidAmount, 0),
    ch: safeFinite(tx.changeAmount, 0),
    st: tx.status,
    ...(tx.voidReason ? { vr: String(tx.voidReason) } : {}),
    it: (tx.items || []).map((item) => [
      String(item.productName || ''),
      String(item.unitName || 'pcs'),
      safeFinite(item.quantity, 1),
      safeFinite(item.unitPrice, 0),
      safeFinite(item.discountAmount, 0),
      safeFinite(item.subtotal, 0),
    ]),
  };
}

export async function publishOnlineReceipt(
  tx: Transaction,
  settings: StoreSettings
): Promise<{ ok: boolean; shortUrl: string }> {
  const shortUrl = buildOnlineReceiptUrl(tx, settings);
  try {
    const res = await fetch('/api/receipts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(buildPublicReceiptPayload(tx, settings)),
    });
    return { ok: res.ok, shortUrl };
  } catch {
    return { ok: false, shortUrl };
  }
}

export async function fetchOnlineReceipt(
  storeSlug: string,
  invoiceNumber: string
): Promise<{ tx: Transaction; settings: StoreSettings } | null> {
  try {
    const res = await fetch(
      `/api/receipts/${encodeURIComponent(storeSlug)}/${encodeURIComponent(invoiceNumber)}`
    );
    if (!res.ok) return null;
    const json = (await res.json()) as { ok?: boolean; receipt?: Record<string, unknown> };
    if (!json.ok || !json.receipt || typeof json.receipt !== 'object') return null;

    const r = json.receipt;
    const pm = VALID_PAYMENT_METHODS.includes(r.pm as PaymentMethod)
      ? (r.pm as PaymentMethod)
      : 'TUNAI';
    const st = VALID_TX_STATUSES.includes(r.st as TransactionStatus)
      ? (r.st as TransactionStatus)
      : 'COMPLETED';
    if (typeof r.sn !== 'string' || typeof r.inv !== 'string' || !Array.isArray(r.it)) {
      return null;
    }

    const items: Array<[string, string, number, number, number, number]> = [];
    for (const row of r.it) {
      if (!Array.isArray(row) || row.length < 6) return null;
      items.push([
        String(row[0] ?? ''),
        String(row[1] ?? 'pcs'),
        safeFinite(row[2], 1),
        safeFinite(row[3], 0),
        safeFinite(row[4], 0),
        safeFinite(row[5], 0),
      ]);
    }

    return buildDecodedResult({
      sn: r.sn,
      sa: typeof r.sa === 'string' ? r.sa : '',
      sp: typeof r.sp === 'string' ? r.sp : '',
      ft: typeof r.ft === 'string' ? r.ft : '',
      inv: r.inv,
      dt: safeFinite(r.dt, Date.now()),
      out: typeof r.out === 'string' ? r.out : '',
      ks: typeof r.ks === 'string' ? r.ks : '',
      plg: typeof r.plg === 'string' ? r.plg : 'Pelanggan Umum',
      sub: safeFinite(r.sub, 0),
      dsc: safeFinite(r.dsc, 0),
      txp: safeFinite(r.txp, 0),
      txa: safeFinite(r.txa, 0),
      tot: safeFinite(r.tot, 0),
      pm,
      pd: safeFinite(r.pd, 0),
      ch: safeFinite(r.ch, 0),
      st,
      ...(typeof r.vr === 'string' && r.vr ? { vr: r.vr } : {}),
      it: items,
    });
  } catch {
    return null;
  }
}

export function parseReceiptRouteFromLocation(
  pathname: string,
  search: string,
  hash: string
): ParsedReceiptRoute | null {
  const tryParseShortString = (raw: string): ParsedReceiptRoute | null => {
    const clean = raw.replace(/^\/+|\/+$/g, '');
    if (!clean) return null;
    const parts = clean.split(/\/+/).filter(Boolean);
    if (parts.length === 2) {
      const [first, second] = parts;
      if (first === 'api' || first === 'assets' || first === 'images') return null;
      return {
        kind: 'short',
        storeSlug: decodeURIComponent(first),
        invoiceNumber: decodeURIComponent(second),
      };
    }
    if (parts.length === 3 && parts[0].toLowerCase() === 'nota') {
      return {
        kind: 'short',
        storeSlug: decodeURIComponent(parts[1]),
        invoiceNumber: decodeURIComponent(parts[2]),
      };
    }
    return null;
  };

  const searchParams = new URLSearchParams(search);
  const fromSearch = searchParams.get('nota');
  if (fromSearch !== null && fromSearch.trim() !== '') {
    if (fromSearch.includes('/')) {
      const asShort = tryParseShortString(fromSearch);
      if (asShort) return asShort;
    }
    return { kind: 'token', token: fromSearch };
  }

  const rawHash = hash.replace(/^#/, '');
  if (rawHash) {
    if (rawHash.startsWith('nota=')) {
      const val = rawHash.slice(5);
      if (val.includes('/')) {
        const asShort = tryParseShortString(val);
        if (asShort) return asShort;
      }
      return { kind: 'token', token: val };
    }
    const hashParams = new URLSearchParams(rawHash.startsWith('?') ? rawHash : `?${rawHash}`);
    const fromHashParam = hashParams.get('nota');
    if (fromHashParam) {
      if (fromHashParam.includes('/')) {
        const asShort = tryParseShortString(fromHashParam);
        if (asShort) return asShort;
      }
      return { kind: 'token', token: fromHashParam };
    }
    if (rawHash.includes('/')) {
      const asShort = tryParseShortString(rawHash);
      if (asShort) return asShort;
    }
  }

  return tryParseShortString(pathname);
}

export function buildWhatsAppReceiptText(
  tx: Transaction,
  settings: StoreSettings,
  baseUrl?: string
): { text: string; receiptUrl: string } {
  const receiptUrl = buildOnlineReceiptUrl(tx, settings, baseUrl);
  const debtInfo = getTransactionDebtInfo(tx);
  const lines = [
    `*${settings.storeName}*`,
    ...(settings.storeAddress ? [settings.storeAddress] : []),
    '------------------------------',
    `No. Nota : ${tx.invoiceNumber}`,
    `Tanggal  : ${formatDateTime(tx.createdAt)}`,
    `Outlet   : ${tx.outletName}`,
    `Kasir    : ${tx.cashierName}`,
    `Pelanggan: ${tx.customerName}`,
    '------------------------------',
    ...tx.items.map(
      (it) =>
        `${it.productName}\n  ${it.quantity} ${it.unitName} x ${formatRupiah(it.unitPrice)} = ${formatRupiah(it.subtotal)}`
    ),
    '------------------------------',
    `Subtotal : ${formatRupiah(tx.subtotal)}`,
    ...(tx.discountAmount > 0 ? [`Diskon   : -${formatRupiah(tx.discountAmount)}`] : []),
    ...(tx.taxAmount > 0
      ? [`PPN (${formatNumber(tx.taxPercent)}%) : ${formatRupiah(tx.taxAmount)}`]
      : []),
    `*TOTAL   : ${formatRupiah(tx.totalAmount)}*`,
    ...(debtInfo.isDebt
      ? [
          `Metode   : ${PAYMENT_LABELS[tx.paymentMethod] || tx.paymentMethod}`,
          `Dibayar  : ${formatRupiah(debtInfo.paid)}`,
          `*Sisa Hutang : ${formatRupiah(debtInfo.remaining)}*`,
          `Status Hutang : ${debtInfo.isSettled ? 'LUNAS (Sudah Terbayar)' : 'BELUM TERBAYAR'}`,
          ...(debtInfo.paidAt ? [`Tgl Lunas : ${formatDateTime(debtInfo.paidAt)}`] : []),
        ]
      : [
          `Bayar (${PAYMENT_LABELS[tx.paymentMethod] || tx.paymentMethod}): ${formatRupiah(tx.paidAmount)}`,
          ...(tx.changeAmount > 0 ? [`Kembali  : ${formatRupiah(tx.changeAmount)}`] : []),
        ]),
    '------------------------------',
    ...(settings.receiptFooter ? [settings.receiptFooter] : []),
    '',
    'Link Nota Online (Buka di Browser):',
    receiptUrl,
    '',
  ];

  return { text: lines.join('\n'), receiptUrl };
}

export function shareReceiptWhatsApp(
  tx: Transaction,
  settings: StoreSettings,
  phoneOverride?: string,
  baseUrl?: string
): WhatsAppShareResult {
  const { text, receiptUrl } = buildWhatsAppReceiptText(tx, settings, baseUrl);
  const rawPhone = (phoneOverride ?? tx.customerWhatsapp).replace(/\D/g, '');
  const waPhone = rawPhone.startsWith('0') ? `62${rawPhone.slice(1)}` : rawPhone;

  if (waPhone.length >= 9) {
    const url = `https://wa.me/${waPhone}?text=${encodeURIComponent(text)}`;
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.click();
    return { receiptUrl, text, mode: 'wa' };
  }

  if (navigator.share) {
    // Only pass `text` (which already contains receiptUrl on its own line) so Android doesn't glue `url` onto the token
    navigator.share({ title: `Struk ${tx.invoiceNumber}`, text }).catch(() => {});
    return { receiptUrl, text, mode: 'share' };
  }

  navigator.clipboard?.writeText(text).catch(() => {});
  return { receiptUrl, text, mode: 'clipboard' };
}

function escapePdfText(str: string): string {
  return str
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
}

export function downloadPdfInvoice(tx: Transaction, settings: StoreSettings): void {
  const ops: string[] = [];
  let y = 790;

  const drawText = (text: string, x: number, size = 10, bold = false) => {
    const font = bold ? 'F2' : 'F1';
    ops.push(`BT /${font} ${size} Tf ${x} ${y} Td (${escapePdfText(text)}) Tj ET`);
  };
  const drawLine = (yPos: number) => {
    ops.push(`0.85 0.88 0.92 RG 1 w 40 ${yPos} m 555 ${yPos} l S`);
  };

  drawText(settings.storeName, 40, 18, true);
  drawText(`INVOICE ${tx.invoiceNumber}`, 390, 13, true);
  y -= 18;
  drawText(settings.storeAddress, 40, 9);
  drawText(formatDateTime(tx.createdAt), 390, 9);
  y -= 14;
  drawText(`Telp: ${settings.storePhone}`, 40, 9);
  y -= 14;
  drawLine(y);
  y -= 20;

  drawText(`Outlet    : ${tx.outletName}`, 40, 10);
  drawText(`Kasir     : ${tx.cashierName}`, 320, 10);
  y -= 16;
  drawText(`Pelanggan : ${tx.customerName}`, 40, 10);
  drawText(`Metode    : ${PAYMENT_LABELS[tx.paymentMethod] || tx.paymentMethod}`, 320, 10);
  y -= 18;
  drawLine(y);
  y -= 16;

  drawText('Produk', 40, 10, true);
  drawText('Qty', 280, 10, true);
  drawText('Harga', 370, 10, true);
  drawText('Subtotal', 475, 10, true);
  y -= 8;
  drawLine(y);
  y -= 16;

  tx.items.forEach((item) => {
    drawText(item.productName.slice(0, 38), 40, 10);
    drawText(`${item.quantity} ${item.unitName}`, 280, 10);
    drawText(formatRupiah(item.unitPrice), 370, 10);
    drawText(formatRupiah(item.subtotal), 475, 10);
    y -= 16;
  });

  y -= 6;
  drawLine(y);
  y -= 18;

  drawText('Subtotal', 370, 10);
  drawText(formatRupiah(tx.subtotal), 475, 10);
  y -= 15;
  if (tx.discountAmount > 0) {
    drawText('Diskon', 370, 10);
    drawText(`-${formatRupiah(tx.discountAmount)}`, 475, 10);
    y -= 15;
  }
  if (tx.taxAmount > 0) {
    drawText(`PPN (${formatNumber(tx.taxPercent)}%)`, 370, 10);
    drawText(formatRupiah(tx.taxAmount), 475, 10);
    y -= 15;
  }
  const debtInfo = getTransactionDebtInfo(tx);
  drawText('TOTAL', 370, 12, true);
  drawText(formatRupiah(tx.totalAmount), 475, 12, true);
  y -= 16;
  drawText('Dibayar', 370, 10);
  drawText(formatRupiah(debtInfo.isDebt ? debtInfo.paid : tx.paidAmount), 475, 10);
  y -= 15;
  if (debtInfo.isDebt) {
    drawText('Sisa Hutang', 370, 10, true);
    drawText(formatRupiah(debtInfo.remaining), 475, 10, true);
    y -= 15;
    drawText('Status Hutang', 370, 10);
    drawText(debtInfo.isSettled ? 'LUNAS' : 'BELUM TERBAYAR', 475, 10, true);
    y -= 15;
  } else if (tx.changeAmount > 0) {
    drawText('Kembali', 370, 10);
    drawText(formatRupiah(tx.changeAmount), 475, 10);
    y -= 15;
  }

  y -= 20;
  drawLine(y);
  y -= 16;
  drawText(settings.receiptFooter, 40, 9);

  const streamContent = ops.join('\n');
  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >> endobj',
    `4 0 obj << /Length ${streamContent.length} >> stream\n${streamContent}\nendstream endobj`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj',
    '6 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> endobj',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [];
  objects.forEach((obj) => {
    offsets.push(pdf.length);
    pdf += obj + '\n';
  });
  const xrefStart = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((off) => {
    pdf += `${off.toString().padStart(10, '0')} 00000 n \n`;
  });
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;

  const blob = new Blob([pdf], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${tx.invoiceNumber}.pdf`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
