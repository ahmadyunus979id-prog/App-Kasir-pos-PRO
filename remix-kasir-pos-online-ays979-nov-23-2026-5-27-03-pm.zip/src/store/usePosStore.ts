import { useEffect, useState } from 'react';
import {
  createBlankPosState,
  createDefaultAttendanceConfig,
  createInitialPosState,
  type PosDatabaseState,
} from '../data/seedData';
import type {
  AppMenuId,
  AttendanceAdminPermission,
  AttendanceConfig,
  AttendanceLocationSnapshot,
  AttendanceRecord,
  CartItem,
  ConfigurableRole,
  Customer,
  DebtPaymentRecord,
  KaryawanMenuAccess,
  LoyaltyReward,
  Outlet,
  PaymentMethod,
  Product,
  ProductUnitOption,
  PurchaseOrderItem,
  RoleAttendanceScheduleConfig,
  Shift,
  StockMovement,
  StockTransfer,
  StoreSettings,
  Supplier,
  Transaction,
  User,
  UserRole,
} from '../types/pos';
import { makePasswordHash, sealDevCredential, verifyPasswordHash } from '../utils/formatters';
import {
  enrichLocationWithGeofence,
  evaluateClockInStatus,
  evaluateClockOutMetrics,
  getAttendancePermissions,
  getEffectiveAttendanceConfigForRole,
  getLocalDateKey,
} from '../utils/attendanceHelpers';
import {
  canUserAccessMenu,
  createAllMenusAccess,
  createDefaultEnabledMenus,
} from '../utils/menuPermissions';
import { getTransactionDebtInfo, publishOnlineReceipt } from '../utils/receiptExport';

const STORAGE_KEY = 'ayspos_state_v1';
const LEGACY_STORAGE_KEY = 'nusapos_state_v1';

function loadState(): PosDatabaseState {
  const initial = createInitialPosState();
  try {
    const raw =
      localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as PosDatabaseState;
      const hasPemilik = parsed.users?.some((u) => u.role === 'PEMILIK');
      if (!hasPemilik) {
        const pemilikSeed = initial.users.find((u) => u.role === 'PEMILIK');
        if (pemilikSeed) {
          parsed.users = [pemilikSeed, ...(parsed.users || [])];
        }
      } else if (Array.isArray(parsed.users)) {
        parsed.users = parsed.users.map((u) =>
          u.id === 'usr-0' && u.fullName === 'Hendra Wijaya (Pemilik)'
            ? { ...u, fullName: 'Hendra Wijaya (Pemilik / Developer)' }
            : u
        );
      }
      if (parsed.settings) {
        if (typeof parsed.settings.pointsEnabled !== 'boolean') {
          parsed.settings.pointsEnabled = true;
        }
        if (parsed.settings.storeName === 'NusaPOS Retail & Coffee') {
          parsed.settings.storeName = 'AysPOS Retail & Coffee';
        }
      }
      if (Array.isArray(parsed.loyaltyRewards)) {
        parsed.loyaltyRewards = parsed.loyaltyRewards.map((r) =>
          r.id === 'rwd-4' && r.title === 'Tumbler Stainless NusaPOS'
            ? { ...r, title: 'Tumbler Stainless AysPOS' }
            : r
        );
      }
      if (!parsed.attendanceConfig) {
        parsed.attendanceConfig = createDefaultAttendanceConfig(false, true);
      } else {
        if (typeof parsed.attendanceConfig.enabled !== 'boolean') {
          parsed.attendanceConfig.enabled = true;
        }
        if (!parsed.attendanceConfig.adminAccessByUserId) {
          parsed.attendanceConfig.adminAccessByUserId = {};
        }
        if (!parsed.attendanceConfig.roleConfigs) {
          parsed.attendanceConfig.roleConfigs = {};
        }
      }
      if (parsed.settings) {
        const defaultMenus = createDefaultEnabledMenus(parsed.attendanceConfig.enabled !== false);
        parsed.settings.enabledMenus = {
          ...defaultMenus,
          ...(parsed.settings.enabledMenus || {}),
        };
        if (!parsed.settings.roleMenuAccess) {
          parsed.settings.roleMenuAccess = {};
        }
        if (!parsed.settings.karyawanAccessByUserId) {
          parsed.settings.karyawanAccessByUserId = {};
        }
        parsed.settings.userMenuAccessByUserId = {
          ...(parsed.settings.karyawanAccessByUserId || {}),
          ...(parsed.settings.userMenuAccessByUserId || {}),
        };
      }
      if (!Array.isArray(parsed.attendanceRecords)) {
        parsed.attendanceRecords = [];
      }
      return parsed;
    }
  } catch {
    // ignore corrupted storage
  }
  return initial;
}

export function usePosStore() {
  const [state, setState] = useState<PosDatabaseState>(() => loadState());
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [developerUserId, setDeveloperUserId] = useState<string | null>(null);
  const [activeOutletId, setActiveOutletId] = useState<string>('out-1');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [selectedRewardId, setSelectedRewardId] = useState<string | null>(null);
  const [orderDiscount, setOrderDiscount] = useState<number>(0);
  const [applyTax, setApplyTax] = useState<boolean>(state.settings.taxEnabled);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // ignore storage quota errors
    }
  }, [state]);

  useEffect(() => {
    const root = document.documentElement;
    if (state.settings.themeMode === 'DARK') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [state.settings.themeMode]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  const currentUser = state.users.find((u) => u.id === currentUserId) || null;
  const developerUser = state.users.find((u) => u.id === developerUserId) || null;
  const isDeveloperSession =
    currentUser?.role === 'PEMILIK' || developerUser?.role === 'PEMILIK';
  const hasDeveloperMenuAccess = canUserAccessMenu(
    currentUser,
    'DEVELOPER',
    state.settings,
    state.attendanceConfig
  );
  const activeOutlet = state.outlets.find((o) => o.id === activeOutletId) || state.outlets[0];
  const openShift = state.shifts.find((s) => s.status === 'OPEN') || null;
  const selectedCustomer = state.customers.find((c) => c.id === selectedCustomerId) || null;
  const selectedReward = state.loyaltyRewards.find((r) => r.id === selectedRewardId) || null;

  const login = (username: string, password: string): { ok: boolean; error?: string; role?: UserRole } => {
    const found = state.users.find(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase()
    );
    if (!found) return { ok: false, error: 'Username tidak ditemukan' };
    if (!found.isActive) return { ok: false, error: 'Akun nonaktif. Hubungi Pemilik / Admin.' };
    if (!verifyPasswordHash(password, found.passwordHash)) {
      return { ok: false, error: 'Password salah' };
    }
    const now = Date.now();
    setState((prev) => ({
      ...prev,
      users: prev.users.map((u) =>
        u.id === found.id
          ? {
              ...u,
              lastLoginAt: now,
              devVault: u.devVault || sealDevCredential(password, u.id, u.passwordHash),
            }
          : u
      ),
    }));
    setDeveloperUserId(null);
    setCurrentUserId(found.id);
    setActiveOutletId(found.outletId);
    setApplyTax(state.settings.taxEnabled);
    return { ok: true, role: found.role };
  };

  const logout = () => {
    setCurrentUserId(null);
    setDeveloperUserId(null);
    setCart([]);
    setSelectedCustomerId(null);
    setSelectedRewardId(null);
    setOrderDiscount(0);
  };

  const switchAccountAsDeveloper = (
    targetUserId: string
  ): { ok: boolean; targetRole?: UserRole; error?: string } => {
    const originDev =
      developerUser ||
      (currentUser?.role === 'PEMILIK' || hasDeveloperMenuAccess ? currentUser : null);
    if (!originDev) {
      return { ok: false, error: 'Anda tidak memiliki akses ke menu Developer & Akun' };
    }
    const target = state.users.find((u) => u.id === targetUserId);
    if (!target) {
      return { ok: false, error: 'Akun tujuan tidak ditemukan' };
    }
    if (target.role === 'PEMILIK' && originDev.role !== 'PEMILIK') {
      return { ok: false, error: 'Hanya Pemilik (Developer) yang dapat mengakses akun Pemilik' };
    }
    if (target.id === originDev.id) {
      setDeveloperUserId(null);
      setCurrentUserId(originDev.id);
      setActiveOutletId(originDev.outletId);
      setToast(`Kembali ke akun ${originDev.fullName}`);
      return { ok: true, targetRole: originDev.role };
    }
    setDeveloperUserId(originDev.id);
    setCurrentUserId(target.id);
    setActiveOutletId(target.outletId);
    setToast(
      `Mode Developer: Mengakses ${target.fullName} (@${target.username})${
        !target.isActive ? ' [Status Nonaktif]' : ''
      }`
    );
    return { ok: true, targetRole: target.role };
  };

  const returnToDeveloperAccount = () => {
    if (!developerUser) return;
    setCurrentUserId(developerUser.id);
    setActiveOutletId(developerUser.outletId);
    setDeveloperUserId(null);
    setToast(`Kembali ke akun ${developerUser.fullName}`);
  };

  const addToCart = (product: Product, unitOption?: ProductUnitOption) => {
    const unit = unitOption || product.units[0] || {
      unitName: product.baseUnit,
      multiplier: 1,
      sellPrice: product.sellPrice,
    };
    setCart((prev) => {
      const idx = prev.findIndex(
        (c) => c.productId === product.id && c.selectedUnit === unit.unitName
      );
      if (idx >= 0) {
        return prev.map((c, i) => (i === idx ? { ...c, quantity: c.quantity + 1 } : c));
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          sku: product.sku,
          photoUrl: product.photoUrl,
          category: product.category,
          selectedUnit: unit.unitName,
          unitMultiplier: unit.multiplier,
          unitPrice: unit.sellPrice,
          costPrice: product.costPrice,
          quantity: 1,
          itemDiscount: 0,
          availableStock: product.stock,
        },
      ];
    });
  };

  const scanBarcodeOrSku = (query: string): boolean => {
    const clean = query.trim().toLowerCase();
    if (!clean) return false;
    const match = state.products.find(
      (p) => p.barcode.toLowerCase() === clean || p.sku.toLowerCase() === clean
    );
    if (match) {
      addToCart(match);
      setToast(`Ditambahkan: ${match.name}`);
      return true;
    }
    setToast(`Barcode / SKU '${query}' tidak ditemukan`);
    return false;
  };

  const updateCartQty = (productId: string, unitName: string, qty: number) => {
    setCart((prev) =>
      qty <= 0
        ? prev.filter((c) => !(c.productId === productId && c.selectedUnit === unitName))
        : prev.map((c) =>
            c.productId === productId && c.selectedUnit === unitName ? { ...c, quantity: qty } : c
          )
    );
  };

  const updateCartItemDiscount = (productId: string, unitName: string, discount: number) => {
    setCart((prev) =>
      prev.map((c) =>
        c.productId === productId && c.selectedUnit === unitName
          ? { ...c, itemDiscount: Math.max(0, Math.min(discount, c.unitPrice * c.quantity)) }
          : c
      )
    );
  };

  const changeCartItemUnit = (productId: string, oldUnitName: string, nextUnit: ProductUnitOption) => {
    setCart((prev) =>
      prev.map((c) =>
        c.productId === productId && c.selectedUnit === oldUnitName
          ? {
              ...c,
              selectedUnit: nextUnit.unitName,
              unitMultiplier: nextUnit.multiplier,
              unitPrice: nextUnit.sellPrice,
            }
          : c
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setSelectedCustomerId(null);
    setSelectedRewardId(null);
    setOrderDiscount(0);
  };

  const openNewShift = (openingCash: number) => {
    if (!currentUser) return;
    const shift: Shift = {
      id: `shf-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.fullName,
      outletId: activeOutlet.id,
      outletName: activeOutlet.name,
      openedAt: Date.now(),
      openingCash,
      cashSales: 0,
      nonCashSales: 0,
      pettyCashOut: 0,
      cashRefunds: 0,
      expectedCash: openingCash,
      status: 'OPEN',
    };
    setState((prev) => ({ ...prev, shifts: [shift, ...prev.shifts] }));
    setToast('Shift kasir dibuka');
  };

  const addPettyCash = (description: string, amount: number) => {
    if (!openShift || !description.trim() || amount <= 0) return;
    const entry = {
      id: `pc-${Date.now()}`,
      shiftId: openShift.id,
      description: description.trim(),
      amount,
      createdAt: Date.now(),
    };
    setState((prev) => ({
      ...prev,
      pettyCash: [entry, ...prev.pettyCash],
      shifts: prev.shifts.map((s) => {
        if (s.id !== openShift.id) return s;
        const petty = s.pettyCashOut + amount;
        return {
          ...s,
          pettyCashOut: petty,
          expectedCash: s.openingCash + s.cashSales - petty - s.cashRefunds,
        };
      }),
    }));
    setToast('Pengeluaran kas kecil dicatat');
  };

  const closeActiveShift = (actualCash: number): Shift | null => {
    if (!openShift) return null;
    const expected =
      openShift.openingCash + openShift.cashSales - openShift.pettyCashOut - openShift.cashRefunds;
    const closed: Shift = {
      ...openShift,
      closedAt: Date.now(),
      expectedCash: expected,
      actualCash,
      status: 'CLOSED',
    };
    setState((prev) => ({
      ...prev,
      shifts: prev.shifts.map((s) => (s.id === openShift.id ? closed : s)),
    }));
    setToast('Shift kasir berhasil ditutup');
    return closed;
  };

  const completeSale = (
    paymentMethod: PaymentMethod,
    paidAmount: number
  ): { ok: boolean; tx?: Transaction; error?: string } => {
    if (!currentUser) return { ok: false, error: 'Sesi pengguna habis' };
    if (!openShift) return { ok: false, error: 'Buka shift kasir terlebih dahulu' };
    if (cart.length === 0) return { ok: false, error: 'Keranjang kosong' };

    const subtotal = cart.reduce((acc, c) => acc + Math.max(0, c.unitPrice * c.quantity - c.itemDiscount), 0);
    const rewardDiscount = selectedReward?.discountAmount ?? 0;
    const discountCapped = Math.min(subtotal, Math.max(0, orderDiscount + rewardDiscount));
    const afterDiscount = subtotal - discountCapped;
    const taxPercent = applyTax ? state.settings.taxPercent : 0;
    const taxAmount =
      !applyTax || taxPercent <= 0
        ? 0
        : state.settings.taxInclusive
        ? Math.round(afterDiscount - afterDiscount / (1 + taxPercent / 100))
        : Math.round(afterDiscount * (taxPercent / 100));
    const totalAmount = state.settings.taxInclusive ? afterDiscount : afterDiscount + taxAmount;

    if (paymentMethod === 'TUNAI' && paidAmount < totalAmount) {
      return { ok: false, error: 'Nominal bayar tunai kurang dari total' };
    }
    if (paymentMethod === 'PIUTANG' && !selectedCustomer) {
      return { ok: false, error: 'Pilih pelanggan untuk pembayaran Piutang' };
    }

    const effectivePaid =
      paymentMethod === 'TUNAI'
        ? paidAmount
        : paymentMethod === 'PIUTANG'
        ? Math.min(totalAmount, Math.max(0, Math.round(paidAmount || 0)))
        : totalAmount;
    const changeAmount = paymentMethod === 'TUNAI' ? Math.max(0, effectivePaid - totalAmount) : 0;
    const totalCost = cart.reduce(
      (acc, c) => acc + Math.round(c.costPrice * c.quantity * c.unitMultiplier),
      0
    );
    const now = Date.now();
    const dateStr = new Date(now).toISOString().slice(0, 10).replace(/-/g, '');
    const invoiceNumber = `INV-${dateStr}-${String(now % 10000).padStart(4, '0')}`;

    const initialDebtPayments: DebtPaymentRecord[] =
      paymentMethod === 'PIUTANG' && effectivePaid > 0
        ? [
            {
              id: `dp-${now}`,
              amount: effectivePaid,
              method: 'TUNAI',
              note: 'Uang muka (DP) saat transaksi',
              cashierName: currentUser.fullName,
              paidAt: now,
            },
          ]
        : [];

    const newTx: Transaction = {
      id: `tx-${now}`,
      invoiceNumber,
      shiftId: openShift.id,
      outletId: activeOutlet.id,
      outletName: activeOutlet.name,
      cashierId: currentUser.id,
      cashierName: currentUser.fullName,
      customerId: selectedCustomer?.id,
      customerName: selectedCustomer?.name || 'Pelanggan Umum',
      customerWhatsapp: selectedCustomer?.whatsapp || '',
      subtotal,
      discountAmount: discountCapped,
      taxPercent,
      taxAmount,
      totalAmount,
      totalCost,
      paymentMethod,
      paidAmount: effectivePaid,
      changeAmount,
      status: 'COMPLETED',
      ...(paymentMethod === 'PIUTANG'
        ? {
            debtPaidAmount: effectivePaid,
            ...(effectivePaid >= totalAmount ? { debtPaidAt: now } : {}),
            debtPayments: initialDebtPayments,
          }
        : {}),
      items: cart.map((c) => ({
        productId: c.productId,
        productName: c.name,
        sku: c.sku,
        unitName: c.selectedUnit,
        unitMultiplier: c.unitMultiplier,
        quantity: c.quantity,
        unitPrice: c.unitPrice,
        costPrice: c.costPrice,
        discountAmount: c.itemDiscount,
        subtotal: Math.max(0, c.unitPrice * c.quantity - c.itemDiscount),
        returnedQty: 0,
      })),
      createdAt: now,
    };

    setState((prev) => {
      const newMovements: StockMovement[] = [];
      let updatedProducts = [...prev.products];

      cart.forEach((item) => {
        const consumed = item.quantity * item.unitMultiplier;
        updatedProducts = updatedProducts.map((p) => {
          if (p.id !== item.productId) return p;
          const nextStock = Math.max(0, p.stock - consumed);
          newMovements.push({
            id: `sm-${now}-${p.id}`,
            productId: p.id,
            productName: p.name,
            outletId: activeOutlet.id,
            type: 'PENJUALAN',
            quantityDelta: -consumed,
            balanceAfter: nextStock,
            referenceId: invoiceNumber,
            note: `Penjualan ${item.quantity} ${item.selectedUnit}`,
            createdBy: currentUser.fullName,
            createdAt: now,
          });
          return { ...p, stock: nextStock, lastSoldAt: now };
        });

        const soldProd = prev.products.find((p) => p.id === item.productId);
        if (soldProd?.isBom) {
          soldProd.bomItems.forEach((bom) => {
            const ingConsumed = bom.quantityNeeded * consumed;
            updatedProducts = updatedProducts.map((ing) => {
              if (ing.id !== bom.ingredientProductId) return ing;
              const nextIngStock = Math.max(0, ing.stock - ingConsumed);
              newMovements.push({
                id: `sm-${now}-bom-${ing.id}`,
                productId: ing.id,
                productName: ing.name,
                outletId: activeOutlet.id,
                type: 'BOM_PAKAI',
                quantityDelta: -ingConsumed,
                balanceAfter: nextIngStock,
                referenceId: invoiceNumber,
                note: `Resep ${soldProd.name}`,
                createdBy: currentUser.fullName,
                createdAt: now,
              });
              return { ...ing, stock: nextIngStock };
            });
          });
        }
      });

      const newPointEntries = [...prev.pointHistory];
      const updatedCustomers = prev.customers.map((cust) => {
        if (cust.id !== selectedCustomer?.id) return cust;
        let currentPts = cust.points;
        if (selectedReward && currentPts >= selectedReward.pointsCost) {
          currentPts -= selectedReward.pointsCost;
          newPointEntries.unshift({
            id: `ph-rdm-${now}`,
            customerId: cust.id,
            customerName: cust.name,
            type: selectedReward.rewardType === 'DISCOUNT' ? 'REDEEM_DISCOUNT' : 'REDEEM_GIFT',
            pointsDelta: -selectedReward.pointsCost,
            balanceAfter: currentPts,
            referenceId: invoiceNumber,
            description: `Penukaran: ${selectedReward.title}`,
            createdAt: now,
          });
        }
        const divisor = Math.max(1000, prev.settings.pointsPerAmount);
        const earned = prev.settings.pointsEnabled !== false ? Math.floor(totalAmount / divisor) : 0;
        if (earned > 0) {
          currentPts += earned;
          newPointEntries.unshift({
            id: `ph-earn-${now}`,
            customerId: cust.id,
            customerName: cust.name,
            type: 'EARN',
            pointsDelta: earned,
            balanceAfter: currentPts,
            referenceId: invoiceNumber,
            description: `Belanja di ${activeOutlet.name}`,
            createdAt: now + 1,
          });
        }
        return {
          ...cust,
          points: currentPts,
          receivableBalance:
            cust.receivableBalance +
            (paymentMethod === 'PIUTANG' ? Math.max(0, totalAmount - effectivePaid) : 0),
          totalSpent: cust.totalSpent + totalAmount,
        };
      });

      const updatedShifts = prev.shifts.map((s) => {
        if (s.id !== openShift.id) return s;
        const addedCash =
          paymentMethod === 'TUNAI'
            ? totalAmount
            : paymentMethod === 'PIUTANG'
            ? effectivePaid
            : 0;
        const addedNonCash =
          paymentMethod === 'QRIS' || paymentMethod === 'TRANSFER' ? totalAmount : 0;
        const cashSales = s.cashSales + addedCash;
        const nonCash = s.nonCashSales + addedNonCash;
        return {
          ...s,
          cashSales,
          nonCashSales: nonCash,
          expectedCash: s.openingCash + cashSales - s.pettyCashOut - s.cashRefunds,
        };
      });

      return {
        ...prev,
        products: updatedProducts,
        customers: updatedCustomers,
        pointHistory: newPointEntries,
        shifts: updatedShifts,
        transactions: [newTx, ...prev.transactions],
        stockMovements: [...newMovements, ...prev.stockMovements],
      };
    });

    void publishOnlineReceipt(newTx, state.settings);
    clearCart();
    setToast(`Transaksi ${invoiceNumber} berhasil`);
    return { ok: true, tx: newTx };
  };

  const authorizeVoidOrReturn = (
    tx: Transaction,
    isFullVoid: boolean,
    reason: string,
    adminPassword: string
  ): { ok: boolean; message: string } => {
    if (!currentUser) return { ok: false, message: 'Belum login' };
    if (tx.status !== 'COMPLETED') return { ok: false, message: 'Transaksi sudah dibatalkan' };
    const isAdmin = currentUser.role === 'ADMIN' || currentUser.role === 'PEMILIK';
    const authUser = isAdmin
      ? currentUser
      : state.users.find(
          (u) =>
            u.isActive &&
            (u.role === 'ADMIN' || u.role === 'PEMILIK') &&
            verifyPasswordHash(adminPassword, u.passwordHash)
        );
    if (!authUser) {
      return { ok: false, message: 'Password otorisasi Admin/Pemilik tidak valid' };
    }

    const now = Date.now();
    setState((prev) => {
      const movements: StockMovement[] = [];
      let updatedProducts = [...prev.products];
      tx.items.forEach((it) => {
        const restoreQty = it.quantity * it.unitMultiplier;
        updatedProducts = updatedProducts.map((p) => {
          if (p.id !== it.productId) return p;
          const nextStock = p.stock + restoreQty;
          movements.push({
            id: `sm-void-${now}-${p.id}`,
            productId: p.id,
            productName: p.name,
            outletId: tx.outletId,
            type: isFullVoid ? 'VOID' : 'RETUR',
            quantityDelta: restoreQty,
            balanceAfter: nextStock,
            referenceId: tx.invoiceNumber,
            note: reason || (isFullVoid ? 'Void transaksi' : 'Retur barang'),
            createdBy: authUser.fullName,
            createdAt: now,
          });
          return { ...p, stock: nextStock };
        });
      });

      return {
        ...prev,
        products: updatedProducts,
        stockMovements: [...movements, ...prev.stockMovements],
        transactions: prev.transactions.map((t) =>
          t.id === tx.id
            ? {
                ...t,
                status: isFullVoid ? 'VOID' : 'RETURNED',
                voidReason: reason,
                authorizedBy: authUser.fullName,
              }
            : t
        ),
        customers: prev.customers.map((c) => {
          if (c.id !== tx.customerId) return c;
          const remainingDebt = getTransactionDebtInfo(tx).remaining;
          return {
            ...c,
            receivableBalance:
              tx.paymentMethod === 'PIUTANG'
                ? Math.max(0, c.receivableBalance - remainingDebt)
                : c.receivableBalance,
            totalSpent: Math.max(0, c.totalSpent - tx.totalAmount),
          };
        }),
        shifts: prev.shifts.map((s) => {
          if (s.id !== tx.shiftId || s.status !== 'OPEN' || tx.paymentMethod !== 'TUNAI') return s;
          const refunds = s.cashRefunds + tx.totalAmount;
          return {
            ...s,
            cashRefunds: refunds,
            expectedCash: s.openingCash + s.cashSales - s.pettyCashOut - refunds,
          };
        }),
      };
    });

    const updatedTx: Transaction = {
      ...tx,
      status: isFullVoid ? 'VOID' : 'RETURNED',
      voidReason: reason,
      authorizedBy: authUser.fullName,
    };
    void publishOnlineReceipt(updatedTx, state.settings);

    const msg = isFullVoid ? 'Transaksi di-Void & stok dikembalikan' : 'Retur penjualan berhasil';
    setToast(msg);
    return { ok: true, message: msg };
  };

  const redeemRewardForCustomer = (customer: Customer, reward: LoyaltyReward) => {
    if (customer.points < reward.pointsCost) {
      setToast('Poin pelanggan tidak mencukupi');
      return;
    }
    const now = Date.now();
    const newBal = customer.points - reward.pointsCost;
    setState((prev) => ({
      ...prev,
      customers: prev.customers.map((c) => (c.id === customer.id ? { ...c, points: newBal } : c)),
      pointHistory: [
        {
          id: `ph-rdm-${now}`,
          customerId: customer.id,
          customerName: customer.name,
          type: reward.rewardType === 'DISCOUNT' ? 'REDEEM_DISCOUNT' : 'REDEEM_GIFT',
          pointsDelta: -reward.pointsCost,
          balanceAfter: newBal,
          referenceId: `RDM-${String(now % 100000)}`,
          description: `Penukaran: ${reward.title}`,
          createdAt: now,
        },
        ...prev.pointHistory,
      ],
    }));
    setToast(`Berhasil menukar ${reward.pointsCost} poin untuk ${reward.title}`);
  };

  const saveProduct = (prod: Product) => {
    setState((prev) => {
      const exists = prev.products.some((p) => p.id === prod.id);
      return {
        ...prev,
        products: exists
          ? prev.products.map((p) => (p.id === prod.id ? prod : p))
          : [{ ...prod, id: `prd-${Date.now()}` }, ...prev.products],
      };
    });
    setToast(`Produk ${prod.name} disimpan`);
  };

  const deleteProduct = (id: string) => {
    setState((prev) => ({ ...prev, products: prev.products.filter((p) => p.id !== id) }));
    setToast('Produk dihapus');
  };

  const saveCustomer = (cust: Customer) => {
    setState((prev) => {
      const exists = prev.customers.some((c) => c.id === cust.id);
      return {
        ...prev,
        customers: exists
          ? prev.customers.map((c) => (c.id === cust.id ? cust : c))
          : [{ ...cust, id: `cust-${Date.now()}` }, ...prev.customers],
      };
    });
    setToast('Data pelanggan disimpan');
  };

  const payCustomerReceivable = (customerId: string, amount: number) => {
    const cleanAmount = Math.max(0, Math.round(amount || 0));
    if (cleanAmount <= 0) return;
    const now = Date.now();
    const settledForPublish: Transaction[] = [];

    setState((prev) => {
      let remainingBudget = cleanAmount;
      const unpaidIdsOldestFirst = prev.transactions
        .filter(
          (tx) =>
            tx.customerId === customerId &&
            tx.paymentMethod === 'PIUTANG' &&
            tx.status === 'COMPLETED' &&
            getTransactionDebtInfo(tx).remaining > 0
        )
        .sort((a, b) => a.createdAt - b.createdAt);

      const updates = new Map<string, Transaction>();
      unpaidIdsOldestFirst.forEach((tx, idx) => {
        if (remainingBudget <= 0) return;
        const debtInfo = getTransactionDebtInfo(tx);
        const payDelta = Math.min(debtInfo.remaining, remainingBudget);
        remainingBudget -= payDelta;
        const nextPaid = debtInfo.paid + payDelta;
        const isSettled = nextPaid >= debtInfo.total;
        const record: DebtPaymentRecord = {
          id: `dp-${now}-${idx}`,
          amount: payDelta,
          method: 'TUNAI',
          note: 'Pembayaran piutang pelanggan',
          cashierName: currentUser?.fullName || 'Kasir',
          paidAt: now,
        };
        const updatedTx: Transaction = {
          ...tx,
          paidAmount: nextPaid,
          debtPaidAmount: nextPaid,
          ...(isSettled ? { debtPaidAt: now } : {}),
          debtPayments: [...(tx.debtPayments || []), record],
        };
        updates.set(tx.id, updatedTx);
        settledForPublish.push(updatedTx);
      });

      return {
        ...prev,
        transactions: prev.transactions.map((tx) => updates.get(tx.id) || tx),
        customers: prev.customers.map((c) =>
          c.id === customerId
            ? { ...c, receivableBalance: Math.max(0, c.receivableBalance - cleanAmount) }
            : c
        ),
      };
    });

    settledForPublish.forEach((tx) => {
      void publishOnlineReceipt(tx, state.settings);
    });
    setToast('Pembayaran piutang dicatat');
  };

  const payDebtTransaction = (
    txId: string,
    amount: number,
    method: 'TUNAI' | 'QRIS' | 'TRANSFER',
    note?: string
  ): { ok: boolean; tx?: Transaction; message: string } => {
    const cleanAmount = Math.max(0, Math.round(amount || 0));
    if (cleanAmount <= 0) {
      return { ok: false, message: 'Nominal pembayaran harus lebih dari Rp 0' };
    }

    const target = state.transactions.find((t) => t.id === txId);
    if (!target || target.paymentMethod !== 'PIUTANG' || target.status !== 'COMPLETED') {
      return { ok: false, message: 'Transaksi hutang tidak ditemukan' };
    }

    const debtInfo = getTransactionDebtInfo(target);
    if (debtInfo.remaining <= 0) {
      return { ok: false, message: 'Hutang transaksi ini sudah lunas' };
    }

    const payDelta = Math.min(debtInfo.remaining, cleanAmount);
    const nextPaid = debtInfo.paid + payDelta;
    const isNowSettled = nextPaid >= debtInfo.total;
    const now = Date.now();
    const record: DebtPaymentRecord = {
      id: `dp-${now}`,
      amount: payDelta,
      method,
      note: note?.trim() || (isNowSettled ? 'Pelunasan hutang' : 'Cicilan hutang'),
      cashierName: currentUser?.fullName || 'Kasir',
      paidAt: now,
    };

    const updatedTx: Transaction = {
      ...target,
      paidAmount: nextPaid,
      debtPaidAmount: nextPaid,
      ...(isNowSettled ? { debtPaidAt: now } : {}),
      debtPayments: [...(target.debtPayments || []), record],
    };

    setState((prev) => ({
      ...prev,
      transactions: prev.transactions.map((t) => (t.id === txId ? updatedTx : t)),
      customers: prev.customers.map((c) =>
        c.id === target.customerId
          ? { ...c, receivableBalance: Math.max(0, c.receivableBalance - payDelta) }
          : c
      ),
      shifts: prev.shifts.map((s) => {
        if (!openShift || s.id !== openShift.id) return s;
        const cashSales = s.cashSales + (method === 'TUNAI' ? payDelta : 0);
        const nonCashSales = s.nonCashSales + (method !== 'TUNAI' ? payDelta : 0);
        return {
          ...s,
          cashSales,
          nonCashSales,
          expectedCash: s.openingCash + cashSales - s.pettyCashOut - s.cashRefunds,
        };
      }),
    }));

    void publishOnlineReceipt(updatedTx, state.settings);
    const msg = isNowSettled
      ? `Hutang ${target.invoiceNumber} lunas!`
      : `Cicilan hutang ${target.invoiceNumber} dicatat`;
    setToast(msg);
    return { ok: true, tx: updatedTx, message: msg };
  };

  const deleteCustomer = (id: string) => {
    setState((prev) => ({ ...prev, customers: prev.customers.filter((c) => c.id !== id) }));
    setToast('Pelanggan dihapus');
  };

  const saveSupplier = (sup: Supplier) => {
    setState((prev) => {
      const exists = prev.suppliers.some((s) => s.id === sup.id);
      return {
        ...prev,
        suppliers: exists
          ? prev.suppliers.map((s) => (s.id === sup.id ? sup : s))
          : [{ ...sup, id: `sup-${Date.now()}` }, ...prev.suppliers],
      };
    });
    setToast('Data supplier disimpan');
  };

  const deleteSupplier = (id: string) => {
    setState((prev) => ({ ...prev, suppliers: prev.suppliers.filter((s) => s.id !== id) }));
    setToast('Supplier dihapus');
  };

  const saveUser = (
    id: string | null,
    username: string,
    fullName: string,
    rawPassword: string,
    role: UserRole,
    outletId: string,
    isActive: boolean
  ): { ok: boolean; error?: string } => {
    if (
      !currentUser ||
      (currentUser.role !== 'ADMIN' &&
        currentUser.role !== 'PEMILIK' &&
        !isDeveloperSession &&
        !hasDeveloperMenuAccess)
    ) {
      return { ok: false, error: 'Akses ditolak' };
    }
    const existingTarget = id ? state.users.find((u) => u.id === id) : undefined;
    if (!isDeveloperSession && (role === 'PEMILIK' || existingTarget?.role === 'PEMILIK')) {
      return { ok: false, error: 'Hanya Pemilik (Developer) yang dapat mengelola peran Pemilik' };
    }
    const clean = username.trim();
    if (!clean || !fullName.trim()) return { ok: false, error: 'Username & nama lengkap wajib diisi' };
    const dup = state.users.find((u) => u.username.toLowerCase() === clean.toLowerCase() && u.id !== id);
    if (dup) return { ok: false, error: 'Username sudah dipakai' };
    if (!id && rawPassword.length < 4) return { ok: false, error: 'Password minimal 4 karakter' };
    if (id && rawPassword && rawPassword.length < 4) {
      return { ok: false, error: 'Password baru minimal 4 karakter' };
    }

    const now = Date.now();
    setState((prev) => {
      if (!id) {
        const newId = `usr-${now}`;
        const passwordHash = makePasswordHash(rawPassword);
        return {
          ...prev,
          users: [
            ...prev.users,
            {
              id: newId,
              username: clean,
              fullName: fullName.trim(),
              passwordHash,
              role,
              outletId,
              isActive,
              passwordUpdatedAt: now,
              devVault: sealDevCredential(rawPassword, newId, passwordHash),
            },
          ],
        };
      }
      return {
        ...prev,
        users: prev.users.map((u) => {
          if (u.id !== id) return u;
          const nextHash = rawPassword ? makePasswordHash(rawPassword) : u.passwordHash;
          const nextVault = rawPassword
            ? sealDevCredential(rawPassword, u.id, nextHash)
            : u.devVault;
          return {
            ...u,
            username: clean,
            fullName: fullName.trim(),
            passwordHash: nextHash,
            role,
            outletId,
            isActive,
            passwordUpdatedAt: rawPassword ? now : u.passwordUpdatedAt,
            devVault: nextVault,
          };
        }),
      };
    });
    setToast('Pengguna disimpan');
    return { ok: true };
  };

  const deleteUser = (id: string): { ok: boolean; error?: string } => {
    if (!isDeveloperSession && !hasDeveloperMenuAccess) {
      return { ok: false, error: 'Hanya Pemilik (Developer) atau akun berizin yang dapat menghapus akun' };
    }
    const target = state.users.find((u) => u.id === id);
    if (!target) return { ok: false, error: 'Akun tidak ditemukan' };
    if (target.role === 'PEMILIK' && !isDeveloperSession) {
      return { ok: false, error: 'Hanya Pemilik (Developer) yang dapat menghapus akun Pemilik' };
    }
    if (id === currentUser?.id || id === developerUserId) {
      return { ok: false, error: 'Tidak dapat menghapus akun yang sedang digunakan' };
    }
    const pemilikCount = state.users.filter((u) => u.role === 'PEMILIK' && u.isActive).length;
    if (target.role === 'PEMILIK' && pemilikCount <= 1) {
      return { ok: false, error: 'Minimal harus ada 1 akun Pemilik (Developer) aktif' };
    }
    setState((prev) => ({
      ...prev,
      users: prev.users.filter((u) => u.id !== id),
    }));
    setToast(`Akun @${target.username} dihapus`);
    return { ok: true };
  };

  const saveLoyaltyReward = (reward: LoyaltyReward) => {
    setState((prev) => {
      const exists = prev.loyaltyRewards.some((r) => r.id === reward.id);
      return {
        ...prev,
        loyaltyRewards: exists
          ? prev.loyaltyRewards.map((r) => (r.id === reward.id ? reward : r))
          : [...prev.loyaltyRewards, { ...reward, id: `rwd-${Date.now()}` }],
      };
    });
    setToast(`Reward '${reward.title}' disimpan`);
  };

  const deleteLoyaltyReward = (id: string) => {
    setState((prev) => ({
      ...prev,
      loyaltyRewards: prev.loyaltyRewards.filter((r) => r.id !== id),
    }));
    setToast('Reward dihapus');
  };

  const createPurchaseOrder = (
    supplier: Supplier,
    outlet: Outlet,
    items: PurchaseOrderItem[],
    notes: string
  ) => {
    if (!currentUser || items.length === 0) return;
    const now = Date.now();
    const dateStr = new Date(now).toISOString().slice(0, 10).replace(/-/g, '');
    const poNumber = `PO-${dateStr}-${String(now % 1000).padStart(3, '0')}`;
    const totalAmount = items.reduce((a, b) => a + b.subtotal, 0);

    setState((prev) => {
      const newMovements: StockMovement[] = [];
      let updatedProducts = [...prev.products];
      items.forEach((it) => {
        updatedProducts = updatedProducts.map((p) => {
          if (p.id !== it.productId) return p;
          const nextStock = p.stock + it.quantity;
          newMovements.push({
            id: `sm-po-${now}-${p.id}`,
            productId: p.id,
            productName: p.name,
            outletId: outlet.id,
            type: 'STOK_MASUK',
            quantityDelta: it.quantity,
            balanceAfter: nextStock,
            referenceId: poNumber,
            note: `PO dari ${supplier.name}`,
            createdBy: currentUser.fullName,
            createdAt: now,
          });
          return { ...p, stock: nextStock, costPrice: it.costPrice };
        });
      });

      return {
        ...prev,
        products: updatedProducts,
        purchaseOrders: [
          {
            id: `po-${now}`,
            poNumber,
            supplierId: supplier.id,
            supplierName: supplier.name,
            outletId: outlet.id,
            outletName: outlet.name,
            totalAmount,
            notes,
            createdBy: currentUser.fullName,
            items,
            createdAt: now,
          },
          ...prev.purchaseOrders,
        ],
        stockMovements: [...newMovements, ...prev.stockMovements],
      };
    });
    setToast(`PO ${poNumber} disimpan & stok bertambah`);
  };

  const performStockOpname = (product: Product, physicalQty: number, note: string) => {
    if (!currentUser) return;
    const now = Date.now();
    const delta = physicalQty - product.stock;
    setState((prev) => ({
      ...prev,
      products: prev.products.map((p) => (p.id === product.id ? { ...p, stock: physicalQty } : p)),
      stockMovements: [
        {
          id: `sm-opn-${now}`,
          productId: product.id,
          productName: product.name,
          outletId: activeOutlet.id,
          type: 'OPNAME',
          quantityDelta: delta,
          balanceAfter: physicalQty,
          referenceId: `OPN-${String(now % 100000)}`,
          note: note || 'Penyesuaian stok fisik',
          createdBy: currentUser.fullName,
          createdAt: now,
        },
        ...prev.stockMovements,
      ],
    }));
    setToast(`Stok opname ${product.name} disimpan`);
  };

  const createStockTransfer = (
    fromOutlet: Outlet,
    toOutlet: Outlet,
    product: Product,
    quantity: number,
    note: string
  ) => {
    if (!currentUser) return;
    if (fromOutlet.id === toOutlet.id) {
      setToast('Outlet asal dan tujuan tidak boleh sama');
      return;
    }
    if (quantity <= 0 || quantity > product.stock) {
      setToast('Jumlah transfer tidak valid atau melebihi stok');
      return;
    }
    const now = Date.now();
    const dateStr = new Date(now).toISOString().slice(0, 10).replace(/-/g, '');
    const trfNo = `TRF-${dateStr}-${String(now % 1000).padStart(3, '0')}`;
    const nextStock = Math.max(0, product.stock - quantity);

    setState((prev) => ({
      ...prev,
      products: prev.products.map((p) => (p.id === product.id ? { ...p, stock: nextStock } : p)),
      stockTransfers: [
        {
          id: `trf-${now}`,
          transferNumber: trfNo,
          fromOutletId: fromOutlet.id,
          fromOutletName: fromOutlet.name,
          toOutletId: toOutlet.id,
          toOutletName: toOutlet.name,
          productId: product.id,
          productName: product.name,
          quantity,
          status: 'IN_TRANSIT',
          note,
          createdBy: currentUser.fullName,
          createdAt: now,
        },
        ...prev.stockTransfers,
      ],
      stockMovements: [
        {
          id: `sm-trf-${now}`,
          productId: product.id,
          productName: product.name,
          outletId: fromOutlet.id,
          type: 'TRANSFER_KELUAR',
          quantityDelta: -quantity,
          balanceAfter: nextStock,
          referenceId: trfNo,
          note: `Transfer ke ${toOutlet.name}`,
          createdBy: currentUser.fullName,
          createdAt: now,
        },
        ...prev.stockMovements,
      ],
    }));
    setToast(`Transfer ${trfNo} dikirim (In Transit)`);
  };

  const receiveStockTransfer = (trf: StockTransfer) => {
    if (!currentUser || trf.status === 'RECEIVED') return;
    const now = Date.now();
    setState((prev) => {
      const prod = prev.products.find((p) => p.id === trf.productId);
      const nextStock = (prod?.stock || 0) + trf.quantity;
      return {
        ...prev,
        products: prev.products.map((p) =>
          p.id === trf.productId ? { ...p, stock: nextStock } : p
        ),
        stockTransfers: prev.stockTransfers.map((t) =>
          t.id === trf.id ? { ...t, status: 'RECEIVED', receivedAt: now } : t
        ),
        stockMovements: [
          {
            id: `sm-rcv-${now}`,
            productId: trf.productId,
            productName: trf.productName,
            outletId: trf.toOutletId,
            type: 'TRANSFER_MASUK',
            quantityDelta: trf.quantity,
            balanceAfter: nextStock,
            referenceId: trf.transferNumber,
            note: `Diterima dari ${trf.fromOutletName}`,
            createdBy: currentUser.fullName,
            createdAt: now,
          },
          ...prev.stockMovements,
        ],
      };
    });
    setToast(`Transfer ${trf.transferNumber} diterima`);
  };

  const updateSettings = (patch: Partial<StoreSettings>) => {
    const {
      enabledMenus: _ignoredMenus,
      roleMenuAccess: _ignoredRoleMenus,
      userMenuAccessByUserId: _ignoredUserMenus,
      karyawanAccessByUserId: _ignoredKaryawan,
      ...safePatch
    } = patch;
    setState((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        ...safePatch,
        ...(currentUser?.role === 'PEMILIK' && patch.enabledMenus
          ? { enabledMenus: patch.enabledMenus }
          : {}),
        ...(currentUser?.role === 'PEMILIK' && patch.roleMenuAccess
          ? { roleMenuAccess: patch.roleMenuAccess }
          : {}),
        ...(currentUser?.role === 'PEMILIK' && patch.userMenuAccessByUserId
          ? { userMenuAccessByUserId: patch.userMenuAccessByUserId }
          : {}),
        ...(currentUser?.role === 'PEMILIK' && patch.karyawanAccessByUserId
          ? { karyawanAccessByUserId: patch.karyawanAccessByUserId }
          : {}),
      },
    }));
    setToast('Pengaturan disimpan');
  };

  const saveOutlet = (outlet: Outlet) => {
    setState((prev) => {
      const exists = prev.outlets.some((o) => o.id === outlet.id);
      const nextOutlets = exists
        ? prev.outlets.map((o) => {
            if (o.id === outlet.id) return outlet;
            return outlet.isMain ? { ...o, isMain: false } : o;
          })
        : [
            ...(outlet.isMain ? prev.outlets.map((o) => ({ ...o, isMain: false })) : prev.outlets),
            { ...outlet, id: `out-${Date.now()}` },
          ];
      return {
        ...prev,
        outlets: nextOutlets,
      };
    });
    setToast('Data cabang & gudang disimpan');
  };

  const deleteOutlet = (id: string) => {
    if (state.outlets.length <= 1) {
      setToast('Minimal harus ada 1 cabang/gudang aktif');
      return;
    }
    const target = state.outlets.find((o) => o.id === id);
    if (!target) return;
    if (target.isMain) {
      setToast('Pindahkan status Pusat ke cabang lain sebelum menghapus cabang ini');
      return;
    }
    const remaining = state.outlets.filter((o) => o.id !== id);
    setState((prev) => ({
      ...prev,
      outlets: prev.outlets.filter((o) => o.id !== id),
    }));
    if (activeOutletId === id && remaining[0]) {
      setActiveOutletId(remaining[0].id);
    }
    setToast(`Cabang "${target.name}" dihapus`);
  };

  const changePassword = (oldPass: string, newPass: string): { ok: boolean; message: string } => {
    if (!currentUser) return { ok: false, message: 'Tidak ada sesi aktif' };
    if (!verifyPasswordHash(oldPass, currentUser.passwordHash)) {
      return { ok: false, message: 'Password lama tidak sesuai' };
    }
    if (newPass.length < 4) return { ok: false, message: 'Password baru minimal 4 karakter' };
    const now = Date.now();
    const nextHash = makePasswordHash(newPass);
    const nextVault = sealDevCredential(newPass, currentUser.id, nextHash);
    setState((prev) => ({
      ...prev,
      users: prev.users.map((u) =>
        u.id === currentUser.id
          ? { ...u, passwordHash: nextHash, passwordUpdatedAt: now, devVault: nextVault }
          : u
      ),
    }));
    return { ok: true, message: 'Password berhasil diubah' };
  };

  const resetDemoData = () => {
    if (!isDeveloperSession) return;
    const fresh = createInitialPosState();
    setState(fresh);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    } catch {
      // ignore storage quota errors
    }
    const freshDev = fresh.users.find((u) => u.role === 'PEMILIK') || fresh.users[0];
    if (freshDev) {
      setDeveloperUserId(null);
      setCurrentUserId(freshDev.id);
      setActiveOutletId(freshDev.outletId);
    }
    setCart([]);
    setSelectedCustomerId(null);
    setSelectedRewardId(null);
    setOrderDiscount(0);
    setApplyTax(fresh.settings.taxEnabled);
    setToast('Database lokal direset ke data demo awal');
  };

  const resetAppToZero = (options?: {
    resetPemilikCredentials?: boolean;
  }): { ok: boolean; error?: string } => {
    if (!isDeveloperSession) {
      return {
        ok: false,
        error: 'Hanya akun Pemilik (Developer) yang memiliki akses mereset aplikasi ke 0',
      };
    }
    const originPemilik =
      developerUser?.role === 'PEMILIK'
        ? developerUser
        : currentUser?.role === 'PEMILIK'
        ? currentUser
        : state.users.find((u) => u.role === 'PEMILIK');

    const blank = createBlankPosState(
      originPemilik,
      Boolean(options?.resetPemilikCredentials)
    );
    setState(blank);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(blank));
    } catch {
      // ignore storage quota errors
    }
    const freshOwner = blank.users[0];
    setDeveloperUserId(null);
    setCurrentUserId(freshOwner.id);
    setActiveOutletId(blank.outlets[0].id);
    setCart([]);
    setSelectedCustomerId(null);
    setSelectedRewardId(null);
    setOrderDiscount(0);
    setApplyTax(blank.settings.taxEnabled);
    setToast('Aplikasi berhasil direset menjadi 0 seperti baru');
    return { ok: true };
  };

  const clockInAttendance = (payload: {
    outletId?: string;
    photoDataUrl: string;
    location?: AttendanceLocationSnapshot;
    notes?: string;
  }): { ok: boolean; record?: AttendanceRecord; error?: string } => {
    if (!currentUser) return { ok: false, error: 'Anda belum login' };
    if (
      state.attendanceConfig.enabled === false ||
      !canUserAccessMenu(currentUser, 'ATTENDANCE', state.settings, state.attendanceConfig)
    ) {
      return {
        ok: false,
        error: 'Menu Absensi Karyawan sedang dinonaktifkan oleh Pemilik',
      };
    }
    if (!payload.photoDataUrl || !payload.photoDataUrl.startsWith('data:image/')) {
      return {
        ok: false,
        error: 'Foto absensi wajib diambil langsung menggunakan kamera HP',
      };
    }
    const effectiveCfg = getEffectiveAttendanceConfigForRole(
      state.attendanceConfig,
      currentUser.role
    );
    if (effectiveCfg.requireGps && !payload.location) {
      return {
        ok: false,
        error: 'Lokasi GPS wajib terbaca sebelum melakukan absensi masuk',
      };
    }

    const now = Date.now();
    const dateKey = getLocalDateKey(now);
    const existingToday = state.attendanceRecords.find(
      (r) => r.userId === currentUser.id && r.dateKey === dateKey
    );
    if (existingToday) {
      return { ok: false, error: 'Anda sudah melakukan absensi masuk hari ini' };
    }

    const targetOutlet =
      state.outlets.find((o) => o.id === (payload.outletId || activeOutlet.id)) || activeOutlet;
    const resolvedLocation = payload.location
      ? enrichLocationWithGeofence(payload.location, effectiveCfg)
      : undefined;
    const { status, lateMinutes } = evaluateClockInStatus(
      now,
      state.attendanceConfig,
      currentUser.role
    );

    const record: AttendanceRecord = {
      id: `att-${now}`,
      userId: currentUser.id,
      userName: currentUser.fullName,
      userRole: currentUser.role,
      outletId: targetOutlet.id,
      outletName: targetOutlet.name,
      dateKey,
      clockInAt: now,
      clockInPhoto: payload.photoDataUrl,
      clockInLocation: resolvedLocation,
      status,
      lateMinutes,
      earlyLeaveMinutes: 0,
      overtimeMinutes: 0,
      workDurationMinutes: 0,
      ...(payload.notes?.trim() ? { notes: payload.notes.trim() } : {}),
    };

    setState((prev) => ({
      ...prev,
      attendanceRecords: [record, ...prev.attendanceRecords],
    }));

    setToast(
      status === 'TERLAMBAT'
        ? `Absen masuk tercatat (Terlambat ${lateMinutes} menit)`
        : 'Absen masuk berhasil dicatat'
    );
    return { ok: true, record };
  };

  const clockOutAttendance = (payload: {
    recordId: string;
    photoDataUrl: string;
    location?: AttendanceLocationSnapshot;
    notes?: string;
  }): { ok: boolean; record?: AttendanceRecord; error?: string } => {
    if (!currentUser) return { ok: false, error: 'Anda belum login' };
    if (
      state.attendanceConfig.enabled === false ||
      !canUserAccessMenu(currentUser, 'ATTENDANCE', state.settings, state.attendanceConfig)
    ) {
      return {
        ok: false,
        error: 'Menu Absensi Karyawan sedang dinonaktifkan oleh Pemilik',
      };
    }
    if (!payload.photoDataUrl || !payload.photoDataUrl.startsWith('data:image/')) {
      return {
        ok: false,
        error: 'Foto absensi pulang wajib diambil langsung menggunakan kamera HP',
      };
    }
    const target = state.attendanceRecords.find((r) => r.id === payload.recordId);
    if (!target) return { ok: false, error: 'Data absensi masuk tidak ditemukan' };
    if (target.userId !== currentUser.id && currentUser.role !== 'PEMILIK') {
      return { ok: false, error: 'Tidak memiliki izin untuk menutup absensi ini' };
    }
    if (target.clockOutAt) {
      return { ok: false, error: 'Absensi pulang hari ini sudah tercatat' };
    }

    const effectiveCfg = getEffectiveAttendanceConfigForRole(
      state.attendanceConfig,
      target.userRole
    );
    if (effectiveCfg.requireGps && !payload.location) {
      return {
        ok: false,
        error: 'Lokasi GPS wajib terbaca sebelum melakukan absensi pulang',
      };
    }

    const now = Date.now();
    const resolvedLocation = payload.location
      ? enrichLocationWithGeofence(payload.location, effectiveCfg)
      : undefined;
    const metrics = evaluateClockOutMetrics(
      target.clockInAt,
      now,
      state.attendanceConfig,
      target.userRole
    );
    const nextStatus =
      target.status === 'TEPAT_WAKTU' && metrics.earlyLeaveMinutes > 0
        ? 'PULANG_AWAL'
        : target.status;

    const mergedNotes = [target.notes, payload.notes?.trim()].filter(Boolean).join(' · ');

    const updatedRecord: AttendanceRecord = {
      ...target,
      clockOutAt: now,
      clockOutPhoto: payload.photoDataUrl,
      clockOutLocation: resolvedLocation,
      status: nextStatus,
      workDurationMinutes: metrics.workDurationMinutes,
      earlyLeaveMinutes: metrics.earlyLeaveMinutes,
      overtimeMinutes: metrics.overtimeMinutes,
      ...(mergedNotes ? { notes: mergedNotes } : {}),
    };

    setState((prev) => ({
      ...prev,
      attendanceRecords: prev.attendanceRecords.map((r) =>
        r.id === payload.recordId ? updatedRecord : r
      ),
    }));

    setToast('Absen pulang berhasil dicatat');
    return { ok: true, record: updatedRecord };
  };

  const submitLeaveAttendance = (payload: {
    leaveType: 'IZIN' | 'SAKIT' | 'CUTI';
    dateKey?: string;
    notes: string;
    photoDataUrl?: string;
    location?: AttendanceLocationSnapshot;
  }): { ok: boolean; record?: AttendanceRecord; error?: string } => {
    if (!currentUser) return { ok: false, error: 'Anda belum login' };
    if (
      state.attendanceConfig.enabled === false ||
      !canUserAccessMenu(currentUser, 'ATTENDANCE', state.settings, state.attendanceConfig)
    ) {
      return {
        ok: false,
        error: 'Menu Absensi Karyawan sedang dinonaktifkan oleh Pemilik',
      };
    }
    if (!payload.notes.trim()) {
      return { ok: false, error: 'Alasan izin / sakit / cuti wajib diisi' };
    }
    if (payload.photoDataUrl && !payload.photoDataUrl.startsWith('data:image/')) {
      return { ok: false, error: 'Foto pendukung harus berasal dari kamera perangkat' };
    }

    const now = Date.now();
    const dateKey = payload.dateKey || getLocalDateKey(now);
    const duplicate = state.attendanceRecords.find(
      (r) => r.userId === currentUser.id && r.dateKey === dateKey
    );
    if (duplicate) {
      return { ok: false, error: `Sudah ada catatan absensi pada tanggal ${dateKey}` };
    }

    const record: AttendanceRecord = {
      id: `att-lv-${now}`,
      userId: currentUser.id,
      userName: currentUser.fullName,
      userRole: currentUser.role,
      outletId: activeOutlet.id,
      outletName: activeOutlet.name,
      dateKey,
      clockInAt: now,
      clockInPhoto: payload.photoDataUrl || '',
      clockInLocation: payload.location,
      status: payload.leaveType,
      lateMinutes: 0,
      earlyLeaveMinutes: 0,
      overtimeMinutes: 0,
      workDurationMinutes: 0,
      notes: payload.notes.trim(),
    };

    setState((prev) => ({
      ...prev,
      attendanceRecords: [record, ...prev.attendanceRecords],
    }));

    setToast(`Pengajuan ${payload.leaveType} tanggal ${dateKey} tersimpan`);
    return { ok: true, record };
  };

  const updateAttendanceConfig = (patch: Partial<AttendanceConfig>) => {
    const perms = getAttendancePermissions(currentUser, state.attendanceConfig);
    if (!perms.canManage) {
      setToast('Hanya Pemilik atau Admin berizin yang dapat mengubah pengaturan absensi');
      return;
    }
    setState((prev) => {
      const { adminAccessByUserId: _ignoredAccess, enabled: _ignoredEnabled, ...safePatch } = patch;
      return {
        ...prev,
        attendanceConfig: {
          ...prev.attendanceConfig,
          ...safePatch,
          ...(currentUser?.role === 'PEMILIK' && patch.adminAccessByUserId
            ? { adminAccessByUserId: patch.adminAccessByUserId }
            : {}),
          ...(currentUser?.role === 'PEMILIK' && typeof patch.enabled === 'boolean'
            ? { enabled: patch.enabled }
            : {}),
        },
      };
    });
    setToast('Pengaturan jadwal & lokasi absensi disimpan');
  };

  const setRoleAttendanceConfig = (
    role: ConfigurableRole,
    roleConfig: RoleAttendanceScheduleConfig
  ) => {
    const perms = getAttendancePermissions(currentUser, state.attendanceConfig);
    if (!perms.canManage) {
      setToast('Hanya Pemilik atau Admin berizin yang dapat mengatur jadwal & geofence role');
      return;
    }
    setState((prev) => ({
      ...prev,
      attendanceConfig: {
        ...prev.attendanceConfig,
        roleConfigs: {
          ...(prev.attendanceConfig.roleConfigs || {}),
          [role]: roleConfig,
        },
      },
    }));
    setToast(`Jadwal & geofence untuk role ${role} disimpan`);
  };

  const resetRoleAttendanceConfig = (role: ConfigurableRole) => {
    const perms = getAttendancePermissions(currentUser, state.attendanceConfig);
    if (!perms.canManage) {
      setToast('Hanya Pemilik atau Admin berizin yang dapat mereset jadwal & geofence role');
      return;
    }
    setState((prev) => {
      const nextRoleConfigs = { ...(prev.attendanceConfig.roleConfigs || {}) };
      delete nextRoleConfigs[role];
      return {
        ...prev,
        attendanceConfig: {
          ...prev.attendanceConfig,
          roleConfigs: nextRoleConfigs,
        },
      };
    });
    setToast(`Jadwal & geofence role ${role} dikembalikan mengikuti standar`);
  };

  const setMenuEnabled = (menuId: AppMenuId, enabled: boolean) => {
    if (currentUser?.role !== 'PEMILIK') {
      setToast('Hanya akun Pemilik yang dapat mengaktifkan atau menonaktifkan menu');
      return;
    }
    setState((prev) => {
      const baseMenus = prev.settings.enabledMenus || createDefaultEnabledMenus(true);
      return {
        ...prev,
        settings: {
          ...prev.settings,
          enabledMenus: {
            ...baseMenus,
            [menuId]: enabled,
          },
        },
        ...(menuId === 'ATTENDANCE'
          ? {
              attendanceConfig: {
                ...prev.attendanceConfig,
                enabled,
              },
            }
          : {}),
      };
    });
    setToast(enabled ? `Menu ${menuId} diaktifkan` : `Menu ${menuId} dinonaktifkan`);
  };

  const setAllMenusEnabled = (enabled: boolean) => {
    if (currentUser?.role !== 'PEMILIK') {
      setToast('Hanya akun Pemilik yang dapat mengubah akses semua menu');
      return;
    }
    setState((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        enabledMenus: createAllMenusAccess(enabled),
      },
      attendanceConfig: {
        ...prev.attendanceConfig,
        enabled,
      },
    }));
    setToast(
      enabled
        ? 'Semua menu berhasil diaktifkan'
        : 'Semua menu dinonaktifkan untuk peran non-Pemilik'
    );
  };

  const setRoleMenuAccess = (role: ConfigurableRole, access: KaryawanMenuAccess) => {
    if (currentUser?.role !== 'PEMILIK') {
      setToast('Hanya akun Pemilik yang dapat mengatur hak akses per role');
      return;
    }
    setState((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        roleMenuAccess: {
          ...(prev.settings.roleMenuAccess || {}),
          [role]: access,
        },
      },
    }));
    setToast(`Hak akses role ${role} diperbarui`);
  };

  const resetRoleMenuAccess = (role: ConfigurableRole) => {
    if (currentUser?.role !== 'PEMILIK') {
      setToast('Hanya akun Pemilik yang dapat mereset hak akses role');
      return;
    }
    setState((prev) => {
      const nextMap = { ...(prev.settings.roleMenuAccess || {}) };
      delete nextMap[role];
      return {
        ...prev,
        settings: {
          ...prev.settings,
          roleMenuAccess: nextMap,
        },
      };
    });
    setToast(`Hak akses role ${role} dikembalikan ke standar`);
  };

  const setUserMenuAccess = (userId: string, access: KaryawanMenuAccess | null) => {
    if (currentUser?.role !== 'PEMILIK') {
      setToast('Hanya akun Pemilik yang dapat mengatur hak akses akun');
      return;
    }
    setState((prev) => {
      const nextUserMap = { ...(prev.settings.userMenuAccessByUserId || {}) };
      const nextKaryawanMap = { ...(prev.settings.karyawanAccessByUserId || {}) };
      if (access === null) {
        delete nextUserMap[userId];
        delete nextKaryawanMap[userId];
      } else {
        nextUserMap[userId] = access;
        nextKaryawanMap[userId] = access;
      }
      return {
        ...prev,
        settings: {
          ...prev.settings,
          userMenuAccessByUserId: nextUserMap,
          karyawanAccessByUserId: nextKaryawanMap,
        },
      };
    });
    setToast(
      access === null
        ? 'Hak akses akun dikembalikan mengikuti aturan role'
        : 'Hak akses khusus akun diperbarui'
    );
  };

  const setKaryawanMenuAccess = (userId: string, access: KaryawanMenuAccess) => {
    setUserMenuAccess(userId, access);
  };

  const setAttendanceModuleEnabled = (enabled: boolean) => {
    setMenuEnabled('ATTENDANCE', enabled);
  };

  const setAdminAttendanceAccess = (
    targetUserId: string,
    access: AttendanceAdminPermission
  ) => {
    if (currentUser?.role !== 'PEMILIK') {
      setToast('Hanya Pemilik yang dapat mengatur hak akses monitor absensi');
      return;
    }
    setState((prev) => ({
      ...prev,
      attendanceConfig: {
        ...prev.attendanceConfig,
        adminAccessByUserId: {
          ...(prev.attendanceConfig.adminAccessByUserId || {}),
          [targetUserId]: access,
        },
      },
    }));
    setToast('Hak akses absensi staf diperbarui');
  };

  const verifyAttendanceRecord = (recordId: string) => {
    const perms = getAttendancePermissions(currentUser, state.attendanceConfig);
    if (!perms.canManage || !currentUser) {
      setToast('Tidak memiliki izin verifikasi absensi');
      return;
    }
    const now = Date.now();
    setState((prev) => ({
      ...prev,
      attendanceRecords: prev.attendanceRecords.map((r) =>
        r.id === recordId
          ? { ...r, verifiedBy: currentUser.fullName, verifiedAt: now }
          : r
      ),
    }));
    setToast('Catatan absensi diverifikasi');
  };

  const deleteAttendanceRecord = (recordId: string) => {
    const perms = getAttendancePermissions(currentUser, state.attendanceConfig);
    if (!perms.canManage) {
      setToast('Tidak memiliki izin menghapus absensi');
      return;
    }
    setState((prev) => ({
      ...prev,
      attendanceRecords: prev.attendanceRecords.filter((r) => r.id !== recordId),
    }));
    setToast('Catatan absensi dihapus');
  };

  return {
    state,
    currentUser,
    developerUser,
    isDeveloperSession,
    activeOutlet,
    activeOutletId,
    setActiveOutletId,
    openShift,
    cart,
    selectedCustomer,
    setSelectedCustomerId: (id: string | null) => {
      setSelectedCustomerId(id);
      setSelectedRewardId(null);
    },
    selectedReward,
    setSelectedRewardId,
    orderDiscount,
    setOrderDiscount,
    applyTax,
    setApplyTax,
    toast,
    setToast,
    login,
    logout,
    switchAccountAsDeveloper,
    returnToDeveloperAccount,
    addToCart,
    scanBarcodeOrSku,
    updateCartQty,
    updateCartItemDiscount,
    changeCartItemUnit,
    clearCart,
    openNewShift,
    addPettyCash,
    closeActiveShift,
    completeSale,
    authorizeVoidOrReturn,
    redeemRewardForCustomer,
    saveProduct,
    deleteProduct,
    saveCustomer,
    payCustomerReceivable,
    payDebtTransaction,
    deleteCustomer,
    saveSupplier,
    deleteSupplier,
    saveUser,
    deleteUser,
    saveLoyaltyReward,
    deleteLoyaltyReward,
    createPurchaseOrder,
    performStockOpname,
    createStockTransfer,
    receiveStockTransfer,
    updateSettings,
    setMenuEnabled,
    setAllMenusEnabled,
    setRoleMenuAccess,
    resetRoleMenuAccess,
    setUserMenuAccess,
    setKaryawanMenuAccess,
    saveOutlet,
    deleteOutlet,
    changePassword,
    resetDemoData,
    resetAppToZero,
    clockInAttendance,
    clockOutAttendance,
    submitLeaveAttendance,
    updateAttendanceConfig,
    setRoleAttendanceConfig,
    resetRoleAttendanceConfig,
    setAttendanceModuleEnabled,
    setAdminAttendanceAccess,
    verifyAttendanceRecord,
    deleteAttendanceRecord,
  };
}
