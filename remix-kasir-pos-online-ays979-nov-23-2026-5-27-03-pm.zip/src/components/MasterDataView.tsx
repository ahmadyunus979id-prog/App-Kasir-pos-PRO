import React, { useState } from 'react';
import {
  Award,
  Camera,
  Check,
  Copy,
  Edit2,
  Eye,
  EyeOff,
  Gift,
  KeyRound,
  LogIn,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { CameraScannerModal } from './CameraScannerModal';
import type {
  BomItem,
  Customer,
  LoyaltyReward,
  LoyaltyRewardType,
  Outlet,
  PointHistory,
  Product,
  ProductUnitOption,
  PurchaseOrder,
  Supplier,
  Transaction,
  User,
  UserRole,
} from '../types/pos';
import {
  checkUserPassword,
  detectKnownDemoPassword,
  formatDateTime,
  formatNumber,
  formatRupiah,
  generateTempPassword,
  revealDevCredential,
} from '../utils/formatters';

interface MasterDataViewProps {
  currentUser: User;
  isDeveloper: boolean;
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  users: User[];
  outlets: Outlet[];
  transactions: Transaction[];
  purchaseOrders: PurchaseOrder[];
  loyaltyRewards: LoyaltyReward[];
  pointHistory: PointHistory[];
  onSaveProduct: (prod: Product) => void;
  onDeleteProduct: (id: string) => void;
  onSaveCustomer: (cust: Customer) => void;
  onPayReceivable: (customerId: string, amount: number) => void;
  onDeleteCustomer: (id: string) => void;
  onRedeemReward: (cust: Customer, reward: LoyaltyReward) => void;
  onSaveReward: (reward: LoyaltyReward) => void;
  onDeleteReward: (id: string) => void;
  onSaveSupplier: (sup: Supplier) => void;
  onDeleteSupplier: (id: string) => void;
  onSaveUser: (
    id: string | null,
    username: string,
    fullName: string,
    password: string,
    role: UserRole,
    outletId: string,
    isActive: boolean
  ) => { ok: boolean; error?: string };
  onDeleteUser: (id: string) => { ok: boolean; error?: string };
  onSwitchAccount: (targetUserId: string) => { ok: boolean; error?: string };
  onNotify: (msg: string) => void;
}

type MasterTab = 'PRODUCTS' | 'CUSTOMERS' | 'SUPPLIERS' | 'USERS';

export const MasterDataView: React.FC<MasterDataViewProps> = ({
  currentUser,
  isDeveloper,
  products,
  customers,
  suppliers,
  users,
  outlets,
  transactions,
  purchaseOrders,
  loyaltyRewards,
  pointHistory,
  onSaveProduct,
  onDeleteProduct,
  onSaveCustomer,
  onPayReceivable,
  onDeleteCustomer,
  onRedeemReward,
  onSaveReward,
  onDeleteReward,
  onSaveSupplier,
  onDeleteSupplier,
  onSaveUser,
  onDeleteUser,
  onSwitchAccount,
  onNotify,
}) => {
  const canManageUsers =
    isDeveloper || currentUser.role === 'ADMIN' || currentUser.role === 'PEMILIK';
  const [tab, setTab] = useState<MasterTab>(
    currentUser.role === 'KASIR' || currentUser.role === 'KARYAWAN' ? 'CUSTOMERS' : 'PRODUCTS'
  );
  const [query, setQuery] = useState('');

  // Modals
  const [editingProduct, setEditingProduct] = useState<Product | null | undefined>(undefined);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null | undefined>(undefined);
  const [profileCustomerId, setProfileCustomerId] = useState<string | null>(null);
  const [profileTab, setProfileTab] = useState<'REDEEM' | 'HISTORY' | 'ORDERS'>('REDEEM');
  const [showRewardsModal, setShowRewardsModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null | undefined>(undefined);
  const [editingUser, setEditingUser] = useState<User | null | undefined>(undefined);
  const [passwordInspectUserId, setPasswordInspectUserId] = useState<string | null>(null);
  const [revealedPassCards, setRevealedPassCards] = useState<Record<string, boolean>>({});

  const passwordInspectUser = users.find((u) => u.id === passwordInspectUserId) || null;

  const profileCustomer = customers.find((c) => c.id === profileCustomerId) || null;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800">
          {(
            [
              { id: 'PRODUCTS', label: 'Produk / Item' },
              { id: 'CUSTOMERS', label: 'Pelanggan & Poin' },
              { id: 'SUPPLIERS', label: 'Supplier' },
              ...(canManageUsers ? [{ id: 'USERS' as const, label: 'Pengguna & Akses' }] : []),
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setTab(t.id);
                setQuery('');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                tab === t.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {tab === 'CUSTOMERS' && (
            <button
              type="button"
              onClick={() => setShowRewardsModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-400 text-xs font-semibold hover:bg-teal-50 dark:hover:bg-teal-950/30 cursor-pointer whitespace-nowrap"
            >
              <Gift className="w-4 h-4" />
              <span>Katalog Hadiah Poin ({loyaltyRewards.length})</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              if (tab === 'PRODUCTS') setEditingProduct(null);
              if (tab === 'CUSTOMERS') setEditingCustomer(null);
              if (tab === 'SUPPLIERS') setEditingSupplier(null);
              if (tab === 'USERS') setEditingUser(null);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Baru</span>
          </button>
        </div>
      </div>

      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Cari data..."
          className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
        />
      </div>

      {/* PRODUCTS TAB */}
      {tab === 'PRODUCTS' && (
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold">Produk</th>
                  <th className="text-left px-4 py-3 font-semibold">SKU / Barcode</th>
                  <th className="text-left px-4 py-3 font-semibold">Kategori / Merek</th>
                  <th className="text-right px-4 py-3 font-semibold">Harga Beli</th>
                  <th className="text-right px-4 py-3 font-semibold">Harga Jual</th>
                  <th className="text-right px-4 py-3 font-semibold">Stok</th>
                  <th className="text-right px-4 py-3 font-semibold">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {products.filter(
                  (p) =>
                    !query.trim() ||
                    p.name.toLowerCase().includes(query.toLowerCase()) ||
                    p.sku.toLowerCase().includes(query.toLowerCase())
                ).length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-sm text-slate-500 dark:text-slate-400">
                      {products.length === 0
                        ? 'Belum ada produk. Klik "Tambah Baru" untuk menambahkan produk pertama.'
                        : 'Tidak ada produk yang cocok dengan pencarian.'}
                    </td>
                  </tr>
                ) : (
                  products
                    .filter(
                      (p) =>
                        !query.trim() ||
                        p.name.toLowerCase().includes(query.toLowerCase()) ||
                        p.sku.toLowerCase().includes(query.toLowerCase())
                    )
                    .map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-3">
                            {p.photoUrl ? (
                              <img
                                src={p.photoUrl}
                                alt={p.name}
                                className="w-10 h-10 rounded-lg object-cover shrink-0"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-500 shrink-0">
                                {p.name.slice(0, 2).toUpperCase()}
                              </div>
                            )}
                            <div>
                              <p className="font-semibold text-slate-900 dark:text-slate-100">{p.name}</p>
                              <p className="text-xs text-slate-500">
                                {p.units.length} satuan{p.isBom ? ' · Resep BOM' : ''}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-2.5 font-mono text-xs">
                          <div>{p.sku}</div>
                          <div className="text-slate-400">{p.barcode}</div>
                        </td>
                        <td className="px-4 py-2.5 text-slate-600 dark:text-slate-300">
                          {p.category} · {p.brand}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono">{formatRupiah(p.costPrice)}</td>
                        <td className="px-4 py-2.5 text-right font-mono font-semibold text-teal-700 dark:text-teal-400">
                          {formatRupiah(p.sellPrice)}/{p.baseUnit}
                        </td>
                        <td
                          className={`px-4 py-2.5 text-right font-mono font-semibold ${
                            p.stock <= p.minStock ? 'text-red-600' : 'text-emerald-600'
                          }`}
                        >
                          {formatNumber(p.stock)} {p.baseUnit}
                        </td>
                        <td className="px-4 py-2.5 text-right">
                          <div className="inline-flex gap-1">
                            <button
                              type="button"
                              onClick={() => setEditingProduct(p)}
                              className="p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteProduct(p.id)}
                              className="p-1.5 rounded text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CUSTOMERS TAB */}
      {tab === 'CUSTOMERS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {customers.filter(
            (c) =>
              !query.trim() ||
              c.name.toLowerCase().includes(query.toLowerCase()) ||
              c.whatsapp.includes(query)
          ).length === 0 ? (
            <div className="md:col-span-2 lg:col-span-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {customers.length === 0
                ? 'Belum ada data pelanggan. Klik "Tambah Baru" untuk mendaftarkan pelanggan.'
                : 'Tidak ada pelanggan yang cocok dengan pencarian.'}
            </div>
          ) : (
            customers
              .filter(
                (c) =>
                  !query.trim() ||
                  c.name.toLowerCase().includes(query.toLowerCase()) ||
                  c.whatsapp.includes(query)
              )
              .map((cust) => (
                <div
                  key={cust.id}
                  onClick={() => {
                    setProfileCustomerId(cust.id);
                    setProfileTab('REDEEM');
                  }}
                  className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-600 p-4 space-y-2.5 cursor-pointer transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-slate-100">{cust.name}</h4>
                      <p className="text-xs text-slate-500">WA: {cust.whatsapp} · {cust.address}</p>
                    </div>
                    <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={() => setEditingCustomer(cust)}
                        className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteCustomer(cust.id)}
                        className="p-1.5 rounded text-red-600 hover:bg-red-50 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-teal-700 dark:text-teal-400">
                      {cust.points} Poin Loyalitas
                    </span>
                    <span className="font-mono text-slate-600 dark:text-slate-300">
                      Belanja: {formatRupiah(cust.totalSpent)}
                    </span>
                  </div>
                  {cust.receivableBalance > 0 && (
                    <p className="text-xs font-mono font-semibold text-red-600">
                      Piutang: {formatRupiah(cust.receivableBalance)}
                    </p>
                  )}
                  <p className="text-[11px] font-semibold text-teal-700 dark:text-teal-400">
                    Klik untuk tukar poin & lihat riwayat →
                  </p>
                </div>
              ))
          )}
        </div>
      )}

      {/* SUPPLIERS TAB */}
      {tab === 'SUPPLIERS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {suppliers.filter(
            (s) => !query.trim() || s.name.toLowerCase().includes(query.toLowerCase())
          ).length === 0 ? (
            <div className="md:col-span-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {suppliers.length === 0
                ? 'Belum ada data supplier. Klik "Tambah Baru" untuk menambahkan pemasok.'
                : 'Tidak ada supplier yang cocok dengan pencarian.'}
            </div>
          ) : (
            suppliers
              .filter((s) => !query.trim() || s.name.toLowerCase().includes(query.toLowerCase()))
              .map((sup) => {
                const poList = purchaseOrders.filter((p) => p.supplierId === sup.id);
                return (
                  <div
                    key={sup.id}
                    className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-2"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-slate-100">{sup.name}</h4>
                        <p className="text-xs text-slate-500">{sup.phone} · {sup.address}</p>
                      </div>
                      <div className="flex gap-1">
                        <button
                          type="button"
                          onClick={() => setEditingSupplier(sup)}
                          className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteSupplier(sup.id)}
                          className="p-1.5 rounded text-red-600 hover:bg-red-50 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    {sup.notes && <p className="text-xs text-slate-600 dark:text-slate-300">{sup.notes}</p>}
                    <p className="text-xs font-medium text-teal-700 dark:text-teal-400">
                      {poList.length} riwayat pasokan PO
                    </p>
                  </div>
                );
              })
          )}
        </div>
      )}

      {/* USERS TAB */}
      {tab === 'USERS' && canManageUsers && (
        <div className="space-y-4">
          {isDeveloper && (
            <div className="rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-indigo-700 dark:text-indigo-300 shrink-0 mt-0.5" />
                <div className="text-xs space-y-0.5">
                  <p className="font-bold text-indigo-950 dark:text-indigo-100 text-sm">
                    Panel Kontrol Developer (Pemilik)
                  </p>
                  <p className="text-indigo-800 dark:text-indigo-300">
                    Anda dapat langsung mengakses akun staf mana pun, memeriksa kecocokan sandi, dan mereset sandi sementara tanpa harus keluar sesi.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-3 text-xs font-mono shrink-0 text-indigo-900 dark:text-indigo-200">
                <span>Total: <strong>{users.length}</strong></span>
                <span>Aktif: <strong>{users.filter((u) => u.isActive).length}</strong></span>
                <span>
                  Sandi Demo:{' '}
                  <strong>
                    {users.filter((u) => detectKnownDemoPassword(u.passwordHash) !== null).length}
                  </strong>
                </span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {users
              .filter(
                (u) =>
                  !query.trim() ||
                  u.fullName.toLowerCase().includes(query.toLowerCase()) ||
                  u.username.toLowerCase().includes(query.toLowerCase())
              )
              .map((u) => {
                const outletName = outlets.find((o) => o.id === u.outletId)?.name || 'Pusat';
                const txCount = transactions.filter((t) => t.cashierId === u.id).length;
                const demoDefault = isDeveloper ? detectKnownDemoPassword(u.passwordHash) : null;
                const isSelf = u.id === currentUser.id;
                const canEditThisUser = isDeveloper || u.role !== 'PEMILIK';

                return (
                  <div
                    key={u.id}
                    className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between gap-3"
                  >
                    <div className="space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <div className="min-w-0">
                          <h4 className="font-bold text-slate-900 dark:text-slate-100 truncate">
                            {u.fullName}
                          </h4>
                          <p className="text-xs text-slate-500 font-mono">@{u.username}</p>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {canEditThisUser && (
                            <button
                              type="button"
                              onClick={() => setEditingUser(u)}
                              aria-label={`Edit ${u.username}`}
                              className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}
                          {isDeveloper && !isSelf && (
                            <button
                              type="button"
                              onClick={() => {
                                const res = onDeleteUser(u.id);
                                if (!res.ok && res.error) onNotify(res.error);
                              }}
                              aria-label={`Hapus ${u.username}`}
                              className="p-1.5 rounded text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                        <p>
                          Peran:{' '}
                          <span className="font-semibold text-slate-900 dark:text-slate-100">
                            {u.role === 'PEMILIK'
                              ? 'Pemilik (Developer)'
                              : u.role === 'GUDANG'
                              ? 'Staf Gudang'
                              : u.role === 'KARYAWAN'
                              ? 'Karyawan (Absensi)'
                              : u.role}
                          </span>{' '}
                          · {outletName}
                        </p>
                        <p className="flex items-center justify-between">
                          <span className={`font-semibold ${u.isActive ? 'text-emerald-600' : 'text-red-600'}`}>
                            {u.isActive ? 'Akun Aktif' : 'Nonaktif'}
                          </span>
                          <span className="font-mono text-slate-500">{txCount} transaksi</span>
                        </p>
                        {isDeveloper && (
                          <>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">
                              Login terakhir:{' '}
                              {u.lastLoginAt ? formatDateTime(u.lastLoginAt) : 'Belum tercatat'}
                            </p>
                            {(() => {
                              const revealed = revealDevCredential(u);
                              const shown = Boolean(revealedPassCards[u.id]);
                              return (
                                <div className="mt-1 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5 flex items-center justify-between gap-2">
                                  <div className="min-w-0">
                                    <span className="text-[10px] text-slate-500 block">
                                      {demoDefault ? 'Sandi (Standar Demo)' : 'Sandi Akun'}
                                    </span>
                                    <span className="font-mono font-bold text-xs text-slate-900 dark:text-slate-100 truncate block">
                                      {revealed !== null
                                        ? shown
                                          ? revealed
                                          : '••••••••'
                                        : 'Hash lama (ubah untuk lihat)'}
                                    </span>
                                  </div>
                                  {revealed !== null && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setRevealedPassCards((prev) => ({
                                          ...prev,
                                          [u.id]: !prev[u.id],
                                        }))
                                      }
                                      aria-label={`Lihat sandi ${u.username}`}
                                      className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer shrink-0"
                                    >
                                      {shown ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                    </button>
                                  )}
                                </div>
                              );
                            })()}
                          </>
                        )}
                      </div>
                    </div>

                    {isDeveloper && (
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2">
                        <button
                          type="button"
                          disabled={isSelf}
                          onClick={() => onSwitchAccount(u.id)}
                          className={`flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                            isSelf
                              ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-default'
                              : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                          }`}
                        >
                          <LogIn className="w-3.5 h-3.5" />
                          <span>{isSelf ? 'Sedang Aktif' : 'Akses Akun'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setPasswordInspectUserId(u.id)}
                          className="flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                          <span>Cek / Atur Sandi</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* CUSTOMER PROFILE DIALOG (Loyalty Points Redemption + History + Receivables) */}
      {profileCustomer && (
        <CustomerProfileModal
          customer={profileCustomer}
          activeTab={profileTab}
          onChangeTab={setProfileTab}
          rewards={loyaltyRewards}
          pointHistory={pointHistory.filter((ph) => ph.customerId === profileCustomer.id)}
          transactions={transactions.filter((t) => t.customerId === profileCustomer.id)}
          onRedeemReward={(r) => onRedeemReward(profileCustomer, r)}
          onPayReceivable={(amt) => onPayReceivable(profileCustomer.id, amt)}
          onClose={() => setProfileCustomerId(null)}
        />
      )}

      {/* LOYALTY REWARDS MANAGER */}
      {showRewardsModal && (
        <LoyaltyRewardsModal
          rewards={loyaltyRewards}
          onSave={onSaveReward}
          onDelete={onDeleteReward}
          onClose={() => setShowRewardsModal(false)}
        />
      )}

      {/* PRODUCT FORM MODAL */}
      {editingProduct !== undefined && (
        <ProductFormModal
          existing={editingProduct}
          allProducts={products}
          outlets={outlets}
          onSave={(prod) => {
            onSaveProduct(prod);
            setEditingProduct(undefined);
          }}
          onClose={() => setEditingProduct(undefined)}
        />
      )}

      {/* CUSTOMER FORM MODAL */}
      {editingCustomer !== undefined && (
        <CustomerFormModal
          existing={editingCustomer}
          onSave={(c) => {
            onSaveCustomer(c);
            setEditingCustomer(undefined);
          }}
          onClose={() => setEditingCustomer(undefined)}
        />
      )}

      {/* SUPPLIER FORM MODAL */}
      {editingSupplier !== undefined && (
        <SupplierFormModal
          existing={editingSupplier}
          onSave={(s) => {
            onSaveSupplier(s);
            setEditingSupplier(undefined);
          }}
          onClose={() => setEditingSupplier(undefined)}
        />
      )}

      {/* USER FORM MODAL */}
      {editingUser !== undefined && (
        <UserFormModal
          existing={editingUser}
          outlets={outlets}
          isDeveloper={isDeveloper}
          onSave={onSaveUser}
          onClose={() => setEditingUser(undefined)}
        />
      )}

      {/* DEVELOPER PASSWORD INSPECT / RESET MODAL */}
      {passwordInspectUser && isDeveloper && (
        <DeveloperPasswordModal
          user={passwordInspectUser}
          onResetPassword={(newPass) =>
            onSaveUser(
              passwordInspectUser.id,
              passwordInspectUser.username,
              passwordInspectUser.fullName,
              newPass,
              passwordInspectUser.role,
              passwordInspectUser.outletId,
              passwordInspectUser.isActive
            )
          }
          onNotify={onNotify}
          onClose={() => setPasswordInspectUserId(null)}
        />
      )}
    </div>
  );
};

const CustomerProfileModal: React.FC<{
  customer: Customer;
  activeTab: 'REDEEM' | 'HISTORY' | 'ORDERS';
  onChangeTab: (t: 'REDEEM' | 'HISTORY' | 'ORDERS') => void;
  rewards: LoyaltyReward[];
  pointHistory: PointHistory[];
  transactions: Transaction[];
  onRedeemReward: (r: LoyaltyReward) => void;
  onPayReceivable: (amt: number) => void;
  onClose: () => void;
}> = ({
  customer,
  activeTab,
  onChangeTab,
  rewards,
  pointHistory,
  transactions,
  onRedeemReward,
  onPayReceivable,
  onClose,
}) => {
  const [payAmt, setPayAmt] = useState(String(customer.receivableBalance));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-lg max-h-[88vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-bold">{customer.name}</h3>
            <p className="text-xs text-slate-500">
              WA: {customer.whatsapp} · {customer.address}
            </p>
          </div>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="rounded-xl bg-teal-50 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-900 p-3.5 flex items-center justify-between">
          <div>
            <p className="text-xs text-teal-700 dark:text-teal-300">Saldo Poin Loyalitas</p>
            <p className="text-2xl font-extrabold font-mono text-teal-800 dark:text-teal-200">
              {customer.points} Poin
            </p>
          </div>
          <Award className="w-8 h-8 text-teal-700 dark:text-teal-400" />
        </div>

        <div className="flex gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
          {[
            { id: 'REDEEM', label: 'Tukar Poin' },
            { id: 'HISTORY', label: `Riwayat Poin (${pointHistory.length})` },
            { id: 'ORDERS', label: `Belanja & Piutang (${transactions.length})` },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => onChangeTab(t.id as 'REDEEM' | 'HISTORY' | 'ORDERS')}
              className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === t.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {activeTab === 'REDEEM' && (
          <div className="space-y-2.5">
            {rewards
              .filter((r) => r.isActive)
              .map((r) => {
                const ok = customer.points >= r.pointsCost;
                return (
                  <div
                    key={r.id}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 flex items-center justify-between gap-3"
                  >
                    <div>
                      <p className="text-sm font-semibold">{r.title}</p>
                      <p className="text-xs text-slate-500">
                        {r.pointsCost} poin · {r.rewardType === 'DISCOUNT' ? 'Diskon Belanja' : 'Hadiah Produk'}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={!ok}
                      onClick={() => onRedeemReward(r)}
                      className="px-3.5 py-1.5 rounded-lg bg-teal-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                    >
                      {ok ? 'Tukar' : 'Kurang'}
                    </button>
                  </div>
                );
              })}
          </div>
        )}

        {activeTab === 'HISTORY' && (
          <div className="space-y-2">
            {pointHistory.length === 0 ? (
              <p className="text-sm text-slate-500 py-4 text-center">Belum ada riwayat poin.</p>
            ) : (
              pointHistory.map((ph) => (
                <div
                  key={ph.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 flex items-center justify-between gap-3"
                >
                  <div>
                    <p className="text-sm font-semibold">{ph.description}</p>
                    <p className="text-xs text-slate-500 font-mono">
                      {ph.referenceId} · {formatDateTime(ph.createdAt)}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p
                      className={`text-sm font-bold font-mono ${
                        ph.pointsDelta >= 0 ? 'text-emerald-600' : 'text-amber-600'
                      }`}
                    >
                      {ph.pointsDelta >= 0 ? '+' : ''}
                      {ph.pointsDelta} poin
                    </p>
                    <p className="text-[11px] font-mono text-slate-400">Sisa: {ph.balanceAfter}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'ORDERS' && (
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span>Total Belanja</span>
              <span className="font-mono font-semibold">{formatRupiah(customer.totalSpent)}</span>
            </div>
            <div className="flex justify-between">
              <span>Saldo Piutang</span>
              <span className="font-mono font-bold text-red-600">
                {formatRupiah(customer.receivableBalance)}
              </span>
            </div>
            {customer.receivableBalance > 0 && (
              <div className="flex gap-2">
                <input
                  type="number"
                  value={payAmt}
                  onChange={(e) => setPayAmt(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => onPayReceivable(Number(payAmt) || 0)}
                  className="px-3.5 py-2 rounded-lg bg-teal-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Bayar Piutang
                </button>
              </div>
            )}
            <div className="border-t border-slate-200 dark:border-slate-800 pt-2 space-y-1.5">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex justify-between text-xs">
                  <span className="font-mono">
                    {tx.invoiceNumber} · {formatDateTime(tx.createdAt)}
                  </span>
                  <span className="font-mono font-semibold">{formatRupiah(tx.totalAmount)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const LoyaltyRewardsModal: React.FC<{
  rewards: LoyaltyReward[];
  onSave: (r: LoyaltyReward) => void;
  onDelete: (id: string) => void;
  onClose: () => void;
}> = ({ rewards, onSave, onDelete, onClose }) => {
  const [title, setTitle] = useState('');
  const [pointsCost, setPointsCost] = useState('100');
  const [rewardType, setRewardType] = useState<LoyaltyRewardType>('DISCOUNT');
  const [discountAmount, setDiscountAmount] = useState('10000');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-md max-h-[88vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">Katalog Hadiah & Diskon Poin</h3>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>
        <div className="space-y-2.5 border-b border-slate-200 dark:border-slate-800 pb-4">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Nama hadiah atau voucher diskon"
            className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
          />
          <div className="flex gap-2">
            {(['DISCOUNT', 'GIFT'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setRewardType(t)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                  rewardType === t
                    ? 'bg-teal-700 text-white border-teal-700'
                    : 'border-slate-300 dark:border-slate-700'
                }`}
              >
                {t === 'DISCOUNT' ? 'Diskon Belanja (Rp)' : 'Hadiah Produk'}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              value={pointsCost}
              onChange={(e) => setPointsCost(e.target.value)}
              placeholder="Poin dibutuhkan"
              className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            {rewardType === 'DISCOUNT' && (
              <input
                type="number"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(e.target.value)}
                placeholder="Nominal diskon Rp"
                className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
              />
            )}
          </div>
          <button
            type="button"
            disabled={!title.trim()}
            onClick={() => {
              onSave({
                id: '',
                title: title.trim(),
                description:
                  rewardType === 'DISCOUNT'
                    ? `Diskon ${formatRupiah(Number(discountAmount) || 0)}`
                    : 'Penukaran hadiah produk',
                pointsCost: Math.max(1, Number(pointsCost) || 100),
                rewardType,
                discountAmount: rewardType === 'DISCOUNT' ? Number(discountAmount) || 0 : 0,
                isActive: true,
              });
              setTitle('');
            }}
            className="w-full py-2 rounded-lg bg-teal-700 text-white text-xs font-semibold cursor-pointer"
          >
            + Tambah Reward Poin
          </button>
        </div>

        <div className="space-y-2">
          {rewards.map((r) => (
            <div
              key={r.id}
              className="rounded-lg border border-slate-200 dark:border-slate-800 p-2.5 flex justify-between items-center text-sm"
            >
              <div>
                <p className="font-semibold">{r.title}</p>
                <p className="text-xs text-slate-500 font-mono">{r.pointsCost} poin</p>
              </div>
              <button
                type="button"
                onClick={() => onDelete(r.id)}
                className="text-red-600 p-1 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ProductFormModal: React.FC<{
  existing: Product | null;
  allProducts: Product[];
  outlets: Outlet[];
  onSave: (p: Product) => void;
  onClose: () => void;
}> = ({ existing, allProducts, outlets, onSave, onClose }) => {
  const [name, setName] = useState(existing?.name || '');
  const [sku, setSku] = useState(existing?.sku || `SKU-${Date.now().toString().slice(-4)}`);
  const [barcode, setBarcode] = useState(existing?.barcode || '');
  const [category, setCategory] = useState(existing?.category || '');
  const [brand, setBrand] = useState(existing?.brand || '');
  const [costPrice, setCostPrice] = useState(existing ? String(existing.costPrice) : '');
  const [sellPrice, setSellPrice] = useState(existing ? String(existing.sellPrice) : '');
  const [baseUnit, setBaseUnit] = useState(existing?.baseUnit || '');
  const [stock, setStock] = useState(existing ? String(existing.stock) : '');
  const [minStock, setMinStock] = useState(existing ? String(existing.minStock) : '');
  const [photoUrl, setPhotoUrl] = useState<string | undefined>(existing?.photoUrl);
  const [scanTarget, setScanTarget] = useState<'barcode' | 'sku' | null>(null);
  const [extraUnits, setExtraUnits] = useState<ProductUnitOption[]>(existing?.units.slice(1) || []);
  const [newUnitName, setNewUnitName] = useState('');
  const [newUnitMult, setNewUnitMult] = useState('');
  const [newUnitPrice, setNewUnitPrice] = useState('');
  const [isBom, setIsBom] = useState(existing?.isBom || false);
  const [bomItems, setBomItems] = useState<BomItem[]>(existing?.bomItems || []);
  const [ingId, setIngId] = useState(allProducts.find((p) => p.id !== existing?.id)?.id || '');
  const [ingQty, setIngQty] = useState('0.1');

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setPhotoUrl(String(reader.result));
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">{existing ? 'Edit Produk' : 'Tambah Produk Baru'}</h3>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          {photoUrl ? (
            <img src={photoUrl} alt="Preview" className="w-14 h-14 rounded-xl object-cover" />
          ) : (
            <div className="w-14 h-14 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs text-slate-400">
              Foto
            </div>
          )}
          <label className="flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>Unggah Foto Produk</span>
            <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
          </label>
        </div>

        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama Produk *"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <div className="flex gap-1.5">
            <input
              type="text"
              value={sku}
              onChange={(e) => setSku(e.target.value)}
              placeholder="SKU (otomatis)"
              className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            <button
              type="button"
              onClick={() => setScanTarget('sku')}
              title="Scan SKU dengan kamera HP"
              aria-label="Scan SKU dengan kamera"
              className="px-2.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              <Camera className="w-4 h-4 text-teal-700 dark:text-teal-400" />
            </button>
          </div>
          <div className="flex gap-1.5">
            <input
              type="text"
              value={barcode}
              onChange={(e) => setBarcode(e.target.value)}
              placeholder="Barcode (kosong / scan)"
              className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            <button
              type="button"
              onClick={() => setScanTarget('barcode')}
              title="Scan Barcode dengan kamera HP"
              aria-label="Scan Barcode dengan kamera"
              className="px-2.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              <Camera className="w-4 h-4 text-teal-700 dark:text-teal-400" />
            </button>
          </div>
          <input
            type="text"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="Kategori (mis. Minuman)"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
          />
          <input
            type="text"
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
            placeholder="Merek"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
          />
          <input
            type="number"
            value={costPrice}
            onChange={(e) => setCostPrice(e.target.value)}
            placeholder="Harga Beli (Rp)"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
          />
          <input
            type="number"
            value={sellPrice}
            onChange={(e) => setSellPrice(e.target.value)}
            placeholder="Harga Jual (Rp)"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
          />
          <input
            type="text"
            value={baseUnit}
            onChange={(e) => setBaseUnit(e.target.value)}
            placeholder="Satuan (mis. pcs/kg/L)"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
          />
          <input
            type="number"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            placeholder="Stok Awal"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
          />
        </div>
        <input
          type="number"
          value={minStock}
          onChange={(e) => setMinStock(e.target.value)}
          placeholder="Minimum Stok Alert"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
        />

        {/* Multi-unit */}
        <div className="border-t border-slate-200 dark:border-slate-800 pt-2 space-y-2">
          <p className="text-xs font-semibold">Multi-Satuan Tambahan</p>
          {extraUnits.map((u, idx) => (
            <div key={idx} className="flex justify-between text-xs">
              <span>
                {u.unitName} = {u.multiplier} {baseUnit} @ {formatRupiah(u.sellPrice)}
              </span>
              <button
                type="button"
                onClick={() => setExtraUnits(extraUnits.filter((_, i) => i !== idx))}
                className="text-red-600"
              >
                Hapus
              </button>
            </div>
          ))}
          <div className="grid grid-cols-3 gap-1.5">
            <input
              type="text"
              value={newUnitName}
              onChange={(e) => setNewUnitName(e.target.value)}
              placeholder="Satuan (dus)"
              className="px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
            />
            <input
              type="number"
              value={newUnitMult}
              onChange={(e) => setNewUnitMult(e.target.value)}
              placeholder="Isi (12)"
              className="px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
            />
            <input
              type="number"
              value={newUnitPrice}
              onChange={(e) => setNewUnitPrice(e.target.value)}
              placeholder="Harga Jual"
              className="px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
            />
          </div>
          <button
            type="button"
            onClick={() => {
              if (newUnitName.trim() && Number(newUnitMult) > 0 && Number(newUnitPrice) > 0) {
                setExtraUnits([
                  ...extraUnits,
                  {
                    unitName: newUnitName.trim(),
                    multiplier: Number(newUnitMult),
                    sellPrice: Number(newUnitPrice),
                  },
                ]);
                setNewUnitName('');
                setNewUnitMult('');
                setNewUnitPrice('');
              }
            }}
            className="text-xs font-semibold text-teal-700 dark:text-teal-400 cursor-pointer"
          >
            + Tambah Satuan
          </button>
        </div>

        {/* BOM */}
        <div className="border-t border-slate-200 dark:border-slate-800 pt-2 space-y-2">
          <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
            <input type="checkbox" checked={isBom} onChange={(e) => setIsBom(e.target.checked)} />
            <span>Produk Resep / Bill of Materials (BOM)</span>
          </label>
          {isBom && (
            <div className="space-y-2">
              {bomItems.map((b, idx) => (
                <div key={idx} className="flex justify-between text-xs">
                  <span>
                    {b.ingredientName}: {b.quantityNeeded} {b.unit}
                  </span>
                  <button
                    type="button"
                    onClick={() => setBomItems(bomItems.filter((_, i) => i !== idx))}
                    className="text-red-600"
                  >
                    Hapus
                  </button>
                </div>
              ))}
              <div className="flex gap-1.5">
                <select
                  value={ingId}
                  onChange={(e) => setIngId(e.target.value)}
                  className="flex-1 px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                >
                  {allProducts
                    .filter((p) => p.id !== existing?.id)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.baseUnit})
                      </option>
                    ))}
                </select>
                <input
                  type="number"
                  step="0.01"
                  value={ingQty}
                  onChange={(e) => setIngQty(e.target.value)}
                  className="w-20 px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={() => {
                    const ing = allProducts.find((p) => p.id === ingId);
                    if (ing && Number(ingQty) > 0) {
                      setBomItems([
                        ...bomItems,
                        {
                          ingredientProductId: ing.id,
                          ingredientName: ing.name,
                          quantityNeeded: Number(ingQty),
                          unit: ing.baseUnit,
                        },
                      ]);
                    }
                  }}
                  className="px-2.5 py-1.5 rounded border border-slate-300 text-xs font-semibold"
                >
                  + Bahan
                </button>
              </div>
            </div>
          )}
        </div>

        <button
          type="button"
          disabled={!name.trim()}
          onClick={() => {
            const sPrice = Number(sellPrice) || 0;
            const unitBase = baseUnit.trim() || 'pcs';
            onSave({
              id: existing?.id || '',
              name: name.trim(),
              sku: sku.trim(),
              barcode: barcode.trim(),
              category: category.trim() || 'Umum',
              brand: brand.trim() || 'Umum',
              costPrice: Number(costPrice) || 0,
              sellPrice: sPrice,
              baseUnit: unitBase,
              units: [{ unitName: unitBase, multiplier: 1, sellPrice: sPrice }, ...extraUnits],
              stock: Number(stock) || 0,
              minStock: Number(minStock) || 0,
              photoUrl,
              outletId: existing?.outletId || outlets[0]?.id || 'out-1',
              isBom,
              bomItems: isBom ? bomItems : [],
              lastSoldAt: existing?.lastSoldAt || Date.now(),
              createdAt: existing?.createdAt || Date.now(),
            });
          }}
          className="w-full py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
        >
          Simpan Produk
        </button>
      </div>

      {scanTarget && (
        <CameraScannerModal
          title={scanTarget === 'barcode' ? 'Scan Barcode Produk' : 'Scan SKU Produk'}
          subtitle="Arahkan kamera HP ke label barcode kemasan produk."
          onDetected={(code) => {
            if (scanTarget === 'barcode') {
              setBarcode(code);
            } else {
              setSku(code);
            }
            setScanTarget(null);
          }}
          onClose={() => setScanTarget(null)}
        />
      )}
    </div>
  );
};

const CustomerFormModal: React.FC<{
  existing: Customer | null;
  onSave: (c: Customer) => void;
  onClose: () => void;
}> = ({ existing, onSave, onClose }) => {
  const [name, setName] = useState(existing?.name || '');
  const [whatsapp, setWhatsapp] = useState(existing?.whatsapp || '');
  const [address, setAddress] = useState(existing?.address || '');
  const [points, setPoints] = useState(String(existing?.points ?? 0));
  const [receivable, setReceivable] = useState(String(existing?.receivableBalance ?? 0));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">{existing ? 'Edit Pelanggan' : 'Tambah Pelanggan'}</h3>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama Pelanggan"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <input
          type="text"
          value={whatsapp}
          onChange={(e) => setWhatsapp(e.target.value)}
          placeholder="No. WhatsApp (628xxx)"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Alamat"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            value={points}
            onChange={(e) => setPoints(e.target.value)}
            placeholder="Poin"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
          />
          <input
            type="number"
            value={receivable}
            onChange={(e) => setReceivable(e.target.value)}
            placeholder="Piutang Rp"
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
          />
        </div>
        <button
          type="button"
          disabled={!name.trim()}
          onClick={() =>
            onSave({
              id: existing?.id || '',
              name: name.trim(),
              whatsapp: whatsapp.trim(),
              address: address.trim(),
              points: Number(points) || 0,
              receivableBalance: Number(receivable) || 0,
              totalSpent: existing?.totalSpent || 0,
            })
          }
          className="w-full py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold cursor-pointer"
        >
          Simpan Pelanggan
        </button>
      </div>
    </div>
  );
};

const SupplierFormModal: React.FC<{
  existing: Supplier | null;
  onSave: (s: Supplier) => void;
  onClose: () => void;
}> = ({ existing, onSave, onClose }) => {
  const [name, setName] = useState(existing?.name || '');
  const [phone, setPhone] = useState(existing?.phone || '');
  const [address, setAddress] = useState(existing?.address || '');
  const [notes, setNotes] = useState(existing?.notes || '');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">{existing ? 'Edit Supplier' : 'Tambah Supplier'}</h3>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama Supplier"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <input
          type="text"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="Telepon"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Alamat"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <input
          type="text"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Catatan"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <button
          type="button"
          disabled={!name.trim()}
          onClick={() =>
            onSave({
              id: existing?.id || '',
              name: name.trim(),
              phone: phone.trim(),
              address: address.trim(),
              notes: notes.trim(),
            })
          }
          className="w-full py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold cursor-pointer"
        >
          Simpan Supplier
        </button>
      </div>
    </div>
  );
};

const UserFormModal: React.FC<{
  existing: User | null;
  outlets: Outlet[];
  isDeveloper: boolean;
  onSave: (
    id: string | null,
    username: string,
    fullName: string,
    password: string,
    role: UserRole,
    outletId: string,
    isActive: boolean
  ) => { ok: boolean; error?: string };
  onClose: () => void;
}> = ({ existing, outlets, isDeveloper, onSave, onClose }) => {
  const [username, setUsername] = useState(existing?.username || '');
  const [fullName, setFullName] = useState(existing?.fullName || '');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [role, setRole] = useState<UserRole>(existing?.role || 'KASIR');
  const [outletId, setOutletId] = useState(existing?.outletId || outlets[0]?.id || 'out-1');
  const [isActive, setIsActive] = useState(existing?.isActive ?? true);
  const [err, setErr] = useState<string | null>(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">{existing ? 'Edit Pengguna' : 'Tambah Pengguna'}</h3>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Username"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <input
          type="text"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          placeholder="Nama Lengkap"
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        />
        <div className="space-y-1">
          <div className="relative">
            <input
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={existing ? 'Password Baru (opsional)' : 'Password'}
              className="w-full pl-3 pr-9 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400"
              aria-label="Tampilkan sandi"
            >
              {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {isDeveloper && (
            <button
              type="button"
              onClick={() => {
                setPassword(generateTempPassword(8));
                setShowPass(true);
              }}
              className="text-[11px] font-semibold text-indigo-700 dark:text-indigo-300 hover:underline cursor-pointer"
            >
              + Buat sandi acak otomatis
            </button>
          )}
        </div>
        <select
          value={role}
          onChange={(e) => setRole(e.target.value as UserRole)}
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        >
          {isDeveloper && <option value="PEMILIK">Pemilik (Developer)</option>}
          <option value="ADMIN">Admin</option>
          <option value="KASIR">Kasir</option>
          <option value="GUDANG">Staf Gudang</option>
          <option value="KARYAWAN">Karyawan (Absensi)</option>
        </select>
        <select
          value={outletId}
          onChange={(e) => setOutletId(e.target.value)}
          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
        >
          {outlets.map((o) => (
            <option key={o.id} value={o.id}>
              {o.name}
            </option>
          ))}
        </select>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} />
          <span>Akun Aktif</span>
        </label>
        {err && <p className="text-xs text-red-600">{err}</p>}
        <button
          type="button"
          onClick={() => {
            const res = onSave(existing?.id || null, username, fullName, password, role, outletId, isActive);
            if (res.ok) onClose();
            else setErr(res.error || 'Gagal menyimpan');
          }}
          className="w-full py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold cursor-pointer"
        >
          Simpan Pengguna
        </button>
      </div>
    </div>
  );
};

const DeveloperPasswordModal: React.FC<{
  user: User;
  onResetPassword: (newPass: string) => { ok: boolean; error?: string };
  onNotify: (msg: string) => void;
  onClose: () => void;
}> = ({ user, onResetPassword, onNotify, onClose }) => {
  const [showStored, setShowStored] = useState(false);
  const [candidate, setCandidate] = useState('');
  const [showCandidate, setShowCandidate] = useState(false);
  const [checkResult, setCheckResult] = useState<{ tested: string; matched: boolean } | null>(null);

  const [newPass, setNewPass] = useState('');
  const [showNewPass, setShowNewPass] = useState(true);
  const [savedPass, setSavedPass] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const demoDefault = detectKnownDemoPassword(user.passwordHash);
  const storedPlain = revealDevCredential(user);

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      onNotify('Sandi disalin ke clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      onNotify('Salin manual teks sandi di atas');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex justify-between items-start gap-2">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              Cek &amp; Atur Sandi Akun
            </h3>
            <p className="text-xs text-slate-500">
              {user.fullName} (<span className="font-mono">@{user.username}</span>)
            </p>
          </div>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* PASSWORD STATUS */}
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 space-y-2 text-xs">
          <p className="font-bold text-slate-800 dark:text-slate-100">Sandi Akun Saat Ini</p>
          {storedPlain !== null ? (
            <div className="space-y-2">
              <p className="text-slate-600 dark:text-slate-300 font-medium">
                {demoDefault
                  ? 'Masih menggunakan sandi standar bawaan demo:'
                  : 'Sandi kustom aktif (tersimpan di brankas Developer):'}
              </p>
              <div className="flex items-center justify-between gap-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2">
                <span className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100">
                  {showStored ? storedPlain : '••••••••'}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowStored(!showStored)}
                    className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    aria-label="Tampilkan sandi akun"
                  >
                    {showStored ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCopy(storedPlain)}
                    className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    aria-label="Salin sandi"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
              {user.passwordUpdatedAt && (
                <p className="text-[11px] text-slate-500">
                  Terakhir diubah: {formatDateTime(user.passwordUpdatedAt)}
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-1 text-slate-600 dark:text-slate-300">
              <p className="text-amber-700 dark:text-amber-400 font-semibold">
                Sandi kustom lama sebelum pembaruan brankas Developer.
              </p>
              <p>
                Diperbarui:{' '}
                {user.passwordUpdatedAt ? formatDateTime(user.passwordUpdatedAt) : 'Tidak diketahui'}
              </p>
            </div>
          )}
        </div>

        {/* VERIFY CANDIDATE PASSWORD */}
        <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
          <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
            Cek Kecocokan Sandi
          </p>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type={showCandidate ? 'text' : 'password'}
                value={candidate}
                onChange={(e) => {
                  setCandidate(e.target.value);
                  setCheckResult(null);
                }}
                placeholder="Ketik sandi yang ingin dicek"
                className="w-full pl-3 pr-9 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
              />
              <button
                type="button"
                onClick={() => setShowCandidate(!showCandidate)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400"
                aria-label="Lihat input cek sandi"
              >
                {showCandidate ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <button
              type="button"
              disabled={!candidate}
              onClick={() => {
                const res = checkUserPassword(candidate, user.passwordHash);
                setCheckResult({ tested: candidate, matched: res.matched });
              }}
              className="px-3.5 py-2 rounded-lg bg-slate-800 dark:bg-slate-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
            >
              Cek Sandi
            </button>
          </div>
          {checkResult && (
            <p
              className={`text-xs font-semibold ${
                checkResult.matched ? 'text-emerald-600' : 'text-red-600'
              }`}
            >
              {checkResult.matched
                ? `Cocok! Sandi tersebut valid untuk akun @${user.username}.`
                : `Tidak cocok dengan sandi tersimpan pada akun @${user.username}.`}
            </p>
          )}
        </div>

        {/* RESET / ASSIGN NEW PASSWORD */}
        <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
              Atur Ulang / Buat Sandi Baru
            </p>
            <button
              type="button"
              onClick={() => {
                setNewPass(generateTempPassword(8));
                setShowNewPass(true);
                setErr(null);
              }}
              className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-700 dark:text-indigo-300 hover:underline cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Buat Sandi Acak</span>
            </button>
          </div>
          <div className="relative">
            <input
              type={showNewPass ? 'text' : 'password'}
              value={newPass}
              onChange={(e) => {
                setNewPass(e.target.value);
                setErr(null);
              }}
              placeholder="Sandi baru (minimal 4 karakter)"
              className="w-full pl-3 pr-9 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            <button
              type="button"
              onClick={() => setShowNewPass(!showNewPass)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400"
              aria-label="Lihat sandi baru"
            >
              {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {err && <p className="text-xs text-red-600">{err}</p>}

          <button
            type="button"
            disabled={newPass.length < 4}
            onClick={() => {
              const res = onResetPassword(newPass);
              if (res.ok) {
                setSavedPass(newPass);
                setNewPass('');
                setCheckResult(null);
                onNotify(`Sandi baru untuk @${user.username} berhasil diterapkan`);
              } else {
                setErr(res.error || 'Gagal memperbarui sandi');
              }
            }}
            className="w-full py-2 rounded-lg bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer"
          >
            Simpan &amp; Terapkan Sandi Baru
          </button>

          {savedPass && (
            <div className="rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 p-3 flex items-center justify-between gap-2 text-xs">
              <div>
                <p className="font-semibold text-emerald-800 dark:text-emerald-200">
                  Sandi baru aktif:
                </p>
                <p className="font-mono font-bold text-sm text-emerald-950 dark:text-emerald-100">
                  {savedPass}
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(savedPass)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-emerald-700 text-white font-semibold cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Disalin' : 'Salin'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
