import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Check,
  ExternalLink,
  RefreshCw,
  RotateCcw,
  ShieldAlert,
  X,
} from 'lucide-react';
import { isRunningInIframe } from '../utils/receiptExport';

interface AttendanceCameraModalProps {
  title: string;
  subtitle: string;
  employeeName: string;
  locationLabel?: string;
  onCaptured: (photoDataUrl: string) => void;
  onClose: () => void;
}

export const AttendanceCameraModal: React.FC<AttendanceCameraModalProps> = ({
  title,
  subtitle,
  employeeName,
  locationLabel,
  onCaptured,
  onClose,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [cameraState, setCameraState] = useState<'starting' | 'active' | 'error'>('starting');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [capturedDataUrl, setCapturedDataUrl] = useState<string | null>(null);

  const inIframe = isRunningInIframe();
  const standaloneUrl = typeof window !== 'undefined' ? window.location.href : '/';

  const stopStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (capturedDataUrl) {
      stopStream();
      return;
    }

    let cancelled = false;

    const startCamera = async () => {
      setCameraState('starting');
      setErrorMessage(null);

      if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        setCameraState('error');
        setErrorMessage(
          'Browser atau perangkat ini tidak mendukung kamera langsung (getUserMedia). Absensi mewajibkan foto langsung dari kamera HP dan melarang upload galeri.'
        );
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 960 },
            height: { ideal: 720 },
          },
          audio: false,
        });

        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        const videoEl = videoRef.current;
        if (!videoEl) return;
        videoEl.srcObject = stream;
        await videoEl.play();

        if (!cancelled) {
          setCameraState('active');
        }
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : String(err);
        const lower = msg.toLowerCase();
        setCameraState('error');
        if (lower.includes('notallowed') || lower.includes('permission') || lower.includes('denied')) {
          setErrorMessage(
            inIframe
              ? 'Izin kamera diblokir di mode preview iframe atau belum diizinkan. Buka aplikasi di Tab Baru untuk menggunakan kamera HP.'
              : 'Izin kamera ditolak oleh browser. Aktifkan izin Kamera pada browser lalu ulangi.'
          );
        } else if (lower.includes('notfound') || lower.includes('requested device not found')) {
          setErrorMessage(
            'Kamera perangkat tidak ditemukan. Gunakan HP atau perangkat berkamera (upload foto galeri tidak diperbolehkan).'
          );
        } else {
          setErrorMessage(`Gagal membuka kamera langsung: ${msg}`);
        }
      }
    };

    void startCamera();

    return () => {
      cancelled = true;
      stopStream();
    };
  }, [facingMode, capturedDataUrl, inIframe]);

  const handleCapture = () => {
    const videoEl = videoRef.current;
    if (!videoEl || videoEl.readyState < 2) return;

    const rawW = videoEl.videoWidth || 640;
    const rawH = videoEl.videoHeight || 480;
    const targetW = Math.min(640, rawW);
    const targetH = Math.round((rawH / rawW) * targetW);

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    if (facingMode === 'user') {
      ctx.translate(targetW, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(videoEl, 0, 0, targetW, targetH);
    ctx.restore();

    // Stamp live verification watermark bar
    const barH = 44;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
    ctx.fillRect(0, targetH - barH, targetW, barH);

    const nowStr = new Date().toLocaleString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    ctx.fillStyle = '#5eead4';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText(`AysPOS LIVE CAM · ${employeeName}`, 10, targetH - 25);

    ctx.fillStyle = '#e2e8f0';
    ctx.font = '11px monospace';
    const subLine = locationLabel ? `${nowStr} · ${locationLabel}` : nowStr;
    ctx.fillText(subLine.slice(0, 68), 10, targetH - 9);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    setCapturedDataUrl(dataUrl);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4">
      <div className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Camera className="w-4 h-4 text-teal-700 dark:text-teal-400 shrink-0" />
              <span>{title}</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>
          </div>
          <button
            type="button"
            onClick={() => {
              stopStream();
              onClose();
            }}
            aria-label="Tutup kamera absensi"
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="rounded-lg bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 px-3 py-2 flex items-center gap-2 text-[11px] font-semibold text-teal-800 dark:text-teal-200">
          <ShieldAlert className="w-4 h-4 shrink-0 text-teal-700 dark:text-teal-400" />
          <span>Kamera Device Langsung · Upload foto dari galeri dilarang</span>
        </div>

        {/* Viewfinder or Preview */}
        <div className="relative aspect-[4/3] w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
          {capturedDataUrl ? (
            <img
              src={capturedDataUrl}
              alt="Pratinjau Selfie Absensi"
              className="w-full h-full object-cover"
            />
          ) : (
            <>
              <video
                ref={videoRef}
                muted
                playsInline
                autoPlay
                className={`w-full h-full object-cover ${
                  facingMode === 'user' ? '-scale-x-100' : ''
                } ${cameraState === 'active' ? 'opacity-100' : 'opacity-25'}`}
              />

              {cameraState === 'starting' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-white text-xs">
                  <RefreshCw className="w-5 h-5 animate-spin text-teal-400" />
                  <span>Menghubungkan kamera HP...</span>
                </div>
              )}

              {cameraState === 'error' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center gap-2.5 bg-slate-950/92">
                  <Camera className="w-8 h-8 text-amber-400" />
                  <p className="text-xs text-slate-200 leading-relaxed">{errorMessage}</p>
                  {inIframe && (
                    <a
                      href={standaloneUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Buka di Tab Baru</span>
                    </a>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Actions */}
        {!capturedDataUrl ? (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setFacingMode((m) => (m === 'user' ? 'environment' : 'user'))}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{facingMode === 'user' ? 'Kamera Depan' : 'Kamera Belakang'}</span>
            </button>

            <button
              type="button"
              disabled={cameraState !== 'active'}
              onClick={handleCapture}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>Ambil Foto Selfie</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setCapturedDataUrl(null)}
              className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Ulangi Foto</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onCaptured(capturedDataUrl);
              }}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Gunakan Foto &amp; Simpan</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
