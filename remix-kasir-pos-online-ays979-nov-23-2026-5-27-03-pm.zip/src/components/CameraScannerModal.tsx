import React, { useEffect, useRef, useState } from 'react';
import { BrowserCodeReader, BrowserMultiFormatReader } from '@zxing/browser';
import {
  Camera,
  ExternalLink,
  Flashlight,
  FlashlightOff,
  ImagePlus,
  RefreshCw,
  ScanBarcode,
  X,
} from 'lucide-react';
import { isRunningInIframe } from '../utils/receiptExport';

interface BarcodeDetectorResultLike {
  rawValue?: string;
}

interface BarcodeDetectorInstanceLike {
  detect: (source: ImageBitmapSource) => Promise<BarcodeDetectorResultLike[]>;
}

interface BarcodeDetectorCtorLike {
  new (options?: { formats?: string[] }): BarcodeDetectorInstanceLike;
}

export interface CameraScannerModalProps {
  title?: string;
  subtitle?: string;
  manualPlaceholder?: string;
  onDetected: (code: string) => void;
  onClose: () => void;
}

export const CameraScannerModal: React.FC<CameraScannerModalProps> = ({
  title = 'Scan SKU / Barcode Kamera',
  subtitle = 'Arahkan kamera HP ke barcode atau QR code SKU produk.',
  manualPlaceholder = 'Atau ketik kode SKU / Barcode secara manual...',
  onDetected,
  onClose,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const detectedLockRef = useRef(false);

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [torchSupported, setTorchSupported] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [cameraState, setCameraState] = useState<'starting' | 'active' | 'error'>('starting');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [lastScanned, setLastScanned] = useState<string | null>(null);

  const inIframe = isRunningInIframe();
  const standaloneUrl = typeof window !== 'undefined' ? window.location.href : '/';

  const handleSuccessCode = (rawCode: string) => {
    const clean = rawCode.trim();
    if (!clean || detectedLockRef.current) return;
    detectedLockRef.current = true;
    setLastScanned(clean);
    onDetected(clean);
  };

  useEffect(() => {
    let cancelled = false;
    let rafTimer: number | null = null;
    let zxingControls: { stop: () => void } | null = null;
    detectedLockRef.current = false;

    const stopEverything = () => {
      if (rafTimer !== null) {
        window.clearTimeout(rafTimer);
        rafTimer = null;
      }
      if (zxingControls) {
        try {
          zxingControls.stop();
        } catch {
          // ignore
        }
        zxingControls = null;
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => {
          try {
            t.stop();
          } catch {
            // ignore
          }
        });
        streamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    };

    const startCamera = async () => {
      setCameraState('starting');
      setErrorMessage(null);
      setTorchOn(false);
      setTorchSupported(false);

      if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        setCameraState('error');
        setErrorMessage(
          'Browser atau perangkat ini tidak mendukung akses kamera langsung (getUserMedia). Gunakan tombol Foto Barcode atau ketik manual di bawah.'
        );
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });

        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        setTorchSupported(BrowserCodeReader.mediaStreamIsTorchCompatible(stream));

        const videoEl = videoRef.current;
        if (!videoEl) return;
        videoEl.srcObject = stream;
        await videoEl.play();

        if (cancelled) return;
        setCameraState('active');

        const win = window as Window & { BarcodeDetector?: BarcodeDetectorCtorLike };
        if (win.BarcodeDetector) {
          let detector: BarcodeDetectorInstanceLike;
          try {
            detector = new win.BarcodeDetector({
              formats: [
                'ean_13',
                'ean_8',
                'upc_a',
                'upc_e',
                'code_128',
                'code_39',
                'code_93',
                'itf',
                'qr_code',
                'data_matrix',
              ],
            });
          } catch {
            detector = new win.BarcodeDetector();
          }

          const scanLoop = async () => {
            if (cancelled || detectedLockRef.current || !videoRef.current) return;
            try {
              if (videoRef.current.readyState >= 2) {
                const barcodes = await detector.detect(videoRef.current);
                if (barcodes.length > 0 && barcodes[0].rawValue) {
                  handleSuccessCode(barcodes[0].rawValue);
                  return;
                }
              }
            } catch {
              // ignore single frame error
            }
            if (!cancelled && !detectedLockRef.current) {
              rafTimer = window.setTimeout(scanLoop, 150);
            }
          };
          rafTimer = window.setTimeout(scanLoop, 180);
        } else {
          const reader = new BrowserMultiFormatReader();
          zxingControls = await reader.decodeFromVideoElement(videoEl, (result) => {
            if (cancelled || detectedLockRef.current) return;
            if (result) {
              handleSuccessCode(result.getText());
            }
          });
        }
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : String(err);
        const lower = msg.toLowerCase();
        setCameraState('error');
        if (lower.includes('notallowed') || lower.includes('permission') || lower.includes('denied')) {
          setErrorMessage(
            inIframe
              ? 'Izin kamera diblokir di mode preview iframe atau belum diizinkan. Buka aplikasi di Tab Baru atau gunakan Foto Barcode di bawah.'
              : 'Izin kamera ditolak oleh browser. Aktifkan izin kamera pada pengaturan browser lalu coba lagi.'
          );
        } else if (lower.includes('notfound') || lower.includes('requested device not found')) {
          setErrorMessage(
            'Kamera tidak terdeteksi di perangkat ini. Anda tetap bisa mengunggah foto barcode atau mengetik SKU secara manual.'
          );
        } else {
          setErrorMessage(`Gagal membuka kamera: ${msg}`);
        }
      }
    };

    void startCamera();

    return () => {
      cancelled = true;
      stopEverything();
    };
  }, [facingMode]);

  const handleToggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track || !torchSupported) return;
    const next = !torchOn;
    try {
      await BrowserCodeReader.mediaStreamSetTorch(track, next);
      setTorchOn(next);
    } catch {
      setTorchSupported(false);
    }
  };

  const handlePhotoScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    try {
      const reader = new BrowserMultiFormatReader();
      const result = await reader.decodeFromImageUrl(objectUrl);
      if (result?.getText()) {
        handleSuccessCode(result.getText());
      } else {
        setErrorMessage('Barcode / QR tidak terbaca pada foto. Pastikan fokus jelas dan cukup cahaya.');
      }
    } catch {
      setErrorMessage('Barcode / QR tidak terbaca pada foto. Coba foto ulang lebih dekat dan terang.');
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4">
      <div className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Camera className="w-4 h-4 text-teal-700 dark:text-teal-400 shrink-0" />
              <span>{title}</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup scanner kamera"
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Camera Viewfinder */}
        <div className="relative aspect-[4/3] w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
          <video
            ref={videoRef}
            muted
            playsInline
            autoPlay
            className={`w-full h-full object-cover ${cameraState === 'active' ? 'opacity-100' : 'opacity-25'}`}
          />

          {/* Targeting reticle overlay */}
          {cameraState === 'active' && (
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-6">
              <div className="w-full max-w-[240px] h-28 border-2 border-teal-400/90 rounded-xl shadow-[0_0_0_9999px_rgba(2,6,23,0.35)] relative">
                <div className="absolute inset-x-3 top-1/2 h-0.5 bg-teal-400/80" />
              </div>
            </div>
          )}

          {cameraState === 'starting' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-white text-xs">
              <RefreshCw className="w-5 h-5 animate-spin text-teal-400" />
              <span>Menyiapkan kamera perangkat...</span>
            </div>
          )}

          {cameraState === 'error' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center gap-2.5 bg-slate-950/90">
              <ScanBarcode className="w-8 h-8 text-amber-400" />
              <p className="text-xs text-slate-200 leading-relaxed">{errorMessage}</p>
              {inIframe && (
                <a
                  href={standaloneUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Buka di Tab Baru</span>
                </a>
              )}
            </div>
          )}
        </div>

        {/* Camera Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{facingMode === 'environment' ? 'Kamera Belakang' : 'Kamera Depan'}</span>
          </button>

          {torchSupported && (
            <button
              type="button"
              onClick={handleToggleTorch}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold cursor-pointer ${
                torchOn
                  ? 'bg-amber-500 border-amber-500 text-white'
                  : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {torchOn ? <FlashlightOff className="w-3.5 h-3.5" /> : <Flashlight className="w-3.5 h-3.5" />}
              <span>{torchOn ? 'Matikan Flash' : 'Nyalakan Flash'}</span>
            </button>
          )}

          <label className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-semibold cursor-pointer ml-auto">
            <ImagePlus className="w-3.5 h-3.5" />
            <span>Foto Barcode</span>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handlePhotoScan}
              className="hidden"
            />
          </label>
        </div>

        {lastScanned && (
          <div className="rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 px-3 py-2 text-xs text-emerald-800 dark:text-emerald-200 font-mono">
            Terbaca: {lastScanned}
          </div>
        )}

        {/* Manual Entry Fallback */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (manualCode.trim()) {
              handleSuccessCode(manualCode);
            }
          }}
          className="pt-3 border-t border-slate-200 dark:border-slate-800 flex gap-2"
        >
          <input
            type="text"
            value={manualCode}
            onChange={(e) => setManualCode(e.target.value)}
            placeholder={manualPlaceholder}
            className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100"
          />
          <button
            type="submit"
            disabled={!manualCode.trim()}
            className="px-4 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            Pakai Kode
          </button>
        </form>
      </div>
    </div>
  );
};
