import React, { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Edit2,
  Eye,
  EyeOff,
  KeyRound,
  LogIn,
  RefreshCw,
  RotateCcw,
  Search,
  ShieldCheck,
  Trash2,
  UserPlus,
  X,
} from 'lucide-react';
import type { PosDatabaseState } from '../data/seedData';
import type { Outlet, Transaction, User, UserRole } from '../types/pos';
import {
  checkUserPassword,
  detectKnownDemoPassword,
  formatDateTime,
  generateTempPassword,
  revealDevCredential,
} from '../utils/formatters';
import { ResetAppModal } from './ResetAppModal';

interface DeveloperConsoleViewProps {
  currentUser: User;
  canSystemReset?: boolean;
  dbState: PosDatabaseState;
  users: User[];
  outlets: Outlet[];
  transactions: Transaction[];
  onSaveUser: (
    id: string | null,
    username: string,
    fullName: string,
    password: string,
    role: UserRole,
    outletId: string,
    isActive: boolean
  ) => { ok: boolean; error?: string };
  onDeleteUser: (id: string) => { ok: boolean; error?: string };
  onSwitchAccount: (targetUserId: string) => { ok: boolean; error?: string };
  onResetDemoData: () => void;
  onResetToZero: (options: { resetPemilikCredentials: boolean }) => {
    ok: boolean;
    error?: string;
  };
  onNotify: (msg: string) => void;
}

const ROLE_LABELS: Record<UserRole, string> = {
  PEMILIK: 'Pemilik (Developer)',
  ADMIN: 'Admin',
  KASIR: 'Kasir',
  GUDANG: 'Staf Gudang',
  KARYAWAN: 'Karyawan (Absensi)',
};

export const DeveloperConsoleView: React.FC<DeveloperConsoleViewProps> = ({
  currentUser,
  canSystemReset = false,
  dbState,
  users,
  outlets,
  transactions,
  onSaveUser,
  onDeleteUser,
  onSwitchAccount,
  onResetDemoData,
  onResetToZero,
  onNotify,
}) => {
  const canManagePemilik = canSystemReset || currentUser.role === 'PEMILIK';
  const [query, setQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | UserRole>('ALL');
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showZeroResetModal, setShowZeroResetModal] = useState(false);
  const [confirmDemoReset, setConfirmDemoReset] = useState(false);
  const [editingModal, setEditingModal] = useState<{
    mode: 'CREATE' | 'EDIT';
    user: User | null;
  } | null>(null);

  const filteredUsers = useMemo(() => {
    const q = query.trim().toLowerCase();
    return users.filter((u) => {
      if (roleFilter !== 'ALL' && u.role !== roleFilter) return false;
      if (!q) return true;
      return (
        u.fullName.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        ROLE_LABELS[u.role].toLowerCase().includes(q)
      );
    });
  }, [users, query, roleFilter]);

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopy = async (id: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedId(id);
      onNotify('Sandi disalin ke clipboard');
      setTimeout(() => setCopiedId((cur) => (cur === id ? null : cur)), 2000);
    } catch {
      onNotify('Salin manual sandi yang ditampilkan');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-indigo-700 dark:text-indigo-400" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              Developer Console — Cek &amp; Ubah User &amp; Sandi
            </h1>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Periksa semua akun pengguna, lihat atau uji sandi, ubah profil/peran/sandi, dan akses akun lain secara langsung.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setEditingModal({ mode: 'CREATE', user: null })}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap w-fit"
        >
          <UserPlus className="w-4 h-4" />
          <span>Tambah User Baru</span>
        </button>
      </div>

      {/* SUMMARY METRICS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Total Akun</p>
          <p className="text-2xl font-extrabold font-mono text-slate-900 dark:text-slate-100 mt-1">
            {users.length}
          </p>
        </div>
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Akun Aktif</p>
          <p className="text-2xl font-extrabold font-mono text-emerald-600 mt-1">
            {users.filter((u) => u.isActive).length}
          </p>
        </div>
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Akun Nonaktif</p>
          <p className="text-2xl font-extrabold font-mono text-red-600 mt-1">
            {users.filter((u) => !u.isActive).length}
          </p>
        </div>
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Sandi Terdeteksi / Vault</p>
          <p className="text-2xl font-extrabold font-mono text-indigo-700 dark:text-indigo-400 mt-1">
            {users.filter((u) => revealDevCredential(u) !== null).length}/{users.length}
          </p>
        </div>
      </div>

      {/* PEMILIK FULL ACCESS & SYSTEM RESET CONTROL */}
      {canManagePemilik && (
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-red-200 dark:border-red-900/70 p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Akses Penuh Pemilik — Reset Aplikasi &amp; Pemulihan Sistem
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Saat ini tersimpan{' '}
            <span className="font-mono font-semibold text-slate-700 dark:text-slate-200">
              {dbState.products.length} produk · {dbState.transactions.length} transaksi ·{' '}
              {dbState.customers.length} pelanggan · {dbState.suppliers.length} supplier ·{' '}
              {dbState.users.length} akun
            </span>
            . Anda dapat mereset aplikasi menjadi <strong>0 seperti baru</strong> untuk mulai dari awal, atau mengisi ulang data demo.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowZeroResetModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Aplikasi ke 0 (Seperti Baru)</span>
          </button>

          {!confirmDemoReset ? (
            <button
              type="button"
              onClick={() => setConfirmDemoReset(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Isi Ulang Data Demo</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  onResetDemoData();
                  setConfirmDemoReset(false);
                }}
                className="px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer"
              >
                Ya, Isi Data Demo
              </button>
              <button
                type="button"
                onClick={() => setConfirmDemoReset(false)}
                className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
            </div>
          )}
        </div>
        </div>
      )}

      {/* SEARCH & ROLE FILTER */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari nama lengkap atau username..."
            className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {(['ALL', 'PEMILIK', 'ADMIN', 'KASIR', 'GUDANG', 'KARYAWAN'] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRoleFilter(r)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                roleFilter === r
                  ? 'bg-indigo-700 text-white'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {r === 'ALL' ? 'Semua Peran' : ROLE_LABELS[r]}
            </button>
          ))}
        </div>
      </div>

      {/* USER CARDS LIST */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredUsers.map((u) => {
          const outletName = outlets.find((o) => o.id === u.outletId)?.name || 'Pusat';
          const txCount = transactions.filter((t) => t.cashierId === u.id).length;
          const isSelf = u.id === currentUser.id;
          const revealed = revealDevCredential(u);
          const isShown = Boolean(revealedIds[u.id]);
          const isDemoDefault = detectKnownDemoPassword(u.passwordHash) !== null;

          return (
            <div
              key={u.id}
              className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-bold text-slate-900 dark:text-slate-100 truncate">
                      {u.fullName}
                    </h3>
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                        u.isActive
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                          : 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300'
                      }`}
                    >
                      {u.isActive ? 'Aktif' : 'Nonaktif'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    @{u.username} · {ROLE_LABELS[u.role]} · {outletName}
                  </p>
                </div>

                {!isSelf && (canManagePemilik || u.role !== 'PEMILIK') && (
                  <button
                    type="button"
                    onClick={() => {
                      const res = onDeleteUser(u.id);
                      if (!res.ok && res.error) onNotify(res.error);
                    }}
                    aria-label={`Hapus akun ${u.username}`}
                    className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 cursor-pointer shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* PASSWORD INSPECTION BOX */}
              <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2.5 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    Sandi Akun {isDemoDefault ? '(Standar Demo)' : '(Tersimpan)'}
                  </p>
                  {revealed !== null ? (
                    <p className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100 truncate">
                      {isShown ? revealed : '••••••••'}
                    </p>
                  ) : (
                    <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">
                      Sandi kustom lama — klik &ldquo;Ubah User &amp; Sandi&rdquo; untuk atur ulang
                    </p>
                  )}
                </div>
                {revealed !== null && (
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => toggleReveal(u.id)}
                      aria-label={isShown ? 'Sembunyikan sandi' : 'Lihat sandi'}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      {isShown ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{isShown ? 'Tutup' : 'Lihat'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopy(u.id, revealed)}
                      aria-label={`Salin sandi ${u.username}`}
                      className="p-1.5 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      {copiedId === u.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                <span>
                  Login terakhir: {u.lastLoginAt ? formatDateTime(u.lastLoginAt) : 'Belum tercatat'}
                </span>
                <span className="font-mono">{txCount} transaksi POS</span>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2">
                {(canManagePemilik || u.role !== 'PEMILIK') && (
                  <>
                    <button
                      type="button"
                      disabled={isSelf}
                      onClick={() => onSwitchAccount(u.id)}
                      className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                        isSelf
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-default'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                      }`}
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>{isSelf ? 'Sedang Dipakai' : 'Akses Akun Ini'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingModal({ mode: 'EDIT', user: u })}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-semibold cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Ubah User &amp; Sandi</span>
                    </button>
                  </>
                )}
                {!canManagePemilik && u.role === 'PEMILIK' && (
                  <span className="text-[11px] text-slate-400 italic">
                    Akun Pemilik hanya dapat dikelola oleh Pemilik
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredUsers.length === 0 && (
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center text-sm text-slate-500">
          Tidak ada akun yang cocok dengan filter pencarian.
        </div>
      )}

      {editingModal && (
        <DeveloperEditUserModal
          existing={editingModal.user}
          outlets={outlets}
          canManagePemilik={canManagePemilik}
          onSave={onSaveUser}
          onNotify={onNotify}
          onClose={() => setEditingModal(null)}
        />
      )}

      {showZeroResetModal && canManagePemilik && (
        <ResetAppModal
          dbState={dbState}
          onConfirmResetToZero={onResetToZero}
          onClose={() => setShowZeroResetModal(false)}
        />
      )}
    </div>
  );
};

const DeveloperEditUserModal: React.FC<{
  existing: User | null;
  outlets: Outlet[];
  canManagePemilik: boolean;
  onSave: (
    id: string | null,
    username: string,
    fullName: string,
    password: string,
    role: UserRole,
    outletId: string,
    isActive: boolean
  ) => { ok: boolean; error?: string };
  onNotify: (msg: string) => void;
  onClose: () => void;
}> = ({ existing, outlets, canManagePemilik, onSave, onNotify, onClose }) => {
  const revealedCurrent = existing ? revealDevCredential(existing) : null;

  const [username, setUsername] = useState(existing?.username || '');
  const [fullName, setFullName] = useState(existing?.fullName || '');
  const [role, setRole] = useState<UserRole>(existing?.role || 'KASIR');
  const [outletId, setOutletId] = useState(existing?.outletId || outlets[0]?.id || 'out-1');
  const [isActive, setIsActive] = useState(existing?.isActive ?? true);
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  // Check candidate password
  const [testPass, setTestPass] = useState('');
  const [testResult, setTestResult] = useState<boolean | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onSave(existing?.id || null, username, fullName, password, role, outletId, isActive);
    if (res.ok) {
      onNotify(
        password
          ? `User @${username.trim()} & sandi baru berhasil disimpan`
          : `Data user @${username.trim()} berhasil diperbarui`
      );
      onClose();
    } else {
      setErr(res.error || 'Gagal menyimpan perubahan');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
      >
        <div className="flex justify-between items-start gap-2">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              {existing ? 'Ubah User & Sandi Akun' : 'Tambah Akun Baru (Developer)'}
            </h3>
            {existing && (
              <p className="text-xs text-slate-500 font-mono">ID: {existing.id}</p>
            )}
          </div>
          <button type="button" onClick={onClose}>
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="space-y-2.5">
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Username Login
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                setErr(null);
              }}
              placeholder="mis. kasir2"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Nama Lengkap
            </label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => {
                setFullName(e.target.value);
                setErr(null);
              }}
              placeholder="Nama lengkap staf"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Peran / Hak Akses
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
              >
                {canManagePemilik && <option value="PEMILIK">Pemilik (Developer)</option>}
                <option value="ADMIN">Admin</option>
                <option value="KASIR">Kasir</option>
                <option value="GUDANG">Staf Gudang</option>
                <option value="KARYAWAN">Karyawan (Absensi)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Cabang / Gudang
              </label>
              <select
                value={outletId}
                onChange={(e) => setOutletId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
              >
                {outlets.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="w-4 h-4 accent-teal-700"
            />
            <span>Akun Aktif (dapat login)</span>
          </label>
        </div>

        {/* SANDI SECTION */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
          {existing && (
            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs">
              <span className="text-slate-500">Sandi Saat Ini: </span>
              <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                {revealedCurrent !== null ? revealedCurrent : 'Terenkripsi (Sandi lama)'}
              </span>
            </div>
          )}

          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-teal-600" />
              <span>{existing ? 'Ubah Sandi (opsional)' : 'Sandi Akun Baru (min. 4 karakter)'}</span>
            </label>
            <button
              type="button"
              onClick={() => {
                setPassword(generateTempPassword(8));
                setShowPass(true);
                setErr(null);
              }}
              className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-700 dark:text-indigo-300 hover:underline cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Buat Acak</span>
            </button>
          </div>

          <div className="relative">
            <input
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setErr(null);
              }}
              placeholder={existing ? 'Kosongkan jika tidak mengubah sandi' : 'Masukkan sandi awal'}
              className="w-full pl-3 pr-9 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400"
              aria-label="Lihat sandi baru"
            >
              {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* TEST CANDIDATE PASSWORD WHEN EDITING */}
        {existing && (
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Uji Kecocokan Sandi Akun Ini
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={testPass}
                onChange={(e) => {
                  setTestPass(e.target.value);
                  setTestResult(null);
                }}
                placeholder="Ketik sandi untuk diuji"
                className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
              />
              <button
                type="button"
                disabled={!testPass}
                onClick={() => {
                  const res = checkUserPassword(testPass, existing.passwordHash);
                  setTestResult(res.matched);
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 dark:bg-slate-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
              >
                Cek
              </button>
            </div>
            {testResult !== null && (
              <p className={`text-xs font-semibold ${testResult ? 'text-emerald-600' : 'text-red-600'}`}>
                {testResult ? 'Cocok! Sandi valid untuk akun ini.' : 'Tidak cocok dengan sandi saat ini.'}
              </p>
            )}
          </div>
        )}

        {err && (
          <div className="rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 px-3 py-2 text-xs text-red-700 dark:text-red-300">
            {err}
          </div>
        )}

        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            className="flex-1 py-2.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold cursor-pointer inline-flex items-center justify-center gap-1.5"
          >
            <span>{existing ? 'Simpan Perubahan' : 'Buat Akun Baru'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
