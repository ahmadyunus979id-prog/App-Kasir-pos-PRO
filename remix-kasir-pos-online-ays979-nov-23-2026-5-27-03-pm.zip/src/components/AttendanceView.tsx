import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CalendarDays,
  Camera,
  CheckCircle2,
  Clock,
  Download,
  Eye,
  FileText,
  Lock,
  LogIn,
  LogOut,
  MapPin,
  Navigation,
  RefreshCw,
  Search,
  Settings2,
  Shield,
  ShieldCheck,
  Trash2,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import type {
  AttendanceAdminPermission,
  AttendanceConfig,
  AttendanceLocationSnapshot,
  AttendanceRecord,
  AttendanceStatus,
  ConfigurableRole,
  Outlet,
  RoleAttendanceScheduleConfig,
  User,
  UserRole,
} from '../types/pos';
import {
  ATTENDANCE_STATUS_LABELS,
  buildAttendanceCsv,
  buildGoogleMapsLink,
  captureCurrentDeviceLocation,
  enrichLocationWithGeofence,
  formatDurationMinutes,
  getAttendancePermissions,
  getEffectiveAttendanceConfigForRole,
  getLocalDateKey,
  getLocalMonthKey,
  hasCustomRoleAttendanceConfig,
} from '../utils/attendanceHelpers';
import { CONFIGURABLE_ROLES } from '../utils/menuPermissions';
import { AttendanceCameraModal } from './AttendanceCameraModal';

interface AttendanceViewProps {
  currentUser: User;
  users: User[];
  outlets: Outlet[];
  activeOutlet: Outlet;
  attendanceConfig: AttendanceConfig;
  attendanceRecords: AttendanceRecord[];
  onClockIn: (payload: {
    outletId?: string;
    photoDataUrl: string;
    location?: AttendanceLocationSnapshot;
    notes?: string;
  }) => { ok: boolean; record?: AttendanceRecord; error?: string };
  onClockOut: (payload: {
    recordId: string;
    photoDataUrl: string;
    location?: AttendanceLocationSnapshot;
    notes?: string;
  }) => { ok: boolean; record?: AttendanceRecord; error?: string };
  onSubmitLeave: (payload: {
    leaveType: 'IZIN' | 'SAKIT' | 'CUTI';
    dateKey?: string;
    notes: string;
    photoDataUrl?: string;
    location?: AttendanceLocationSnapshot;
  }) => { ok: boolean; record?: AttendanceRecord; error?: string };
  onUpdateConfig: (patch: Partial<AttendanceConfig>) => void;
  onSetRoleConfig: (role: ConfigurableRole, config: RoleAttendanceScheduleConfig) => void;
  onResetRoleConfig: (role: ConfigurableRole) => void;
  onToggleModuleEnabled: (enabled: boolean) => void;
  onSetAdminAccess: (adminUserId: string, access: AttendanceAdminPermission) => void;
  onVerifyRecord: (recordId: string) => void;
  onDeleteRecord: (recordId: string) => void;
  onNotify: (msg: string) => void;
}

type AttendanceTab = 'MY_ATTENDANCE' | 'MONITOR' | 'REPORT' | 'SETTINGS';

const ROLE_LABELS: Record<UserRole, string> = {
  PEMILIK: 'Pemilik',
  ADMIN: 'Admin',
  KASIR: 'Kasir',
  GUDANG: 'Gudang',
  KARYAWAN: 'Karyawan',
};

const STATUS_BADGE_CLASSES: Record<AttendanceStatus, string> = {
  TEPAT_WAKTU:
    'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-900',
  TERLAMBAT:
    'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-900',
  PULANG_AWAL:
    'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950/50 dark:text-orange-300 dark:border-orange-900',
  IZIN:
    'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/50 dark:text-sky-300 dark:border-sky-900',
  SAKIT:
    'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-900',
  CUTI:
    'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/50 dark:text-indigo-300 dark:border-indigo-900',
};

function formatClock(ts?: number): string {
  if (!ts) return '-';
  return new Date(ts).toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

function formatReadableDate(dateKey: string): string {
  const parts = dateKey.split('-').map(Number);
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return dateKey;
  const d = new Date(parts[0], parts[1] - 1, parts[2]);
  return d.toLocaleDateString('id-ID', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  currentUser,
  users,
  outlets,
  activeOutlet,
  attendanceConfig,
  attendanceRecords,
  onClockIn,
  onClockOut,
  onSubmitLeave,
  onUpdateConfig,
  onSetRoleConfig,
  onResetRoleConfig,
  onToggleModuleEnabled,
  onSetAdminAccess,
  onVerifyRecord,
  onDeleteRecord,
  onNotify,
}) => {
  const isModuleEnabled = attendanceConfig.enabled !== false;
  const permissions = useMemo(
    () => getAttendancePermissions(currentUser, attendanceConfig),
    [currentUser, attendanceConfig]
  );
  const myEffectiveConfig = useMemo(
    () => getEffectiveAttendanceConfigForRole(attendanceConfig, currentUser.role),
    [attendanceConfig, currentUser.role]
  );

  const [activeTab, setActiveTab] = useState<AttendanceTab>('MY_ATTENDANCE');
  const [nowTs, setNowTs] = useState<number>(() => Date.now());

  // Live GPS state for current device check-in/out
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [liveLocation, setLiveLocation] = useState<AttendanceLocationSnapshot | undefined>(
    undefined
  );
  const [gpsError, setGpsError] = useState<string | null>(null);

  // My Attendance inputs
  const [selectedOutletId, setSelectedOutletId] = useState<string>(activeOutlet.id);
  const [attendanceNote, setAttendanceNote] = useState<string>('');
  const [cameraModalMode, setCameraModalMode] = useState<
    null | 'CLOCK_IN' | 'CLOCK_OUT' | 'LEAVE_PROOF'
  >(null);

  // Leave request modal
  const [showLeaveModal, setShowLeaveModal] = useState<boolean>(false);
  const [leaveType, setLeaveType] = useState<'IZIN' | 'SAKIT' | 'CUTI'>('IZIN');
  const [leaveDateKey, setLeaveDateKey] = useState<string>(() => getLocalDateKey(Date.now()));
  const [leaveNotes, setLeaveNotes] = useState<string>('');
  const [leavePhotoDataUrl, setLeavePhotoDataUrl] = useState<string>('');

  // Monitor filters & detail modal
  const [monitorDate, setMonitorDate] = useState<string>(() => getLocalDateKey(Date.now()));
  const [showAllDates, setShowAllDates] = useState<boolean>(false);
  const [monitorUserFilter, setMonitorUserFilter] = useState<string>('ALL');
  const [monitorStatusFilter, setMonitorStatusFilter] = useState<string>('ALL');
  const [monitorSearch, setMonitorSearch] = useState<string>('');
  const [detailRecord, setDetailRecord] = useState<AttendanceRecord | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Report month filter
  const [reportMonth, setReportMonth] = useState<string>(() => getLocalMonthKey(Date.now()));

  // Config draft state (per DEFAULT or specific Role)
  const [selectedScheduleRole, setSelectedScheduleRole] = useState<'DEFAULT' | ConfigurableRole>(
    'DEFAULT'
  );
  const activeDraftConfig = useMemo(
    () =>
      selectedScheduleRole === 'DEFAULT'
        ? attendanceConfig
        : getEffectiveAttendanceConfigForRole(attendanceConfig, selectedScheduleRole),
    [attendanceConfig, selectedScheduleRole]
  );
  const [cfgStart, setCfgStart] = useState<string>(activeDraftConfig.workStartTime);
  const [cfgEnd, setCfgEnd] = useState<string>(activeDraftConfig.workEndTime);
  const [cfgTolerance, setCfgTolerance] = useState<number>(activeDraftConfig.lateToleranceMinutes);
  const [cfgRadius, setCfgRadius] = useState<number>(activeDraftConfig.geofenceRadiusMeters);
  const [cfgRequireGps, setCfgRequireGps] = useState<boolean>(activeDraftConfig.requireGps);
  const [cfgOutletLat, setCfgOutletLat] = useState<string>(
    activeDraftConfig.outletLatitude !== undefined ? String(activeDraftConfig.outletLatitude) : ''
  );
  const [cfgOutletLng, setCfgOutletLng] = useState<string>(
    activeDraftConfig.outletLongitude !== undefined ? String(activeDraftConfig.outletLongitude) : ''
  );
  const [capturingOutletGps, setCapturingOutletGps] = useState<boolean>(false);

  useEffect(() => {
    const id = window.setInterval(() => setNowTs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    setSelectedOutletId(activeOutlet.id);
  }, [activeOutlet.id]);

  useEffect(() => {
    setCfgStart(activeDraftConfig.workStartTime);
    setCfgEnd(activeDraftConfig.workEndTime);
    setCfgTolerance(activeDraftConfig.lateToleranceMinutes);
    setCfgRadius(activeDraftConfig.geofenceRadiusMeters);
    setCfgRequireGps(activeDraftConfig.requireGps);
    setCfgOutletLat(
      activeDraftConfig.outletLatitude !== undefined ? String(activeDraftConfig.outletLatitude) : ''
    );
    setCfgOutletLng(
      activeDraftConfig.outletLongitude !== undefined
        ? String(activeDraftConfig.outletLongitude)
        : ''
    );
  }, [activeDraftConfig]);

  useEffect(() => {
    setLiveLocation((prev) =>
      prev ? enrichLocationWithGeofence(prev, attendanceConfig, currentUser.role) : prev
    );
  }, [attendanceConfig, currentUser.role]);

  // Keep selected tab valid when permissions change
  useEffect(() => {
    if ((activeTab === 'MONITOR' || activeTab === 'REPORT') && !permissions.canViewAll) {
      setActiveTab('MY_ATTENDANCE');
    } else if (activeTab === 'SETTINGS' && !permissions.isOwner && !permissions.canManage) {
      setActiveTab('MY_ATTENDANCE');
    }
  }, [activeTab, permissions]);

  // Auto-acquire GPS location on mount
  const refreshDeviceLocation = async (): Promise<AttendanceLocationSnapshot | undefined> => {
    setGpsStatus('loading');
    setGpsError(null);
    const res = await captureCurrentDeviceLocation(attendanceConfig, currentUser.role);
    if (res.ok) {
      setLiveLocation(res.location);
      setGpsStatus('ready');
      return res.location;
    }
    setGpsStatus('error');
    setGpsError(res.error);
    return undefined;
  };

  useEffect(() => {
    void refreshDeviceLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const todayKey = getLocalDateKey(nowTs);

  const myRecords = useMemo(
    () =>
      attendanceRecords
        .filter((r) => r.userId === currentUser.id)
        .sort((a, b) => b.clockInAt - a.clockInAt),
    [attendanceRecords, currentUser.id]
  );

  const myTodayRecord = useMemo(
    () => myRecords.find((r) => r.dateKey === todayKey) || null,
    [myRecords, todayKey]
  );

  const isLeaveToday =
    myTodayRecord &&
    (myTodayRecord.status === 'IZIN' ||
      myTodayRecord.status === 'SAKIT' ||
      myTodayRecord.status === 'CUTI');

  const activeUsersList = useMemo(() => users.filter((u) => u.isActive), [users]);
  const staffUsersList = useMemo(() => users.filter((u) => u.role !== 'PEMILIK'), [users]);

  const todayMonitorStats = useMemo(() => {
    const todays = attendanceRecords.filter((r) => r.dateKey === monitorDate);
    const present = todays.filter(
      (r) => r.status === 'TEPAT_WAKTU' || r.status === 'TERLAMBAT' || r.status === 'PULANG_AWAL'
    );
    const onTime = todays.filter((r) => r.status === 'TEPAT_WAKTU');
    const late = todays.filter((r) => r.status === 'TERLAMBAT');
    const leaves = todays.filter(
      (r) => r.status === 'IZIN' || r.status === 'SAKIT' || r.status === 'CUTI'
    );
    const recordedUserIds = new Set(todays.map((r) => r.userId));
    const notCheckedIn = activeUsersList.filter((u) => !recordedUserIds.has(u.id));
    return {
      presentCount: present.length,
      onTimeCount: onTime.length,
      lateCount: late.length,
      leaveCount: leaves.length,
      notCheckedIn,
    };
  }, [attendanceRecords, monitorDate, activeUsersList]);

  const filteredMonitorRecords = useMemo(() => {
    const q = monitorSearch.trim().toLowerCase();
    return attendanceRecords
      .filter((r) => {
        if (!showAllDates && monitorDate && r.dateKey !== monitorDate) return false;
        if (monitorUserFilter !== 'ALL' && r.userId !== monitorUserFilter) return false;
        if (monitorStatusFilter !== 'ALL' && r.status !== monitorStatusFilter) return false;
        if (q) {
          const hay = `${r.userName} ${r.outletName} ${r.notes || ''}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.clockInAt - a.clockInAt);
  }, [
    attendanceRecords,
    showAllDates,
    monitorDate,
    monitorUserFilter,
    monitorStatusFilter,
    monitorSearch,
  ]);

  const monthRecords = useMemo(
    () =>
      attendanceRecords
        .filter((r) => r.dateKey.startsWith(reportMonth))
        .sort((a, b) => b.clockInAt - a.clockInAt),
    [attendanceRecords, reportMonth]
  );

  const monthlySummaryByUser = useMemo(() => {
    const map = new Map<
      string,
      {
        userId: string;
        userName: string;
        userRole: UserRole;
        presentDays: number;
        onTimeDays: number;
        lateDays: number;
        totalLateMinutes: number;
        leaveDays: number;
        totalWorkMinutes: number;
        totalOvertimeMinutes: number;
      }
    >();

    users.forEach((u) => {
      map.set(u.id, {
        userId: u.id,
        userName: u.fullName,
        userRole: u.role,
        presentDays: 0,
        onTimeDays: 0,
        lateDays: 0,
        totalLateMinutes: 0,
        leaveDays: 0,
        totalWorkMinutes: 0,
        totalOvertimeMinutes: 0,
      });
    });

    monthRecords.forEach((r) => {
      const entry = map.get(r.userId) || {
        userId: r.userId,
        userName: r.userName,
        userRole: r.userRole,
        presentDays: 0,
        onTimeDays: 0,
        lateDays: 0,
        totalLateMinutes: 0,
        leaveDays: 0,
        totalWorkMinutes: 0,
        totalOvertimeMinutes: 0,
      };
      if (r.status === 'IZIN' || r.status === 'SAKIT' || r.status === 'CUTI') {
        entry.leaveDays += 1;
      } else {
        entry.presentDays += 1;
        if (r.status === 'TEPAT_WAKTU') entry.onTimeDays += 1;
        if (r.status === 'TERLAMBAT') {
          entry.lateDays += 1;
          entry.totalLateMinutes += r.lateMinutes || 0;
        }
        entry.totalWorkMinutes += r.workDurationMinutes || 0;
        entry.totalOvertimeMinutes += r.overtimeMinutes || 0;
      }
      map.set(r.userId, entry);
    });

    return Array.from(map.values()).sort((a, b) => b.presentDays - a.presentDays);
  }, [users, monthRecords]);

  const startCameraFlow = async (mode: 'CLOCK_IN' | 'CLOCK_OUT') => {
    let loc = liveLocation;
    if (!loc) {
      loc = await refreshDeviceLocation();
    }
    if (myEffectiveConfig.requireGps && !loc) {
      onNotify(
        'Lokasi GPS wajib aktif untuk absensi. Klik Perbarui GPS dan izinkan akses lokasi pada HP/browser.'
      );
      return;
    }
    setCameraModalMode(mode);
  };

  const handleCameraCaptured = (photoDataUrl: string) => {
    if (cameraModalMode === 'CLOCK_IN') {
      const res = onClockIn({
        outletId: selectedOutletId,
        photoDataUrl,
        location: liveLocation,
        notes: attendanceNote,
      });
      if (!res.ok && res.error) {
        onNotify(res.error);
      } else {
        setAttendanceNote('');
      }
      setCameraModalMode(null);
      return;
    }

    if (cameraModalMode === 'CLOCK_OUT' && myTodayRecord) {
      const res = onClockOut({
        recordId: myTodayRecord.id,
        photoDataUrl,
        location: liveLocation,
        notes: attendanceNote,
      });
      if (!res.ok && res.error) {
        onNotify(res.error);
      } else {
        setAttendanceNote('');
      }
      setCameraModalMode(null);
      return;
    }

    if (cameraModalMode === 'LEAVE_PROOF') {
      setLeavePhotoDataUrl(photoDataUrl);
      setCameraModalMode(null);
    }
  };

  const handleLeaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onSubmitLeave({
      leaveType,
      dateKey: leaveDateKey,
      notes: leaveNotes,
      photoDataUrl: leavePhotoDataUrl || undefined,
      location: liveLocation,
    });
    if (!res.ok) {
      onNotify(res.error || 'Gagal menyimpan pengajuan');
      return;
    }
    setLeaveNotes('');
    setLeavePhotoDataUrl('');
    setShowLeaveModal(false);
  };

  const handleDownloadCsv = () => {
    const csv = buildAttendanceCsv(monthRecords, permissions.canViewLocation);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rekap-absensi-${reportMonth}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onNotify(`Rekap absensi ${reportMonth}.csv berhasil diunduh`);
  };

  const handleCaptureOutletGps = async () => {
    setCapturingOutletGps(true);
    const res = await captureCurrentDeviceLocation(attendanceConfig);
    setCapturingOutletGps(false);
    if (!res.ok) {
      onNotify(res.error);
      return;
    }
    setCfgOutletLat(res.location.latitude.toFixed(6));
    setCfgOutletLng(res.location.longitude.toFixed(6));
    onNotify('Koordinat GPS outlet berhasil diambil dari perangkat ini');
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedLat = cfgOutletLat.trim() ? Number(cfgOutletLat.trim()) : undefined;
    const parsedLng = cfgOutletLng.trim() ? Number(cfgOutletLng.trim()) : undefined;
    if (
      (parsedLat !== undefined && !Number.isFinite(parsedLat)) ||
      (parsedLng !== undefined && !Number.isFinite(parsedLng))
    ) {
      onNotify('Koordinat latitude/longitude outlet tidak valid');
      return;
    }
    const cleanPayload: RoleAttendanceScheduleConfig = {
      workStartTime: cfgStart,
      workEndTime: cfgEnd,
      lateToleranceMinutes: Math.max(0, Math.round(cfgTolerance || 0)),
      geofenceRadiusMeters: Math.max(10, Math.round(cfgRadius || 150)),
      requireGps: cfgRequireGps,
      outletLatitude: parsedLat,
      outletLongitude: parsedLng,
    };

    if (selectedScheduleRole === 'DEFAULT') {
      onUpdateConfig(cleanPayload);
    } else {
      onSetRoleConfig(selectedScheduleRole, cleanPayload);
    }
  };

  const renderLocationSummary = (
    loc?: AttendanceLocationSnapshot,
    fallbackMaskedText = 'Lokasi terkunci (khusus Pemilik / Admin berizin)'
  ) => {
    if (!permissions.canViewLocation) {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
          <Lock className="w-3.5 h-3.5 shrink-0" />
          <span>{fallbackMaskedText}</span>
        </span>
      );
    }
    if (!loc) {
      return <span className="text-xs text-slate-400">Lokasi tidak tercatat</span>;
    }
    return (
      <div className="space-y-1">
        <p className="text-xs font-medium text-slate-800 dark:text-slate-200 line-clamp-2">
          {loc.addressLabel || `${loc.latitude.toFixed(5)}, ${loc.longitude.toFixed(5)}`}
        </p>
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-500 dark:text-slate-400">
          <span className="font-mono">
            {loc.latitude.toFixed(5)}, {loc.longitude.toFixed(5)}
          </span>
          {typeof loc.accuracyMeters === 'number' && <span>±{loc.accuracyMeters}m</span>}
          {typeof loc.distanceMeters === 'number' && (
            <span
              className={`px-1.5 py-0.5 rounded font-semibold ${
                loc.withinGeofence
                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                  : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
              }`}
            >
              {loc.distanceMeters}m ({loc.withinGeofence ? 'Dalam Area' : 'Luar Area'})
            </span>
          )}
          <a
            href={buildGoogleMapsLink(loc.latitude, loc.longitude)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-teal-700 dark:text-teal-400 hover:underline font-semibold"
          >
            <Navigation className="w-3 h-3" />
            <span>Buka Peta</span>
          </a>
        </div>
      </div>
    );
  };

  if (!isModuleEnabled && !permissions.isOwner) {
    return (
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3 max-w-lg mx-auto my-8">
        <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h1 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          Menu Absensi Karyawan Dinonaktifkan
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          Menu Absensi Karyawan sedang dinonaktifkan oleh Pemilik toko. Hubungi Pemilik apabila
          fitur ini perlu diaktifkan kembali.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* PEMILIK MASTER ENABLE / DISABLE BANNER */}
      {permissions.isOwner && !isModuleEnabled && (
        <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <Lock className="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-amber-950 dark:text-amber-100">
                Menu Absensi Karyawan Sedang Dinonaktifkan
              </p>
              <p className="text-xs text-amber-800 dark:text-amber-300 mt-0.5">
                Seluruh akun karyawan (Admin, Kasir, &amp; Gudang) tidak dapat melihat atau mengakses
                menu ini sampai Anda mengaktifkannya kembali.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onToggleModuleEnabled(true)}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold cursor-pointer whitespace-nowrap shrink-0"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Aktifkan Menu Absensi</span>
          </button>
        </div>
      )}

      {/* HEADER & SUB-NAVIGATION */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-teal-700 dark:text-teal-400" />
              <span>Absensi Karyawan</span>
            </h1>
            {permissions.isOwner && (
              <button
                type="button"
                onClick={() => onToggleModuleEnabled(!isModuleEnabled)}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer transition-colors ${
                  isModuleEnabled
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-900'
                    : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-900'
                }`}
                title="Klik untuk mengaktifkan atau menonaktifkan menu Absensi bagi semua karyawan"
              >
                {isModuleEnabled ? 'Aktif (Klik untuk Nonaktifkan)' : 'Nonaktif (Klik untuk Aktifkan)'}
              </button>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Verifikasi kamera HP langsung (tanpa galeri) &amp; pelacakan GPS real-time.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 bg-white dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('MY_ATTENDANCE')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              activeTab === 'MY_ATTENDANCE'
                ? 'bg-teal-700 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Absensi Saya</span>
          </button>

          {permissions.canViewAll && (
            <>
              <button
                type="button"
                onClick={() => setActiveTab('MONITOR')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  activeTab === 'MONITOR'
                    ? 'bg-teal-700 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Monitor &amp; Lokasi</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('REPORT')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  activeTab === 'REPORT'
                    ? 'bg-teal-700 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Rekap &amp; Laporan</span>
              </button>
            </>
          )}

          {(permissions.isOwner || permissions.canManage) && (
            <button
              type="button"
              onClick={() => setActiveTab('SETTINGS')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'SETTINGS'
                  ? 'bg-teal-700 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>
                {permissions.isOwner ? 'Jadwal, Geofence & Akses' : 'Jadwal & Geofence'}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: ABSENSI SAYA */}
      {activeTab === 'MY_ATTENDANCE' && (
        <div className="space-y-5">
          {currentUser.role === 'ADMIN' && (!permissions.canViewAll || !permissions.canManage) && (
            <div className="rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 p-3.5 flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
              <Lock className="w-4 h-4 shrink-0 mt-0.5 text-amber-700 dark:text-amber-400" />
              <div>
                <p className="font-semibold">
                  Akses Monitor, Lokasi &amp; Pengaturan Jadwal / Geofence Terbatas
                </p>
                <p className="mt-0.5 text-amber-800 dark:text-amber-300">
                  Hanya akun Pemilik yang dapat mengatur jadwal &amp; akses secara otomatis. Admin hanya dapat membuka halaman Monitor atau Pengaturan Jadwal Kerja &amp; Radius Lokasi (Geofence) apabila sudah diberi akses oleh Pemilik.
                </p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* CLOCK & CHECK-IN CARD */}
            <div className="lg:col-span-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-teal-700 dark:text-teal-400">
                    {formatReadableDate(todayKey)}
                  </p>
                  <p className="text-3xl font-extrabold font-mono tracking-tight text-slate-900 dark:text-slate-100 mt-1">
                    {new Date(nowTs).toLocaleTimeString('id-ID', {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex flex-wrap items-center gap-1.5">
                    <span>
                      Jam Kerja ({ROLE_LABELS[currentUser.role]}):{' '}
                      <strong>{myEffectiveConfig.workStartTime}</strong> –{' '}
                      <strong>{myEffectiveConfig.workEndTime}</strong> · Toleransi{' '}
                      <strong>{myEffectiveConfig.lateToleranceMinutes} mnt</strong> · Radius{' '}
                      <strong>{myEffectiveConfig.geofenceRadiusMeters}m</strong>
                    </span>
                    {hasCustomRoleAttendanceConfig(attendanceConfig, currentUser.role) && (
                      <span className="px-1.5 py-0.5 rounded bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-[10px] font-bold">
                        Khusus Role
                      </span>
                    )}
                  </p>
                </div>

                <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2.5 text-xs space-y-1">
                  <p className="font-bold text-slate-800 dark:text-slate-200">
                    {currentUser.fullName}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400">
                    Peran: {ROLE_LABELS[currentUser.role]} · Outlet: {activeOutlet.name}
                  </p>
                </div>
              </div>

              {/* LIVE GPS READOUT */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <MapPin className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                    <span>Status Lokasi GPS Perangkat</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => void refreshDeviceLocation()}
                    disabled={gpsStatus === 'loading'}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${gpsStatus === 'loading' ? 'animate-spin' : ''}`}
                    />
                    <span>Perbarui GPS</span>
                  </button>
                </div>

                {gpsStatus === 'loading' && (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Sedang membaca koordinat GPS dari perangkat...
                  </p>
                )}

                {gpsStatus === 'ready' && liveLocation && (
                  <div className="text-xs space-y-1">
                    <p className="font-semibold text-emerald-700 dark:text-emerald-400">
                      GPS Terkunci: {liveLocation.addressLabel}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                      Koordinat: {liveLocation.latitude.toFixed(6)},{' '}
                      {liveLocation.longitude.toFixed(6)}
                      {typeof liveLocation.accuracyMeters === 'number'
                        ? ` · Akurasi ±${liveLocation.accuracyMeters}m`
                        : ''}
                      {typeof liveLocation.distanceMeters === 'number'
                        ? ` · Jarak ke outlet ${liveLocation.distanceMeters}m (${
                            liveLocation.withinGeofence ? 'Dalam Radius' : 'Di Luar Radius'
                          })`
                        : ''}
                    </p>
                  </div>
                )}

                {gpsStatus === 'error' && (
                  <div className="flex items-start gap-2 text-xs text-amber-800 dark:text-amber-300">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold">{gpsError}</p>
                      <p className="text-[11px] opacity-90 mt-0.5">
                        {myEffectiveConfig.requireGps
                          ? 'Kebijakan aktif mewajibkan GPS terbaca sebelum absensi.'
                          : 'GPS opsional saat ini, Anda tetap dapat absen dengan kamera langsung.'}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* OUTLET & NOTES INPUTS */}
              {(!myTodayRecord || (!myTodayRecord.clockOutAt && !isLeaveToday)) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {!myTodayRecord && (
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Lokasi Outlet Tugas
                      </label>
                      <select
                        value={selectedOutletId}
                        onChange={(e) => setSelectedOutletId(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-medium"
                      >
                        {outlets.map((o) => (
                          <option key={o.id} value={o.id}>
                            {o.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div className={myTodayRecord ? 'sm:col-span-2' : ''}>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Catatan Kehadiran (Opsional)
                    </label>
                    <input
                      type="text"
                      value={attendanceNote}
                      onChange={(e) => setAttendanceNote(e.target.value)}
                      placeholder="Misal: Shift pagi kasir depan / tugas antar stok"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                    />
                  </div>
                </div>
              )}

              {/* ACTION BUTTONS */}
              {!myTodayRecord && (
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    type="button"
                    onClick={() => void startCameraFlow('CLOCK_IN')}
                    className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-sm font-bold cursor-pointer shadow-sm"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Absen Masuk (Kamera HP Langsung)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLeaveDateKey(todayKey);
                      setShowLeaveModal(true);
                    }}
                    className="inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <CalendarDays className="w-4 h-4" />
                    <span>Ajukan Izin / Sakit / Cuti</span>
                  </button>
                </div>
              )}

              {myTodayRecord && !myTodayRecord.clockOutAt && !isLeaveToday && (
                <div className="rounded-xl border border-teal-200 dark:border-teal-900 bg-teal-50/70 dark:bg-teal-950/30 p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-xs font-bold text-teal-800 dark:text-teal-300">
                        Sedang Bertugas Sejak {formatClock(myTodayRecord.clockInAt)}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                        Durasi berjalan:{' '}
                        <strong>
                          {formatDurationMinutes(
                            Math.max(0, Math.round((nowTs - myTodayRecord.clockInAt) / 60000))
                          )}
                        </strong>
                      </p>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                        STATUS_BADGE_CLASSES[myTodayRecord.status]
                      }`}
                    >
                      {ATTENDANCE_STATUS_LABELS[myTodayRecord.status]}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => void startCameraFlow('CLOCK_OUT')}
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold cursor-pointer shadow-sm"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Absen Pulang (Kamera HP Langsung)</span>
                  </button>
                </div>
              )}

              {myTodayRecord && (myTodayRecord.clockOutAt || isLeaveToday) && (
                <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/30 p-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                        {isLeaveToday
                          ? `Status Hari Ini: ${ATTENDANCE_STATUS_LABELS[myTodayRecord.status]}`
                          : 'Absensi Hari Ini Lengkap'}
                      </p>
                      <p className="text-xs text-emerald-800 dark:text-emerald-300 mt-0.5">
                        {isLeaveToday
                          ? myTodayRecord.notes
                          : `Masuk ${formatClock(myTodayRecord.clockInAt)} · Pulang ${formatClock(
                              myTodayRecord.clockOutAt
                            )} · Total ${formatDurationMinutes(myTodayRecord.workDurationMinutes)}`}
                      </p>
                    </div>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                      STATUS_BADGE_CLASSES[myTodayRecord.status]
                    }`}
                  >
                    {ATTENDANCE_STATUS_LABELS[myTodayRecord.status]}
                  </span>
                </div>
              )}
            </div>

            {/* TODAY'S PHOTO PROOF & POLICY SUMMARY */}
            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                <span>Bukti Foto Hari Ini</span>
              </h2>

              <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
                <p className="font-bold text-slate-800 dark:text-slate-100">
                  Kebijakan Anti-Kecurangan
                </p>
                <p>• Foto wajib diambil live dari kamera HP.</p>
                <p>• Upload dari galeri/file dinonaktifkan total.</p>
                <p>• Koordinat GPS disimpan &amp; dapat dipantau Pemilik.</p>
              </div>

              {myTodayRecord ? (
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="space-y-1">
                    <p className="text-[11px] font-semibold text-slate-500">Foto Masuk</p>
                    {myTodayRecord.clockInPhoto ? (
                      <img
                        src={myTodayRecord.clockInPhoto}
                        alt="Selfie Masuk"
                        className="w-full aspect-[4/3] object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                      />
                    ) : (
                      <div className="w-full aspect-[4/3] rounded-lg border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center text-[11px] text-slate-400">
                        Tanpa Foto
                      </div>
                    )}
                  </div>
                  <div className="space-y-1">
                    <p className="text-[11px] font-semibold text-slate-500">Foto Pulang</p>
                    {myTodayRecord.clockOutPhoto ? (
                      <img
                        src={myTodayRecord.clockOutPhoto}
                        alt="Selfie Pulang"
                        className="w-full aspect-[4/3] object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                      />
                    ) : (
                      <div className="w-full aspect-[4/3] rounded-lg border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center text-[11px] text-slate-400">
                        Belum Pulang
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                  Belum ada foto absensi hari ini. Klik tombol Absen Masuk untuk membuka kamera HP.
                </div>
              )}
            </div>
          </div>

          {/* PERSONAL ATTENDANCE HISTORY */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>Riwayat Absensi Saya ({myRecords.length})</span>
            </h2>

            {myRecords.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 py-4 text-center">
                Belum ada riwayat absensi untuk akun ini.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                      <th className="py-2.5 pr-3 font-semibold">Tanggal</th>
                      <th className="py-2.5 px-3 font-semibold">Outlet</th>
                      <th className="py-2.5 px-3 font-semibold">Masuk</th>
                      <th className="py-2.5 px-3 font-semibold">Pulang</th>
                      <th className="py-2.5 px-3 font-semibold">Durasi</th>
                      <th className="py-2.5 px-3 font-semibold">Status</th>
                      <th className="py-2.5 pl-3 font-semibold text-right">Detail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {myRecords.slice(0, 20).map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 pr-3 font-semibold whitespace-nowrap">
                          {formatReadableDate(rec.dateKey)}
                        </td>
                        <td className="py-2.5 px-3">{rec.outletName}</td>
                        <td className="py-2.5 px-3 font-mono">{formatClock(rec.clockInAt)}</td>
                        <td className="py-2.5 px-3 font-mono">{formatClock(rec.clockOutAt)}</td>
                        <td className="py-2.5 px-3">
                          {rec.workDurationMinutes > 0
                            ? formatDurationMinutes(rec.workDurationMinutes)
                            : '-'}
                        </td>
                        <td className="py-2.5 px-3">
                          <span
                            className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-bold border ${
                              STATUS_BADGE_CLASSES[rec.status]
                            }`}
                          >
                            {ATTENDANCE_STATUS_LABELS[rec.status]}
                          </span>
                        </td>
                        <td className="py-2.5 pl-3 text-right">
                          <button
                            type="button"
                            onClick={() => setDetailRecord(rec)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 text-[11px] font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Lihat</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: MONITOR & LOKASI KARYAWAN */}
      {activeTab === 'MONITOR' && permissions.canViewAll && (
        <div className="space-y-5">
          {/* LOCATION ACCESS NOTICE IF ADMIN WITHOUT LOCATION PERMISSION */}
          {!permissions.canViewLocation && (
            <div className="rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 p-3.5 flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
              <Lock className="w-4 h-4 shrink-0 mt-0.5 text-amber-700 dark:text-amber-400" />
              <div>
                <p className="font-semibold">Akses Koordinat Lokasi GPS Dinonaktifkan Pemilik</p>
                <p className="mt-0.5">
                  Anda dapat memantau daftar kehadiran dan foto absensi, namun koordinat GPS dan
                  tautan peta karyawan disembunyikan sampai Pemilik mengizinkannya.
                </p>
              </div>
            </div>
          )}

          {/* KPI CARDS */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-[11px] font-semibold text-slate-500">Hadir ({monitorDate})</p>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 mt-1">
                {todayMonitorStats.presentCount}
              </p>
            </div>
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-[11px] font-semibold text-emerald-600">Tepat Waktu</p>
              <p className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-400 mt-1">
                {todayMonitorStats.onTimeCount}
              </p>
            </div>
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-[11px] font-semibold text-amber-600">Terlambat</p>
              <p className="text-2xl font-extrabold text-amber-700 dark:text-amber-400 mt-1">
                {todayMonitorStats.lateCount}
              </p>
            </div>
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-[11px] font-semibold text-sky-600">Izin / Sakit / Cuti</p>
              <p className="text-2xl font-extrabold text-sky-700 dark:text-sky-400 mt-1">
                {todayMonitorStats.leaveCount}
              </p>
            </div>
            <div className="col-span-2 lg:col-span-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-[11px] font-semibold text-slate-500">Belum Absen</p>
              <p className="text-2xl font-extrabold text-rose-600 dark:text-rose-400 mt-1">
                {todayMonitorStats.notCheckedIn.length}
              </p>
            </div>
          </div>

          {todayMonitorStats.notCheckedIn.length > 0 && (
            <div className="rounded-xl bg-slate-100 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 px-4 py-2.5 text-xs flex flex-wrap items-center gap-2">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Belum absen pada {monitorDate}:
              </span>
              {todayMonitorStats.notCheckedIn.map((u) => (
                <span
                  key={u.id}
                  className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium"
                >
                  {u.fullName} ({ROLE_LABELS[u.role]})
                </span>
              ))}
            </div>
          )}

          {/* FILTER BAR */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                Cari Karyawan / Catatan
              </label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={monitorSearch}
                  onChange={(e) => setMonitorSearch(e.target.value)}
                  placeholder="Nama atau catatan..."
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                Tanggal
              </label>
              <input
                type="date"
                value={monitorDate}
                disabled={showAllDates}
                onChange={(e) => setMonitorDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                Karyawan
              </label>
              <select
                value={monitorUserFilter}
                onChange={(e) => setMonitorUserFilter(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
              >
                <option value="ALL">Semua Karyawan</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                Status
              </label>
              <select
                value={monitorStatusFilter}
                onChange={(e) => setMonitorStatusFilter(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
              >
                <option value="ALL">Semua Status</option>
                {Object.entries(ATTENDANCE_STATUS_LABELS).map(([k, label]) => (
                  <option key={k} value={k}>
                    {label}
                  </option>
                ))}
              </select>
            </div>

            <label className="inline-flex items-center gap-2 py-2 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-semibold cursor-pointer">
              <input
                type="checkbox"
                checked={showAllDates}
                onChange={(e) => setShowAllDates(e.target.checked)}
                className="rounded"
              />
              <span>Tampilkan Semua Tanggal</span>
            </label>
          </div>

          {/* MONITOR TABLE */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 overflow-x-auto">
            {filteredMonitorRecords.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 py-8 text-center">
                Tidak ada data absensi untuk filter yang dipilih.
              </p>
            ) : (
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="py-2.5 pr-3 font-semibold">Karyawan</th>
                    <th className="py-2.5 px-3 font-semibold">Tanggal &amp; Jam</th>
                    <th className="py-2.5 px-3 font-semibold">Foto Selfie</th>
                    <th className="py-2.5 px-3 font-semibold">Lokasi GPS Masuk</th>
                    <th className="py-2.5 px-3 font-semibold">Status</th>
                    <th className="py-2.5 pl-3 font-semibold text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredMonitorRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 align-top">
                      <td className="py-3 pr-3">
                        <p className="font-bold text-slate-900 dark:text-slate-100">
                          {rec.userName}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          {ROLE_LABELS[rec.userRole]} · {rec.outletName}
                        </p>
                        {rec.verifiedBy && (
                          <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-semibold text-emerald-700 dark:text-emerald-400">
                            <ShieldCheck className="w-3 h-3" />
                            Diverifikasi {rec.verifiedBy}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        <p className="font-semibold">{formatReadableDate(rec.dateKey)}</p>
                        <p className="font-mono text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                          Masuk: {formatClock(rec.clockInAt)}
                        </p>
                        <p className="font-mono text-[11px] text-slate-500">
                          Pulang: {formatClock(rec.clockOutAt)}
                        </p>
                        {rec.workDurationMinutes > 0 && (
                          <p className="text-[11px] text-teal-700 dark:text-teal-400 font-semibold mt-0.5">
                            Durasi: {formatDurationMinutes(rec.workDurationMinutes)}
                          </p>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5">
                          {rec.clockInPhoto ? (
                            <button
                              type="button"
                              onClick={() => setDetailRecord(rec)}
                              className="cursor-pointer group relative"
                              title="Klik untuk memperbesar foto masuk"
                            >
                              <img
                                src={rec.clockInPhoto}
                                alt={`Masuk ${rec.userName}`}
                                className="w-12 h-10 object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                              />
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400">-</span>
                          )}
                          {rec.clockOutPhoto && (
                            <button
                              type="button"
                              onClick={() => setDetailRecord(rec)}
                              className="cursor-pointer"
                              title="Klik untuk memperbesar foto pulang"
                            >
                              <img
                                src={rec.clockOutPhoto}
                                alt={`Pulang ${rec.userName}`}
                                className="w-12 h-10 object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                              />
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-3 max-w-[260px]">
                        {renderLocationSummary(rec.clockInLocation)}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-bold border ${
                            STATUS_BADGE_CLASSES[rec.status]
                          }`}
                        >
                          {ATTENDANCE_STATUS_LABELS[rec.status]}
                        </span>
                        {rec.lateMinutes > 0 && (
                          <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-1">
                            Telat {rec.lateMinutes} mnt
                          </p>
                        )}
                        {rec.overtimeMinutes > 0 && (
                          <p className="text-[11px] text-teal-700 dark:text-teal-400 mt-0.5">
                            Lembur {rec.overtimeMinutes} mnt
                          </p>
                        )}
                      </td>
                      <td className="py-3 pl-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setDetailRecord(rec)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-[11px] font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Detail</span>
                          </button>

                          {permissions.canManage && !rec.verifiedBy && (
                            <button
                              type="button"
                              onClick={() => onVerifyRecord(rec.id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold cursor-pointer"
                              title="Verifikasi absensi"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {permissions.canManage &&
                            (confirmDeleteId === rec.id ? (
                              <button
                                type="button"
                                onClick={() => {
                                  onDeleteRecord(rec.id);
                                  setConfirmDeleteId(null);
                                }}
                                className="px-2 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer"
                              >
                                Hapus?
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(rec.id)}
                                className="p-1.5 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                                title="Hapus catatan absensi"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: REKAP & LAPORAN */}
      {activeTab === 'REPORT' && permissions.canViewAll && (
        <div className="space-y-4">
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Periode Bulan:
              </label>
              <input
                type="month"
                value={reportMonth}
                onChange={(e) => setReportMonth(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
              />
            </div>

            <button
              type="button"
              onClick={handleDownloadCsv}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>
                Unduh Rekap CSV ({monthRecords.length} Baris
                {permissions.canViewLocation ? ' + Lokasi GPS' : ''})
              </span>
            </button>
          </div>

          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="py-2.5 pr-3 font-semibold">Karyawan</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Hadir</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Tepat Waktu</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Terlambat</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Akumulasi Telat</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Izin / Sakit / Cuti</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Total Jam Kerja</th>
                  <th className="py-2.5 pl-3 font-semibold text-center">Lembur</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {monthlySummaryByUser.map((row) => (
                  <tr key={row.userId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 pr-3">
                      <p className="font-bold text-slate-900 dark:text-slate-100">
                        {row.userName}
                      </p>
                      <p className="text-[11px] text-slate-500">{ROLE_LABELS[row.userRole]}</p>
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold">{row.presentDays} hari</td>
                    <td className="py-2.5 px-3 text-center text-emerald-700 dark:text-emerald-400 font-semibold">
                      {row.onTimeDays}
                    </td>
                    <td className="py-2.5 px-3 text-center text-amber-700 dark:text-amber-400 font-semibold">
                      {row.lateDays}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {row.totalLateMinutes > 0 ? `${row.totalLateMinutes} mnt` : '-'}
                    </td>
                    <td className="py-2.5 px-3 text-center text-sky-700 dark:text-sky-400 font-semibold">
                      {row.leaveDays}
                    </td>
                    <td className="py-2.5 px-3 text-center font-semibold">
                      {row.totalWorkMinutes > 0
                        ? formatDurationMinutes(row.totalWorkMinutes)
                        : '-'}
                    </td>
                    <td className="py-2.5 pl-3 text-center text-teal-700 dark:text-teal-400 font-semibold">
                      {row.totalOvertimeMinutes > 0
                        ? formatDurationMinutes(row.totalOvertimeMinutes)
                        : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: PENGATURAN JADWAL & HAK AKSES MONITOR STAF (KHUSUS PEMILIK / ADMIN BERIZIN) */}
      {activeTab === 'SETTINGS' && (permissions.isOwner || permissions.canManage) && (
        <div className="space-y-4">
          {!permissions.isOwner && (
            <div className="rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 px-4 py-3 flex items-start gap-2.5 text-xs text-teal-900 dark:text-teal-100">
              <ShieldCheck className="w-4 h-4 text-teal-700 dark:text-teal-400 shrink-0 mt-0.5" />
              <span>
                Anda membuka halaman <strong>Jadwal Kerja &amp; Radius Lokasi (Geofence)</strong>{' '}
                berdasarkan izin yang diberikan oleh akun <strong>Pemilik</strong>. Pengaturan hak akses staf tetap dikelola khusus oleh Pemilik.
              </span>
            </div>
          )}

          <div
            className={
              permissions.isOwner ? 'grid grid-cols-1 lg:grid-cols-2 gap-5' : 'max-w-3xl'
            }
          >
            {/* OWNER-ONLY STAFF ATTENDANCE PERMISSIONS PANEL */}
            {permissions.isOwner && (
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                    <span>Hak Akses Monitor &amp; Lokasi Staf (Khusus Pemilik)</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Semua fitur absensi, jadwal, &amp; lokasi otomatis terbuka untuk Pemilik. Admin dan staf hanya dapat membuka menu monitor atau pengaturan jadwal &amp; geofence apabila diberi izin di bawah ini.
                  </p>
                </div>

                {staffUsersList.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-4 text-xs text-slate-500">
                    Belum ada akun staf non-Pemilik. Buat akun baru di menu Master Data atau
                    Developer Console untuk mengatur hak aksesnya.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {staffUsersList.map((staff) => {
                      const currentAccess: AttendanceAdminPermission = attendanceConfig
                        .adminAccessByUserId?.[staff.id] || {
                        viewAttendance: false,
                        viewLocation: false,
                        manageAttendance: false,
                      };

                      const updateFlag = (
                        field: keyof AttendanceAdminPermission,
                        checked: boolean
                      ) => {
                        const next: AttendanceAdminPermission = {
                          ...currentAccess,
                          [field]: checked,
                        };
                        if ((field === 'viewLocation' || field === 'manageAttendance') && checked) {
                          next.viewAttendance = true;
                        }
                        onSetAdminAccess(staff.id, next);
                      };

                      return (
                        <div
                          key={staff.id}
                          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-3"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div>
                              <div className="flex flex-wrap items-center gap-1.5">
                                <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                                  {staff.fullName}{' '}
                                  <span className="text-slate-400 font-normal">@{staff.username}</span>
                                </p>
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                  {ROLE_LABELS[staff.role]}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500">
                                Status akun: {staff.isActive ? 'Aktif' : 'Nonaktif'}
                              </p>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  onSetAdminAccess(staff.id, {
                                    viewAttendance: true,
                                    viewLocation: true,
                                    manageAttendance: true,
                                  })
                                }
                                className="px-2.5 py-1 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-[11px] font-semibold cursor-pointer"
                              >
                                Berikan Semua
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  onSetAdminAccess(staff.id, {
                                    viewAttendance: false,
                                    viewLocation: false,
                                    manageAttendance: false,
                                  })
                                }
                                className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                              >
                                Cabut Akses
                              </button>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 gap-2 text-xs">
                            <label className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
                              <span>Lihat Rekap, Monitor &amp; Foto Karyawan</span>
                              <input
                                type="checkbox"
                                checked={currentAccess.viewAttendance}
                                onChange={(e) => updateFlag('viewAttendance', e.target.checked)}
                              />
                            </label>

                            <label className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
                              <span>Baca Koordinat Lokasi GPS &amp; Peta Karyawan</span>
                              <input
                                type="checkbox"
                                checked={currentAccess.viewLocation}
                                onChange={(e) => updateFlag('viewLocation', e.target.checked)}
                              />
                            </label>

                            <label className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
                              <span>
                                Buka &amp; Atur Jadwal Kerja, Radius Geofence, Verifikasi &amp; Hapus
                              </span>
                              <input
                                type="checkbox"
                                checked={currentAccess.manageAttendance}
                                onChange={(e) => updateFlag('manageAttendance', e.target.checked)}
                              />
                            </label>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* SCHEDULE & GEOFENCE FORM (PER-ROLE & STANDAR DEFAULT) */}
            <form
              onSubmit={handleSaveConfig}
              className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                    <span>Jadwal Kerja &amp; Radius Lokasi (Geofence)</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Atur jadwal standar atau sesuaikan jam kerja, toleransi, dan radius geofence untuk setiap role secara terpisah.
                  </p>
                </div>

                {selectedScheduleRole !== 'DEFAULT' &&
                  hasCustomRoleAttendanceConfig(attendanceConfig, selectedScheduleRole) && (
                    <button
                      type="button"
                      onClick={() => onResetRoleConfig(selectedScheduleRole)}
                      className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      Reset Ikut Standar
                    </button>
                  )}
              </div>

              {/* ROLE SELECTOR TABS */}
              <div className="space-y-1.5">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Pilih Target Role yang Diatur
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSelectedScheduleRole('DEFAULT')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                      selectedScheduleRole === 'DEFAULT'
                        ? 'bg-teal-700 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    Standar (Default)
                  </button>
                  {CONFIGURABLE_ROLES.map((r) => {
                    const hasCustom = hasCustomRoleAttendanceConfig(attendanceConfig, r.id);
                    const active = selectedScheduleRole === r.id;
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setSelectedScheduleRole(r.id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                          active
                            ? 'bg-teal-700 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <span>{r.label}</span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                            active
                              ? 'bg-white/20 text-white'
                              : hasCustom
                              ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
                              : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {hasCustom ? 'Kustom' : 'Standar'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold mb-1">Jam Masuk</label>
                  <input
                    type="time"
                    value={cfgStart}
                    onChange={(e) => setCfgStart(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1">Jam Pulang</label>
                  <input
                    type="time"
                    value={cfgEnd}
                    onChange={(e) => setCfgEnd(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold mb-1">
                    Toleransi Terlambat (Menit)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={180}
                    value={cfgTolerance}
                    onChange={(e) => setCfgTolerance(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1">
                    Radius Geofence (Meter)
                  </label>
                  <input
                    type="number"
                    min={10}
                    max={10000}
                    value={cfgRadius}
                    onChange={(e) => setCfgRadius(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold">
                    Titik Koordinat Outlet{' '}
                    {selectedScheduleRole !== 'DEFAULT' ? '(Opsional per Role)' : ''}
                  </span>
                  <button
                    type="button"
                    onClick={() => void handleCaptureOutletGps()}
                    disabled={capturingOutletGps}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 text-white text-[11px] font-semibold cursor-pointer disabled:opacity-50"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>
                      {capturingOutletGps
                        ? 'Mengambil GPS...'
                        : 'Ambil Lokasi Outlet Sekarang (GPS)'}
                    </span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                      Latitude
                    </label>
                    <input
                      type="text"
                      value={cfgOutletLat}
                      onChange={(e) => setCfgOutletLat(e.target.value)}
                      placeholder="-6.208763"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                      Longitude
                    </label>
                    <input
                      type="text"
                      value={cfgOutletLng}
                      onChange={(e) => setCfgOutletLng(e.target.value)}
                      placeholder="106.845599"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs font-semibold cursor-pointer">
                <div>
                  <p>Wajibkan GPS Aktif Saat Absen</p>
                  <p className="text-[11px] font-normal text-slate-500">
                    Jika aktif, karyawan tidak dapat check-in/out bila izin lokasi GPS mati.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={cfgRequireGps}
                  onChange={(e) => setCfgRequireGps(e.target.checked)}
                />
              </label>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs sm:text-sm font-bold cursor-pointer"
              >
                {selectedScheduleRole === 'DEFAULT'
                  ? 'Simpan Pengaturan Standar (Default)'
                  : `Simpan Jadwal & Geofence Role ${
                      CONFIGURABLE_ROLES.find((r) => r.id === selectedScheduleRole)?.label ||
                      selectedScheduleRole
                    }`}
              </button>

              {/* RINGKASAN PER ROLE */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Ringkasan Aturan Aktif Per Role
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {CONFIGURABLE_ROLES.map((r) => {
                    const eff = getEffectiveAttendanceConfigForRole(attendanceConfig, r.id);
                    const isCustom = hasCustomRoleAttendanceConfig(attendanceConfig, r.id);
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setSelectedScheduleRole(r.id)}
                        className={`text-left rounded-lg border p-2.5 text-[11px] transition-colors cursor-pointer ${
                          selectedScheduleRole === r.id
                            ? 'border-teal-500 bg-teal-50/70 dark:bg-teal-950/40'
                            : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-bold text-slate-900 dark:text-slate-100">
                            {r.label}
                          </span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                              isCustom
                                ? 'bg-teal-100 text-teal-800 dark:bg-teal-900/70 dark:text-teal-300'
                                : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                            }`}
                          >
                            {isCustom ? 'Khusus Role' : 'Standar'}
                          </span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 mt-1 font-mono">
                          {eff.workStartTime}–{eff.workEndTime} · Tol {eff.lateToleranceMinutes}m ·
                          Radius {eff.geofenceRadiusMeters}m
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LIVE CAMERA MODAL (NO GALLERY UPLOAD) */}
      {cameraModalMode && (
        <AttendanceCameraModal
          title={
            cameraModalMode === 'CLOCK_IN'
              ? 'Foto Selfie Absen Masuk'
              : cameraModalMode === 'CLOCK_OUT'
              ? 'Foto Selfie Absen Pulang'
              : 'Foto Bukti Pengajuan (Kamera HP)'
          }
          subtitle={
            cameraModalMode === 'CLOCK_IN'
              ? 'Ambil foto wajah langsung di area kerja menggunakan kamera perangkat.'
              : cameraModalMode === 'CLOCK_OUT'
              ? 'Ambil foto langsung saat menyelesaikan jam kerja.'
              : 'Foto surat/kondisi wajib diambil langsung menggunakan kamera HP.'
          }
          employeeName={currentUser.fullName}
          locationLabel={
            liveLocation
              ? `${liveLocation.latitude.toFixed(5)}, ${liveLocation.longitude.toFixed(5)}`
              : undefined
          }
          onCaptured={handleCameraCaptured}
          onClose={() => setCameraModalMode(null)}
        />
      )}

      {/* LEAVE REQUEST MODAL */}
      {showLeaveModal && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/70 p-4">
          <form
            onSubmit={handleLeaveSubmit}
            className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Ajukan Izin / Sakit / Cuti
              </h3>
              <button
                type="button"
                onClick={() => setShowLeaveModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Jenis Pengajuan</label>
                <select
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value as 'IZIN' | 'SAKIT' | 'CUTI')}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
                >
                  <option value="IZIN">Izin</option>
                  <option value="SAKIT">Sakit</option>
                  <option value="CUTI">Cuti</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Tanggal</label>
                <input
                  type="date"
                  value={leaveDateKey}
                  onChange={(e) => setLeaveDateKey(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">Keterangan / Alasan</label>
              <textarea
                rows={3}
                required
                value={leaveNotes}
                onChange={(e) => setLeaveNotes(e.target.value)}
                placeholder="Tuliskan alasan izin, sakit, atau cuti..."
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold">
                  Foto Bukti (Opsional, Kamera HP Langsung)
                </span>
                <button
                  type="button"
                  onClick={() => setCameraModalMode('LEAVE_PROOF')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-400 text-xs font-semibold hover:bg-teal-50 dark:hover:bg-teal-950/30 cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{leavePhotoDataUrl ? 'Ambil Ulang Foto' : 'Ambil Foto Kamera'}</span>
                </button>
              </div>
              {leavePhotoDataUrl && (
                <img
                  src={leavePhotoDataUrl}
                  alt="Bukti Pengajuan"
                  className="w-full h-36 object-cover rounded-xl border border-slate-200 dark:border-slate-700"
                />
              )}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowLeaveModal(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 px-4 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs sm:text-sm font-bold cursor-pointer"
              >
                Kirim Pengajuan
              </button>
            </div>
          </form>
        </div>
      )}

      {/* RECORD DETAIL & PHOTO INSPECTION MODAL */}
      {detailRecord && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/75 p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  Detail Absensi · {detailRecord.userName}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {formatReadableDate(detailRecord.dateKey)} · {ROLE_LABELS[detailRecord.userRole]}{' '}
                  · {detailRecord.outletName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDetailRecord(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 space-y-2">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Absen Masuk ({formatClock(detailRecord.clockInAt)})
                </p>
                {detailRecord.clockInPhoto ? (
                  <img
                    src={detailRecord.clockInPhoto}
                    alt={`Foto masuk ${detailRecord.userName}`}
                    className="w-full aspect-[4/3] object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                  />
                ) : (
                  <div className="w-full aspect-[4/3] rounded-lg border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center text-xs text-slate-400">
                    Tidak ada foto masuk
                  </div>
                )}
                <div className="pt-1">
                  {detailRecord.userId === currentUser.id && !permissions.canViewLocation
                    ? detailRecord.clockInLocation
                      ? `${detailRecord.clockInLocation.latitude.toFixed(
                          5
                        )}, ${detailRecord.clockInLocation.longitude.toFixed(5)}`
                      : 'Lokasi tidak tercatat'
                    : renderLocationSummary(detailRecord.clockInLocation)}
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 space-y-2">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Absen Pulang ({formatClock(detailRecord.clockOutAt)})
                </p>
                {detailRecord.clockOutPhoto ? (
                  <img
                    src={detailRecord.clockOutPhoto}
                    alt={`Foto pulang ${detailRecord.userName}`}
                    className="w-full aspect-[4/3] object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                  />
                ) : (
                  <div className="w-full aspect-[4/3] rounded-lg border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center text-xs text-slate-400">
                    Belum absen pulang
                  </div>
                )}
                <div className="pt-1">
                  {detailRecord.clockOutLocation ? (
                    detailRecord.userId === currentUser.id && !permissions.canViewLocation ? (
                      `${detailRecord.clockOutLocation.latitude.toFixed(
                        5
                      )}, ${detailRecord.clockOutLocation.longitude.toFixed(5)}`
                    ) : (
                      renderLocationSummary(detailRecord.clockOutLocation)
                    )
                  ) : (
                    <span className="text-xs text-slate-400">Lokasi pulang belum ada</span>
                  )}
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5 text-xs space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                    STATUS_BADGE_CLASSES[detailRecord.status]
                  }`}
                >
                  {ATTENDANCE_STATUS_LABELS[detailRecord.status]}
                </span>
                {detailRecord.lateMinutes > 0 && (
                  <span className="text-amber-700 dark:text-amber-400 font-semibold">
                    Terlambat {detailRecord.lateMinutes} menit
                  </span>
                )}
                {detailRecord.workDurationMinutes > 0 && (
                  <span className="text-slate-700 dark:text-slate-300 font-semibold">
                    Durasi Kerja {formatDurationMinutes(detailRecord.workDurationMinutes)}
                  </span>
                )}
                {detailRecord.overtimeMinutes > 0 && (
                  <span className="text-teal-700 dark:text-teal-400 font-semibold">
                    Lembur {detailRecord.overtimeMinutes} menit
                  </span>
                )}
              </div>
              {detailRecord.notes && (
                <p className="text-slate-600 dark:text-slate-300">Catatan: {detailRecord.notes}</p>
              )}
              {detailRecord.verifiedBy && (
                <p className="text-emerald-700 dark:text-emerald-400 font-semibold">
                  Diverifikasi oleh {detailRecord.verifiedBy}
                </p>
              )}
            </div>

            {permissions.canManage && (
              <div className="flex items-center justify-end gap-2">
                {!detailRecord.verifiedBy && (
                  <button
                    type="button"
                    onClick={() => {
                      onVerifyRecord(detailRecord.id);
                      setDetailRecord({
                        ...detailRecord,
                        verifiedBy: currentUser.fullName,
                        verifiedAt: Date.now(),
                      });
                    }}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Verifikasi Absensi</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    onDeleteRecord(detailRecord.id);
                    setDetailRecord(null);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Hapus Catatan</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
