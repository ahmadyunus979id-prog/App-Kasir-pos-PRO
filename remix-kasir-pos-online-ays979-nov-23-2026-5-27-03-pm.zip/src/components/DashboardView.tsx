import React, { useMemo, useState } from 'react';
import { AlertTriangle, ReceiptText } from 'lucide-react';
import type {
  Outlet,
  PettyCash,
  Product,
  PurchaseOrder,
  StockMovement,
  Transaction,
} from '../types/pos';
import { formatDateTime, formatNumber, formatRupiah } from '../utils/formatters';

interface DashboardViewProps {
  transactions: Transaction[];
  products: Product[];
  purchaseOrders: PurchaseOrder[];
  stockMovements: StockMovement[];
  pettyCash: PettyCash[];
  outlets: Outlet[];
  onOpenReceipt: (tx: Transaction) => void;
}

type PeriodFilter = 'TODAY' | 'MONTH' | 'ALL';
type DashboardTab = 'OVERVIEW' | 'SALES' | 'STOCK';

export const DashboardView: React.FC<DashboardViewProps> = ({
  transactions,
  products,
  purchaseOrders,
  stockMovements,
  pettyCash,
  outlets,
  onOpenReceipt,
}) => {
  const [tab, setTab] = useState<DashboardTab>('OVERVIEW');
  const [period, setPeriod] = useState<PeriodFilter>('MONTH');
  const [outletFilter, setOutletFilter] = useState<string>('ALL');

  const startOfDay = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }, []);

  const startOfMonth = useMemo(() => {
    const d = new Date();
    d.setDate(1);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }, []);

  const completedAll = useMemo(
    () =>
      transactions.filter(
        (t) =>
          t.status === 'COMPLETED' &&
          (outletFilter === 'ALL' || t.outletId === outletFilter)
      ),
    [transactions, outletFilter]
  );

  const filteredTx = useMemo(
    () =>
      transactions.filter((t) => {
        const outletOk = outletFilter === 'ALL' || t.outletId === outletFilter;
        const timeOk =
          period === 'TODAY'
            ? t.createdAt >= startOfDay
            : period === 'MONTH'
            ? t.createdAt >= startOfMonth
            : true;
        return outletOk && timeOk;
      }),
    [transactions, outletFilter, period, startOfDay, startOfMonth]
  );

  const dailyRevenue = useMemo(
    () => completedAll.filter((t) => t.createdAt >= startOfDay).reduce((a, b) => a + b.totalAmount, 0),
    [completedAll, startOfDay]
  );

  const monthlyRevenue = useMemo(
    () => completedAll.filter((t) => t.createdAt >= startOfMonth).reduce((a, b) => a + b.totalAmount, 0),
    [completedAll, startOfMonth]
  );

  const inventoryValue = useMemo(
    () => products.reduce((acc, p) => acc + Math.round(p.stock * p.costPrice), 0),
    [products]
  );

  const lowStockProducts = useMemo(
    () => products.filter((p) => p.stock <= p.minStock),
    [products]
  );

  const topProducts = useMemo(() => {
    const map = new Map<string, { name: string; qty: number; revenue: number }>();
    filteredTx
      .filter((t) => t.status === 'COMPLETED')
      .forEach((t) => {
        t.items.forEach((it) => {
          const cur = map.get(it.productName) || { name: it.productName, qty: 0, revenue: 0 };
          cur.qty += it.quantity;
          cur.revenue += it.subtotal;
          map.set(it.productName, cur);
        });
      });
    return Array.from(map.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [filteredTx]);

  const maxTopRevenue = Math.max(1, ...topProducts.map((t) => t.revenue));

  const salesMetrics = useMemo(() => {
    const done = filteredTx.filter((t) => t.status === 'COMPLETED');
    const gross = done.reduce((a, b) => a + b.subtotal, 0);
    const discount = done.reduce((a, b) => a + b.discountAmount, 0);
    const tax = done.reduce((a, b) => a + b.taxAmount, 0);
    const net = done.reduce((a, b) => a + b.totalAmount, 0);
    const cogs = done.reduce((a, b) => a + b.totalCost, 0);
    const pettyOut = pettyCash.reduce((a, b) => a + b.amount, 0);
    const profit = net - tax - cogs - pettyOut;

    const byCashier = new Map<string, { count: number; total: number }>();
    const byOutlet = new Map<string, { count: number; total: number }>();
    done.forEach((t) => {
      const c = byCashier.get(t.cashierName) || { count: 0, total: 0 };
      c.count += 1;
      c.total += t.totalAmount;
      byCashier.set(t.cashierName, c);

      const o = byOutlet.get(t.outletName) || { count: 0, total: 0 };
      o.count += 1;
      o.total += t.totalAmount;
      byOutlet.set(t.outletName, o);
    });

    return {
      gross,
      discount,
      tax,
      net,
      cogs,
      pettyOut,
      profit,
      byCashier: Array.from(byCashier.entries()),
      byOutlet: Array.from(byOutlet.entries()),
    };
  }, [filteredTx, pettyCash]);

  const categoryValuation = useMemo(() => {
    const map = new Map<string, { units: number; value: number }>();
    products.forEach((p) => {
      const cur = map.get(p.category) || { units: 0, value: 0 };
      cur.units += p.stock;
      cur.value += Math.round(p.stock * p.costPrice);
      map.set(p.category, cur);
    });
    return Array.from(map.entries());
  }, [products]);

  return (
    <div className="space-y-5">
      {/* Sub-navigation & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800">
          {[
            { id: 'OVERVIEW', label: 'Ringkasan' },
            { id: 'SALES', label: 'Laporan Penjualan' },
            { id: 'STOCK', label: 'Pembelian & Stok' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as DashboardTab)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                tab === item.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {([
            { id: 'TODAY', label: 'Hari Ini' },
            { id: 'MONTH', label: 'Bulan Ini' },
            { id: 'ALL', label: 'Semua' },
          ] as const).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer whitespace-nowrap ${
                period === p.id
                  ? 'bg-teal-700 border-teal-700 text-white'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {p.label}
            </button>
          ))}
          <select
            value={outletFilter}
            onChange={(e) => setOutletFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
          >
            <option value="ALL">Semua Outlet</option>
            {outlets.map((o) => (
              <option key={o.id} value={o.id}>
                {o.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {tab === 'OVERVIEW' && (
        <div className="space-y-5">
          {/* KPI Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                label: 'Omzet Hari Ini',
                val: formatRupiah(dailyRevenue),
                sub: 'Transaksi selesai hari ini',
                accent: 'text-teal-700 dark:text-teal-400',
              },
              {
                label: 'Omzet Bulan Ini',
                val: formatRupiah(monthlyRevenue),
                sub: 'Akumulasi bulan berjalan',
                accent: 'text-slate-900 dark:text-slate-100',
              },
              {
                label: 'Jumlah Transaksi',
                val: `${filteredTx.filter((t) => t.status === 'COMPLETED').length} Nota`,
                sub: 'Sesuai filter periode',
                accent: 'text-slate-900 dark:text-slate-100',
              },
              {
                label: 'Nilai Persediaan',
                val: formatRupiah(inventoryValue),
                sub: `${products.length} SKU aktif`,
                accent: 'text-slate-900 dark:text-slate-100',
              },
            ].map((kpi) => (
              <div
                key={kpi.label}
                className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-1"
              >
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{kpi.label}</p>
                <p className={`text-xl font-bold tabular-nums ${kpi.accent}`}>{kpi.val}</p>
                <p className="text-xs text-slate-400 dark:text-slate-500">{kpi.sub}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Top Selling Products */}
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Produk Terlaris
              </h3>
              {topProducts.length === 0 ? (
                <p className="text-sm text-slate-500">Belum ada penjualan pada periode ini.</p>
              ) : (
                <div className="space-y-3">
                  {topProducts.map((tp) => (
                    <div key={tp.name} className="space-y-1.5">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium text-slate-800 dark:text-slate-200 truncate pr-2">
                          {tp.name}
                        </span>
                        <span className="font-mono text-xs text-teal-700 dark:text-teal-400 shrink-0">
                          {tp.qty} terjual · {formatRupiah(tp.revenue)}
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-teal-600 rounded-full"
                          style={{ width: `${Math.max(8, (tp.revenue / maxTopRevenue) * 100)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Low Stock Alerts */}
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  Peringatan Stok Menipis ({lowStockProducts.length})
                </h3>
              </div>
              {lowStockProducts.length === 0 ? (
                <p className="text-sm text-slate-500">Semua stok produk aman di atas batas minimum.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {lowStockProducts.map((p) => (
                    <div key={p.id} className="py-2.5 flex items-center justify-between text-sm">
                      <div>
                        <p className="font-medium text-slate-800 dark:text-slate-200">{p.name}</p>
                        <p className="text-xs text-slate-500">
                          {p.sku} · Minimum {formatNumber(p.minStock)} {p.baseUnit}
                        </p>
                      </div>
                      <span className="font-mono text-xs font-semibold text-red-600 dark:text-red-400">
                        Sisa {formatNumber(p.stock)} {p.baseUnit}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Transaksi Terbaru
            </h3>
            {filteredTx.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Belum ada transaksi penjualan pada periode ini.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredTx.slice(0, 6).map((tx) => (
                  <button
                    key={tx.id}
                    type="button"
                    onClick={() => onOpenReceipt(tx)}
                    className="w-full py-3 flex items-center justify-between gap-4 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 px-2 rounded-lg transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <ReceiptText className="w-4 h-4 text-teal-700 dark:text-teal-400 shrink-0" />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 font-mono">
                          {tx.invoiceNumber}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {tx.customerName} · {tx.paymentMethod} · Kasir: {tx.cashierName} · {formatDateTime(tx.createdAt)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100">
                        {formatRupiah(tx.totalAmount)}
                      </p>
                      <p
                        className={`text-xs font-medium ${
                          tx.status === 'COMPLETED'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {tx.status === 'COMPLETED' ? 'Selesai' : tx.status}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'SALES' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Laporan Laba Rugi
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Penjualan Kotor (Subtotal)</span>
                  <span className="font-mono">{formatRupiah(salesMetrics.gross)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Total Diskon</span>
                  <span className="font-mono text-amber-600">-{formatRupiah(salesMetrics.discount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">PPN Terkumpul</span>
                  <span className="font-mono">{formatRupiah(salesMetrics.tax)}</span>
                </div>
                <div className="flex justify-between font-semibold pt-2 border-t border-slate-200 dark:border-slate-800">
                  <span>Total Omzet Penjualan</span>
                  <span className="font-mono">{formatRupiah(salesMetrics.net)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Harga Pokok Penjualan (HPP)</span>
                  <span className="font-mono text-red-600">-{formatRupiah(salesMetrics.cogs)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Pengeluaran Kas Kecil</span>
                  <span className="font-mono text-red-600">-{formatRupiah(salesMetrics.pettyOut)}</span>
                </div>
                <div className="flex justify-between text-base font-bold pt-2 border-t border-slate-200 dark:border-slate-800">
                  <span>Estimasi Laba Bersih</span>
                  <span
                    className={`font-mono ${
                      salesMetrics.profit >= 0
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-red-600 dark:text-red-400'
                    }`}
                  >
                    {formatRupiah(salesMetrics.profit)}
                  </span>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 mb-2">
                  Performa per Kasir
                </h3>
                <div className="space-y-1.5 text-sm">
                  {salesMetrics.byCashier.map(([name, d]) => (
                    <div key={name} className="flex justify-between">
                      <span className="text-slate-700 dark:text-slate-300">
                        {name} ({d.count} nota)
                      </span>
                      <span className="font-mono font-semibold">{formatRupiah(d.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 mb-2">
                  Performa per Outlet
                </h3>
                <div className="space-y-1.5 text-sm">
                  {salesMetrics.byOutlet.map(([name, d]) => (
                    <div key={name} className="flex justify-between">
                      <span className="text-slate-700 dark:text-slate-300">
                        {name} ({d.count} nota)
                      </span>
                      <span className="font-mono font-semibold">{formatRupiah(d.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Rekap Nota / Transaksi ({filteredTx.length})
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 dark:text-slate-400">
                  <tr>
                    <th className="text-left px-4 py-2.5 font-semibold">No. Nota</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Waktu</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Pelanggan</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Kasir</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Metode</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Status</th>
                    <th className="text-right px-4 py-2.5 font-semibold">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredTx.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                        Belum ada transaksi pada periode ini.
                      </td>
                    </tr>
                  ) : (
                    filteredTx.map((tx) => (
                      <tr
                        key={tx.id}
                        onClick={() => onOpenReceipt(tx)}
                        className="hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                      >
                        <td className="px-4 py-2.5 font-mono font-medium text-teal-700 dark:text-teal-400">
                          {tx.invoiceNumber}
                        </td>
                        <td className="px-4 py-2.5 text-slate-500">{formatDateTime(tx.createdAt)}</td>
                        <td className="px-4 py-2.5">{tx.customerName}</td>
                        <td className="px-4 py-2.5">{tx.cashierName}</td>
                        <td className="px-4 py-2.5">{tx.paymentMethod}</td>
                        <td className="px-4 py-2.5">
                          <span
                            className={
                              tx.status === 'COMPLETED'
                                ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                                : 'text-red-600 dark:text-red-400 font-medium'
                            }
                          >
                            {tx.status === 'COMPLETED' ? 'Selesai' : tx.status}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono font-semibold">
                          {formatRupiah(tx.totalAmount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'STOCK' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Valuasi Inventaris per Kategori
              </h3>
              {categoryValuation.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">Belum ada produk terdaftar.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                  {categoryValuation.map(([cat, info]) => (
                    <div key={cat} className="py-2 flex justify-between">
                      <span>
                        {cat} ({formatNumber(info.units)} unit)
                      </span>
                      <span className="font-mono font-semibold">{formatRupiah(info.value)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Riwayat Belanja ke Supplier ({purchaseOrders.length})
              </h3>
              {purchaseOrders.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">Belum ada riwayat Purchase Order.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                  {purchaseOrders.map((po) => (
                    <div key={po.id} className="py-2.5 flex justify-between gap-4">
                      <div>
                        <p className="font-semibold font-mono">{po.poNumber}</p>
                        <p className="text-xs text-slate-500">
                          {po.supplierName} · {po.outletName} · {formatDateTime(po.createdAt)}
                        </p>
                      </div>
                      <span className="font-mono font-semibold text-teal-700 dark:text-teal-400">
                        {formatRupiah(po.totalAmount)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Kartu Stok (Masuk / Keluar)
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 dark:text-slate-400">
                  <tr>
                    <th className="text-left px-4 py-2.5 font-semibold">Waktu</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Produk</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Jenis</th>
                    <th className="text-left px-4 py-2.5 font-semibold">Referensi</th>
                    <th className="text-right px-4 py-2.5 font-semibold">Perubahan</th>
                    <th className="text-right px-4 py-2.5 font-semibold">Saldo Akhir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {stockMovements.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-4 py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                        Belum ada pergerakan stok tercatat.
                      </td>
                    </tr>
                  ) : (
                    stockMovements.slice(0, 40).map((m) => (
                      <tr key={m.id}>
                        <td className="px-4 py-2.5 text-slate-500">{formatDateTime(m.createdAt)}</td>
                        <td className="px-4 py-2.5 font-medium">{m.productName}</td>
                        <td className="px-4 py-2.5 text-xs">{m.type}</td>
                        <td className="px-4 py-2.5 font-mono text-xs">{m.referenceId}</td>
                        <td
                          className={`px-4 py-2.5 text-right font-mono font-semibold ${
                            m.quantityDelta >= 0
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-red-600 dark:text-red-400'
                          }`}
                        >
                          {m.quantityDelta >= 0 ? '+' : ''}
                          {formatNumber(m.quantityDelta)}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono">{formatNumber(m.balanceAfter)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
