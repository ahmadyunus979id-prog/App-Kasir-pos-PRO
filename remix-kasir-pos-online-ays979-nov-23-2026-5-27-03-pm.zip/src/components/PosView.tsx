import React, { useMemo, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  Clock,
  Coffee,
  FileDown,
  History,
  Lock,
  MessageCircle,
  Minus,
  Package,
  Plus,
  Printer,
  QrCode,
  Receipt,
  ScanBarcode,
  Search,
  ShoppingBag,
  ShoppingCart,
  Trash2,
  Wallet,
  X,
} from 'lucide-react';
import { CameraScannerModal } from './CameraScannerModal';
import type {
  CartItem,
  Customer,
  LoyaltyReward,
  PaymentMethod,
  PettyCash,
  Product,
  ProductUnitOption,
  Shift,
  StoreSettings,
  Transaction,
  User,
} from '../types/pos';
import { formatDateTime, formatNumber, formatRupiah } from '../utils/formatters';
import {
  downloadPdfInvoice,
  getTransactionDebtInfo,
  PAYMENT_LABELS,
  publishOnlineReceipt,
  shareReceiptWhatsApp,
} from '../utils/receiptExport';

interface PosViewProps {
  currentUser: User;
  products: Product[];
  customers: Customer[];
  loyaltyRewards: LoyaltyReward[];
  transactions: Transaction[];
  openShift: Shift | null;
  pettyCash: PettyCash[];
  settings: StoreSettings;
  cart: CartItem[];
  selectedCustomer: Customer | null;
  selectedReward: LoyaltyReward | null;
  orderDiscount: number;
  applyTax: boolean;
  onAddProduct: (product: Product, unit?: ProductUnitOption) => void;
  onScanBarcode: (code: string) => boolean;
  onUpdateQty: (productId: string, unitName: string, qty: number) => void;
  onUpdateItemDiscount: (productId: string, unitName: string, disc: number) => void;
  onChangeItemUnit: (productId: string, oldUnit: string, nextUnit: ProductUnitOption) => void;
  onClearCart: () => void;
  onSelectCustomer: (id: string | null) => void;
  onSelectReward: (id: string | null) => void;
  onSetOrderDiscount: (amount: number) => void;
  onSetApplyTax: (enabled: boolean) => void;
  onOpenShift: (openingCash: number) => void;
  onAddPettyCash: (desc: string, amount: number) => void;
  onCloseShift: (actualCash: number) => Shift | null;
  onCheckout: (method: PaymentMethod, paidAmount: number) => { ok: boolean; tx?: Transaction; error?: string };
  onOpenReceipt: (tx: Transaction) => void;
  onAuthorizeVoidOrReturn: (
    tx: Transaction,
    isFullVoid: boolean,
    reason: string,
    adminPassword: string
  ) => { ok: boolean; message: string };
  onPayDebt: (
    txId: string,
    amount: number,
    method: 'TUNAI' | 'QRIS' | 'TRANSFER',
    note?: string
  ) => { ok: boolean; tx?: Transaction; message: string };
  onNotify: (msg: string) => void;
}

export const PosView: React.FC<PosViewProps> = ({
  currentUser,
  products,
  customers,
  loyaltyRewards,
  transactions,
  openShift,
  pettyCash,
  settings,
  cart,
  selectedCustomer,
  selectedReward,
  orderDiscount,
  applyTax,
  onAddProduct,
  onScanBarcode,
  onUpdateQty,
  onUpdateItemDiscount,
  onChangeItemUnit,
  onClearCart,
  onSelectCustomer,
  onSelectReward,
  onSetOrderDiscount,
  onSetApplyTax,
  onOpenShift,
  onAddPettyCash,
  onCloseShift,
  onCheckout,
  onOpenReceipt,
  onAuthorizeVoidOrReturn,
  onPayDebt,
  onNotify,
}) => {
  const [posMenuTab, setPosMenuTab] = useState<'CASHIER' | 'DEBTS'>('CASHIER');
  const [debtFilterTab, setDebtFilterTab] = useState<'UNPAID' | 'PAID'>('UNPAID');
  const [debtSearch, setDebtSearch] = useState('');
  const [debtPayTarget, setDebtPayTarget] = useState<Transaction | null>(null);
  const [debtPayAmount, setDebtPayAmount] = useState('');
  const [debtPayMethod, setDebtPayMethod] = useState<'TUNAI' | 'QRIS' | 'TRANSFER'>('TUNAI');
  const [debtPayNote, setDebtPayNote] = useState('');
  const [debtPayErr, setDebtPayErr] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('Semua');
  const [unitPickerProduct, setUnitPickerProduct] = useState<Product | null>(null);
  const [showScannerModal, setShowScannerModal] = useState(false);
  const [showCameraScanner, setShowCameraScanner] = useState(false);
  const [scannerCode, setScannerCode] = useState('');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showShiftModal, setShowShiftModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [closedShiftRecap, setClosedShiftRecap] = useState<Shift | null>(null);

  // Checkout Modal State
  const [payMethod, setPayMethod] = useState<PaymentMethod>('TUNAI');
  const [paidInput, setPaidInput] = useState('');
  const [checkoutErr, setCheckoutErr] = useState<string | null>(null);

  // Shift Modal State
  const [openingCashInput, setOpeningCashInput] = useState('500000');
  const [actualCashInput, setActualCashInput] = useState('');
  const [pettyDesc, setPettyDesc] = useState('');
  const [pettyAmount, setPettyAmount] = useState('');

  // Void / Retur State
  const [voidTarget, setVoidTarget] = useState<Transaction | null>(null);
  const [isFullVoid, setIsFullVoid] = useState(true);
  const [voidReason, setVoidReason] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [voidMsg, setVoidMsg] = useState<string | null>(null);

  const debtTransactions = useMemo(
    () =>
      transactions
        .filter((tx) => tx.paymentMethod === 'PIUTANG' && tx.status === 'COMPLETED')
        .map((tx) => ({ tx, debtInfo: getTransactionDebtInfo(tx) })),
    [transactions]
  );

  const unpaidDebts = useMemo(
    () => debtTransactions.filter((d) => !d.debtInfo.isSettled),
    [debtTransactions]
  );

  const paidDebts = useMemo(
    () =>
      debtTransactions
        .filter((d) => d.debtInfo.isSettled)
        .sort((a, b) => (b.debtInfo.paidAt ?? b.tx.createdAt) - (a.debtInfo.paidAt ?? a.tx.createdAt)),
    [debtTransactions]
  );

  const totalUnpaidAmount = useMemo(
    () => unpaidDebts.reduce((acc, d) => acc + d.debtInfo.remaining, 0),
    [unpaidDebts]
  );

  const totalPaidAmount = useMemo(
    () => paidDebts.reduce((acc, d) => acc + d.debtInfo.total, 0),
    [paidDebts]
  );

  const visibleDebts = useMemo(() => {
    const base = debtFilterTab === 'UNPAID' ? unpaidDebts : paidDebts;
    const q = debtSearch.trim().toLowerCase();
    if (!q) return base;
    return base.filter(
      ({ tx }) =>
        tx.customerName.toLowerCase().includes(q) ||
        tx.invoiceNumber.toLowerCase().includes(q) ||
        tx.customerWhatsapp.toLowerCase().includes(q)
    );
  }, [debtFilterTab, unpaidDebts, paidDebts, debtSearch]);

  const openDebtPaymentModal = (tx: Transaction) => {
    const info = getTransactionDebtInfo(tx);
    setDebtPayTarget(tx);
    setDebtPayAmount(String(info.remaining));
    setDebtPayMethod('TUNAI');
    setDebtPayNote('');
    setDebtPayErr(null);
  };

  const categories = useMemo(
    () => ['Semua', ...Array.from(new Set(products.map((p) => p.category))).sort()],
    [products]
  );

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      const catOk = category === 'Semua' || p.category === category;
      const qOk =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.toLowerCase().includes(q);
      return catOk && qOk;
    });
  }, [products, category, search]);

  const subtotal = useMemo(
    () => cart.reduce((acc, c) => acc + Math.max(0, c.unitPrice * c.quantity - c.itemDiscount), 0),
    [cart]
  );
  const rewardDiscount = selectedReward?.discountAmount ?? 0;
  const discountCapped = Math.min(subtotal, Math.max(0, orderDiscount + rewardDiscount));
  const afterDiscount = subtotal - discountCapped;
  const taxAmount =
    !applyTax || settings.taxPercent <= 0
      ? 0
      : settings.taxInclusive
      ? Math.round(afterDiscount - afterDiscount / (1 + settings.taxPercent / 100))
      : Math.round(afterDiscount * (settings.taxPercent / 100));
  const grandTotal = settings.taxInclusive ? afterDiscount : afterDiscount + taxAmount;

  const eligibleRewards = useMemo(() => {
    if (!selectedCustomer) return [];
    return loyaltyRewards.filter((r) => r.isActive && r.pointsCost <= selectedCustomer.points);
  }, [loyaltyRewards, selectedCustomer]);

  const openCheckout = () => {
    setPayMethod('TUNAI');
    setPaidInput(String(grandTotal));
    setCheckoutErr(null);
    setShowCheckoutModal(true);
  };

  return (
    <div className="space-y-4">
      {/* Shift, Menu Hutang & Nota Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setPosMenuTab('CASHIER')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                posMenuTab === 'CASHIER'
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>Kasir Transaksi</span>
            </button>
            <button
              type="button"
              onClick={() => setPosMenuTab('DEBTS')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                posMenuTab === 'DEBTS'
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>Daftar Hutang Pelanggan</span>
              {unpaidDebts.length > 0 && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold font-mono leading-none ${
                    posMenuTab === 'DEBTS'
                      ? 'bg-white text-teal-800'
                      : 'bg-amber-500 text-white'
                  }`}
                >
                  {unpaidDebts.length}
                </span>
              )}
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              setActualCashInput(String(openShift?.expectedCash ?? 0));
              setShowShiftModal(true);
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400" />
            <span>
              {openShift
                ? `Shift Aktif · Kas Laci: ${formatRupiah(openShift.expectedCash)}`
                : 'Buka Shift Kasir'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => {
              setVoidTarget(null);
              setVoidMsg(null);
              setShowHistoryModal(true);
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <History className="w-3.5 h-3.5" />
            <span>Riwayat Nota · Void &amp; Retur</span>
          </button>
        </div>
        <span className="text-xs text-slate-500 dark:text-slate-400">
          PPN Default: {formatNumber(settings.taxPercent)}% · {settings.paperWidth === 'MM_58' ? 'Thermal 58mm' : 'Thermal 80mm'}
        </span>
      </div>

      {posMenuTab === 'DEBTS' ? (
        <div className="space-y-4">
          {/* Summary KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Hutang Belum Terbayar ({unpaidDebts.length} nota)
                </p>
                <p className="text-2xl font-extrabold font-mono text-rose-600 dark:text-rose-400 mt-1">
                  {formatRupiah(totalUnpaidAmount)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
            </div>

            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Hutang Sudah Terbayar / Lunas ({paidDebts.length} nota)
                </p>
                <p className="text-2xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                  {formatRupiah(totalPaidAmount)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Sub-tabs & Search */}
          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setDebtFilterTab('UNPAID')}
                  className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    debtFilterTab === 'UNPAID'
                      ? 'bg-white dark:bg-slate-900 text-rose-700 dark:text-rose-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Belum Terbayar ({unpaidDebts.length})
                </button>
                <button
                  type="button"
                  onClick={() => setDebtFilterTab('PAID')}
                  className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    debtFilterTab === 'PAID'
                      ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Sudah Terbayar ({paidDebts.length})
                </button>
              </div>

              <div className="relative flex-1 sm:max-w-xs">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={debtSearch}
                  onChange={(e) => setDebtSearch(e.target.value)}
                  placeholder="Cari nama pelanggan, no. nota, WA..."
                  className="w-full pl-9 pr-8 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
                {debtSearch && (
                  <button
                    type="button"
                    onClick={() => setDebtSearch('')}
                    aria-label="Hapus pencarian hutang"
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {visibleDebts.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-800 py-10 px-4 text-center space-y-1.5">
                <Receipt className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {debtFilterTab === 'UNPAID'
                    ? 'Tidak ada hutang pelanggan yang belum terbayar'
                    : 'Belum ada riwayat hutang yang sudah terbayar'}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {debtFilterTab === 'UNPAID'
                    ? 'Transaksi dengan metode Piutang / Tempo akan otomatis muncul di daftar ini.'
                    : 'Nota hutang yang sudah dilunasi akan tersimpan di tab ini.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {visibleDebts.map(({ tx, debtInfo }) => {
                  const itemSummary = tx.items
                    .slice(0, 3)
                    .map((it) => `${it.productName} (${it.quantity} ${it.unitName})`)
                    .join(', ');
                  const extraItemsCount = Math.max(0, tx.items.length - 3);
                  return (
                    <div
                      key={tx.id}
                      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-4 space-y-3"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100">
                              {tx.invoiceNumber}
                            </span>
                            {debtInfo.isSettled ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Sudah Terbayar · Lunas</span>
                              </span>
                            ) : debtInfo.paid > 0 ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-900">
                                <Clock className="w-3 h-3" />
                                <span>Cicilan · Belum Lunas</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900">
                                <Clock className="w-3 h-3" />
                                <span>Belum Terbayar</span>
                              </span>
                            )}
                          </div>
                          <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                            {tx.customerName}
                            {tx.customerWhatsapp && (
                              <span className="ml-2 text-xs font-mono font-normal text-slate-500 dark:text-slate-400">
                                · WA: {tx.customerWhatsapp}
                              </span>
                            )}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            Nota: {formatDateTime(tx.createdAt)} · Outlet: {tx.outletName} · Kasir: {tx.cashierName}
                          </p>
                          {debtInfo.paidAt && (
                            <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                              Lunas pada: {formatDateTime(debtInfo.paidAt)}
                            </p>
                          )}
                        </div>

                        <div className="text-left sm:text-right space-y-0.5 shrink-0">
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            Total Tagihan: <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">{formatRupiah(debtInfo.total)}</span>
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            Sudah Dibayar: <span className="font-mono font-semibold text-teal-700 dark:text-teal-400">{formatRupiah(debtInfo.paid)}</span>
                          </p>
                          <p className="text-sm font-extrabold font-mono">
                            Sisa Hutang:{' '}
                            <span
                              className={
                                debtInfo.isSettled
                                  ? 'text-emerald-600 dark:text-emerald-400'
                                  : 'text-rose-600 dark:text-rose-400'
                              }
                            >
                              {formatRupiah(debtInfo.remaining)}
                            </span>
                          </p>
                        </div>
                      </div>

                      <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs text-slate-600 dark:text-slate-300 space-y-1">
                        <p>
                          <span className="font-semibold text-slate-700 dark:text-slate-200">
                            Rincian ({tx.items.length} item):
                          </span>{' '}
                          {itemSummary}
                          {extraItemsCount > 0 ? ` (+${extraItemsCount} item lainnya)` : ''}
                        </p>
                        {tx.debtPayments && tx.debtPayments.length > 0 && (
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            <span className="font-semibold">Riwayat Bayar:</span>{' '}
                            {tx.debtPayments
                              .map(
                                (p) =>
                                  `${PAYMENT_LABELS[p.method] || p.method} ${formatRupiah(p.amount)} (${formatDateTime(p.paidAt)})`
                              )
                              .join(' · ')}
                          </p>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                        {!debtInfo.isSettled && (
                          <button
                            type="button"
                            onClick={() => openDebtPaymentModal(tx)}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
                          >
                            <Wallet className="w-3.5 h-3.5 shrink-0" />
                            <span>Bayar / Lunasi</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onOpenReceipt(tx)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs font-semibold cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400 shrink-0" />
                          <span>Cetak Nota</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            void publishOnlineReceipt(tx, settings);
                            shareReceiptWhatsApp(tx, settings, tx.customerWhatsapp);
                            onNotify('Nota hutang & link online dibagikan ke WhatsApp');
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>Share WhatsApp</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            downloadPdfInvoice(tx, settings);
                            onNotify(`Invoice PDF ${tx.invoiceNumber}.pdf diunduh`);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs font-semibold cursor-pointer"
                        >
                          <FileDown className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400 shrink-0" />
                          <span>Cetak PDF</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : (
      /* Main Split POS Layout */
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Catalog Pane */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && search.trim()) {
                    if (onScanBarcode(search)) {
                      setSearch('');
                    }
                  }
                }}
                placeholder="Cari nama produk, SKU, atau tekan Enter setelah scan barcode..."
                className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
              {search && (
                <button
                  type="button"
                  onClick={() => setSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowCameraScanner(true)}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold cursor-pointer whitespace-nowrap"
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">Scan Kamera</span>
            </button>
            <button
              type="button"
              onClick={() => setShowScannerModal(true)}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <ScanBarcode className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span className="hidden md:inline">Input Kode</span>
            </button>
          </div>

          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  category === cat
                    ? 'bg-teal-700 text-white'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Product Grid */}
          {filteredProducts.length === 0 ? (
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {products.length === 0
                ? 'Belum ada produk di katalog. Tambahkan produk pertama di menu Master Data.'
                : 'Tidak ada produk yang cocok dengan pencarian atau kategori.'}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
              {filteredProducts.map((prod) => (
                <button
                  key={prod.id}
                  type="button"
                  onClick={() => {
                    if (prod.units.length > 1) {
                      setUnitPickerProduct(prod);
                    } else {
                      onAddProduct(prod, prod.units[0]);
                    }
                  }}
                  className="text-left rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-600 dark:hover:border-teal-500 p-3 flex flex-col gap-2.5 transition-colors cursor-pointer"
                >
                  <div className="aspect-square w-full rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                    {prod.photoUrl ? (
                      <img
                        src={prod.photoUrl}
                        alt={prod.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : prod.category === 'Minuman' ? (
                      <Coffee className="w-9 h-9 text-teal-700/60 dark:text-teal-400/60" />
                    ) : prod.category === 'Bahan Baku' ? (
                      <Package className="w-9 h-9 text-slate-500/70" />
                    ) : (
                      <ShoppingBag className="w-9 h-9 text-amber-600/60" />
                    )}
                  </div>
                  <div className="space-y-1 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-[11px] font-mono text-slate-400 dark:text-slate-500">
                        {prod.sku} · {prod.category}
                      </p>
                      <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug">
                        {prod.name}
                      </h4>
                    </div>
                    <div className="pt-1 flex items-baseline justify-between gap-1">
                      <span className="text-sm font-bold font-mono text-teal-700 dark:text-teal-400">
                        {formatRupiah(prod.sellPrice)}
                      </span>
                      <span
                        className={`text-[11px] font-mono ${
                          prod.stock <= prod.minStock
                            ? 'text-red-600 dark:text-red-400 font-semibold'
                            : 'text-slate-500'
                        }`}
                      >
                        {formatNumber(prod.stock)} {prod.baseUnit}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Cart Pane */}
        <div className="lg:col-span-5 xl:col-span-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3.5 lg:sticky lg:top-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Keranjang ({cart.reduce((a, b) => a + b.quantity, 0)} item)
            </h3>
            {cart.length > 0 && (
              <button
                type="button"
                onClick={onClearCart}
                className="text-xs font-semibold text-red-600 hover:underline cursor-pointer"
              >
                Kosongkan
              </button>
            )}
          </div>

          {/* Customer Selector & Loyalty Redemption */}
          <div className="space-y-2">
            <select
              value={selectedCustomer?.id || ''}
              onChange={(e) => onSelectCustomer(e.target.value || null)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-800 dark:text-slate-100"
            >
              <option value="">Pelanggan Umum</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.points} poin)
                </option>
              ))}
            </select>

            {selectedCustomer && (
              <div className="space-y-1.5">
                <select
                  value={selectedReward?.id || ''}
                  onChange={(e) => onSelectReward(e.target.value || null)}
                  className="w-full px-3 py-2 rounded-lg border border-teal-300 dark:border-teal-800 bg-teal-50/50 dark:bg-teal-950/30 text-xs font-medium text-teal-900 dark:text-teal-200"
                >
                  <option value="">
                    {eligibleRewards.length > 0
                      ? `Tukar Poin (${selectedCustomer.points} poin tersedia)`
                      : `Saldo Poin: ${selectedCustomer.points} (belum cukup reward)`}
                  </option>
                  {eligibleRewards.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.title} (-{r.pointsCost} poin)
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 px-0.5">
                  {settings.pointsEnabled !== false
                    ? `Estimasi poin transaksi ini: +${formatNumber(
                        Math.floor(grandTotal / Math.max(1000, settings.pointsPerAmount))
                      )} poin`
                    : 'Perolehan poin belanja otomatis sedang dinonaktifkan'}
                </p>
              </div>
            )}
          </div>

          {/* Cart Items */}
          <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {cart.length === 0 ? (
              <p className="py-10 text-center text-sm text-slate-400">
                Pilih produk di sebelah kiri untuk memulai transaksi.
              </p>
            ) : (
              cart.map((item) => {
                const prod = products.find((p) => p.id === item.productId);
                const lineNet = Math.max(0, item.unitPrice * item.quantity - item.itemDiscount);
                return (
                  <div key={`${item.productId}-${item.selectedUnit}`} className="py-2.5 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {item.name}
                        </p>
                        <div className="flex items-center gap-2 mt-0.5">
                          {prod && prod.units.length > 1 ? (
                            <select
                              value={item.selectedUnit}
                              onChange={(e) => {
                                const u = prod.units.find((x) => x.unitName === e.target.value);
                                if (u) onChangeItemUnit(item.productId, item.selectedUnit, u);
                              }}
                              className="text-xs rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-1.5 py-0.5"
                            >
                              {prod.units.map((u) => (
                                <option key={u.unitName} value={u.unitName}>
                                  {u.unitName} ({formatRupiah(u.sellPrice)})
                                </option>
                              ))}
                            </select>
                          ) : (
                            <span className="text-xs text-slate-500 font-mono">
                              {formatRupiah(item.unitPrice)} / {item.selectedUnit}
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.productId, item.selectedUnit, 0)}
                        className="text-slate-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(item.productId, item.selectedUnit, item.quantity - 1)}
                          className="w-7 h-7 rounded-md border border-slate-300 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-7 text-center text-sm font-mono font-semibold">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQty(item.productId, item.selectedUnit, item.quantity + 1)}
                          className="w-7 h-7 rounded-md border border-slate-300 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min={0}
                          value={item.itemDiscount || ''}
                          onChange={(e) =>
                            onUpdateItemDiscount(
                              item.productId,
                              item.selectedUnit,
                              Number(e.target.value) || 0
                            )
                          }
                          placeholder="Diskon Rp"
                          className="w-20 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono text-right"
                        />
                        <span className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100">
                          {formatRupiah(lineNet)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Totals */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2 text-sm">
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-600 dark:text-slate-400">Diskon Nota (Rp)</span>
              <input
                type="number"
                min={0}
                value={orderDiscount || ''}
                onChange={(e) => onSetOrderDiscount(Number(e.target.value) || 0)}
                placeholder="0"
                className="w-28 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-right font-mono text-sm"
              />
            </div>

            {selectedReward && selectedReward.discountAmount > 0 && (
              <div className="flex justify-between text-xs text-teal-700 dark:text-teal-400 font-medium">
                <span>Diskon Poin ({selectedReward.title})</span>
                <span className="font-mono">-{formatRupiah(selectedReward.discountAmount)}</span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer text-slate-600 dark:text-slate-400">
                <input
                  type="checkbox"
                  checked={applyTax}
                  onChange={(e) => onSetApplyTax(e.target.checked)}
                  className="rounded border-slate-300 text-teal-700"
                />
                <span>PPN ({formatNumber(settings.taxPercent)}%)</span>
              </label>
              <span className="font-mono">{formatRupiah(taxAmount)}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-600 dark:text-slate-400">Subtotal</span>
              <span className="font-mono">{formatRupiah(subtotal)}</span>
            </div>

            <div className="flex justify-between items-baseline pt-2 border-t border-slate-200 dark:border-slate-800">
              <span className="font-bold text-slate-900 dark:text-slate-100">Total Tagihan</span>
              <span className="text-xl font-extrabold font-mono text-teal-700 dark:text-teal-400">
                {formatRupiah(grandTotal)}
              </span>
            </div>
          </div>

          <button
            type="button"
            disabled={cart.length === 0}
            onClick={openCheckout}
            className="w-full py-3 px-4 rounded-xl bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            Bayar Sekarang
          </button>
        </div>
      </div>
      )}

      {/* Unit Picker Modal */}
      {unitPickerProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
            <h3 className="text-base font-bold">Pilih Satuan · {unitPickerProduct.name}</h3>
            <div className="space-y-2">
              {unitPickerProduct.units.map((u) => (
                <button
                  key={u.unitName}
                  type="button"
                  onClick={() => {
                    onAddProduct(unitPickerProduct, u);
                    setUnitPickerProduct(null);
                  }}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-600 cursor-pointer"
                >
                  <span className="text-sm font-medium">
                    {u.unitName} ({formatNumber(u.multiplier)} {unitPickerProduct.baseUnit})
                  </span>
                  <span className="font-mono text-sm font-bold text-teal-700 dark:text-teal-400">
                    {formatRupiah(u.sellPrice)}
                  </span>
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setUnitPickerProduct(null)}
              className="w-full py-2 text-sm font-semibold text-slate-500 cursor-pointer"
            >
              Batal
            </button>
          </div>
        </div>
      )}

      {/* Barcode Quick Scan Modal */}
      {showScannerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-base font-bold">Scan / Input Barcode</h3>
              <button type="button" onClick={() => setShowScannerModal(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <input
              type="text"
              value={scannerCode}
              onChange={(e) => setScannerCode(e.target.value)}
              placeholder="Ketik atau arahkan scanner barcode / SKU..."
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono"
            />
            <div className="space-y-1.5">
              <p className="text-xs font-semibold text-slate-500">Sampel Barcode Cepat:</p>
              {products.slice(0, 4).map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    onScanBarcode(p.barcode);
                    setShowScannerModal(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs flex justify-between cursor-pointer"
                >
                  <span>{p.name}</span>
                  <span className="font-mono text-slate-500">{p.barcode}</span>
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowScannerModal(false);
                  setShowCameraScanner(true);
                }}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                <Camera className="w-4 h-4" />
                <span>Kamera HP</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onScanBarcode(scannerCode)) {
                    setScannerCode('');
                    setShowScannerModal(false);
                  }
                }}
                className="flex-1 py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold cursor-pointer"
              >
                Cari &amp; Tambah ke Keranjang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Live Mobile Camera Barcode / SKU Scanner */}
      {showCameraScanner && (
        <CameraScannerModal
          title="Scan Kamera — Kasir POS"
          subtitle="Arahkan kamera HP ke barcode atau QR SKU untuk menambahkan barang ke keranjang."
          onDetected={(code) => {
            onScanBarcode(code);
            setShowCameraScanner(false);
          }}
          onClose={() => setShowCameraScanner(false)}
        />
      )}

      {/* Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">Pembayaran</h3>
              <button type="button" onClick={() => setShowCheckoutModal(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            {!openShift && (
              <div className="rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 p-3 space-y-2">
                <p className="text-xs text-amber-800 dark:text-amber-300">
                  Shift kasir belum dibuka. Buka shift dulu untuk mencatat laci kas.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setShowCheckoutModal(false);
                    setShowShiftModal(true);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-amber-600 text-white text-xs font-semibold cursor-pointer"
                >
                  Buka Shift Sekarang
                </button>
              </div>
            )}

            <div className="rounded-xl bg-teal-50 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-900 p-3.5">
              <p className="text-xs text-teal-700 dark:text-teal-300">Total Tagihan</p>
              <p className="text-2xl font-extrabold font-mono text-teal-800 dark:text-teal-300">
                {formatRupiah(grandTotal)}
              </p>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">Metode Pembayaran</p>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'TUNAI', label: 'Tunai', enabled: true },
                    { id: 'QRIS', label: 'QRIS', enabled: settings.qrisEnabled },
                    { id: 'TRANSFER', label: 'Transfer / Kartu', enabled: settings.transferEnabled },
                    { id: 'PIUTANG', label: 'Piutang / Tempo', enabled: settings.piutangEnabled },
                  ] as const
                )
                  .filter((m) => m.enabled)
                  .map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        setPayMethod(m.id);
                        setCheckoutErr(null);
                        if (m.id === 'PIUTANG') {
                          setPaidInput('0');
                        } else if (m.id === 'TUNAI') {
                          setPaidInput(String(grandTotal));
                        }
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold border cursor-pointer ${
                        payMethod === m.id
                          ? 'bg-teal-700 border-teal-700 text-white'
                          : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
              </div>
            </div>

            {payMethod === 'TUNAI' && (
              <div className="space-y-2.5">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Nominal Uang Diterima (Rp)
                </label>
                <input
                  type="number"
                  value={paidInput}
                  onChange={(e) => setPaidInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-base font-bold"
                />
                <div className="flex flex-wrap gap-1.5">
                  {Array.from(new Set([grandTotal, 50000, 100000, 200000])).map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setPaidInput(String(amt))}
                      className="px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 text-xs font-mono hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      {amt === grandTotal ? 'Uang Pas' : formatRupiah(amt)}
                    </button>
                  ))}
                </div>
                <div className="flex justify-between items-center pt-1">
                  <span className="text-sm font-medium">Kembalian</span>
                  <span className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
                    {formatRupiah(Math.max(0, (Number(paidInput) || 0) - grandTotal))}
                  </span>
                </div>
              </div>
            )}

            {payMethod === 'QRIS' && (
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 text-center space-y-2">
                <QrCode className="w-24 h-24 mx-auto text-slate-800 dark:text-slate-200" />
                <p className="text-sm font-semibold">QRIS Dinamis · {settings.storeName}</p>
                <p className="text-xs font-mono text-teal-700 dark:text-teal-400">
                  Nominal: {formatRupiah(grandTotal)}
                </p>
              </div>
            )}

            {payMethod === 'PIUTANG' && (
              <div className="space-y-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-3.5">
                {!selectedCustomer ? (
                  <p className="text-xs text-red-600 font-medium">
                    Pilih pelanggan terdaftar di keranjang untuk pembayaran Piutang.
                  </p>
                ) : (
                  <>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 dark:text-slate-400">Pelanggan</span>
                      <span className="font-bold text-slate-900 dark:text-slate-100">
                        {selectedCustomer.name}
                      </span>
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
                        Uang Muka / DP (Rp, opsional)
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={grandTotal}
                        value={paidInput}
                        onChange={(e) => setPaidInput(e.target.value)}
                        placeholder="0"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-sm font-bold"
                      />
                    </div>
                    <div className="flex justify-between items-center text-xs pt-1">
                      <span className="text-slate-600 dark:text-slate-400">Sisa Dicatat Sebagai Hutang</span>
                      <span className="text-sm font-extrabold font-mono text-rose-600 dark:text-rose-400">
                        {formatRupiah(Math.max(0, grandTotal - Math.max(0, Number(paidInput) || 0)))}
                      </span>
                    </div>
                  </>
                )}
              </div>
            )}

            {checkoutErr && (
              <p className="text-xs text-red-600 font-medium">{checkoutErr}</p>
            )}

            <button
              type="button"
              disabled={!openShift || (payMethod === 'PIUTANG' && !selectedCustomer)}
              onClick={() => {
                const res = onCheckout(payMethod, Number(paidInput) || 0);
                if (!res.ok) {
                  setCheckoutErr(res.error || 'Gagal checkout');
                } else if (res.tx) {
                  setShowCheckoutModal(false);
                  onOpenReceipt(res.tx);
                }
              }}
              className="w-full py-2.5 px-4 rounded-lg bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-sm font-semibold cursor-pointer"
            >
              Selesaikan & Cetak Struk
            </button>
          </div>
        </div>
      )}

      {/* Shift Open / Petty Cash / Close Modal */}
      {showShiftModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">
                {openShift ? 'Kelola & Tutup Shift Kasir' : 'Buka Shift Kasir'}
              </h3>
              <button type="button" onClick={() => setShowShiftModal(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            {!openShift ? (
              <div className="space-y-3">
                <label className="block text-xs font-semibold">Modal Awal Kas Laci (Rp)</label>
                <input
                  type="number"
                  value={openingCashInput}
                  onChange={(e) => setOpeningCashInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                />
                <button
                  type="button"
                  onClick={() => {
                    onOpenShift(Number(openingCashInput) || 0);
                    setShowShiftModal(false);
                  }}
                  className="w-full py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold cursor-pointer"
                >
                  Buka Shift Sekarang
                </button>
              </div>
            ) : (
              <div className="space-y-4 text-sm">
                <div className="space-y-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 p-3">
                  <div className="flex justify-between">
                    <span>Modal Awal</span>
                    <span className="font-mono">{formatRupiah(openShift.openingCash)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Penjualan Tunai</span>
                    <span className="font-mono">{formatRupiah(openShift.cashSales)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Non-Tunai (QRIS/Transfer)</span>
                    <span className="font-mono">{formatRupiah(openShift.nonCashSales)}</span>
                  </div>
                  <div className="flex justify-between text-red-600">
                    <span>Kas Kecil Keluar</span>
                    <span className="font-mono">-{formatRupiah(openShift.pettyCashOut)}</span>
                  </div>
                  <div className="flex justify-between font-bold pt-1.5 border-t border-slate-200 dark:border-slate-700">
                    <span>Ekspektasi Kas Laci</span>
                    <span className="font-mono text-teal-700 dark:text-teal-400">
                      {formatRupiah(openShift.expectedCash)}
                    </span>
                  </div>
                </div>

                {/* Petty Cash */}
                <div className="space-y-2 border-t border-slate-200 dark:border-slate-800 pt-3">
                  <p className="text-xs font-semibold">Catat Pengeluaran Kas Kecil</p>
                  <input
                    type="text"
                    value={pettyDesc}
                    onChange={(e) => setPettyDesc(e.target.value)}
                    placeholder="Keterangan (mis. beli plastik / es)"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                  />
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={pettyAmount}
                      onChange={(e) => setPettyAmount(e.target.value)}
                      placeholder="Nominal Rp"
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        onAddPettyCash(pettyDesc, Number(pettyAmount) || 0);
                        setPettyDesc('');
                        setPettyAmount('');
                      }}
                      className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer"
                    >
                      Catat
                    </button>
                  </div>
                  {pettyCash
                    .filter((pc) => pc.shiftId === openShift.id)
                    .map((pc) => (
                      <p key={pc.id} className="text-xs text-slate-500">
                        • {pc.description}: {formatRupiah(pc.amount)}
                      </p>
                    ))}
                </div>

                {/* Close Shift */}
                <div className="space-y-2 border-t border-slate-200 dark:border-slate-800 pt-3">
                  <label className="block text-xs font-semibold">Kas Fisik Aktual di Laci (Rp)</label>
                  <input
                    type="number"
                    value={actualCashInput}
                    onChange={(e) => setActualCashInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const closed = onCloseShift(Number(actualCashInput) || 0);
                      setShowShiftModal(false);
                      if (closed) setClosedShiftRecap(closed);
                    }}
                    className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-semibold cursor-pointer"
                  >
                    Tutup Shift Kasir
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Closed Shift Recap Modal */}
      {closedShiftRecap && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3 text-sm">
            <h3 className="text-lg font-bold">Rekap Tutup Shift</h3>
            <p className="text-xs text-slate-500">
              {closedShiftRecap.userName} · {closedShiftRecap.outletName}
            </p>
            <div className="space-y-1.5 border-y border-slate-200 dark:border-slate-800 py-3">
              <div className="flex justify-between">
                <span>Kas Seharusnya</span>
                <span className="font-mono">{formatRupiah(closedShiftRecap.expectedCash)}</span>
              </div>
              <div className="flex justify-between">
                <span>Kas Fisik Aktual</span>
                <span className="font-mono">{formatRupiah(closedShiftRecap.actualCash ?? 0)}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>Selisih</span>
                <span className="font-mono">
                  {formatRupiah((closedShiftRecap.actualCash ?? 0) - closedShiftRecap.expectedCash)}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setClosedShiftRecap(null)}
              className="w-full py-2 rounded-lg bg-teal-700 text-white font-semibold cursor-pointer"
            >
              Selesai
            </button>
          </div>
        </div>
      )}

      {/* History + Void & Retur Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-lg max-h-[88vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">Riwayat Nota, Void & Retur</h3>
              <button type="button" onClick={() => setShowHistoryModal(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            {!voidTarget ? (
              <div className="space-y-2.5">
                {transactions.slice(0, 20).map((tx) => (
                  <div
                    key={tx.id}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-bold font-mono">{tx.invoiceNumber}</p>
                      <p className="text-xs text-slate-500">
                        {tx.customerName} · {tx.paymentMethod} · {formatDateTime(tx.createdAt)}
                      </p>
                      <p className="text-xs font-mono font-semibold text-teal-700 dark:text-teal-400">
                        {formatRupiah(tx.totalAmount)} · {tx.status}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setShowHistoryModal(false);
                          onOpenReceipt(tx);
                        }}
                        className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer"
                      >
                        Struk
                      </button>
                      {tx.status === 'COMPLETED' && (
                        <button
                          type="button"
                          onClick={() => {
                            setVoidTarget(tx);
                            setVoidMsg(null);
                          }}
                          className="px-2.5 py-1.5 rounded-lg border border-red-300 text-red-600 text-xs font-semibold cursor-pointer"
                        >
                          Void/Retur
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm font-semibold font-mono">
                  {voidTarget.invoiceNumber} ({formatRupiah(voidTarget.totalAmount)})
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsFullVoid(true)}
                    className={`flex-1 py-2 rounded-lg text-xs font-semibold border cursor-pointer ${
                      isFullVoid ? 'bg-red-600 text-white border-red-600' : 'border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    Void Transaksi
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsFullVoid(false)}
                    className={`flex-1 py-2 rounded-lg text-xs font-semibold border cursor-pointer ${
                      !isFullVoid ? 'bg-amber-600 text-white border-amber-600' : 'border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    Retur Penjualan
                  </button>
                </div>
                <input
                  type="text"
                  value={voidReason}
                  onChange={(e) => setVoidReason(e.target.value)}
                  placeholder="Alasan pembatalan / retur"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
                />
                {currentUser.role !== 'ADMIN' && currentUser.role !== 'PEMILIK' ? (
                  <input
                    type="password"
                    value={adminPass}
                    onChange={(e) => setAdminPass(e.target.value)}
                    placeholder="Password Otorisasi Admin (admin123)"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm"
                  />
                ) : (
                  <p className="text-xs text-emerald-600 font-medium">
                    Terotorisasi langsung sebagai {currentUser.role} ({currentUser.fullName})
                  </p>
                )}
                {voidMsg && <p className="text-xs text-red-600">{voidMsg}</p>}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setVoidTarget(null)}
                    className="flex-1 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-sm font-semibold cursor-pointer"
                  >
                    Kembali
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const res = onAuthorizeVoidOrReturn(voidTarget, isFullVoid, voidReason, adminPass);
                      if (res.ok) {
                        setVoidTarget(null);
                        setVoidReason('');
                        setAdminPass('');
                      } else {
                        setVoidMsg(res.message);
                      }
                    }}
                    className="flex-1 py-2 rounded-lg bg-red-600 text-white text-sm font-semibold cursor-pointer"
                  >
                    Proses
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {/* Debt Settlement / Partial Payment Modal */}
      {debtPayTarget && (() => {
        const info = getTransactionDebtInfo(debtPayTarget);
        const halfAmt = Math.max(1, Math.round(info.remaining / 2));
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
            <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold">Pembayaran Hutang Pelanggan</h3>
                  <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                    {debtPayTarget.invoiceNumber} · {debtPayTarget.customerName}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setDebtPayTarget(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5 space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Total Tagihan</span>
                  <span className="font-mono font-semibold">{formatRupiah(info.total)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sudah Dibayar</span>
                  <span className="font-mono font-semibold text-teal-700 dark:text-teal-400">
                    {formatRupiah(info.paid)}
                  </span>
                </div>
                <div className="flex justify-between pt-1.5 border-t border-slate-200 dark:border-slate-800 text-sm font-extrabold">
                  <span>Sisa Hutang</span>
                  <span className="font-mono text-rose-600 dark:text-rose-400">
                    {formatRupiah(info.remaining)}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Metode Pembayaran
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'TUNAI', label: 'Tunai' },
                      { id: 'QRIS', label: 'QRIS' },
                      { id: 'TRANSFER', label: 'Transfer' },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setDebtPayMethod(m.id)}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold border cursor-pointer ${
                        debtPayMethod === m.id
                          ? 'bg-teal-700 border-teal-700 text-white'
                          : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Nominal Pembayaran (Rp)
                </label>
                <input
                  type="number"
                  min={1}
                  max={info.remaining}
                  value={debtPayAmount}
                  onChange={(e) => {
                    setDebtPayAmount(e.target.value);
                    setDebtPayErr(null);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-base font-bold"
                />
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setDebtPayAmount(String(info.remaining))}
                    className="px-2.5 py-1 rounded-md border border-teal-600 text-teal-700 dark:text-teal-300 text-xs font-semibold hover:bg-teal-50 dark:hover:bg-teal-950/40 cursor-pointer"
                  >
                    Lunasi Penuh ({formatRupiah(info.remaining)})
                  </button>
                  {info.remaining > 1000 && (
                    <button
                      type="button"
                      onClick={() => setDebtPayAmount(String(halfAmt))}
                      className="px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 text-xs font-mono hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      50% ({formatRupiah(halfAmt)})
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Catatan (Opsional)
                </label>
                <input
                  type="text"
                  value={debtPayNote}
                  onChange={(e) => setDebtPayNote(e.target.value)}
                  placeholder="Mis. pelunasan via transfer BCA / cicilan ke-1"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                />
              </div>

              {debtPayErr && <p className="text-xs text-rose-600 font-medium">{debtPayErr}</p>}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    const res = onPayDebt(
                      debtPayTarget.id,
                      Number(debtPayAmount) || 0,
                      debtPayMethod,
                      debtPayNote
                    );
                    if (!res.ok) {
                      setDebtPayErr(res.message);
                    } else {
                      setDebtPayTarget(null);
                    }
                  }}
                  className="py-2.5 px-3 rounded-lg border border-teal-700 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-semibold cursor-pointer"
                >
                  Simpan Pembayaran
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const res = onPayDebt(
                      debtPayTarget.id,
                      Number(debtPayAmount) || 0,
                      debtPayMethod,
                      debtPayNote
                    );
                    if (!res.ok) {
                      setDebtPayErr(res.message);
                    } else {
                      setDebtPayTarget(null);
                      if (res.tx) onOpenReceipt(res.tx);
                    }
                  }}
                  className="py-2.5 px-3 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
                >
                  Bayar &amp; Cetak Nota
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
