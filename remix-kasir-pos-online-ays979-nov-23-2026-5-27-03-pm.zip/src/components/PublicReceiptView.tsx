import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Copy,
  FileDown,
  Printer,
  RotateCcw,
  Store,
  XCircle,
} from 'lucide-react';
import type { StoreSettings, Transaction } from '../types/pos';
import { formatDateTime, formatNumber, formatRupiah } from '../utils/formatters';
import {
  buildOnlineReceiptUrl,
  buildReceiptPreviewLines,
  downloadPdfInvoice,
  getTransactionDebtInfo,
  PAYMENT_LABELS,
  printThermalBrowserDialog,
} from '../utils/receiptExport';

interface PublicReceiptViewProps {
  data: { tx: Transaction; settings: StoreSettings } | null;
  loading?: boolean;
  onExitPublicView: () => void;
}

export const PublicReceiptView: React.FC<PublicReceiptViewProps> = ({
  data,
  loading = false,
  onExitPublicView,
}) => {
  const [copied, setCopied] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const shareUrl = useMemo(() => {
    if (!data) return '';
    return buildOnlineReceiptUrl(data.tx, data.settings);
  }, [data]);

  const handleCopyLink = () => {
    if (!shareUrl) return;
    navigator.clipboard?.writeText(shareUrl).catch(() => {});
    setCopied(true);
    setStatusMessage('Link nota online berhasil disalin.');
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading && !data) {
    return (
      <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm p-6 text-center space-y-3">
          <div className="w-10 h-10 rounded-full border-2 border-teal-700 border-t-transparent animate-spin mx-auto" />
          <h1 className="text-base font-bold">Memuat Nota Digital...</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Mengambil rincian transaksi dari server toko.
          </p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm p-6 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="space-y-1.5">
            <h1 className="text-lg font-bold">Link Nota Online Tidak Valid</h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Tautan nota tidak ditemukan, belum tersinkron, atau rusak. Minta pengirim
              membagikan ulang tautan struk dari WhatsApp.
            </p>
          </div>
          <button
            type="button"
            onClick={onExitPublicView}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Buka Aplikasi AysPOS</span>
          </button>
        </div>
      </div>
    );
  }

  const { tx, settings } = data;
  const previewLines = buildReceiptPreviewLines(tx, settings);
  const debtInfo = getTransactionDebtInfo(tx);

  const statusMeta =
    tx.status === 'VOID'
      ? {
          label: 'DIBATALKAN (VOID)',
          badgeClass:
            'bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-900',
          icon: <XCircle className="w-3.5 h-3.5" />,
        }
      : tx.status === 'RETURNED'
      ? {
          label: 'RETUR',
          badgeClass:
            'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-900',
          icon: <RotateCcw className="w-3.5 h-3.5" />,
        }
      : debtInfo.isDebt && !debtInfo.isSettled
      ? {
          label: debtInfo.paid > 0 ? 'CICILAN HUTANG' : 'BELUM TERBAYAR',
          badgeClass:
            'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-900',
          icon: <AlertTriangle className="w-3.5 h-3.5" />,
        }
      : {
          label: 'LUNAS',
          badgeClass:
            'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900',
          icon: <CheckCircle2 className="w-3.5 h-3.5" />,
        };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 py-6 px-4">
      <div className="max-w-md mx-auto space-y-4">
        <div className="no-print flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-400">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-[#162231] text-white">
              <Store className="w-3.5 h-3.5" />
            </span>
            <span>Nota Digital Online</span>
          </div>
          <button
            type="button"
            onClick={onExitPublicView}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Masuk Kasir</span>
          </button>
        </div>

        <article className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <header className="bg-[#162231] text-white px-5 py-5 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h1 className="text-lg font-extrabold tracking-tight truncate">
                  {settings.storeName}
                </h1>
                {settings.storeAddress && (
                  <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                    {settings.storeAddress}
                  </p>
                )}
                {settings.storePhone && (
                  <p className="text-xs text-slate-300 mt-0.5">Telp: {settings.storePhone}</p>
                )}
              </div>
              <span
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border shrink-0 ${statusMeta.badgeClass}`}
              >
                {statusMeta.icon}
                <span>{statusMeta.label}</span>
              </span>
            </div>

            <div className="rounded-xl bg-slate-800/80 border border-slate-700/80 px-4 py-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[11px] uppercase tracking-wider text-slate-400">No. Nota</p>
                <p className="text-sm font-bold font-mono text-white truncate">
                  {tx.invoiceNumber}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-[11px] uppercase tracking-wider text-slate-400">Total Bayar</p>
                <p className="text-base font-extrabold text-cyan-300">
                  {formatRupiah(tx.totalAmount)}
                </p>
              </div>
            </div>
          </header>

          <div className="p-5 space-y-4">
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2.5 text-xs border-b border-dashed border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Tanggal</dt>
                <dd className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5">
                  {formatDateTime(tx.createdAt)}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Outlet</dt>
                <dd className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5">
                  {tx.outletName}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Pelanggan</dt>
                <dd className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5">
                  {tx.customerName}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Kasir</dt>
                <dd className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5">
                  {tx.cashierName}
                </dd>
              </div>
              <div className="col-span-2">
                <dt className="text-slate-500 dark:text-slate-400">Metode Pembayaran</dt>
                <dd className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5">
                  {PAYMENT_LABELS[tx.paymentMethod] || tx.paymentMethod}
                </dd>
              </div>
            </dl>

            <div className="space-y-2.5 border-b border-dashed border-slate-200 dark:border-slate-800 pb-4">
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Rincian Belanja ({tx.items.length} item)
              </p>
              <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                {tx.items.map((item, idx) => (
                  <li key={`${item.productId}-${idx}`} className="py-2 first:pt-0 last:pb-0">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                          {item.productName}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          {item.quantity} {item.unitName} &times; {formatRupiah(item.unitPrice)}
                        </p>
                        {item.discountAmount > 0 && (
                          <p className="text-xs text-rose-600 dark:text-rose-400">
                            Diskon item: -{formatRupiah(item.discountAmount)}
                          </p>
                        )}
                      </div>
                      <p className="text-sm font-bold text-slate-900 dark:text-slate-100 shrink-0">
                        {formatRupiah(item.subtotal)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>Subtotal</span>
                <span className="font-semibold">{formatRupiah(tx.subtotal)}</span>
              </div>
              {tx.discountAmount > 0 && (
                <div className="flex items-center justify-between text-rose-600 dark:text-rose-400">
                  <span>Diskon</span>
                  <span className="font-semibold">-{formatRupiah(tx.discountAmount)}</span>
                </div>
              )}
              {tx.taxAmount > 0 && (
                <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                  <span>PPN ({formatNumber(tx.taxPercent)}%)</span>
                  <span className="font-semibold">{formatRupiah(tx.taxAmount)}</span>
                </div>
              )}
              <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800 text-sm font-extrabold text-slate-900 dark:text-slate-100">
                <span>TOTAL</span>
                <span>{formatRupiah(tx.totalAmount)}</span>
              </div>
              <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>Dibayar</span>
                <span className="font-semibold">
                  {formatRupiah(debtInfo.isDebt ? debtInfo.paid : tx.paidAmount)}
                </span>
              </div>
              {debtInfo.isDebt && (
                <div
                  className={`flex items-center justify-between font-bold ${
                    debtInfo.isSettled
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : 'text-rose-700 dark:text-rose-400'
                  }`}
                >
                  <span>Sisa Hutang</span>
                  <span>{formatRupiah(debtInfo.remaining)}</span>
                </div>
              )}
              {!debtInfo.isDebt && tx.changeAmount > 0 && (
                <div className="flex items-center justify-between text-emerald-700 dark:text-emerald-400 font-semibold">
                  <span>Kembalian</span>
                  <span>{formatRupiah(tx.changeAmount)}</span>
                </div>
              )}
            </div>

            {tx.voidReason && (
              <div className="rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 px-3 py-2 text-xs text-rose-800 dark:text-rose-200">
                <span className="font-bold">Catatan Pembatalan:</span> {tx.voidReason}
              </div>
            )}

            {settings.receiptFooter && (
              <p className="pt-3 border-t border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
                {settings.receiptFooter}
              </p>
            )}
          </div>
        </article>

        {statusMessage && (
          <div className="no-print rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-900 px-3.5 py-2.5 text-xs font-semibold text-emerald-800 dark:text-emerald-200">
            {statusMessage}
          </div>
        )}

        <div className="no-print grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => {
              downloadPdfInvoice(tx, settings);
              setStatusMessage(`Invoice ${tx.invoiceNumber}.pdf berhasil diunduh.`);
            }}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
          >
            <FileDown className="w-4 h-4 shrink-0" />
            <span>Download PDF</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const res = printThermalBrowserDialog(previewLines, settings);
              setStatusMessage(res.message);
            }}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
          >
            <Printer className="w-4 h-4 shrink-0" />
            <span>Cetak Struk</span>
          </button>

          <button
            type="button"
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
          >
            {copied ? (
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <Copy className="w-4 h-4 shrink-0" />
            )}
            <span>{copied ? 'Link Disalin' : 'Salin Link'}</span>
          </button>
        </div>

        <p className="no-print text-center text-[11px] text-slate-500 dark:text-slate-400">
          Nota online ini dapat dibuka langsung melalui browser dari WhatsApp pelanggan.
        </p>
      </div>
    </div>
  );
};
