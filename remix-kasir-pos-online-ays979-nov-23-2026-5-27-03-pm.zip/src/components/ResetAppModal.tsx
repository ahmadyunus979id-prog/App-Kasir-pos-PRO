import React, { useState } from 'react';
import { AlertTriangle, RotateCcw, X } from 'lucide-react';
import type { PosDatabaseState } from '../data/seedData';

interface ResetAppModalProps {
  dbState: PosDatabaseState;
  onConfirmResetToZero: (options: { resetPemilikCredentials: boolean }) => {
    ok: boolean;
    error?: string;
  };
  onClose: () => void;
}

export const ResetAppModal: React.FC<ResetAppModalProps> = ({
  dbState,
  onConfirmResetToZero,
  onClose,
}) => {
  const [confirmText, setConfirmText] = useState('');
  const [resetPemilikCredentials, setResetPemilikCredentials] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isConfirmed = confirmText.trim().toUpperCase() === 'RESET';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isConfirmed) return;
    const res = onConfirmResetToZero({ resetPemilikCredentials });
    if (res.ok) {
      onClose();
    } else {
      setError(res.error || 'Gagal mereset aplikasi');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-red-200 dark:border-red-900 p-5 space-y-4 shadow-xl"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Reset Aplikasi Menjadi 0 (Seperti Baru)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Akses Penuh Pemilik — Penghapusan seluruh data operasional ke kondisi kosong.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup dialog reset"
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5 space-y-2">
          <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
            Data saat ini yang akan dihapus menjadi 0:
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono">
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5">
              <span className="text-slate-500 block text-[10px]">Produk</span>
              <strong className="text-slate-900 dark:text-slate-100">
                {dbState.products.length}
              </strong>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5">
              <span className="text-slate-500 block text-[10px]">Transaksi</span>
              <strong className="text-slate-900 dark:text-slate-100">
                {dbState.transactions.length}
              </strong>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5">
              <span className="text-slate-500 block text-[10px]">Pelanggan</span>
              <strong className="text-slate-900 dark:text-slate-100">
                {dbState.customers.length}
              </strong>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5">
              <span className="text-slate-500 block text-[10px]">Supplier &amp; PO</span>
              <strong className="text-slate-900 dark:text-slate-100">
                {dbState.suppliers.length} / {dbState.purchaseOrders.length}
              </strong>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5">
              <span className="text-slate-500 block text-[10px]">Shift &amp; Mutasi</span>
              <strong className="text-slate-900 dark:text-slate-100">
                {dbState.shifts.length} / {dbState.stockMovements.length}
              </strong>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5">
              <span className="text-slate-500 block text-[10px]">Akun / Cabang</span>
              <strong className="text-slate-900 dark:text-slate-100">
                {dbState.users.length} / {dbState.outlets.length}
              </strong>
            </div>
          </div>
        </div>

        <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-disc pl-4">
          <li>
            Semua produk, transaksi penjualan, shift kasir, kas kecil, absensi karyawan,
            pelanggan, poin loyalitas, supplier, PO, mutasi &amp; transfer stok dihapus menjadi{' '}
            <strong>0</strong>.
          </li>
          <li>
            Profil toko, pajak, printer, serta cabang tambahan dikembalikan ke bawaan awal yang
            bersih (menyisakan <strong>1 Outlet Pusat</strong>).
          </li>
          <li>
            Semua akun staf (Admin, Kasir, Gudang) dihapus dan hanya menyisakan{' '}
            <strong>1 akun Pemilik</strong> agar Anda tetap dapat masuk &amp; mengelola sistem.
          </li>
        </ul>

        <label className="flex items-start gap-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-xs text-slate-700 dark:text-slate-200 cursor-pointer">
          <input
            type="checkbox"
            checked={resetPemilikCredentials}
            onChange={(e) => setResetPemilikCredentials(e.target.checked)}
            className="w-4 h-4 accent-red-600 mt-0.5 shrink-0"
          />
          <span>
            Kembalikan juga username &amp; sandi akun Pemilik ke standar pabrik (
            <code className="font-mono font-bold">pemilik</code> /{' '}
            <code className="font-mono font-bold">pemilik123</code>)
          </span>
        </label>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
            Ketik <span className="font-mono font-bold text-red-600">RESET</span> untuk melanjutkan
          </label>
          <input
            type="text"
            value={confirmText}
            onChange={(e) => {
              setConfirmText(e.target.value);
              setError(null);
            }}
            placeholder="Ketik RESET"
            autoFocus
            className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-red-600"
          />
        </div>

        {error && (
          <div className="rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 px-3 py-2 text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}

        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={!isConfirmed}
            className="flex-1 py-2.5 px-4 rounded-lg bg-red-600 hover:bg-red-700 disabled:opacity-45 disabled:cursor-not-allowed text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Aplikasi ke 0 Sekarang</span>
          </button>
        </div>
      </form>
    </div>
  );
};
