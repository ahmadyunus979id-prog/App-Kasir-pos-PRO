import React, { useEffect, useMemo, useState } from 'react';
import {
  Award,
  Bluetooth,
  Building2,
  Check,
  CreditCard,
  Download,
  Edit2,
  ExternalLink,
  KeyRound,
  LogIn,
  LogOut,
  Moon,
  Percent,
  Plus,
  Printer,
  Radar,
  RefreshCw,
  RotateCcw,
  ScanBarcode,
  ShieldCheck,
  SlidersHorizontal,
  Store,
  Sun,
  Trash2,
  Upload,
  Usb,
  Users,
  X,
} from 'lucide-react';
import type { PosDatabaseState } from '../data/seedData';
import type {
  AppMenuId,
  AttendanceConfig,
  ConfigurableRole,
  KaryawanMenuAccess,
  Outlet,
  PaperWidth,
  SavedPrinter,
  StoreSettings,
  User,
} from '../types/pos';
import { formatDateTime } from '../utils/formatters';
import {
  ALL_TOGGLEABLE_MENUS,
  canUserAccessMenu,
  CONFIGURABLE_ROLES,
  createAllMenusAccess,
  createDefaultKaryawanAccess,
  getEffectiveRoleMenuAccess,
  getEffectiveUserMenuAccess,
  hasCustomUserMenuOverride,
  isMenuGloballyEnabled,
} from '../utils/menuPermissions';
import {
  getAuthorizedBluetoothPrinters,
  isRunningInIframe,
  printThermalBluetoothWeb,
  printThermalBrowserDialog,
  printThermalSerialWeb,
  scanAndPairBluetoothPrinter,
  scanAndPairSerialPrinter,
  upsertSavedPrinter,
  type ThermalPrintResult,
} from '../utils/receiptExport';
import { ResetAppModal } from './ResetAppModal';

interface SettingsViewProps {
  currentUser: User;
  isDeveloper: boolean;
  allUsers: User[];
  allDatabaseState: PosDatabaseState;
  settings: StoreSettings;
  attendanceConfig: AttendanceConfig;
  outlets: Outlet[];
  onUpdateSettings: (patch: Partial<StoreSettings>) => void;
  onToggleAttendanceEnabled: (enabled: boolean) => void;
  onSetMenuEnabled: (menuId: AppMenuId, enabled: boolean) => void;
  onSetAllMenusEnabled: (enabled: boolean) => void;
  onSetRoleMenuAccess: (role: ConfigurableRole, access: KaryawanMenuAccess) => void;
  onResetRoleMenuAccess: (role: ConfigurableRole) => void;
  onSetUserMenuAccess: (userId: string, access: KaryawanMenuAccess | null) => void;
  onSetKaryawanMenuAccess: (userId: string, access: KaryawanMenuAccess) => void;
  onSaveOutlet: (outlet: Outlet) => void;
  onDeleteOutlet: (id: string) => void;
  onChangePassword: (oldPass: string, newPass: string) => { ok: boolean; message: string };
  onSwitchAccount: (targetUserId: string) => { ok: boolean; error?: string };
  onOpenDeveloperConsole: () => void;
  onResetDemoData: () => void;
  onResetToZero: (options: { resetPemilikCredentials: boolean }) => {
    ok: boolean;
    error?: string;
  };
  onLogout: () => void;
  onNotify: (msg: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  isDeveloper,
  allUsers,
  allDatabaseState,
  settings,
  attendanceConfig,
  outlets,
  onUpdateSettings,
  onToggleAttendanceEnabled: _onToggleAttendanceEnabled,
  onSetMenuEnabled,
  onSetAllMenusEnabled,
  onSetRoleMenuAccess,
  onResetRoleMenuAccess,
  onSetUserMenuAccess,
  onSetKaryawanMenuAccess: _onSetKaryawanMenuAccess,
  onSaveOutlet,
  onDeleteOutlet,
  onChangePassword,
  onSwitchAccount,
  onOpenDeveloperConsole,
  onResetDemoData,
  onResetToZero,
  onLogout,
  onNotify,
}) => {
  const canEditStore = isDeveloper || currentUser.role === 'ADMIN' || currentUser.role === 'PEMILIK';
  const canAccessDeveloperMenu = canUserAccessMenu(
    currentUser,
    'DEVELOPER',
    settings,
    attendanceConfig
  );
  const [confirmResetDemo, setConfirmResetDemo] = useState(false);
  const [showZeroResetModal, setShowZeroResetModal] = useState(false);
  const [accessControlTab, setAccessControlTab] = useState<'ROLES' | 'USERS' | 'MENUS'>('ROLES');
  const [userRoleFilter, setUserRoleFilter] = useState<'ALL' | ConfigurableRole>('ALL');

  const [storeName, setStoreName] = useState(settings.storeName);
  const [storeAddress, setStoreAddress] = useState(settings.storeAddress);
  const [storePhone, setStorePhone] = useState(settings.storePhone);
  const [taxPercent, setTaxPercent] = useState(String(settings.taxPercent));
  const [pointsPerAmount, setPointsPerAmount] = useState(String(settings.pointsPerAmount));
  const [printerName, setPrinterName] = useState(settings.printerName);
  const [printerAddress, setPrinterAddress] = useState(settings.printerAddress);
  const [receiptFooter, setReceiptFooter] = useState(settings.receiptFooter);
  const [printerTestStatus, setPrinterTestStatus] = useState<ThermalPrintResult | null>(null);
  const [scanningBt, setScanningBt] = useState(false);

  const inIframe = useMemo(() => isRunningInIframe(), []);
  const standaloneUrl = typeof window !== 'undefined' ? window.location.href : '/';
  const savedPrinters = settings.savedPrinters || [];

  useEffect(() => {
    setStoreName(settings.storeName);
    setStoreAddress(settings.storeAddress);
    setStorePhone(settings.storePhone);
    setTaxPercent(String(settings.taxPercent));
    setPointsPerAmount(String(settings.pointsPerAmount));
    setPrinterName(settings.printerName);
    setPrinterAddress(settings.printerAddress);
    setReceiptFooter(settings.receiptFooter);
  }, [settings]);

  useEffect(() => {
    let active = true;
    getAuthorizedBluetoothPrinters().then((authorized) => {
      if (!active || authorized.length === 0) return;
      let merged = [...(settings.savedPrinters || [])];
      let changed = false;
      authorized.forEach((dev) => {
        if (!merged.some((p) => p.id === dev.id)) {
          merged = upsertSavedPrinter(merged, {
            id: dev.id,
            name: dev.name,
            address: dev.id,
            connectionType: 'BLE',
            paperWidth: settings.paperWidth,
            lastConnectedAt: Date.now(),
          });
          changed = true;
        }
      });
      if (changed) {
        onUpdateSettings({ savedPrinters: merged });
      }
    });
    return () => {
      active = false;
    };
  }, []);

  // New / Edit Outlet
  const [newOutletName, setNewOutletName] = useState('');
  const [newOutletAddress, setNewOutletAddress] = useState('');
  const [newOutletPhone, setNewOutletPhone] = useState('');
  const [editingOutlet, setEditingOutlet] = useState<Outlet | null>(null);

  // Change password
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passStatus, setPassStatus] = useState<{ ok: boolean; text: string } | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onUpdateSettings({ logoUrl: reader.result });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveStoreProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      storeName: storeName.trim() || settings.storeName,
      storeAddress: storeAddress.trim(),
      storePhone: storePhone.trim(),
    });
  };

  const handleSaveTaxAndLoyalty = (e: React.FormEvent) => {
    e.preventDefault();
    const taxNum = Math.max(0, Math.min(100, Number(taxPercent) || 0));
    const ptsNum = Math.max(1000, Number(pointsPerAmount) || 10000);
    onUpdateSettings({
      taxPercent: taxNum,
      pointsPerAmount: ptsNum,
    });
  };

  const applySavedPrinter = (printer: SavedPrinter) => {
    const nextList = upsertSavedPrinter(settings.savedPrinters, printer);
    setPrinterName(printer.name);
    setPrinterAddress(printer.address);
    onUpdateSettings({
      printerName: printer.name,
      printerAddress: printer.address,
      activePrinterId: printer.id,
      savedPrinters: nextList,
    });
  };

  const handleDeleteSavedPrinter = (id: string) => {
    const nextList = savedPrinters.filter((p) => p.id !== id);
    const nextActive = settings.activePrinterId === id ? nextList[0]?.id : settings.activePrinterId;
    onUpdateSettings({
      savedPrinters: nextList,
      activePrinterId: nextActive,
    });
  };

  const handleSavePrinter = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = printerName.trim() || 'Thermal Printer';
    const cleanAddress = printerAddress.trim();
    const manualPrinter: SavedPrinter = {
      id: cleanAddress ? `manual-${cleanAddress}` : `manual-${cleanName.toLowerCase().replace(/\s+/g, '-')}`,
      name: cleanName,
      address: cleanAddress || 'Manual',
      connectionType: 'MANUAL',
      paperWidth: settings.paperWidth,
      lastConnectedAt: Date.now(),
    };
    onUpdateSettings({
      printerName: cleanName,
      printerAddress: cleanAddress,
      receiptFooter: receiptFooter.trim(),
      activePrinterId: manualPrinter.id,
      savedPrinters: upsertSavedPrinter(settings.savedPrinters, manualPrinter),
    });
    setPrinterTestStatus({
      ok: true,
      message: `Printer "${cleanName}" disimpan ke daftar perangkat.`,
    });
  };

  const buildSampleLines = () => [
    settings.storeName.toUpperCase(),
    settings.storeAddress,
    '--------------------------------',
    'TES CETAK PRINTER THERMAL',
    `Lebar: ${settings.paperWidth === 'MM_58' ? '58mm' : '80mm'}`,
    `Printer: ${printerName || 'Thermal Printer'}`,
    `Waktu: ${formatDateTime(Date.now())}`,
    '--------------------------------',
    settings.receiptFooter,
  ];

  const handleScanNearbyBluetooth = async () => {
    setScanningBt(true);
    const res = await scanAndPairBluetoothPrinter(settings.paperWidth);
    setScanningBt(false);
    setPrinterTestStatus(res);
    if (res.printer) {
      applySavedPrinter(res.printer);
    }
    if (res.ok) onNotify(res.message);
  };

  const handleScanNearbySerial = async () => {
    setScanningBt(true);
    const res = await scanAndPairSerialPrinter(settings.paperWidth);
    setScanningBt(false);
    setPrinterTestStatus(res);
    if (res.printer) {
      applySavedPrinter(res.printer);
    }
    if (res.ok) onNotify(res.message);
  };

  const handleTestBluetoothPrint = async (preferredId?: string) => {
    const res = await printThermalBluetoothWeb(
      buildSampleLines(),
      preferredId || settings.activePrinterId,
      settings.paperWidth
    );
    setPrinterTestStatus(res);
    if (res.printer) {
      applySavedPrinter(res.printer);
    }
    if (res.ok) onNotify(res.message);
  };

  const handleTestSerialPrint = async () => {
    const res = await printThermalSerialWeb(buildSampleLines());
    setPrinterTestStatus(res);
    if (res.ok) onNotify(res.message);
  };

  const handleTestDriverPrint = () => {
    const res = printThermalBrowserDialog(buildSampleLines(), settings);
    setPrinterTestStatus(res);
    if (res.ok) onNotify(res.message);
  };

  const handleAddOutlet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOutletName.trim()) return;
    onSaveOutlet({
      id: '',
      name: newOutletName.trim(),
      address: newOutletAddress.trim() || '-',
      phone: newOutletPhone.trim() || '-',
      isMain: false,
    });
    setNewOutletName('');
    setNewOutletAddress('');
    setNewOutletPhone('');
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass !== confirmPass) {
      setPassStatus({ ok: false, text: 'Konfirmasi password baru tidak cocok' });
      return;
    }
    const res = onChangePassword(oldPass, newPass);
    setPassStatus({ ok: res.ok, text: res.message });
    if (res.ok) {
      setOldPass('');
      setNewPass('');
      setConfirmPass('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Pengaturan Sistem & Perangkat
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Kelola profil toko, cabang, tampilan gelap/cerah, pajak PPN, printer thermal Bluetooth, dan keamanan akun.
          </p>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 text-sm font-semibold cursor-pointer whitespace-nowrap w-fit"
        >
          <LogOut className="w-4 h-4" />
          <span>Keluar Akun ({currentUser.username})</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* KONTROL MENU & HAK AKSES SEMUA ROLE (KHUSUS AKUN PEMILIK) */}
        {currentUser.role === 'PEMILIK' && (
          <div className="lg:col-span-2 rounded-xl bg-white dark:bg-slate-900 border border-teal-200 dark:border-teal-900 p-5 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5 text-teal-700 dark:text-teal-400" />
                  <span>Kontrol Menu &amp; Hak Akses Semua Role (Khusus Pemilik)</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Atur hak akses menu untuk setiap role (Admin, Kasir, Staf Gudang, Karyawan), kustomisasi per akun, dan aktif/nonaktifkan menu secara global.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSetAllMenusEnabled(true)}
                  className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
                >
                  Aktifkan Semua Menu
                </button>
                <button
                  type="button"
                  onClick={() => onSetAllMenusEnabled(false)}
                  className="px-3 py-1.5 rounded-lg border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold cursor-pointer"
                >
                  Nonaktifkan Semua Menu
                </button>
              </div>
            </div>

            {/* SUB-TABS KONTROL AKSES */}
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setAccessControlTab('ROLES')}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                  accessControlTab === 'ROLES'
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                Hak Akses Per Role
              </button>
              <button
                type="button"
                onClick={() => setAccessControlTab('USERS')}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                  accessControlTab === 'USERS'
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                Hak Akses Per Akun ({allUsers.filter((u) => u.role !== 'PEMILIK').length})
              </button>
              <button
                type="button"
                onClick={() => setAccessControlTab('MENUS')}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                  accessControlTab === 'MENUS'
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                Aktif / Nonaktif Menu Global
              </button>
            </div>

            {/* TAB 1: HAK AKSES PER ROLE */}
            {accessControlTab === 'ROLES' && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Perubahan pada role langsung berlaku untuk seluruh akun dengan role tersebut (kecuali akun yang memiliki pengaturan khusus di tab Per Akun). Akun Pemilik selalu memiliki akses penuh.
                </p>
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                  {CONFIGURABLE_ROLES.map((roleInfo) => {
                    const effRole = getEffectiveRoleMenuAccess(roleInfo.id, settings);
                    const hasSavedRoleConfig = Boolean(settings.roleMenuAccess?.[roleInfo.id]);
                    const toggleRoleMenu = (menuId: AppMenuId, checked: boolean) => {
                      onSetRoleMenuAccess(roleInfo.id, {
                        ...effRole,
                        [menuId]: checked,
                      });
                    };

                    return (
                      <div
                        key={roleInfo.id}
                        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-3"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                                Role: {roleInfo.label}
                              </span>
                              <span
                                className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                  hasSavedRoleConfig
                                    ? 'bg-teal-100 text-teal-800 dark:bg-teal-950/70 dark:text-teal-300'
                                    : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                                }`}
                              >
                                {hasSavedRoleConfig ? 'Kustom Role' : 'Standar'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                              {roleInfo.description}
                            </p>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                onSetRoleMenuAccess(roleInfo.id, createAllMenusAccess(true))
                              }
                              className="px-2 py-1 rounded-md bg-teal-700 hover:bg-teal-800 text-white text-[11px] font-semibold cursor-pointer"
                            >
                              Semua Menu
                            </button>
                            <button
                              type="button"
                              onClick={() => onResetRoleMenuAccess(roleInfo.id)}
                              className="px-2 py-1 rounded-md border border-slate-300 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              Reset Default Role
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {ALL_TOGGLEABLE_MENUS.map((m) => {
                            const globallyOn = isMenuGloballyEnabled(
                              m.id,
                              settings,
                              attendanceConfig
                            );
                            return (
                              <label
                                key={m.id}
                                className="flex items-center justify-between gap-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-2 text-[11px] font-semibold cursor-pointer"
                              >
                                <span className="truncate">
                                  {m.shortLabel}
                                  {!globallyOn && (
                                    <span className="block text-[9px] text-rose-500 font-normal">
                                      (Menu Global Off)
                                    </span>
                                  )}
                                </span>
                                <input
                                  type="checkbox"
                                  checked={Boolean(effRole[m.id])}
                                  onChange={(e) => toggleRoleMenu(m.id, e.target.checked)}
                                  className="w-3.5 h-3.5 accent-teal-700 shrink-0"
                                />
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: HAK AKSES PER AKUN (SEMUA ROLE NON-PEMILIK) */}
            {accessControlTab === 'USERS' && (
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Kustomisasi izin menu per akun dari semua role (Admin, Kasir, Staf Gudang, Karyawan), atau pilih &ldquo;Ikut Default Role&rdquo; agar mengikuti aturan role-nya.
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => setUserRoleFilter('ALL')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-semibold cursor-pointer ${
                        userRoleFilter === 'ALL'
                          ? 'bg-teal-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      Semua Role
                    </button>
                    {CONFIGURABLE_ROLES.map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setUserRoleFilter(r.id)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-semibold cursor-pointer ${
                          userRoleFilter === r.id
                            ? 'bg-teal-700 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {r.label}
                      </button>
                    ))}
                  </div>
                </div>

                {allUsers.filter(
                  (u) =>
                    u.role !== 'PEMILIK' &&
                    (userRoleFilter === 'ALL' || u.role === userRoleFilter)
                ).length === 0 ? (
                  <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-4 text-xs text-slate-500 space-y-2">
                    <p>
                      Belum ada akun untuk filter role ini. Tambahkan akun baru di Master Data atau Developer Console.
                    </p>
                    <button
                      type="button"
                      onClick={onOpenDeveloperConsole}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      Buka Developer Console
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 pt-1">
                    {allUsers
                      .filter(
                        (u) =>
                          u.role !== 'PEMILIK' &&
                          (userRoleFilter === 'ALL' || u.role === userRoleFilter)
                      )
                      .map((staff) => {
                        const eff = getEffectiveUserMenuAccess(staff, settings);
                        const isCustom = hasCustomUserMenuOverride(staff.id, settings);
                        const roleInfo = CONFIGURABLE_ROLES.find((r) => r.id === staff.role);
                        const updateMenuFlag = (menuId: AppMenuId, checked: boolean) => {
                          onSetUserMenuAccess(staff.id, {
                            ...eff,
                            [menuId]: checked,
                          });
                        };

                        return (
                          <div
                            key={staff.id}
                            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 space-y-2.5"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div>
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                                    {staff.fullName}{' '}
                                    <span className="font-mono font-normal text-slate-500">
                                      @{staff.username}
                                    </span>
                                  </p>
                                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                    {roleInfo?.label || staff.role}
                                  </span>
                                  <span
                                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                      isCustom
                                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300'
                                        : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300'
                                    }`}
                                  >
                                    {isCustom ? 'Kustom Akun' : 'Ikut Role'}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-500">
                                  Status: {staff.isActive ? 'Aktif' : 'Nonaktif'}
                                </p>
                              </div>
                              <div className="flex flex-wrap items-center gap-1.5">
                                {isCustom && (
                                  <button
                                    type="button"
                                    onClick={() => onSetUserMenuAccess(staff.id, null)}
                                    className="px-2 py-1 rounded-md border border-slate-300 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                  >
                                    Ikut Default Role
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() =>
                                    onSetUserMenuAccess(staff.id, createDefaultKaryawanAccess())
                                  }
                                  className="px-2 py-1 rounded-md border border-slate-300 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  Hanya Absensi
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    onSetUserMenuAccess(staff.id, createAllMenusAccess(true))
                                  }
                                  className="px-2 py-1 rounded-md bg-teal-700 hover:bg-teal-800 text-white text-[11px] font-semibold cursor-pointer"
                                >
                                  Aktifkan Semua
                                </button>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                              {ALL_TOGGLEABLE_MENUS.map((m) => {
                                const globallyOn = isMenuGloballyEnabled(
                                  m.id,
                                  settings,
                                  attendanceConfig
                                );
                                return (
                                  <label
                                    key={m.id}
                                    className="flex items-center justify-between gap-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-2.5 py-2 text-[11px] font-semibold cursor-pointer"
                                  >
                                    <span className="truncate">
                                      {m.shortLabel}
                                      {!globallyOn && (
                                        <span className="block text-[9px] text-rose-500 font-normal">
                                          (Menu Global Off)
                                        </span>
                                      )}
                                    </span>
                                    <input
                                      type="checkbox"
                                      checked={Boolean(eff[m.id])}
                                      onChange={(e) => updateMenuFlag(m.id, e.target.checked)}
                                      className="w-3.5 h-3.5 accent-teal-700 shrink-0"
                                    />
                                  </label>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: AKTIF / NONAKTIF MENU GLOBAL */}
            {accessControlTab === 'MENUS' && (
              <div className="space-y-2.5">
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Menu yang dinonaktifkan secara global disembunyikan &amp; diblokir untuk seluruh role (Admin, Kasir, Staf Gudang, dan Karyawan). Akun Pemilik tetap memiliki akses penuh.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-1">
                  {ALL_TOGGLEABLE_MENUS.map((menu) => {
                    const enabled = isMenuGloballyEnabled(menu.id, settings, attendanceConfig);
                    return (
                      <label
                        key={menu.id}
                        className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                              {menu.label}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                enabled
                                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300'
                                  : 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300'
                              }`}
                            >
                              {enabled ? 'Aktif' : 'Nonaktif'}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {menu.description}
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={enabled}
                          onChange={(e) => onSetMenuEnabled(menu.id, e.target.checked)}
                          className="w-4 h-4 accent-teal-700 shrink-0"
                        />
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAMPILAN & PAJAK */}
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Tampilan Gelap / Cerah
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Sesuaikan kenyamanan tampilan layar kasir siang atau malam hari.
              </p>
            </div>
            <div className="flex gap-1.5 bg-slate-100 dark:bg-slate-950 p-1 rounded-lg border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => onUpdateSettings({ themeMode: 'LIGHT' })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer ${
                  settings.themeMode === 'LIGHT'
                    ? 'bg-white text-teal-700 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>Cerah</span>
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ themeMode: 'DARK' })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer ${
                  settings.themeMode === 'DARK'
                    ? 'bg-slate-800 text-teal-300 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>Gelap</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSaveTaxAndLoyalty} className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center gap-2">
              <Percent className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Pajak PPN & Aturan Poin Loyalitas
              </h3>
            </div>

            <div className="space-y-2.5">
              <label className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
                <span>Aktifkan PPN otomatis di kasir</span>
                <input
                  type="checkbox"
                  checked={settings.taxEnabled}
                  disabled={!canEditStore}
                  onChange={(e) => onUpdateSettings({ taxEnabled: e.target.checked })}
                  className="w-4 h-4 accent-teal-700"
                />
              </label>

              <label className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
                <span>Harga produk sudah termasuk PPN (Inklusif)</span>
                <input
                  type="checkbox"
                  checked={settings.taxInclusive}
                  disabled={!canEditStore}
                  onChange={(e) => onUpdateSettings({ taxInclusive: e.target.checked })}
                  className="w-4 h-4 accent-teal-700"
                />
              </label>

              <label className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
                <span>Aktifkan perolehan poin loyalitas (Nominal per 1 Poin)</span>
                <input
                  type="checkbox"
                  checked={settings.pointsEnabled !== false}
                  disabled={!canEditStore}
                  onChange={(e) => onUpdateSettings({ pointsEnabled: e.target.checked })}
                  className="w-4 h-4 accent-teal-700"
                />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Tarif Pajak PPN (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  disabled={!canEditStore}
                  value={taxPercent}
                  onChange={(e) => setTaxPercent(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100 disabled:opacity-60"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  <Award className="w-3.5 h-3.5 inline mr-1 text-teal-600" />
                  Nominal per 1 Poin (Rp)
                  {settings.pointsEnabled === false && (
                    <span className="ml-1.5 text-[11px] font-normal text-amber-600 dark:text-amber-400">
                      (Nonaktif)
                    </span>
                  )}
                </label>
                <input
                  type="number"
                  min="1000"
                  step="1000"
                  disabled={!canEditStore || settings.pointsEnabled === false}
                  value={pointsPerAmount}
                  onChange={(e) => setPointsPerAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100 disabled:opacity-50"
                />
              </div>
            </div>

            {settings.pointsEnabled === false && (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Perolehan poin belanja pelanggan sedang dinonaktifkan. Transaksi kasir tidak akan menambah poin baru sampai fitur ini diaktifkan kembali.
              </p>
            )}

            {canEditStore && (
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
              >
                Simpan Pajak & Poin
              </button>
            )}
          </form>
        </div>

        {/* PROFIL USAHA & LOGO */}
        <form
          onSubmit={handleSaveStoreProfile}
          className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
        >
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-teal-700 dark:text-teal-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Profil Usaha & Logo Toko
            </h2>
          </div>

          <div className="flex items-center gap-4">
            {settings.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt="Logo Toko"
                className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
              />
            ) : (
              <div className="w-16 h-16 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 flex items-center justify-center font-bold text-xl border border-teal-200 dark:border-teal-900">
                {settings.storeName.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div className="space-y-1.5">
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Logo Toko</span>
                <input
                  type="file"
                  accept="image/*"
                  disabled={!canEditStore}
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
              {settings.logoUrl && canEditStore && (
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ logoUrl: undefined })}
                  className="block text-xs text-red-600 dark:text-red-400 hover:underline cursor-pointer"
                >
                  Hapus logo
                </button>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Nama Toko / Usaha
            </label>
            <input
              type="text"
              disabled={!canEditStore}
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 disabled:opacity-60"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Alamat Toko (Tampil di Struk & PDF)
            </label>
            <input
              type="text"
              disabled={!canEditStore}
              value={storeAddress}
              onChange={(e) => setStoreAddress(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 disabled:opacity-60"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Telepon / WhatsApp Toko
            </label>
            <input
              type="text"
              disabled={!canEditStore}
              value={storePhone}
              onChange={(e) => setStorePhone(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 disabled:opacity-60"
            />
          </div>

          {canEditStore && (
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
            >
              Simpan Profil Usaha
            </button>
          )}
        </form>

        {/* SETTING PRINTER THERMAL BLUETOOTH */}
        <form
          onSubmit={handleSavePrinter}
          className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Printer className="w-5 h-5 text-teal-700 dark:text-teal-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Printer Thermal Struk (58mm &amp; 80mm)
              </h2>
            </div>
          </div>

          {inIframe && (
            <div className="rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 p-3 space-y-2 text-xs text-amber-900 dark:text-amber-200">
              <p className="leading-relaxed">
                Aplikasi sedang berjalan di dalam <strong>preview iframe</strong> sehingga browser membatasi akses scan Bluetooth langsung. Buka di tab browser mandiri agar fitur <strong>Cari Printer Bluetooth Terdekat</strong> aktif.
              </p>
              <a
                href={standaloneUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Buka di Tab Baru (Aktifkan Bluetooth)</span>
              </a>
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={scanningBt}
              onClick={handleScanNearbyBluetooth}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer disabled:opacity-60"
            >
              <Radar className="w-3.5 h-3.5" />
              <span>{scanningBt ? 'Memindai...' : 'Cari Bluetooth Terdekat'}</span>
            </button>
            <button
              type="button"
              onClick={handleTestDriverPrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950 text-xs font-semibold cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Tes Driver Thermal</span>
            </button>
            <button
              type="button"
              onClick={() => handleTestBluetoothPrint()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
            >
              <Bluetooth className="w-3.5 h-3.5" />
              <span>Tes Bluetooth BLE</span>
            </button>
            <button
              type="button"
              disabled={scanningBt}
              onClick={handleScanNearbySerial}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
            >
              <Usb className="w-3.5 h-3.5" />
              <span>Cari USB / Serial SPP</span>
            </button>
          </div>

          {printerTestStatus && (
            <div
              className={`rounded-lg px-3 py-2.5 text-xs leading-relaxed border space-y-2 ${
                printerTestStatus.ok
                  ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-200'
                  : 'bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200'
              }`}
            >
              <p className="font-medium">{printerTestStatus.message}</p>
              {printerTestStatus.blockedInIframe && (
                <a
                  href={standaloneUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Buka di Tab Baru Sekarang</span>
                </a>
              )}
            </div>
          )}

          {savedPrinters.length > 0 && (
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 space-y-2">
              <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
                Printer Tersimpan ({savedPrinters.length})
              </p>
              <div className="space-y-2">
                {savedPrinters.map((sp) => {
                  const isActive = sp.id === settings.activePrinterId;
                  return (
                    <div
                      key={sp.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {sp.name}
                          {isActive && (
                            <span className="ml-2 text-emerald-600 dark:text-emerald-400 font-bold">
                              • Aktif
                            </span>
                          )}
                        </p>
                        <p className="font-mono text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {sp.connectionType} · {sp.address}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {!isActive && (
                          <button
                            type="button"
                            onClick={() => applySavedPrinter(sp)}
                            className="px-2.5 py-1 rounded-md border border-teal-600 text-teal-700 dark:text-teal-300 font-semibold hover:bg-teal-50 dark:hover:bg-teal-950 cursor-pointer"
                          >
                            Pakai
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            sp.connectionType === 'SERIAL'
                              ? handleTestSerialPrint()
                              : sp.connectionType === 'MANUAL'
                              ? handleTestDriverPrint()
                              : handleTestBluetoothPrint(sp.id)
                          }
                          className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                        >
                          Tes Cetak
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteSavedPrinter(sp.id)}
                          aria-label={`Hapus printer ${sp.name}`}
                          className="p-1 text-red-600 hover:bg-red-50 dark:hover:bg-red-950 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex gap-2">
            {(['MM_58', 'MM_80'] as PaperWidth[]).map((pw) => (
              <button
                key={pw}
                type="button"
                onClick={() => onUpdateSettings({ paperWidth: pw })}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                  settings.paperWidth === pw
                    ? 'border-teal-700 bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                Kertas Thermal {pw === 'MM_58' ? '58mm' : '80mm'}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Nama Perangkat Printer
              </label>
              <input
                type="text"
                value={printerName}
                onChange={(e) => setPrinterName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                MAC Address / Bluetooth ID
              </label>
              <input
                type="text"
                value={printerAddress}
                onChange={(e) => setPrinterAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Catatan Kaki / Footer Struk
            </label>
            <input
              type="text"
              value={receiptFooter}
              onChange={(e) => setReceiptFooter(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
            />
          </div>

          <label className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
            <span>Tampilkan Logo Toko pada Preview Struk</span>
            <input
              type="checkbox"
              checked={settings.printLogo}
              onChange={(e) => onUpdateSettings({ printLogo: e.target.checked })}
              className="w-4 h-4 accent-teal-700"
            />
          </label>

          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
          >
            Simpan Pengaturan Printer
          </button>
        </form>

        {/* PERANGKAT, PEMBAYARAN & SINKRONISASI E-COMMERCE */}
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-teal-700 dark:text-teal-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Perangkat, Metode Bayar & Sinkronisasi E-Commerce
            </h2>
          </div>

          <div className="space-y-2.5 text-sm text-slate-700 dark:text-slate-300">
            <label className="flex items-center justify-between cursor-pointer">
              <span className="flex items-center gap-2">
                <ScanBarcode className="w-4 h-4 text-slate-400" />
                Barcode Scanner USB / Bluetooth HID
              </span>
              <input
                type="checkbox"
                checked={settings.scannerHidEnabled}
                onChange={(e) => onUpdateSettings({ scannerHidEnabled: e.target.checked })}
                className="w-4 h-4 accent-teal-700"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span>Pembayaran QRIS Dinamis / Statis</span>
              <input
                type="checkbox"
                checked={settings.qrisEnabled}
                disabled={!canEditStore}
                onChange={(e) => onUpdateSettings({ qrisEnabled: e.target.checked })}
                className="w-4 h-4 accent-teal-700"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span>Pembayaran Transfer Bank / Kartu Debit</span>
              <input
                type="checkbox"
                checked={settings.transferEnabled}
                disabled={!canEditStore}
                onChange={(e) => onUpdateSettings({ transferEnabled: e.target.checked })}
                className="w-4 h-4 accent-teal-700"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span>Pembayaran Piutang / Tempo Pelanggan</span>
              <input
                type="checkbox"
                checked={settings.piutangEnabled}
                disabled={!canEditStore}
                onChange={(e) => onUpdateSettings({ piutangEnabled: e.target.checked })}
                className="w-4 h-4 accent-teal-700"
              />
            </label>
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2.5 text-sm text-slate-700 dark:text-slate-300">
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              Integrasi Stok E-Commerce
            </p>
            <label className="flex items-center justify-between cursor-pointer">
              <span>Sinkronisasi Stok Shopee</span>
              <input
                type="checkbox"
                checked={settings.ecommerceShopeeSync}
                disabled={!canEditStore}
                onChange={(e) => onUpdateSettings({ ecommerceShopeeSync: e.target.checked })}
                className="w-4 h-4 accent-teal-700"
              />
            </label>
            <label className="flex items-center justify-between cursor-pointer">
              <span>Sinkronisasi Stok Tokopedia</span>
              <input
                type="checkbox"
                checked={settings.ecommerceTokopediaSync}
                disabled={!canEditStore}
                onChange={(e) => onUpdateSettings({ ecommerceTokopediaSync: e.target.checked })}
                className="w-4 h-4 accent-teal-700"
              />
            </label>

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Terakhir sinkron:{' '}
                {settings.lastSyncAt ? formatDateTime(settings.lastSyncAt) : 'Belum pernah'}
              </span>
              <button
                type="button"
                onClick={() => onUpdateSettings({ lastSyncAt: Date.now() })}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sinkronkan Sekarang</span>
              </button>
            </div>
          </div>
        </div>

        {/* MULTI-CABANG / OUTLET */}
        <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-teal-700 dark:text-teal-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Cabang &amp; Gudang ({outlets.length})
              </h2>
            </div>
            {canEditStore && (
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Pemilik / Admin dapat edit
              </span>
            )}
          </div>

          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {outlets.map((o) => {
              const isEditing = editingOutlet?.id === o.id;
              if (isEditing && editingOutlet) {
                return (
                  <div key={o.id} className="py-3 space-y-2.5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1">
                          Nama Cabang / Gudang
                        </label>
                        <input
                          type="text"
                          value={editingOutlet.name}
                          onChange={(e) =>
                            setEditingOutlet({ ...editingOutlet, name: e.target.value })
                          }
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1">
                          No. Telepon
                        </label>
                        <input
                          type="text"
                          value={editingOutlet.phone}
                          onChange={(e) =>
                            setEditingOutlet({ ...editingOutlet, phone: e.target.value })
                          }
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1">
                        Alamat Lengkap
                      </label>
                      <input
                        type="text"
                        value={editingOutlet.address}
                        onChange={(e) =>
                          setEditingOutlet({ ...editingOutlet, address: e.target.value })
                        }
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingOutlet.isMain}
                        onChange={(e) =>
                          setEditingOutlet({ ...editingOutlet, isMain: e.target.checked })
                        }
                        className="w-4 h-4 accent-teal-700"
                      />
                      <span>Tetapkan sebagai Cabang Pusat</span>
                    </label>
                    <div className="flex flex-wrap gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          if (!editingOutlet.name.trim()) return;
                          onSaveOutlet({
                            ...editingOutlet,
                            name: editingOutlet.name.trim(),
                            address: editingOutlet.address.trim() || '-',
                            phone: editingOutlet.phone.trim() || '-',
                          });
                          setEditingOutlet(null);
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Simpan Perubahan</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingOutlet(null)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Batal</span>
                      </button>
                    </div>
                  </div>
                );
              }

              return (
                <div key={o.id} className="py-2.5 flex items-center justify-between gap-2 text-sm">
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 dark:text-slate-100">
                      {o.name}{' '}
                      {o.isMain && (
                        <span className="text-xs font-medium text-teal-700 dark:text-teal-400 ml-1">
                          (Pusat)
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {o.address} · {o.phone}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {canEditStore ? (
                      <>
                        <button
                          type="button"
                          onClick={() => setEditingOutlet({ ...o })}
                          aria-label={`Edit ${o.name}`}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        {!o.isMain && outlets.length > 1 && (
                          <button
                            type="button"
                            onClick={() => onDeleteOutlet(o.id)}
                            aria-label={`Hapus ${o.name}`}
                            className="p-1.5 rounded-md text-red-600 hover:bg-red-50 dark:hover:bg-red-950 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </>
                    ) : (
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {canEditStore && (
            <form onSubmit={handleAddOutlet} className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Tambah Cabang / Gudang Baru
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  value={newOutletName}
                  onChange={(e) => setNewOutletName(e.target.value)}
                  placeholder="Nama cabang (mis. Cabang Kemang)"
                  className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                />
                <input
                  type="text"
                  value={newOutletPhone}
                  onChange={(e) => setNewOutletPhone(e.target.value)}
                  placeholder="No. Telepon"
                  className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                />
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newOutletAddress}
                  onChange={(e) => setNewOutletAddress(e.target.value)}
                  placeholder="Alamat cabang"
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                />
                <button
                  type="submit"
                  className="flex items-center gap-1 px-3 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah</span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* GANTI PASSWORD */}
        <form
          onSubmit={handlePasswordSubmit}
          className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
        >
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-teal-700 dark:text-teal-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Ganti Password Akun ({currentUser.fullName})
            </h2>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Password Lama
              </label>
              <input
                type="password"
                value={oldPass}
                onChange={(e) => {
                  setOldPass(e.target.value);
                  setPassStatus(null);
                }}
                required
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Password Baru
                </label>
                <input
                  type="password"
                  value={newPass}
                  onChange={(e) => {
                    setNewPass(e.target.value);
                    setPassStatus(null);
                  }}
                  required
                  minLength={4}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Konfirmasi Password Baru
                </label>
                <input
                  type="password"
                  value={confirmPass}
                  onChange={(e) => {
                    setConfirmPass(e.target.value);
                    setPassStatus(null);
                  }}
                  required
                  minLength={4}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>
          </div>

          {passStatus && (
            <div
              className={`rounded-lg px-3 py-2 text-xs font-medium ${
                passStatus.ok
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900'
                  : 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900'
              }`}
            >
              {passStatus.text}
            </div>
          )}

          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-slate-900 dark:bg-teal-700 hover:bg-slate-800 dark:hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer"
          >
            Perbarui Password
          </button>
        </form>

        {/* DEVELOPER TOOLS & BACKUP */}
        {canAccessDeveloperMenu && (
          <div className="lg:col-span-2 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-900 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-700 dark:text-indigo-400" />
                <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  Mode Developer &amp; Utilitas Sistem
                </h2>
              </div>
              <span className="text-xs font-mono text-indigo-700 dark:text-indigo-300">
                {allUsers.length} Akun · {allDatabaseState.products.length} Produk ·{' '}
                {allDatabaseState.transactions.length} Transaksi
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 p-3.5 space-y-2.5">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  Akses Cepat Akun Staf
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Uji tampilan kasir, gudang, atau admin secara langsung, atau buka halaman Developer untuk melihat serta mengubah semua user &amp; sandi.
                </p>
                <div>
                  <button
                    type="button"
                    onClick={onOpenDeveloperConsole}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-semibold cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Cek &amp; Ubah User &amp; Sandi</span>
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {allUsers
                    .filter((u) => isDeveloper || u.role !== 'PEMILIK')
                    .map((u) => {
                      const isSelf = u.id === currentUser.id;
                      return (
                        <button
                          key={u.id}
                          type="button"
                          disabled={isSelf}
                          onClick={() => onSwitchAccount(u.id)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                            isSelf
                              ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-default'
                              : 'bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-900/60'
                          }`}
                        >
                          <LogIn className="w-3.5 h-3.5" />
                          <span>
                            {u.username} ({u.role})
                          </span>
                        </button>
                      );
                    })}
                </div>
              </div>

              {isDeveloper && (
                <div className="rounded-lg border border-slate-200 dark:border-slate-800 p-3.5 space-y-2.5">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  Backup &amp; Reset Data Sistem
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Unduh salinan data operasional, isi ulang data demo awal, atau reset aplikasi menjadi <strong>0 seperti baru</strong>.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const safeSnapshot = {
                        ...allDatabaseState,
                        users: allDatabaseState.users.map(
                          ({ passwordHash: _ph, devVault: _dv, ...rest }) => rest
                        ),
                      };
                      const blob = new Blob([JSON.stringify(safeSnapshot, null, 2)], {
                        type: 'application/json',
                      });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `ayspos-backup-${new Date().toISOString().slice(0, 10)}.json`;
                      a.click();
                      URL.revokeObjectURL(url);
                      onNotify('Backup JSON berhasil diunduh');
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh Backup JSON</span>
                  </button>

                  {!confirmResetDemo ? (
                    <button
                      type="button"
                      onClick={() => setConfirmResetDemo(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-300 dark:border-amber-800 text-xs font-semibold text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Reset Data Demo</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          onResetDemoData();
                          setConfirmResetDemo(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer"
                      >
                        Konfirmasi Demo
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmResetDemo(false)}
                        className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer"
                      >
                        Batal
                      </button>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setShowZeroResetModal(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset Aplikasi ke 0 (Seperti Baru)</span>
                  </button>
                </div>
              </div>
              )}
            </div>
          </div>
        )}
      </div>

      {showZeroResetModal && isDeveloper && (
        <ResetAppModal
          dbState={allDatabaseState}
          onConfirmResetToZero={onResetToZero}
          onClose={() => setShowZeroResetModal(false)}
        />
      )}
    </div>
  );
};
