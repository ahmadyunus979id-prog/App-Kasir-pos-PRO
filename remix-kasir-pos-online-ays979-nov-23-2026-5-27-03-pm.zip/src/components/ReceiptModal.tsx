import React, { useEffect, useMemo, useState } from 'react';
import {
  Bluetooth,
  Check,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  FileDown,
  Globe,
  MessageCircle,
  Printer,
  Radar,
  Smartphone,
  Usb,
  X,
} from 'lucide-react';
import type { PaperWidth, StoreSettings, Transaction } from '../types/pos';
import {
  buildOnlineReceiptUrl,
  buildReceiptPreviewLines,
  downloadEscPosFile,
  downloadPdfInvoice,
  isRunningInIframe,
  printThermalBluetoothWeb,
  printThermalBrowserDialog,
  printThermalRawBtAndroid,
  printThermalSerialWeb,
  publishOnlineReceipt,
  scanAndPairBluetoothPrinter,
  shareReceiptWhatsApp,
  upsertSavedPrinter,
  type ThermalPrintResult,
} from '../utils/receiptExport';

interface ReceiptModalProps {
  tx: Transaction;
  settings: StoreSettings;
  onChangePaperWidth: (width: PaperWidth) => void;
  onUpdateSettings: (patch: Partial<StoreSettings>) => void;
  onNotify: (msg: string) => void;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  tx,
  settings,
  onChangePaperWidth,
  onUpdateSettings,
  onNotify,
  onClose,
}) => {
  const [waPhone, setWaPhone] = useState(tx.customerWhatsapp || '');
  const [copiedLink, setCopiedLink] = useState(false);
  const [printingMode, setPrintingMode] = useState<'BLE' | 'SCAN' | 'SERIAL' | null>(null);
  const [printStatus, setPrintStatus] = useState<ThermalPrintResult | null>(null);

  const inIframe = useMemo(() => isRunningInIframe(), []);
  const standaloneUrl = typeof window !== 'undefined' ? window.location.href : '/';
  const onlineReceiptUrl = useMemo(() => buildOnlineReceiptUrl(tx, settings), [tx, settings]);
  const lines = useMemo(() => buildReceiptPreviewLines(tx, settings), [tx, settings]);
  const widthLabel = settings.paperWidth === 'MM_58' ? '58mm' : '80mm';

  useEffect(() => {
    void publishOnlineReceipt(tx, settings);
  }, [tx, settings]);

  const activeSavedPrinter = useMemo(
    () =>
      (settings.savedPrinters || []).find((p) => p.id === settings.activePrinterId) ||
      (settings.savedPrinters || [])[0] ||
      null,
    [settings.savedPrinters, settings.activePrinterId]
  );

  const persistPrinterResult = (res: ThermalPrintResult) => {
    if (!res.printer) return;
    onUpdateSettings({
      printerName: res.printer.name,
      printerAddress: res.printer.address,
      activePrinterId: res.printer.id,
      savedPrinters: upsertSavedPrinter(settings.savedPrinters, res.printer),
    });
  };

  const handleScanBluetooth = async () => {
    setPrintingMode('SCAN');
    const res = await scanAndPairBluetoothPrinter(settings.paperWidth);
    setPrintingMode(null);
    setPrintStatus(res);
    persistPrinterResult(res);
    if (res.ok) onNotify(res.message);
  };

  const handleBluetoothPrint = async () => {
    setPrintingMode('BLE');
    const res = await printThermalBluetoothWeb(
      lines,
      activeSavedPrinter?.connectionType === 'BLE' ? activeSavedPrinter.id : undefined,
      settings.paperWidth
    );
    setPrintingMode(null);
    setPrintStatus(res);
    persistPrinterResult(res);
    if (res.ok) onNotify(res.message);
  };

  const handleSerialPrint = async () => {
    setPrintingMode('SERIAL');
    const res = await printThermalSerialWeb(lines);
    setPrintingMode(null);
    setPrintStatus(res);
    if (res.ok) onNotify(res.message);
  };

  const handleDriverPrint = () => {
    const res = printThermalBrowserDialog(lines, settings);
    setPrintStatus(res);
    if (res.ok) onNotify(res.message);
  };

  const handleRawBtPrint = () => {
    const res = printThermalRawBtAndroid(lines);
    setPrintStatus(res);
    if (res.ok) onNotify(res.message);
  };

  return (
    <div className="receipt-modal-root fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="receipt-modal-card w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="no-print flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              Struk & Invoice Digital
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              {tx.invoiceNumber} · {tx.customerName}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup modal struk"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="no-print flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Kertas:
            </span>
            {(['MM_58', 'MM_80'] as PaperWidth[]).map((pw) => (
              <button
                key={pw}
                type="button"
                onClick={() => onChangePaperWidth(pw)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  settings.paperWidth === pw
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {pw === 'MM_58' ? 'Thermal 58mm' : 'Thermal 80mm'}
              </button>
            ))}
          </div>

          <button
            type="button"
            disabled={printingMode !== null}
            onClick={handleScanBluetooth}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <Radar className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>{printingMode === 'SCAN' ? 'Memindai...' : 'Cari Printer Terdekat'}</span>
          </button>
        </div>

        {(activeSavedPrinter || settings.printerName) && (
          <div className="no-print flex items-center justify-between gap-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="truncate font-semibold text-slate-800 dark:text-slate-200">
                Printer Tersimpan: {activeSavedPrinter?.name || settings.printerName}
              </span>
            </div>
            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 shrink-0">
              {activeSavedPrinter?.connectionType || 'SAVED'}
            </span>
          </div>
        )}

        <div className="rounded-xl bg-amber-50/40 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 overflow-x-auto">
          {settings.printLogo && settings.logoUrl && (
            <div className="flex justify-center mb-2">
              <img
                src={settings.logoUrl}
                alt="Logo Toko"
                className="h-10 w-10 object-cover rounded"
              />
            </div>
          )}
          <pre
            className={`font-mono text-slate-900 dark:text-slate-100 leading-snug whitespace-pre mx-auto w-fit ${
              settings.paperWidth === 'MM_58' ? 'text-[11px]' : 'text-[10px]'
            }`}
          >
            {lines.join('\n')}
          </pre>
        </div>

        {printStatus && (
          <div
            className={`no-print rounded-lg px-3.5 py-2.5 text-xs leading-relaxed border space-y-2 ${
              printStatus.ok
                ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-200'
                : 'bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200'
            }`}
          >
            <p className="font-semibold">{printStatus.message}</p>
            {(printStatus.blockedInIframe || inIframe) && !printStatus.ok && (
              <div className="flex flex-wrap gap-2 pt-0.5">
                <a
                  href={standaloneUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Buka di Tab Baru (Aktifkan Bluetooth)</span>
                </a>
              </div>
            )}
          </div>
        )}

        <div className="no-print space-y-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleDriverPrint}
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>Cetak Driver Thermal ({widthLabel})</span>
            </button>

            <button
              type="button"
              disabled={printingMode !== null}
              onClick={handleBluetoothPrint}
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/50 text-xs sm:text-sm font-semibold transition-colors cursor-pointer disabled:opacity-60"
            >
              <Bluetooth className="w-4 h-4 shrink-0" />
              <span>
                {printingMode === 'BLE' ? 'Menghubungkan...' : `Bluetooth BLE (${widthLabel})`}
              </span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              disabled={printingMode !== null}
              onClick={handleSerialPrint}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-60"
            >
              <Usb className="w-3.5 h-3.5 shrink-0" />
              <span>{printingMode === 'SERIAL' ? 'Mengirim...' : 'USB / Serial SPP'}</span>
            </button>

            <button
              type="button"
              onClick={handleRawBtPrint}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5 shrink-0" />
              <span>RawBT Android</span>
            </button>

            <button
              type="button"
              onClick={() => {
                downloadEscPosFile(lines, tx.invoiceNumber);
                onNotify(`File ESC/POS ${tx.invoiceNumber}.bin diunduh`);
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>ESC/POS (.bin)</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              downloadPdfInvoice(tx, settings);
              onNotify(`Invoice ${tx.invoiceNumber}.pdf diunduh`);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold transition-colors cursor-pointer"
          >
            <FileDown className="w-4 h-4 text-teal-700 dark:text-teal-400" />
            <span>Download Invoice PDF</span>
          </button>
        </div>

        <div className="no-print pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
            Kirim Struk Digital &amp; Link Nota Online ke WhatsApp Pelanggan
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={waPhone}
              onChange={(e) => setWaPhone(e.target.value)}
              placeholder="62812xxxx (opsional)"
              className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
            />
            <button
              type="button"
              onClick={() => {
                void publishOnlineReceipt(tx, settings);
                shareReceiptWhatsApp(tx, settings, waPhone);
                onNotify('Nota & link pendek dibagikan ke WhatsApp / Clipboard');
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold cursor-pointer whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Share WA</span>
            </button>
          </div>

          <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-2.5 space-y-2">
            <div className="flex items-center justify-between gap-2 text-[11px]">
              <span className="inline-flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-200">
                <Globe className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                <span>Link Nota Online (Otomatis ikut di pesan WhatsApp)</span>
              </span>
            </div>
            <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800">
              {onlineReceiptUrl}
            </p>
            <div className="flex flex-wrap gap-2">
              <a
                href={onlineReceiptUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Buka Nota Online</span>
              </a>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard?.writeText(onlineReceiptUrl).catch(() => {});
                  setCopiedLink(true);
                  onNotify('Link nota online disalin');
                  setTimeout(() => setCopiedLink(false), 2000);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
              >
                {copiedLink ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copiedLink ? 'Tersalin' : 'Salin Link'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
