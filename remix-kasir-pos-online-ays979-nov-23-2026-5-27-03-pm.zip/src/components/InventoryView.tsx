import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRightLeft,
  Camera,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Layers,
  Package,
  Plus,
  ShoppingCart,
  Trash2,
  UtensilsCrossed,
} from 'lucide-react';
import { CameraScannerModal } from './CameraScannerModal';
import type {
  Outlet,
  Product,
  PurchaseOrder,
  PurchaseOrderItem,
  StockMovement,
  StockTransfer,
  Supplier,
} from '../types/pos';
import { formatDateTime, formatNumber, formatRupiah } from '../utils/formatters';

interface InventoryViewProps {
  products: Product[];
  suppliers: Supplier[];
  outlets: Outlet[];
  activeOutlet: Outlet;
  purchaseOrders: PurchaseOrder[];
  stockMovements: StockMovement[];
  stockTransfers: StockTransfer[];
  onCreatePurchaseOrder: (
    supplier: Supplier,
    outlet: Outlet,
    items: PurchaseOrderItem[],
    notes: string
  ) => void;
  onPerformStockOpname: (product: Product, physicalQty: number, note: string) => void;
  onCreateTransfer: (
    fromOutlet: Outlet,
    toOutlet: Outlet,
    product: Product,
    quantity: number,
    note: string
  ) => void;
  onReceiveTransfer: (transfer: StockTransfer) => void;
}

type InventoryTab = 'STOCK' | 'PO' | 'OPNAME' | 'TRANSFER' | 'ALERTS';

export const InventoryView: React.FC<InventoryViewProps> = ({
  products,
  suppliers,
  outlets,
  activeOutlet,
  purchaseOrders,
  stockMovements,
  stockTransfers,
  onCreatePurchaseOrder,
  onPerformStockOpname,
  onCreateTransfer,
  onReceiveTransfer,
}) => {
  const [tab, setTab] = useState<InventoryTab>('STOCK');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('Semua');

  // PO State
  const [poSupplierId, setPoSupplierId] = useState<string>(suppliers[0]?.id || '');
  const [poOutletId, setPoOutletId] = useState<string>(activeOutlet.id);
  const [poProductId, setPoProductId] = useState<string>(products[0]?.id || '');
  const [poQty, setPoQty] = useState<string>('10');
  const [poCost, setPoCost] = useState<string>(String(products[0]?.costPrice || 0));
  const [poDraftItems, setPoDraftItems] = useState<PurchaseOrderItem[]>([]);
  const [poNotes, setPoNotes] = useState('');

  // Opname State
  const [opnameProductId, setOpnameProductId] = useState<string>(products[0]?.id || '');
  const [opnamePhysical, setOpnamePhysical] = useState<string>(String(products[0]?.stock || 0));
  const [opnameNote, setOpnameNote] = useState('');
  const [showOpnameScanner, setShowOpnameScanner] = useState(false);
  const [opnameScanFeedback, setOpnameScanFeedback] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  // Transfer State
  const [fromOutletId, setFromOutletId] = useState<string>(activeOutlet.id);
  const [toOutletId, setToOutletId] = useState<string>(
    outlets.find((o) => o.id !== activeOutlet.id)?.id || activeOutlet.id
  );
  const [transferProductId, setTransferProductId] = useState<string>(products[0]?.id || '');
  const [transferQty, setTransferQty] = useState<string>('5');
  const [transferNote, setTransferNote] = useState('');

  const categories = useMemo(
    () => ['Semua', ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  );

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      const catOk = categoryFilter === 'Semua' || p.category === categoryFilter;
      const qOk =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q);
      return catOk && qOk;
    });
  }, [products, search, categoryFilter]);

  const totalInventoryValue = useMemo(
    () => filteredProducts.reduce((acc, p) => acc + Math.round(p.stock * p.costPrice), 0),
    [filteredProducts]
  );

  const lowStockList = useMemo(
    () => products.filter((p) => p.stock <= p.minStock),
    [products]
  );

  const deadStockList = useMemo(() => {
    const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    return products.filter((p) => p.stock > 0 && now - p.lastSoldAt > thirtyDaysMs);
  }, [products]);

  const bomProducts = useMemo(() => products.filter((p) => p.isBom), [products]);

  const opnameHistory = useMemo(
    () => stockMovements.filter((m) => m.type === 'OPNAME'),
    [stockMovements]
  );

  const effectivePoSupplierId = suppliers.some((s) => s.id === poSupplierId)
    ? poSupplierId
    : suppliers[0]?.id || '';
  const effectivePoOutletId = outlets.some((o) => o.id === poOutletId)
    ? poOutletId
    : activeOutlet.id;
  const effectivePoProductId = products.some((p) => p.id === poProductId)
    ? poProductId
    : products[0]?.id || '';
  const effectiveOpnameProductId = products.some((p) => p.id === opnameProductId)
    ? opnameProductId
    : products[0]?.id || '';
  const effectiveFromOutletId = outlets.some((o) => o.id === fromOutletId)
    ? fromOutletId
    : activeOutlet.id;
  const effectiveToOutletId = outlets.some((o) => o.id === toOutletId)
    ? toOutletId
    : outlets.find((o) => o.id !== activeOutlet.id)?.id || activeOutlet.id;
  const effectiveTransferProductId = products.some((p) => p.id === transferProductId)
    ? transferProductId
    : products[0]?.id || '';

  const selectedOpnameProduct =
    products.find((p) => p.id === effectiveOpnameProductId) || products[0];

  const handleAddPoItem = () => {
    const prod = products.find((p) => p.id === effectivePoProductId);
    const qty = Number(poQty);
    const cost = Number(poCost);
    if (!prod || qty <= 0 || cost < 0) return;

    setPoDraftItems((prev) => {
      const existing = prev.find((i) => i.productId === prod.id);
      if (existing) {
        return prev.map((i) =>
          i.productId === prod.id
            ? {
                ...i,
                quantity: i.quantity + qty,
                costPrice: cost,
                subtotal: (i.quantity + qty) * cost,
              }
            : i
        );
      }
      return [
        ...prev,
        {
          productId: prod.id,
          productName: prod.name,
          quantity: qty,
          costPrice: cost,
          subtotal: qty * cost,
        },
      ];
    });
  };

  const handleSubmitPo = (e: React.FormEvent) => {
    e.preventDefault();
    const sup = suppliers.find((s) => s.id === effectivePoSupplierId);
    const out = outlets.find((o) => o.id === effectivePoOutletId);
    if (!sup || !out || poDraftItems.length === 0) return;
    onCreatePurchaseOrder(sup, out, poDraftItems, poNotes);
    setPoDraftItems([]);
    setPoNotes('');
  };

  const handleSubmitOpname = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOpnameProduct) return;
    const physical = Number(opnamePhysical);
    if (Number.isNaN(physical) || physical < 0) return;
    onPerformStockOpname(selectedOpnameProduct, physical, opnameNote);
    setOpnameNote('');
  };

  const handleSubmitTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const fromOut = outlets.find((o) => o.id === effectiveFromOutletId);
    const toOut = outlets.find((o) => o.id === effectiveToOutletId);
    const prod = products.find((p) => p.id === effectiveTransferProductId);
    const qty = Number(transferQty);
    if (!fromOut || !toOut || !prod || Number.isNaN(qty)) return;
    onCreateTransfer(fromOut, toOut, prod, qty, transferNote);
    setTransferNote('');
  };

  const tabs: { id: InventoryTab; label: string }[] = [
    { id: 'STOCK', label: 'Daftar & Nilai Stok' },
    { id: 'PO', label: 'Pembelian / PO' },
    { id: 'OPNAME', label: 'Stok Opname' },
    { id: 'TRANSFER', label: 'Transfer Outlet' },
    { id: 'ALERTS', label: `Peringatan & BOM (${lowStockList.length + deadStockList.length})` },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Inventory & Manajemen Stok
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Pantau stok real-time, Purchase Order supplier, stok opname, transfer cabang, dan resep BOM.
          </p>
        </div>

        <div className="flex flex-wrap gap-1.5 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                tab === t.id
                  ? 'bg-white dark:bg-slate-800 text-teal-700 dark:text-teal-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: DAFTAR & NILAI STOK */}
      {tab === 'STOCK' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Item Terfilter</p>
              <p className="text-2xl font-bold tabular-nums text-slate-900 dark:text-slate-100 mt-1">
                {filteredProducts.length} SKU
              </p>
            </div>
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Valuasi Persediaan</p>
              <p className="text-2xl font-bold tabular-nums text-teal-700 dark:text-teal-400 mt-1">
                {formatRupiah(totalInventoryValue)}
              </p>
            </div>
            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Item Stok Menipis</p>
              <p className="text-2xl font-bold tabular-nums text-amber-600 dark:text-amber-400 mt-1">
                {lowStockList.length} Produk
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari nama produk, SKU, atau merek..."
              className="flex-1 px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-slate-100"
            />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              aria-label="Filter kategori stok"
              className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-slate-100"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-slate-50 dark:bg-slate-950 text-xs uppercase text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Produk / SKU</th>
                    <th className="px-4 py-3 font-semibold">Kategori</th>
                    <th className="px-4 py-3 font-semibold text-right">Sisa Stok</th>
                    <th className="px-4 py-3 font-semibold text-right">Min. Stok</th>
                    <th className="px-4 py-3 font-semibold text-right">HPP / Modal</th>
                    <th className="px-4 py-3 font-semibold text-right">Nilai Persediaan</th>
                    <th className="px-4 py-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                        {products.length === 0
                          ? 'Belum ada produk terdaftar. Tambahkan produk di menu Master Data.'
                          : 'Tidak ada produk yang cocok dengan filter.'}
                      </td>
                    </tr>
                  ) : (
                    filteredProducts.map((p) => {
                      const valuation = Math.round(p.stock * p.costPrice);
                      const isLow = p.stock <= p.minStock;
                      return (
                        <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-900 dark:text-slate-100">{p.name}</div>
                            <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                              {p.sku} · {p.brand}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{p.category}</td>
                          <td className="px-4 py-3 text-right font-mono font-semibold text-slate-900 dark:text-slate-100">
                            {formatNumber(p.stock)} {p.baseUnit}
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-slate-500 dark:text-slate-400">
                            {formatNumber(p.minStock)} {p.baseUnit}
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-slate-700 dark:text-slate-300">
                            {formatRupiah(p.costPrice)}
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-semibold text-teal-700 dark:text-teal-400">
                            {formatRupiah(valuation)}
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`text-xs font-semibold ${
                                isLow
                                  ? 'text-amber-600 dark:text-amber-400'
                                  : 'text-emerald-600 dark:text-emerald-400'
                              }`}
                            >
                              {isLow ? 'Stok Menipis' : 'Aman'}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PURCHASE ORDER (STOK MASUK) */}
      {tab === 'PO' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <form
            onSubmit={handleSubmitPo}
            className="lg:col-span-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 h-fit"
          >
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-teal-700 dark:text-teal-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Buat Purchase Order (Stok Masuk)
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Supplier
                </label>
                <select
                  value={effectivePoSupplierId}
                  onChange={(e) => setPoSupplierId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  {suppliers.length === 0 && <option value="">Belum ada supplier</option>}
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Outlet Tujuan
                </label>
                <select
                  value={effectivePoOutletId}
                  onChange={(e) => setPoOutletId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  {outlets.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 space-y-3">
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
                Tambah Barang ke Daftar PO
              </label>
              <select
                value={effectivePoProductId}
                onChange={(e) => {
                  const nextId = e.target.value;
                  setPoProductId(nextId);
                  const found = products.find((p) => p.id === nextId);
                  if (found) setPoCost(String(found.costPrice));
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-slate-100"
              >
                {products.length === 0 && <option value="">Belum ada produk</option>}
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.baseUnit}) — Stok: {p.stock}
                  </option>
                ))}
              </select>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                    Qty Beli
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={poQty}
                    onChange={(e) => setPoQty(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-mono text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                    Harga Beli / Unit (Rp)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={poCost}
                    onChange={(e) => setPoCost(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-mono text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleAddPoItem}
                className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-teal-600 text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/50 text-xs font-semibold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Item ke PO</span>
              </button>
            </div>

            {poDraftItems.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Item Draft ({poDraftItems.length})
                </p>
                <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                  {poDraftItems.map((it) => (
                    <div key={it.productId} className="flex items-center justify-between px-3 py-2 text-xs">
                      <div>
                        <p className="font-semibold text-slate-800 dark:text-slate-100">{it.productName}</p>
                        <p className="font-mono text-slate-500 dark:text-slate-400">
                          {it.quantity} x {formatRupiah(it.costPrice)} = {formatRupiah(it.subtotal)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setPoDraftItems((prev) => prev.filter((x) => x.productId !== it.productId))
                        }
                        aria-label={`Hapus ${it.productName} dari PO`}
                        className="p-1 text-red-600 hover:bg-red-50 dark:hover:bg-red-950 rounded cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between text-sm font-bold pt-1 text-slate-900 dark:text-slate-100">
                  <span>Total Pembelian</span>
                  <span className="font-mono text-teal-700 dark:text-teal-400">
                    {formatRupiah(poDraftItems.reduce((a, b) => a + b.subtotal, 0))}
                  </span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Catatan PO
              </label>
              <input
                type="text"
                value={poNotes}
                onChange={(e) => setPoNotes(e.target.value)}
                placeholder="No. surat jalan / tempo pembayaran..."
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <button
              type="submit"
              disabled={poDraftItems.length === 0}
              className="w-full py-2.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold disabled:opacity-50 cursor-pointer"
            >
              Simpan PO & Tambah Stok Otomatis
            </button>
          </form>

          <div className="lg:col-span-7 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Riwayat Pembelian Supplier ({purchaseOrders.length})
            </h3>
            {purchaseOrders.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Belum ada riwayat Purchase Order.
              </p>
            ) : (
              <div className="space-y-3">
                {purchaseOrders.map((po) => (
                  <div
                    key={po.id}
                    className="rounded-lg border border-slate-200 dark:border-slate-800 p-4 space-y-2"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-mono font-bold text-sm text-teal-700 dark:text-teal-400">
                          {po.poNumber}
                        </span>
                        <span className="text-xs text-slate-500 dark:text-slate-400 ml-2">
                          {formatDateTime(po.createdAt)}
                        </span>
                      </div>
                      <span className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100">
                        {formatRupiah(po.totalAmount)}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      Supplier: <span className="font-semibold">{po.supplierName}</span> · Outlet:{' '}
                      {po.outletName} · Oleh: {po.createdBy}
                    </p>
                    <div className="text-xs text-slate-500 dark:text-slate-400 space-y-0.5 pt-1 border-t border-slate-100 dark:border-slate-800">
                      {po.items.map((it) => (
                        <div key={it.productId} className="flex justify-between">
                          <span>
                            {it.productName} ({it.quantity} unit)
                          </span>
                          <span className="font-mono">{formatRupiah(it.subtotal)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: STOK OPNAME */}
      {tab === 'OPNAME' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <form
            onSubmit={handleSubmitOpname}
            className="lg:col-span-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 h-fit"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-teal-700 dark:text-teal-400" />
                <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  Penyesuaian Stok Opname
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  setOpnameScanFeedback(null);
                  setShowOpnameScanner(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Scan Kamera</span>
              </button>
            </div>

            {opnameScanFeedback && (
              <div
                className={`rounded-lg px-3 py-2 text-xs font-medium border ${
                  opnameScanFeedback.ok
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-200'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-200'
                }`}
              >
                {opnameScanFeedback.message}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Pilih Produk
              </label>
              <select
                value={effectiveOpnameProductId}
                onChange={(e) => {
                  const id = e.target.value;
                  setOpnameProductId(id);
                  const found = products.find((p) => p.id === id);
                  if (found) setOpnamePhysical(String(found.stock));
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              >
                {products.length === 0 && <option value="">Belum ada produk</option>}
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (Stok Sistem: {p.stock} {p.baseUnit})
                  </option>
                ))}
              </select>
            </div>

            {selectedOpnameProduct && (
              <div className="grid grid-cols-2 gap-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3">
                <div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Stok Catatan Sistem</p>
                  <p className="text-lg font-mono font-bold text-slate-900 dark:text-slate-100">
                    {formatNumber(selectedOpnameProduct.stock)} {selectedOpnameProduct.baseUnit}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Selisih (Fisik - Sistem)</p>
                  {(() => {
                    const delta = (Number(opnamePhysical) || 0) - selectedOpnameProduct.stock;
                    return (
                      <p
                        className={`text-lg font-mono font-bold ${
                          delta === 0
                            ? 'text-slate-500'
                            : delta > 0
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {delta > 0 ? `+${formatNumber(delta)}` : formatNumber(delta)}{' '}
                        {selectedOpnameProduct.baseUnit}
                      </p>
                    );
                  })()}
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Jumlah Stok Fisik Lapangan
              </label>
              <input
                type="number"
                min="0"
                step="any"
                value={opnamePhysical}
                onChange={(e) => setOpnamePhysical(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Keterangan Selisih / Alasan
              </label>
              <input
                type="text"
                value={opnameNote}
                onChange={(e) => setOpnameNote(e.target.value)}
                placeholder="Mis. Barang rusak, susut timbangan, atau hitung ulang"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold cursor-pointer"
            >
              Simpan Hasil Stok Opname
            </button>
          </form>

          <div className="lg:col-span-7 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Riwayat Penyesuaian Opname
            </h3>
            {opnameHistory.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Belum ada riwayat penyesuaian stok opname.
              </p>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {opnameHistory.map((m) => (
                  <div key={m.id} className="py-3 flex items-center justify-between gap-3 text-sm">
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-slate-100">{m.productName}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {formatDateTime(m.createdAt)} · {m.note} · Oleh {m.createdBy}
                      </p>
                    </div>
                    <div className="text-right font-mono">
                      <p
                        className={`font-bold ${
                          m.quantityDelta >= 0
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {m.quantityDelta >= 0 ? `+${m.quantityDelta}` : m.quantityDelta}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Akhir: {m.balanceAfter}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: TRANSFER MULTI-OUTLET */}
      {tab === 'TRANSFER' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <form
            onSubmit={handleSubmitTransfer}
            className="lg:col-span-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 h-fit"
          >
            <div className="flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5 text-teal-700 dark:text-teal-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Kirim Transfer Stok Antar Cabang
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Outlet Asal
                </label>
                <select
                  value={effectiveFromOutletId}
                  onChange={(e) => setFromOutletId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  {outlets.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Outlet / Gudang Tujuan
                </label>
                <select
                  value={effectiveToOutletId}
                  onChange={(e) => setToOutletId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  {outlets.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Produk Ditransfer
              </label>
              <select
                value={effectiveTransferProductId}
                onChange={(e) => setTransferProductId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              >
                {products.length === 0 && <option value="">Belum ada produk</option>}
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (Tersedia: {p.stock} {p.baseUnit})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Jumlah Dikirim
              </label>
              <input
                type="number"
                min="1"
                step="any"
                value={transferQty}
                onChange={(e) => setTransferQty(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Catatan Pengiriman
              </label>
              <input
                type="text"
                value={transferNote}
                onChange={(e) => setTransferNote(e.target.value)}
                placeholder="Kurir / jadwal pengiriman..."
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold cursor-pointer"
            >
              Kirim Transfer (Status In Transit)
            </button>
          </form>

          <div className="lg:col-span-7 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Monitor Barang In Transit & Riwayat Transfer
            </h3>
            {stockTransfers.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">Belum ada transfer stok.</p>
            ) : (
              <div className="space-y-3">
                {stockTransfers.map((trf) => (
                  <div
                    key={trf.id}
                    className="rounded-lg border border-slate-200 dark:border-slate-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100">
                          {trf.transferNumber}
                        </span>
                        <span
                          className={`text-xs font-semibold ${
                            trf.status === 'IN_TRANSIT'
                              ? 'text-amber-600 dark:text-amber-400'
                              : 'text-emerald-600 dark:text-emerald-400'
                          }`}
                        >
                          {trf.status === 'IN_TRANSIT' ? '• In Transit' : '✓ Diterima'}
                        </span>
                      </div>
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                        {trf.productName} — {formatNumber(trf.quantity)} unit
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {trf.fromOutletName} → {trf.toOutletName} · {formatDateTime(trf.createdAt)}
                      </p>
                    </div>
                    {trf.status === 'IN_TRANSIT' ? (
                      <button
                        type="button"
                        onClick={() => onReceiveTransfer(trf)}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Terima Barang</span>
                      </button>
                    ) : (
                      <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                        {trf.receivedAt ? formatDateTime(trf.receivedAt) : 'Selesai'}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: PERINGATAN & RESEP BOM */}
      {tab === 'ALERTS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
              <AlertTriangle className="w-5 h-5" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Peringatan Stok Menipis (Low Stock)
              </h2>
            </div>
            {lowStockList.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Semua stok produk berada di atas batas minimum.
              </p>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {lowStockList.map((p) => (
                  <div key={p.id} className="py-3 flex items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold text-sm text-slate-900 dark:text-slate-100">{p.name}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        SKU: {p.sku} · Batas min: {p.minStock} {p.baseUnit}
                      </p>
                    </div>
                    <span className="font-mono font-bold text-sm text-amber-600 dark:text-amber-400">
                      Sisa {p.stock} {p.baseUnit}
                    </span>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                <Clock className="w-5 h-5 text-slate-500" />
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  Analisis Dead Stock (&gt;30 Hari Tidak Terjual)
                </h3>
              </div>
              {deadStockList.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Tidak ada barang mengendap lebih dari 30 hari.
                </p>
              ) : (
                <div className="divide-y divide-slate-200 dark:divide-slate-800">
                  {deadStockList.map((p) => (
                    <div key={p.id} className="py-2.5 flex items-center justify-between text-sm">
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{p.name}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Terakhir terjual: {formatDateTime(p.lastSoldAt)}
                        </p>
                      </div>
                      <div className="text-right font-mono">
                        <p className="font-semibold text-slate-800 dark:text-slate-200">
                          {p.stock} {p.baseUnit}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Modal: {formatRupiah(p.stock * p.costPrice)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400">
              <UtensilsCrossed className="w-5 h-5" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Resep / Bill of Materials (BOM F&amp;B)
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Setiap penjualan produk BOM otomatis memotong stok bahan baku sesuai takaran resep di bawah ini.
            </p>
            {bomProducts.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Belum ada produk dengan komposisi BOM. Aktifkan di Master Data Produk.
              </p>
            ) : (
              <div className="space-y-3">
                {bomProducts.map((bp) => (
                  <div
                    key={bp.id}
                    className="rounded-lg border border-slate-200 dark:border-slate-800 p-4 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Layers className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                        <span className="font-bold text-sm text-slate-900 dark:text-slate-100">
                          {bp.name}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                        Stok jadi: {bp.stock} {bp.baseUnit}
                      </span>
                    </div>
                    <div className="space-y-1.5 text-xs">
                      {bp.bomItems.map((ing, idx) => {
                        const rawIng = products.find((p) => p.id === ing.ingredientProductId);
                        return (
                          <div
                            key={`${bp.id}-${idx}`}
                            className="flex items-center justify-between bg-slate-50 dark:bg-slate-950 px-3 py-1.5 rounded"
                          >
                            <span className="text-slate-700 dark:text-slate-300">
                              <Package className="w-3.5 h-3.5 inline mr-1.5 text-slate-400" />
                              {ing.ingredientName}
                            </span>
                            <span className="font-mono text-slate-900 dark:text-slate-100">
                              {ing.quantityNeeded} {ing.unit}
                              {rawIng ? ` (Sisa gudang: ${rawIng.stock})` : ''}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {showOpnameScanner && (
        <CameraScannerModal
          title="Scan Produk — Stok Opname"
          subtitle="Scan SKU atau Barcode produk untuk langsung mengisi form Stok Opname."
          onDetected={(rawCode) => {
            const clean = rawCode.trim().toLowerCase();
            const match = products.find(
              (p) => p.barcode.toLowerCase() === clean || p.sku.toLowerCase() === clean
            );
            if (match) {
              setOpnameProductId(match.id);
              setOpnamePhysical(String(match.stock));
              setOpnameScanFeedback({
                ok: true,
                message: `Produk terpilih: ${match.name} (${match.sku})`,
              });
            } else {
              setOpnameScanFeedback({
                ok: false,
                message: `SKU / Barcode "${rawCode.trim()}" tidak ditemukan di daftar produk.`,
              });
            }
            setShowOpnameScanner(false);
          }}
          onClose={() => setShowOpnameScanner(false)}
        />
      )}
    </div>
  );
};
