export type UserRole = 'PEMILIK' | 'ADMIN' | 'KASIR' | 'GUDANG' | 'KARYAWAN';

export type ConfigurableRole = Exclude<UserRole, 'PEMILIK'>;

export type AppMenuId =
  | 'DASHBOARD'
  | 'POS'
  | 'ATTENDANCE'
  | 'MASTER'
  | 'INVENTORY'
  | 'DEVELOPER'
  | 'SETTINGS';

export type KaryawanMenuAccess = Partial<Record<AppMenuId, boolean>>;

export type PaymentMethod = 'TUNAI' | 'QRIS' | 'TRANSFER' | 'PIUTANG';

export type TransactionStatus = 'COMPLETED' | 'VOID' | 'RETURNED';

export type StockMovementType =
  | 'PENJUALAN'
  | 'STOK_MASUK'
  | 'OPNAME'
  | 'TRANSFER_KELUAR'
  | 'TRANSFER_MASUK'
  | 'RETUR'
  | 'VOID'
  | 'BOM_PAKAI';

export type TransferStatus = 'IN_TRANSIT' | 'RECEIVED';

export type ThemeMode = 'LIGHT' | 'DARK';

export type PaperWidth = 'MM_58' | 'MM_80';

export type PrinterConnectionType = 'BLE' | 'SERIAL' | 'MANUAL';

export interface SavedPrinter {
  id: string;
  name: string;
  address: string;
  connectionType: PrinterConnectionType;
  paperWidth: PaperWidth;
  lastConnectedAt: number;
}

export type LoyaltyRewardType = 'DISCOUNT' | 'GIFT';

export type PointHistoryType = 'EARN' | 'REDEEM_DISCOUNT' | 'REDEEM_GIFT' | 'ADJUST';

export interface Outlet {
  id: string;
  name: string;
  address: string;
  phone: string;
  isMain: boolean;
}

export interface User {
  id: string;
  username: string;
  fullName: string;
  passwordHash: string;
  role: UserRole;
  outletId: string;
  isActive: boolean;
  passwordUpdatedAt?: number;
  lastLoginAt?: number;
  devVault?: string;
}

export interface ProductUnitOption {
  unitName: string;
  multiplier: number;
  sellPrice: number;
}

export interface BomItem {
  ingredientProductId: string;
  ingredientName: string;
  quantityNeeded: number;
  unit: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  category: string;
  brand: string;
  costPrice: number;
  sellPrice: number;
  baseUnit: string;
  units: ProductUnitOption[];
  stock: number;
  minStock: number;
  photoUrl?: string;
  outletId: string;
  isBom: boolean;
  bomItems: BomItem[];
  lastSoldAt: number;
  createdAt: number;
}

export interface Customer {
  id: string;
  name: string;
  whatsapp: string;
  address: string;
  points: number;
  receivableBalance: number;
  totalSpent: number;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address: string;
  notes: string;
}

export interface PettyCash {
  id: string;
  shiftId: string;
  description: string;
  amount: number;
  createdAt: number;
}

export interface Shift {
  id: string;
  userId: string;
  userName: string;
  outletId: string;
  outletName: string;
  openedAt: number;
  closedAt?: number;
  openingCash: number;
  cashSales: number;
  nonCashSales: number;
  pettyCashOut: number;
  cashRefunds: number;
  expectedCash: number;
  actualCash?: number;
  status: 'OPEN' | 'CLOSED';
}

export interface TransactionItem {
  productId: string;
  productName: string;
  sku: string;
  unitName: string;
  unitMultiplier: number;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  discountAmount: number;
  subtotal: number;
  returnedQty: number;
}

export interface DebtPaymentRecord {
  id: string;
  amount: number;
  method: 'TUNAI' | 'QRIS' | 'TRANSFER';
  note?: string;
  cashierName: string;
  paidAt: number;
}

export interface Transaction {
  id: string;
  invoiceNumber: string;
  shiftId: string;
  outletId: string;
  outletName: string;
  cashierId: string;
  cashierName: string;
  customerId?: string;
  customerName: string;
  customerWhatsapp: string;
  subtotal: number;
  discountAmount: number;
  taxPercent: number;
  taxAmount: number;
  totalAmount: number;
  totalCost: number;
  paymentMethod: PaymentMethod;
  paidAmount: number;
  changeAmount: number;
  status: TransactionStatus;
  voidReason?: string;
  authorizedBy?: string;
  debtPaidAmount?: number;
  debtPaidAt?: number;
  debtPayments?: DebtPaymentRecord[];
  items: TransactionItem[];
  createdAt: number;
}

export interface PurchaseOrderItem {
  productId: string;
  productName: string;
  quantity: number;
  costPrice: number;
  subtotal: number;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  outletId: string;
  outletName: string;
  totalAmount: number;
  notes: string;
  createdBy: string;
  items: PurchaseOrderItem[];
  createdAt: number;
}

export interface StockMovement {
  id: string;
  productId: string;
  productName: string;
  outletId: string;
  type: StockMovementType;
  quantityDelta: number;
  balanceAfter: number;
  referenceId: string;
  note: string;
  createdBy: string;
  createdAt: number;
}

export interface StockTransfer {
  id: string;
  transferNumber: string;
  fromOutletId: string;
  fromOutletName: string;
  toOutletId: string;
  toOutletName: string;
  productId: string;
  productName: string;
  quantity: number;
  status: TransferStatus;
  note: string;
  createdBy: string;
  createdAt: number;
  receivedAt?: number;
}

export interface LoyaltyReward {
  id: string;
  title: string;
  description: string;
  pointsCost: number;
  rewardType: LoyaltyRewardType;
  discountAmount: number;
  isActive: boolean;
}

export interface PointHistory {
  id: string;
  customerId: string;
  customerName: string;
  type: PointHistoryType;
  pointsDelta: number;
  balanceAfter: number;
  referenceId: string;
  description: string;
  createdAt: number;
}

export interface StoreSettings {
  storeName: string;
  storeAddress: string;
  storePhone: string;
  logoUrl?: string;
  taxPercent: number;
  taxEnabled: boolean;
  taxInclusive: boolean;
  pointsEnabled: boolean;
  pointsPerAmount: number;
  themeMode: ThemeMode;
  paperWidth: PaperWidth;
  printerName: string;
  printerAddress: string;
  savedPrinters?: SavedPrinter[];
  activePrinterId?: string;
  printLogo: boolean;
  receiptFooter: string;
  scannerHidEnabled: boolean;
  qrisEnabled: boolean;
  transferEnabled: boolean;
  piutangEnabled: boolean;
  ecommerceShopeeSync: boolean;
  ecommerceTokopediaSync: boolean;
  lastSyncAt?: number;
  enabledMenus?: Record<AppMenuId, boolean>;
  roleMenuAccess?: Partial<Record<ConfigurableRole, KaryawanMenuAccess>>;
  userMenuAccessByUserId?: Record<string, KaryawanMenuAccess>;
  karyawanAccessByUserId?: Record<string, KaryawanMenuAccess>;
}

export interface CartItem {
  productId: string;
  name: string;
  sku: string;
  photoUrl?: string;
  category: string;
  selectedUnit: string;
  unitMultiplier: number;
  unitPrice: number;
  costPrice: number;
  quantity: number;
  itemDiscount: number;
  availableStock: number;
}

export type AttendanceStatus =
  | 'TEPAT_WAKTU'
  | 'TERLAMBAT'
  | 'PULANG_AWAL'
  | 'IZIN'
  | 'SAKIT'
  | 'CUTI';

export interface AttendanceLocationSnapshot {
  latitude: number;
  longitude: number;
  accuracyMeters?: number;
  distanceMeters?: number;
  withinGeofence?: boolean;
  addressLabel?: string;
  capturedAt: number;
}

export interface AttendanceAdminPermission {
  viewAttendance: boolean;
  viewLocation: boolean;
  manageAttendance: boolean;
}

export interface RoleAttendanceScheduleConfig {
  workStartTime: string;
  workEndTime: string;
  lateToleranceMinutes: number;
  geofenceRadiusMeters: number;
  outletLatitude?: number;
  outletLongitude?: number;
  requireGps: boolean;
}

export interface AttendanceConfig {
  enabled: boolean;
  workStartTime: string;
  workEndTime: string;
  lateToleranceMinutes: number;
  geofenceRadiusMeters: number;
  outletLatitude?: number;
  outletLongitude?: number;
  requireGps: boolean;
  adminAccessByUserId: Record<string, AttendanceAdminPermission>;
  roleConfigs?: Partial<Record<UserRole, Partial<RoleAttendanceScheduleConfig>>>;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  outletId: string;
  outletName: string;
  dateKey: string;
  clockInAt: number;
  clockInPhoto: string;
  clockInLocation?: AttendanceLocationSnapshot;
  clockOutAt?: number;
  clockOutPhoto?: string;
  clockOutLocation?: AttendanceLocationSnapshot;
  status: AttendanceStatus;
  lateMinutes: number;
  earlyLeaveMinutes: number;
  overtimeMinutes: number;
  workDurationMinutes: number;
  notes?: string;
  verifiedBy?: string;
  verifiedAt?: number;
}
