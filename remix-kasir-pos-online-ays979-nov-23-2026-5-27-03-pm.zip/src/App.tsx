import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeftRight,
  BarChart3,
  Boxes,
  CheckCircle2,
  ChevronRight,
  Database,
  LogOut,
  Menu,
  Moon,
  RotateCcw,
  Settings as SettingsIcon,
  ShieldCheck,
  ShoppingBag,
  Store,
  Sun,
  UserCheck,
  X,
} from 'lucide-react';
import { AttendanceView } from './components/AttendanceView';
import { DashboardView } from './components/DashboardView';
import { DeveloperConsoleView } from './components/DeveloperConsoleView';
import { InventoryView } from './components/InventoryView';
import { LoginView } from './components/LoginView';
import { MasterDataView } from './components/MasterDataView';
import { PosView } from './components/PosView';
import { PublicReceiptView } from './components/PublicReceiptView';
import { ReceiptModal } from './components/ReceiptModal';
import { SettingsView } from './components/SettingsView';
import { usePosStore } from './store/usePosStore';
import type { AppMenuId, StoreSettings, Transaction, User, UserRole } from './types/pos';
import { canUserAccessMenu, isMenuGloballyEnabled } from './utils/menuPermissions';
import {
  decodeOnlineReceiptData,
  fetchOnlineReceipt,
  parseReceiptRouteFromLocation,
  type ParsedReceiptRoute,
} from './utils/receiptExport';

type RouteId =
  | 'DASHBOARD'
  | 'POS'
  | 'ATTENDANCE'
  | 'MASTER'
  | 'INVENTORY'
  | 'DEVELOPER'
  | 'SETTINGS';

const ROLE_LABELS: Record<UserRole, string> = {
  PEMILIK: 'Pemilik (Developer)',
  ADMIN: 'Admin',
  KASIR: 'Kasir',
  GUDANG: 'Staf Gudang',
  KARYAWAN: 'Karyawan',
};

export function App() {
  const store = usePosStore();
  const { currentUser, developerUser, isDeveloperSession, state, activeOutlet, openShift, toast } = store;

  const [activeRoute, setActiveRoute] = useState<RouteId>('DASHBOARD');
  const [receiptTx, setReceiptTx] = useState<Transaction | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [desktopSidebarOpen, setDesktopSidebarOpen] = useState(true);
  const [publicRoute, setPublicRoute] = useState<ParsedReceiptRoute | null>(() => {
    if (typeof window === 'undefined') return null;
    return parseReceiptRouteFromLocation(
      window.location.pathname,
      window.location.search,
      window.location.hash
    );
  });
  const [remoteReceiptData, setRemoteReceiptData] = useState<{
    tx: Transaction;
    settings: StoreSettings;
  } | null>(null);
  const [loadingRemoteReceipt, setLoadingRemoteReceipt] = useState(false);

  const localOrTokenReceiptData = useMemo(() => {
    if (!publicRoute) return null;
    if (publicRoute.kind === 'token') {
      const decoded = decodeOnlineReceiptData(publicRoute.token);
      if (decoded) return decoded;
      const localMatch = state.transactions.find(
        (t) => t.invoiceNumber.toLowerCase() === publicRoute.token.trim().toLowerCase()
      );
      return localMatch ? { tx: localMatch, settings: state.settings } : null;
    }
    const localMatch = state.transactions.find(
      (t) => t.invoiceNumber.toLowerCase() === publicRoute.invoiceNumber.trim().toLowerCase()
    );
    return localMatch ? { tx: localMatch, settings: state.settings } : null;
  }, [publicRoute, state.transactions, state.settings]);

  useEffect(() => {
    let active = true;
    if (!publicRoute || publicRoute.kind !== 'short') {
      setRemoteReceiptData(null);
      setLoadingRemoteReceipt(false);
      return;
    }
    setLoadingRemoteReceipt(true);
    fetchOnlineReceipt(publicRoute.storeSlug, publicRoute.invoiceNumber)
      .then((fetched) => {
        if (!active) return;
        setRemoteReceiptData(fetched);
      })
      .finally(() => {
        if (active) setLoadingRemoteReceipt(false);
      });
    return () => {
      active = false;
    };
  }, [publicRoute]);

  const publicReceiptData = remoteReceiptData || localOrTokenReceiptData;

  const handleExitPublicView = () => {
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.delete('nota');
      window.history.replaceState({}, '', `/${url.search}`);
    }
    setRemoteReceiptData(null);
    setPublicRoute(null);
  };

  // Support ?autostart=1 for automated quick entry to Admin dashboard
  useEffect(() => {
    if (publicRoute === null && !currentUser && typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') {
        store.login('admin', 'admin123');
      }
    }
  }, [currentUser, publicRoute]);

  const navItems = useMemo(() => {
    if (!currentUser) return [];
    const role = currentUser.role;
    const isOwner = role === 'PEMILIK';

    const menuLabel = (menuId: AppMenuId, baseLabel: string) => {
      if (isOwner && !isMenuGloballyEnabled(menuId, state.settings, state.attendanceConfig)) {
        return `${baseLabel} (Nonaktif)`;
      }
      return baseLabel;
    };

    const defs: { id: RouteId; label: string; icon: React.ReactNode; visible: boolean }[] = [
      {
        id: 'DASHBOARD',
        label: menuLabel('DASHBOARD', 'Dashboard & Laporan'),
        icon: <BarChart3 className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'DASHBOARD', state.settings, state.attendanceConfig),
      },
      {
        id: 'POS',
        label: menuLabel('POS', 'Kasir (POS)'),
        icon: <ShoppingBag className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'POS', state.settings, state.attendanceConfig),
      },
      {
        id: 'ATTENDANCE',
        label: menuLabel('ATTENDANCE', 'Absensi Karyawan'),
        icon: <UserCheck className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'ATTENDANCE', state.settings, state.attendanceConfig),
      },
      {
        id: 'MASTER',
        label: menuLabel(
          'MASTER',
          role === 'KASIR' || role === 'KARYAWAN' ? 'Pelanggan & Poin' : 'Master Data'
        ),
        icon: <Database className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'MASTER', state.settings, state.attendanceConfig),
      },
      {
        id: 'INVENTORY',
        label: menuLabel('INVENTORY', 'Stok & Inventory'),
        icon: <Boxes className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'INVENTORY', state.settings, state.attendanceConfig),
      },
      {
        id: 'DEVELOPER',
        label: menuLabel('DEVELOPER', 'Developer & Akun'),
        icon: <ShieldCheck className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'DEVELOPER', state.settings, state.attendanceConfig),
      },
      {
        id: 'SETTINGS',
        label: menuLabel('SETTINGS', 'Pengaturan'),
        icon: <SettingsIcon className="w-4 h-4" />,
        visible: canUserAccessMenu(currentUser, 'SETTINGS', state.settings, state.attendanceConfig),
      },
    ];
    return defs.filter((item) => item.visible);
  }, [currentUser, state.settings, state.attendanceConfig]);

  const pickDefaultRouteForUser = (user: Pick<User, 'id' | 'role'>): RouteId => {
    const preferredOrder: RouteId[] =
      user.role === 'KARYAWAN'
        ? ['ATTENDANCE', 'POS', 'INVENTORY', 'MASTER', 'DASHBOARD', 'DEVELOPER', 'SETTINGS']
        : user.role === 'KASIR'
        ? ['POS', 'ATTENDANCE', 'MASTER', 'SETTINGS', 'DEVELOPER']
        : user.role === 'GUDANG'
        ? ['INVENTORY', 'ATTENDANCE', 'MASTER', 'SETTINGS', 'DEVELOPER']
        : ['DASHBOARD', 'POS', 'ATTENDANCE', 'MASTER', 'INVENTORY', 'DEVELOPER', 'SETTINGS'];

    const match = preferredOrder.find((id) =>
      canUserAccessMenu(user, id as AppMenuId, state.settings, state.attendanceConfig)
    );
    return match || 'ATTENDANCE';
  };

  // Keep activeRoute valid when role or enabled menus change
  useEffect(() => {
    if (!currentUser || navItems.length === 0) return;
    if (!navItems.some((n) => n.id === activeRoute)) {
      setActiveRoute(navItems[0].id);
    }
  }, [currentUser, navItems, activeRoute]);

  const handleLogin = (username: string, password: string) => {
    const res = store.login(username, password);
    if (res.ok && res.role) {
      const loggedUser = state.users.find(
        (u) => u.username.toLowerCase() === username.trim().toLowerCase()
      );
      if (loggedUser) {
        setActiveRoute(pickDefaultRouteForUser(loggedUser));
      } else if (res.role === 'KARYAWAN') {
        setActiveRoute('ATTENDANCE');
      } else if (res.role === 'KASIR') {
        setActiveRoute('POS');
      } else if (res.role === 'GUDANG') {
        setActiveRoute('INVENTORY');
      } else {
        setActiveRoute('DASHBOARD');
      }
    }
    return res;
  };

  const handleDeveloperSwitchAccount = (targetUserId: string) => {
    const res = store.switchAccountAsDeveloper(targetUserId);
    if (res.ok) {
      const targetUser = state.users.find((u) => u.id === targetUserId);
      if (targetUser) {
        setActiveRoute(pickDefaultRouteForUser(targetUser));
      } else if (res.targetRole === 'KARYAWAN') {
        setActiveRoute('ATTENDANCE');
      } else if (res.targetRole === 'KASIR') {
        setActiveRoute('POS');
      } else if (res.targetRole === 'GUDANG') {
        setActiveRoute('INVENTORY');
      } else {
        setActiveRoute('DASHBOARD');
      }
    }
    return res;
  };

  const handleReturnToDeveloper = () => {
    store.returnToDeveloperAccount();
    setActiveRoute('DASHBOARD');
  };

  if (publicRoute !== null) {
    return (
      <PublicReceiptView
        data={publicReceiptData}
        loading={loadingRemoteReceipt}
        onExitPublicView={handleExitPublicView}
      />
    );
  }

  if (!currentUser) {
    return (
      <LoginView
        storeName={state.settings.storeName}
        onLogin={handleLogin}
      />
    );
  }

  const renderSidebarContent = (isMobileDrawer: boolean) => (
    <div className="flex flex-col h-full bg-[#162231] text-slate-200 select-none">
      {/* BRAND HEADER */}
      <div className="h-16 px-5 flex items-center justify-between gap-3 border-b border-slate-800/90 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          {state.settings.logoUrl ? (
            <img
              src={state.settings.logoUrl}
              alt={state.settings.storeName}
              className="w-9 h-9 rounded-xl object-cover shrink-0 ring-1 ring-white/15"
            />
          ) : (
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 to-teal-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <Store className="w-5 h-5" />
            </div>
          )}
          <div className="min-w-0">
            <p className="text-base font-extrabold tracking-tight text-white truncate">
              AysPOS
            </p>
            <p className="text-[11px] text-slate-400 truncate">
              {state.settings.storeName}
            </p>
          </div>
        </div>
        {isMobileDrawer && (
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            aria-label="Tutup menu navigasi"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* VERTICAL NAV LIST */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
        <div>
          <p className="px-3 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            Aplikasi Kasir &amp; Inventori
          </p>
          <p className="px-3 text-[11px] text-slate-500 mt-0.5">
            Navigasi Modul Utama
          </p>
        </div>

        <nav aria-label="Menu Utama" className="space-y-1.5">
          {navItems.map((item) => {
            const active = activeRoute === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveRoute(item.id);
                  if (isMobileDrawer) setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                  active
                    ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-white shadow-md shadow-cyan-950/40'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-3 min-w-0">
                  <span className={active ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                </span>
                <ChevronRight
                  className={`w-4 h-4 shrink-0 transition-transform ${
                    active ? 'text-white translate-x-0.5' : 'text-slate-500'
                  }`}
                />
              </button>
            );
          })}
        </nav>
      </div>

      {/* ACCOUNT & DEVELOPER FOOTER */}
      <div className="p-4 border-t border-slate-800/90 space-y-3 shrink-0 bg-[#121c29]">
        <div className="rounded-xl bg-slate-800/60 border border-slate-700/70 p-3 space-y-2">
          <div>
            <p className="text-xs font-bold text-white truncate">
              {currentUser.fullName}
            </p>
            <p className="text-[11px] text-slate-400">
              Peran: {ROLE_LABELS[currentUser.role]}
            </p>
            <p className="text-[11px] text-cyan-400 mt-1 font-medium">
              {openShift ? `Shift Buka (${openShift.userName})` : 'Shift Kasir Tertutup'}
            </p>
          </div>

          {isDeveloperSession && (
            <div className="pt-2 border-t border-slate-700/70 space-y-1.5">
              <label className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-cyan-300">
                <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                <span>Akses Akun (Developer)</span>
              </label>
              <select
                value={currentUser.id}
                onChange={(e) => {
                  handleDeveloperSwitchAccount(e.target.value);
                  if (isMobileDrawer) setMobileMenuOpen(false);
                }}
                aria-label="Pindah akun sebagai Developer"
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-700 bg-slate-900 text-xs font-semibold text-slate-100"
              >
                {state.users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName} ({ROLE_LABELS[u.role]})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            store.logout();
          }}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-slate-700 bg-slate-800/50 text-xs font-semibold text-slate-200 hover:bg-slate-800 hover:text-white cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Keluar Akun</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* LEFT DESKTOP VERTICAL SIDEBAR */}
      {desktopSidebarOpen && (
        <aside className="no-print hidden lg:flex lg:w-64 lg:flex-col shrink-0 border-r border-slate-800">
          {renderSidebarContent(false)}
        </aside>
      )}

      {/* MOBILE VERTICAL SLIDE-OVER DRAWER */}
      {mobileMenuOpen && (
        <div className="no-print fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-[1px]"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative w-72 max-w-[82vw] h-full shadow-2xl z-10 flex flex-col">
            {renderSidebarContent(true)}
          </aside>
        </div>
      )}

      {/* MAIN CONTENT SHELL */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* TOP HEADER */}
        <header className="no-print h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-3 sm:px-4 lg:px-6 flex items-center justify-between gap-2 sm:gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={() => {
                if (typeof window !== 'undefined' && window.innerWidth >= 1024) {
                  setDesktopSidebarOpen((v) => !v);
                } else {
                  setMobileMenuOpen(true);
                }
              }}
              aria-label="Buka menu navigasi"
              className="p-2 rounded-lg bg-[#162231] text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
            >
              <Menu className="w-4 h-4" />
            </button>

            <div className="min-w-0">
              <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                {navItems.find((n) => n.id === activeRoute)?.label || 'AysPOS'}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate lg:hidden">
                {currentUser.fullName} · {ROLE_LABELS[currentUser.role]}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <select
              value={activeOutlet.id}
              onChange={(e) => store.setActiveOutletId(e.target.value)}
              aria-label="Pilih Outlet Aktif"
              className="px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold text-slate-800 dark:text-slate-100 max-w-[145px] sm:max-w-[180px]"
            >
              {state.outlets.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() =>
                store.updateSettings({
                  themeMode: state.settings.themeMode === 'DARK' ? 'LIGHT' : 'DARK',
                })
              }
              aria-label={
                state.settings.themeMode === 'DARK'
                  ? 'Ubah ke Mode Cerah'
                  : 'Ubah ke Mode Gelap'
              }
              className="p-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              {state.settings.themeMode === 'DARK' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>
          </div>
        </header>

        {/* MODE DEVELOPER ACTIVE IMPERSONATION BANNER */}
        {developerUser && (
          <div className="no-print bg-indigo-50 dark:bg-indigo-950/60 border-b border-indigo-200 dark:border-indigo-900 px-4 lg:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 text-indigo-950 dark:text-indigo-100">
              <ArrowLeftRight className="w-4 h-4 text-indigo-700 dark:text-indigo-300 shrink-0" />
              <span>
                <strong>Mode Developer:</strong> Sedang mengakses akun{' '}
                <strong>{currentUser.fullName}</strong> (@{currentUser.username} ·{' '}
                {ROLE_LABELS[currentUser.role]})
              </span>
            </div>
            <button
              type="button"
              onClick={handleReturnToDeveloper}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-semibold cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Kembali ke {developerUser.username} (Developer)</span>
            </button>
          </div>
        )}

        {/* VIEW CONTENT */}
        <main className="flex-1 p-4 lg:p-6 max-w-[1440px] w-full mx-auto space-y-4">
          {currentUser.role === 'PEMILIK' &&
            activeRoute !== 'ATTENDANCE' &&
            !isMenuGloballyEnabled(
              activeRoute as AppMenuId,
              state.settings,
              state.attendanceConfig
            ) && (
              <div className="rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-amber-900 dark:text-amber-200 font-medium">
                  Menu ini sedang <strong>Dinonaktifkan</strong> oleh Pemilik — peran lain tidak
                  dapat melihat atau mengaksesnya.
                </span>
                <button
                  type="button"
                  onClick={() => store.setMenuEnabled(activeRoute as AppMenuId, true)}
                  className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white font-semibold cursor-pointer"
                >
                  Aktifkan Menu Ini
                </button>
              </div>
            )}

          {navItems.length === 0 && (
            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3 max-w-lg mx-auto my-8">
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                Tidak Ada Menu Aktif untuk Akun Ini
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                Semua menu sedang dinonaktifkan oleh Pemilik toko. Hubungi Pemilik untuk
                mengaktifkan akses menu yang Anda butuhkan.
              </p>
            </div>
          )}

          {activeRoute === 'DASHBOARD' &&
            canUserAccessMenu(currentUser, 'DASHBOARD', state.settings, state.attendanceConfig) && (
              <DashboardView
                transactions={state.transactions}
                products={state.products}
                purchaseOrders={state.purchaseOrders}
                stockMovements={state.stockMovements}
                pettyCash={state.pettyCash}
                outlets={state.outlets}
                onOpenReceipt={(tx) => setReceiptTx(tx)}
              />
            )}

          {activeRoute === 'POS' &&
            canUserAccessMenu(currentUser, 'POS', state.settings, state.attendanceConfig) && (
              <PosView
                currentUser={currentUser}
                products={state.products}
                customers={state.customers}
                loyaltyRewards={state.loyaltyRewards}
                transactions={state.transactions}
                openShift={openShift}
                pettyCash={state.pettyCash}
                settings={state.settings}
                cart={store.cart}
                selectedCustomer={store.selectedCustomer}
                selectedReward={store.selectedReward}
                orderDiscount={store.orderDiscount}
                applyTax={store.applyTax}
                onAddProduct={store.addToCart}
                onScanBarcode={store.scanBarcodeOrSku}
                onUpdateQty={store.updateCartQty}
                onUpdateItemDiscount={store.updateCartItemDiscount}
                onChangeItemUnit={store.changeCartItemUnit}
                onClearCart={store.clearCart}
                onSelectCustomer={store.setSelectedCustomerId}
                onSelectReward={store.setSelectedRewardId}
                onSetOrderDiscount={store.setOrderDiscount}
                onSetApplyTax={store.setApplyTax}
                onOpenShift={store.openNewShift}
                onAddPettyCash={store.addPettyCash}
                onCloseShift={store.closeActiveShift}
                onCheckout={store.completeSale}
                onOpenReceipt={(tx) => setReceiptTx(tx)}
                onAuthorizeVoidOrReturn={store.authorizeVoidOrReturn}
                onPayDebt={store.payDebtTransaction}
                onNotify={(msg) => store.setToast(msg)}
              />
            )}

          {activeRoute === 'ATTENDANCE' &&
            canUserAccessMenu(
              currentUser,
              'ATTENDANCE',
              state.settings,
              state.attendanceConfig
            ) && (
              <AttendanceView
                currentUser={currentUser}
                users={state.users}
                outlets={state.outlets}
                activeOutlet={activeOutlet}
                attendanceConfig={state.attendanceConfig}
                attendanceRecords={state.attendanceRecords}
                onClockIn={store.clockInAttendance}
                onClockOut={store.clockOutAttendance}
                onSubmitLeave={store.submitLeaveAttendance}
                onUpdateConfig={store.updateAttendanceConfig}
                onSetRoleConfig={store.setRoleAttendanceConfig}
                onResetRoleConfig={store.resetRoleAttendanceConfig}
                onToggleModuleEnabled={store.setAttendanceModuleEnabled}
                onSetAdminAccess={store.setAdminAttendanceAccess}
                onVerifyRecord={store.verifyAttendanceRecord}
                onDeleteRecord={store.deleteAttendanceRecord}
                onNotify={(msg) => store.setToast(msg)}
              />
            )}

          {activeRoute === 'MASTER' &&
            canUserAccessMenu(currentUser, 'MASTER', state.settings, state.attendanceConfig) && (
              <MasterDataView
                currentUser={currentUser}
                isDeveloper={canUserAccessMenu(
                  currentUser,
                  'DEVELOPER',
                  state.settings,
                  state.attendanceConfig
                )}
                products={state.products}
                customers={state.customers}
                suppliers={state.suppliers}
                users={state.users}
                outlets={state.outlets}
                transactions={state.transactions}
                purchaseOrders={state.purchaseOrders}
                loyaltyRewards={state.loyaltyRewards}
                pointHistory={state.pointHistory}
                onSaveProduct={store.saveProduct}
                onDeleteProduct={store.deleteProduct}
                onSaveCustomer={store.saveCustomer}
                onPayReceivable={store.payCustomerReceivable}
                onDeleteCustomer={store.deleteCustomer}
                onRedeemReward={store.redeemRewardForCustomer}
                onSaveReward={store.saveLoyaltyReward}
                onDeleteReward={store.deleteLoyaltyReward}
                onSaveSupplier={store.saveSupplier}
                onDeleteSupplier={store.deleteSupplier}
                onSaveUser={store.saveUser}
                onDeleteUser={store.deleteUser}
                onSwitchAccount={handleDeveloperSwitchAccount}
                onNotify={(msg) => store.setToast(msg)}
              />
            )}

          {activeRoute === 'INVENTORY' &&
            canUserAccessMenu(currentUser, 'INVENTORY', state.settings, state.attendanceConfig) && (
              <InventoryView
                products={state.products}
                suppliers={state.suppliers}
                outlets={state.outlets}
                activeOutlet={activeOutlet}
                purchaseOrders={state.purchaseOrders}
                stockMovements={state.stockMovements}
                stockTransfers={state.stockTransfers}
                onCreatePurchaseOrder={store.createPurchaseOrder}
                onPerformStockOpname={store.performStockOpname}
                onCreateTransfer={store.createStockTransfer}
                onReceiveTransfer={store.receiveStockTransfer}
              />
            )}

          {activeRoute === 'DEVELOPER' &&
            canUserAccessMenu(
              currentUser,
              'DEVELOPER',
              state.settings,
              state.attendanceConfig
            ) && (
              <DeveloperConsoleView
                currentUser={currentUser}
                canSystemReset={isDeveloperSession}
                dbState={state}
                users={state.users}
                outlets={state.outlets}
                transactions={state.transactions}
                onSaveUser={store.saveUser}
                onDeleteUser={store.deleteUser}
                onSwitchAccount={handleDeveloperSwitchAccount}
                onResetDemoData={store.resetDemoData}
                onResetToZero={store.resetAppToZero}
                onNotify={(msg) => store.setToast(msg)}
              />
            )}

          {activeRoute === 'SETTINGS' &&
            canUserAccessMenu(currentUser, 'SETTINGS', state.settings, state.attendanceConfig) && (
              <SettingsView
                currentUser={currentUser}
                isDeveloper={isDeveloperSession}
                allUsers={state.users}
                allDatabaseState={state}
                settings={state.settings}
                attendanceConfig={state.attendanceConfig}
                outlets={state.outlets}
                onUpdateSettings={store.updateSettings}
                onToggleAttendanceEnabled={store.setAttendanceModuleEnabled}
                onSetMenuEnabled={store.setMenuEnabled}
                onSetAllMenusEnabled={store.setAllMenusEnabled}
                onSetRoleMenuAccess={store.setRoleMenuAccess}
                onResetRoleMenuAccess={store.resetRoleMenuAccess}
                onSetUserMenuAccess={store.setUserMenuAccess}
                onSetKaryawanMenuAccess={store.setKaryawanMenuAccess}
                onSaveOutlet={store.saveOutlet}
                onDeleteOutlet={store.deleteOutlet}
                onChangePassword={store.changePassword}
                onSwitchAccount={handleDeveloperSwitchAccount}
                onOpenDeveloperConsole={() => setActiveRoute('DEVELOPER')}
                onResetDemoData={store.resetDemoData}
                onResetToZero={store.resetAppToZero}
                onLogout={store.logout}
                onNotify={(msg) => store.setToast(msg)}
              />
            )}
        </main>
      </div>

      {/* TOAST BANNER */}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="no-print fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-sm font-semibold shadow-lg"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" />
          <span>{toast}</span>
        </div>
      )}

      {/* THERMAL RECEIPT / WHATSAPP / PDF MODAL */}
      {receiptTx && (
        <ReceiptModal
          tx={receiptTx}
          settings={state.settings}
          onChangePaperWidth={(paperWidth) => store.updateSettings({ paperWidth })}
          onUpdateSettings={(patch) => store.updateSettings(patch)}
          onNotify={(msg) => store.setToast(msg)}
          onClose={() => setReceiptTx(null)}
        />
      )}
    </div>
  );
}

export default App;
