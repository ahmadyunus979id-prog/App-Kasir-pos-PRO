package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ThemeMode
import com.example.ui.components.ReceiptPreviewDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MasterDataScreen
import com.example.ui.screens.PosScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NusaPosTheme
import com.example.ui.viewmodel.PosViewModel

private enum class AppDestination(val label: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Outlined.Dashboard),
    POS("Kasir", Icons.Outlined.PointOfSale),
    MASTER("Master", Icons.Outlined.FolderCopy),
    INVENTORY("Stok", Icons.Outlined.Inventory2),
    SETTINGS("Pengaturan", Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: PosViewModel = viewModel()
            NusaPosApp(vm = vm)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NusaPosApp(vm: PosViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val currentUser by vm.currentUser.collectAsState()
    val outlets by vm.outlets.collectAsState()
    val activeOutletId by vm.activeOutletId.collectAsState()
    val loginError by vm.loginError.collectAsState()
    val snackbarMessage by vm.snackbarMessage.collectAsState()

    val products by vm.products.collectAsState()
    val bomItems by vm.bomItems.collectAsState()
    val customers by vm.customers.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    val users by vm.users.collectAsState()
    val openShift by vm.openShift.collectAsState()
    val pettyCashList by vm.pettyCashList.collectAsState()
    val transactions by vm.transactions.collectAsState()
    val transactionItems by vm.transactionItems.collectAsState()
    val purchaseOrders by vm.purchaseOrders.collectAsState()
    val stockMovements by vm.stockMovements.collectAsState()
    val stockTransfers by vm.stockTransfers.collectAsState()
    val loyaltyRewards by vm.loyaltyRewards.collectAsState()
    val pointHistory by vm.pointHistory.collectAsState()

    val cartItems by vm.cartItems.collectAsState()
    val selectedCustomer by vm.selectedCustomer.collectAsState()
    val selectedReward by vm.selectedReward.collectAsState()
    val orderDiscount by vm.orderDiscount.collectAsState()
    val applyTax by vm.applyTax.collectAsState()
    val receiptTx by vm.receiptTx.collectAsState()
    val pairedDevices by vm.pairedDevices.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(snackbarMessage) {
        if (!snackbarMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(snackbarMessage!!)
            vm.clearSnackbar()
        }
    }

    NusaPosTheme(themeMode = settings.themeMode) {
        val user = currentUser
        if (user == null) {
            Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
                Box(modifier = Modifier.padding(padding)) {
                    LoginScreen(
                        storeName = settings.storeName,
                        loginError = loginError,
                        onClearError = vm::clearLoginError,
                        onLogin = vm::login
                    )
                }
            }
        } else {
            val allowedDestinations = remember(user.role) {
                buildList {
                    if (user.role.canAccessDashboard) add(AppDestination.DASHBOARD)
                    if (user.role.canAccessPos) add(AppDestination.POS)
                    if (user.role.canAccessMasterData || user.role.canAccessPos) add(AppDestination.MASTER)
                    if (user.role.canAccessInventory) add(AppDestination.INVENTORY)
                    add(AppDestination.SETTINGS)
                }
            }
            var currentDestination by remember(user.id) {
                mutableStateOf(
                    if (user.role.canAccessDashboard) AppDestination.DASHBOARD
                    else if (user.role.canAccessPos) AppDestination.POS
                    else AppDestination.INVENTORY
                )
            }
            if (currentDestination !in allowedDestinations) {
                currentDestination = allowedDestinations.first()
            }

            var showOutletMenu by remember { mutableStateOf(false) }
            val activeOutlet = outlets.firstOrNull { it.id == activeOutletId } ?: outlets.firstOrNull()

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useRail = maxWidth >= 720.dp

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            title = {
                                Column {
                                    Text(
                                        text = currentDestination.label,
                                        style = MaterialTheme.typography.titleLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${user.fullName} (${user.role.label})",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            },
                            actions = {
                                Box {
                                    TextButton(onClick = { showOutletMenu = true }) {
                                        Icon(Icons.Outlined.Storefront, contentDescription = null)
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            activeOutlet?.name ?: "Outlet",
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showOutletMenu,
                                        onDismissRequest = { showOutletMenu = false }
                                    ) {
                                        outlets.forEach { o ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        o.name,
                                                        fontWeight = if (o.id == activeOutletId) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                },
                                                onClick = {
                                                    vm.setActiveOutlet(o.id)
                                                    showOutletMenu = false
                                                }
                                            )
                                        }
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        val next = if (settings.themeMode == ThemeMode.DARK) ThemeMode.LIGHT else ThemeMode.DARK
                                        vm.toggleThemeMode(next)
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (settings.themeMode == ThemeMode.DARK)
                                            Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                        contentDescription = "Ubah Tema"
                                    )
                                }
                            }
                        )
                    },
                    bottomBar = {
                        if (!useRail) {
                            NavigationBar {
                                allowedDestinations.forEach { dest ->
                                    NavigationBarItem(
                                        selected = currentDestination == dest,
                                        onClick = { currentDestination = dest },
                                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                                        label = { Text(dest.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (useRail) {
                            NavigationRail(modifier = Modifier.fillMaxHeight()) {
                                allowedDestinations.forEach { dest ->
                                    NavigationRailItem(
                                        selected = currentDestination == dest,
                                        onClick = { currentDestination = dest },
                                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                                        label = { Text(dest.label) }
                                    )
                                }
                            }
                        }

                        Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                            when (currentDestination) {
                                AppDestination.DASHBOARD -> DashboardScreen(
                                    transactions = transactions,
                                    transactionItems = transactionItems,
                                    products = products,
                                    purchaseOrders = purchaseOrders,
                                    stockMovements = stockMovements,
                                    pettyCashList = pettyCashList,
                                    outlets = outlets,
                                    onOpenReceipt = vm::showReceiptForTransaction
                                )
                                AppDestination.POS -> PosScreen(
                                    currentUser = user,
                                    products = products,
                                    customers = customers,
                                    transactions = transactions,
                                    openShift = openShift,
                                    pettyCashList = pettyCashList,
                                    settings = settings,
                                    cartItems = cartItems,
                                    selectedCustomer = selectedCustomer,
                                    loyaltyRewards = loyaltyRewards,
                                    selectedReward = selectedReward,
                                    orderDiscount = orderDiscount,
                                    applyTax = applyTax,
                                    onAddProduct = vm::addToCart,
                                    onScanBarcode = vm::scanBarcodeOrSku,
                                    onUpdateQty = vm::updateCartItemQuantity,
                                    onUpdateItemDiscount = vm::updateCartItemDiscount,
                                    onChangeItemUnit = vm::changeCartItemUnit,
                                    onClearCart = vm::clearCart,
                                    onSelectCustomer = vm::selectCustomer,
                                    onSelectReward = vm::selectLoyaltyReward,
                                    onSetOrderDiscount = vm::setOrderDiscount,
                                    onSetApplyTax = vm::setApplyTax,
                                    onCheckout = vm::checkout,
                                    onOpenShift = vm::openShift,
                                    onAddPettyCash = vm::addPettyCash,
                                    onCloseShift = vm::closeShift,
                                    onPrintShift = { closed -> vm.printShiftReportBluetooth(context, closed) },
                                    onOpenReceipt = vm::showReceiptForTransaction,
                                    onAuthorizeVoidOrReturn = vm::authorizeAndVoidOrReturn
                                )
                                AppDestination.MASTER -> MasterDataScreen(
                                    currentUser = user,
                                    products = products,
                                    bomItems = bomItems,
                                    customers = customers,
                                    suppliers = suppliers,
                                    users = users,
                                    outlets = outlets,
                                    transactions = transactions,
                                    purchaseOrders = purchaseOrders,
                                    loyaltyRewards = loyaltyRewards,
                                    pointHistory = pointHistory,
                                    onSaveProduct = vm::saveProduct,
                                    onDeleteProduct = vm::deleteProduct,
                                    onSaveCustomer = vm::saveCustomer,
                                    onPayReceivable = vm::payCustomerReceivable,
                                    onDeleteCustomer = vm::deleteCustomer,
                                    onRedeemReward = vm::redeemRewardForCustomer,
                                    onSaveReward = vm::saveLoyaltyReward,
                                    onDeleteReward = vm::deleteLoyaltyReward,
                                    onSaveSupplier = vm::saveSupplier,
                                    onDeleteSupplier = vm::deleteSupplier,
                                    onSaveUser = vm::saveUser
                                )
                                AppDestination.INVENTORY -> InventoryScreen(
                                    products = products,
                                    bomItems = bomItems,
                                    suppliers = suppliers,
                                    outlets = outlets,
                                    purchaseOrders = purchaseOrders,
                                    stockTransfers = stockTransfers,
                                    onCreatePurchaseOrder = vm::createPurchaseOrder,
                                    onPerformOpname = vm::performStockOpname,
                                    onCreateTransfer = vm::createStockTransfer,
                                    onReceiveTransfer = vm::receiveStockTransfer
                                )
                                AppDestination.SETTINGS -> SettingsScreen(
                                    currentUser = user,
                                    settings = settings,
                                    outlets = outlets,
                                    pairedDevices = pairedDevices,
                                    onUpdateSettings = vm::updateSettings,
                                    onSaveOutlet = vm::saveOutlet,
                                    onRefreshPairedPrinters = { vm.refreshPairedPrinters(context) },
                                    onTestPrint = { vm.testPrintBluetooth(context) },
                                    onChangePassword = vm::changePassword,
                                    onLogout = vm::logout
                                )
                            }
                        }
                    }
                }
            }

            receiptTx?.let { tx ->
                val items = transactionItems.filter { it.transactionId == tx.id }
                ReceiptPreviewDialog(
                    tx = tx,
                    items = items,
                    settings = settings,
                    onPaperWidthChange = vm::setPaperWidth,
                    onPrintBluetooth = { vm.printReceiptBluetooth(context, tx) },
                    onShareWhatsApp = { phone -> vm.shareReceiptWhatsApp(context, tx, phone) },
                    onDownloadPdf = { share -> vm.exportPdfInvoice(context, tx, share) },
                    onDismiss = vm::dismissReceiptModal
                )
            }
        }
    }
}
