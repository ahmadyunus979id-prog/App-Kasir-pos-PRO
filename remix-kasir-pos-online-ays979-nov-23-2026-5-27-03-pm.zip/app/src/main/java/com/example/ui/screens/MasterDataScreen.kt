package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.BomItemEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.LoyaltyRewardEntity
import com.example.data.local.OutletEntity
import com.example.data.local.PointHistoryEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.SupplierEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.data.model.LoyaltyRewardType
import com.example.data.model.PointHistoryType
import com.example.data.model.ProductUnitOption
import com.example.data.model.UserRole
import com.example.ui.components.ProductThumbnail
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TabularNumericStyle
import com.example.ui.theme.WarningAmber
import com.example.util.formatDateTime
import com.example.util.formatNumber
import com.example.util.formatRupiah

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MasterDataScreen(
    currentUser: UserEntity,
    products: List<ProductEntity>,
    bomItems: List<BomItemEntity>,
    customers: List<CustomerEntity>,
    suppliers: List<SupplierEntity>,
    users: List<UserEntity>,
    outlets: List<OutletEntity>,
    transactions: List<TransactionEntity>,
    purchaseOrders: List<PurchaseOrderEntity>,
    loyaltyRewards: List<LoyaltyRewardEntity>,
    pointHistory: List<PointHistoryEntity>,
    onSaveProduct: (ProductEntity, List<BomItemEntity>) -> Unit,
    onDeleteProduct: (ProductEntity) -> Unit,
    onSaveCustomer: (CustomerEntity) -> Unit,
    onPayReceivable: (CustomerEntity, Long) -> Unit,
    onDeleteCustomer: (CustomerEntity) -> Unit,
    onRedeemReward: (CustomerEntity, LoyaltyRewardEntity) -> Unit,
    onSaveReward: (LoyaltyRewardEntity) -> Unit,
    onDeleteReward: (LoyaltyRewardEntity) -> Unit,
    onSaveSupplier: (SupplierEntity) -> Unit,
    onDeleteSupplier: (SupplierEntity) -> Unit,
    onSaveUser: (Long?, String, String, String?, UserRole, Long, Boolean, (Boolean, String?) -> Unit) -> Unit
) {
    val tabs = remember(currentUser.role) {
        if (currentUser.role.canManageUsers) {
            listOf("Produk", "Pelanggan", "Supplier", "Pengguna")
        } else {
            listOf("Produk", "Pelanggan", "Supplier")
        }
    }
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showProductForm by remember { mutableStateOf(false) }

    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var showCustomerForm by remember { mutableStateOf(false) }
    var detailCustomerId by remember { mutableStateOf<Long?>(null) }
    var showRewardsManager by remember { mutableStateOf(false) }

    var editingSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var showSupplierForm by remember { mutableStateOf(false) }
    var detailSupplier by remember { mutableStateOf<SupplierEntity?>(null) }

    var editingUser by remember { mutableStateOf<UserEntity?>(null) }
    var showUserForm by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    when (selectedTab) {
                        0 -> {
                            editingProduct = null
                            showProductForm = true
                        }
                        1 -> {
                            editingCustomer = null
                            showCustomerForm = true
                        }
                        2 -> {
                            editingSupplier = null
                            showSupplierForm = true
                        }
                        3 -> {
                            editingUser = null
                            showUserForm = true
                        }
                    }
                }
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Tambah Data")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            PrimaryTabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = {
                            selectedTab = idx
                            searchQuery = ""
                        },
                        text = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Cari ${tabs[selectedTab].lowercase()}...") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )

            when (selectedTab) {
                0 -> {
                    val filtered = products.filter {
                        searchQuery.isBlank() ||
                            it.name.contains(searchQuery, ignoreCase = true) ||
                            it.sku.contains(searchQuery, ignoreCase = true) ||
                            it.barcode.contains(searchQuery, ignoreCase = true)
                    }
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filtered, key = { it.id }) { prod ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ProductThumbnail(
                                        photoUri = prod.photoUri,
                                        category = prod.category,
                                        productName = prod.name,
                                        size = 56.dp
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(prod.name, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "${prod.sku} · ${prod.category} · ${prod.brand}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "Beli ${formatRupiah(prod.costPrice)} · Jual ${formatRupiah(prod.sellPrice)}/${prod.baseUnit}",
                                            style = MaterialTheme.typography.labelMedium.merge(TabularNumericStyle),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            "Stok: ${formatNumber(prod.stock)} ${prod.baseUnit}" +
                                                if (prod.isBom) " · Resep BOM" else "",
                                            style = MaterialTheme.typography.labelMedium.merge(TabularNumericStyle),
                                            color = if (prod.stock <= prod.minStock) DangerRed else SuccessGreen
                                        )
                                    }
                                    Row {
                                        IconButton(onClick = {
                                            editingProduct = prod
                                            showProductForm = true
                                        }) {
                                            Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                                        }
                                        IconButton(onClick = { onDeleteProduct(prod) }) {
                                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus", tint = DangerRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    val filtered = customers.filter {
                        searchQuery.isBlank() ||
                            it.name.contains(searchQuery, ignoreCase = true) ||
                            it.whatsapp.contains(searchQuery, ignoreCase = true)
                    }
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            OutlinedButton(
                                onClick = { showRewardsManager = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Kelola Katalog Hadiah & Diskon Poin (${loyaltyRewards.size})")
                            }
                        }
                        items(filtered, key = { it.id }) { cust ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { detailCustomerId = cust.id }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(cust.name, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "WA: ${cust.whatsapp} · ${cust.address}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "Poin: ${cust.points} · Belanja: ${formatRupiah(cust.totalSpent)}",
                                            style = MaterialTheme.typography.labelMedium.merge(TabularNumericStyle),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        if (cust.receivableBalance > 0) {
                                            Text(
                                                "Piutang: ${formatRupiah(cust.receivableBalance)}",
                                                style = MaterialTheme.typography.labelMedium.merge(TabularNumericStyle),
                                                color = DangerRed
                                            )
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = {
                                            editingCustomer = cust
                                            showCustomerForm = true
                                        }) {
                                            Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                                        }
                                        IconButton(onClick = { onDeleteCustomer(cust) }) {
                                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus", tint = DangerRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    val filtered = suppliers.filter {
                        searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true)
                    }
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filtered, key = { it.id }) { sup ->
                            val poCount = purchaseOrders.count { it.supplierId == sup.id }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { detailSupplier = sup }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sup.name, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "${sup.phone} · ${sup.address}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            "$poCount riwayat pasokan PO",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Row {
                                        IconButton(onClick = {
                                            editingSupplier = sup
                                            showSupplierForm = true
                                        }) {
                                            Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                                        }
                                        IconButton(onClick = { onDeleteSupplier(sup) }) {
                                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus", tint = DangerRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    val filtered = users.filter {
                        searchQuery.isBlank() ||
                            it.fullName.contains(searchQuery, ignoreCase = true) ||
                            it.username.contains(searchQuery, ignoreCase = true)
                    }
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filtered, key = { it.id }) { u ->
                            val outletName = outlets.firstOrNull { it.id == u.outletId }?.name ?: "Pusat"
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${u.fullName} (@${u.username})", fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "Peran: ${u.role.label} · $outletName",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            if (u.isActive) "Status: Aktif" else "Status: Nonaktif",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (u.isActive) SuccessGreen else DangerRed
                                        )
                                    }
                                    IconButton(onClick = {
                                        editingUser = u
                                        showUserForm = true
                                    }) {
                                        Icon(Icons.Outlined.Edit, contentDescription = "Edit Pengguna")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showProductForm) {
        ProductFormDialog(
            existing = editingProduct,
            existingBoms = editingProduct?.let { p -> bomItems.filter { it.parentProductId == p.id } }.orEmpty(),
            allProducts = products,
            outlets = outlets,
            onSave = { prod, boms ->
                onSaveProduct(prod, boms)
                showProductForm = false
            },
            onDismiss = { showProductForm = false }
        )
    }

    if (showCustomerForm) {
        CustomerFormDialog(
            existing = editingCustomer,
            onSave = {
                onSaveCustomer(it)
                showCustomerForm = false
            },
            onDismiss = { showCustomerForm = false }
        )
    }

    val detailCustomer = detailCustomerId?.let { id -> customers.firstOrNull { it.id == id } }
    detailCustomer?.let { cust ->
        val custTxs = transactions.filter { it.customerId == cust.id }
        val custPointsHistory = pointHistory.filter { it.customerId == cust.id }
        var payAmount by remember(cust.receivableBalance) { mutableStateOf(cust.receivableBalance.toString()) }
        var profileTab by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { detailCustomerId = null },
            title = {
                Column {
                    Text(cust.name)
                    Text(
                        "Saldo Poin: ${cust.points} poin · WA: ${cust.whatsapp}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(selected = profileTab == 0, onClick = { profileTab = 0 }, label = { Text("Tukar Poin") })
                        FilterChip(selected = profileTab == 1, onClick = { profileTab = 1 }, label = { Text("Riwayat Poin (${custPointsHistory.size})") })
                        FilterChip(selected = profileTab == 2, onClick = { profileTab = 2 }, label = { Text("Belanja & Piutang") })
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        when (profileTab) {
                            0 -> {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("Total Poin Aktif", style = MaterialTheme.typography.labelMedium)
                                        Text(
                                            "${cust.points} Poin",
                                            style = MaterialTheme.typography.headlineMedium.merge(TabularNumericStyle),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Text("Pilih Hadiah / Diskon untuk Ditukar:", style = MaterialTheme.typography.labelLarge)
                                loyaltyRewards.filter { it.isActive }.forEach { reward ->
                                    val canRedeem = cust.points >= reward.pointsCost
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(reward.title, fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    "${reward.pointsCost} poin · ${reward.rewardType.label}",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Button(
                                                onClick = { onRedeemReward(cust, reward) },
                                                enabled = canRedeem
                                            ) {
                                                Text(if (canRedeem) "Tukar" else "Kurang")
                                            }
                                        }
                                    }
                                }
                            }
                            1 -> {
                                if (custPointsHistory.isEmpty()) {
                                    Text("Belum ada riwayat poin atau penukaran.", style = MaterialTheme.typography.bodyMedium)
                                } else {
                                    custPointsHistory.forEach { ph ->
                                        val isEarn = ph.pointsDelta >= 0
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(ph.type.label, fontWeight = FontWeight.SemiBold)
                                                    Text(ph.description, style = MaterialTheme.typography.bodyMedium)
                                                    Text(
                                                        "${ph.referenceId} · ${formatDateTime(ph.createdAt)}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Column(horizontalAlignment = Alignment.End) {
                                                    Text(
                                                        "${if (isEarn) "+" else ""}${ph.pointsDelta} poin",
                                                        style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                                                        color = if (isEarn) SuccessGreen else WarningAmber
                                                    )
                                                    Text(
                                                        "Sisa: ${ph.balanceAfter}",
                                                        style = MaterialTheme.typography.labelSmall.merge(TabularNumericStyle),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            2 -> {
                                Text("Alamat: ${cust.address}")
                                Text("Total Belanja: ${formatRupiah(cust.totalSpent)}", style = TabularNumericStyle)
                                Text(
                                    "Piutang Terdaftar: ${formatRupiah(cust.receivableBalance)}",
                                    style = TabularNumericStyle,
                                    color = if (cust.receivableBalance > 0) DangerRed else SuccessGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                if (cust.receivableBalance > 0) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedTextField(
                                            value = payAmount,
                                            onValueChange = { payAmount = it.filter { c -> c.isDigit() } },
                                            label = { Text("Bayar Piutang (Rp)") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Button(onClick = {
                                            val amt = payAmount.toLongOrNull() ?: 0L
                                            if (amt > 0) {
                                                onPayReceivable(cust, amt)
                                            }
                                        }) {
                                            Icon(Icons.Outlined.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Bayar")
                                        }
                                    }
                                }
                                HorizontalDivider()
                                Text("Riwayat Belanja (${custTxs.size})", style = MaterialTheme.typography.labelLarge)
                                if (custTxs.isEmpty()) {
                                    Text("Belum ada transaksi.", style = MaterialTheme.typography.bodyMedium)
                                } else {
                                    custTxs.take(10).forEach { tx ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("${tx.invoiceNumber} (${formatDateTime(tx.createdAt)})", style = MaterialTheme.typography.bodyMedium)
                                            Text(formatRupiah(tx.totalAmount), style = TabularNumericStyle)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { detailCustomerId = null }) { Text("Tutup") }
            }
        )
    }

    if (showRewardsManager) {
        LoyaltyRewardsManagerDialog(
            rewards = loyaltyRewards,
            onSaveReward = onSaveReward,
            onDeleteReward = onDeleteReward,
            onDismiss = { showRewardsManager = false }
        )
    }

    if (showSupplierForm) {
        SupplierFormDialog(
            existing = editingSupplier,
            onSave = {
                onSaveSupplier(it)
                showSupplierForm = false
            },
            onDismiss = { showSupplierForm = false }
        )
    }

    detailSupplier?.let { sup ->
        val supPos = purchaseOrders.filter { it.supplierId == sup.id }
        AlertDialog(
            onDismissRequest = { detailSupplier = null },
            title = { Text(sup.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Telepon: ${sup.phone}")
                    Text("Alamat: ${sup.address}")
                    if (sup.notes.isNotBlank()) Text("Catatan: ${sup.notes}")
                    HorizontalDivider()
                    Text("Riwayat Pasokan (${supPos.size})", style = MaterialTheme.typography.labelLarge)
                    if (supPos.isEmpty()) {
                        Text("Belum ada PO dari supplier ini.")
                    } else {
                        supPos.forEach { po ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${po.poNumber} · ${formatDateTime(po.createdAt)}", style = MaterialTheme.typography.bodyMedium)
                                Text(formatRupiah(po.totalAmount), style = TabularNumericStyle)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { detailSupplier = null }) { Text("Tutup") }
            }
        )
    }

    if (showUserForm) {
        UserFormDialog(
            existing = editingUser,
            outlets = outlets,
            onSave = { id, uname, fname, pass, role, oid, active, onErr ->
                onSaveUser(id, uname, fname, pass, role, oid, active) { ok, msg ->
                    if (ok) showUserForm = false else onErr(msg ?: "Gagal")
                }
            },
            onDismiss = { showUserForm = false }
        )
    }
}

@Composable
private fun ProductFormDialog(
    existing: ProductEntity?,
    existingBoms: List<BomItemEntity>,
    allProducts: List<ProductEntity>,
    outlets: List<OutletEntity>,
    onSave: (ProductEntity, List<BomItemEntity>) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var sku by remember { mutableStateOf(existing?.sku ?: "SKU-${(System.currentTimeMillis() % 10000)}") }
    var barcode by remember { mutableStateOf(existing?.barcode ?: "899${(System.currentTimeMillis() % 1000000000L)}") }
    var category by remember { mutableStateOf(existing?.category ?: "Minuman") }
    var brand by remember { mutableStateOf(existing?.brand ?: "Umum") }
    var costPrice by remember { mutableStateOf(existing?.costPrice?.toString() ?: "") }
    var sellPrice by remember { mutableStateOf(existing?.sellPrice?.toString() ?: "") }
    var baseUnit by remember { mutableStateOf(existing?.baseUnit ?: "pcs") }
    var stock by remember { mutableStateOf(existing?.stock?.toString() ?: "0") }
    var minStock by remember { mutableStateOf(existing?.minStock?.toString() ?: "5") }
    var photoUri by remember { mutableStateOf(existing?.photoUri) }
    var isBom by remember { mutableStateOf(existing?.isBom ?: false) }

    val extraUnits = remember {
        mutableStateListOf<ProductUnitOption>().apply {
            existing?.getUnitOptions()?.drop(1)?.let { addAll(it) }
        }
    }
    var newUnitName by remember { mutableStateOf("") }
    var newUnitMult by remember { mutableStateOf("") }
    var newUnitPrice by remember { mutableStateOf("") }

    val bomDrafts = remember {
        mutableStateListOf<BomItemEntity>().apply { addAll(existingBoms) }
    }
    var bomIngredientMenu by remember { mutableStateOf(false) }
    var selectedIngredient by remember { mutableStateOf(allProducts.firstOrNull { it.id != existing?.id }) }
    var bomQtyText by remember { mutableStateOf("0.1") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            photoUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Produk" else "Edit Produk") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ProductThumbnail(photoUri, category, name.ifBlank { "Produk" }, size = 64.dp)
                    OutlinedButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Outlined.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pilih Foto Produk")
                    }
                }

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Produk") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = barcode, onValueChange = { barcode = it }, label = { Text("Barcode") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Kategori") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Merek") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = costPrice,
                        onValueChange = { costPrice = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga Beli") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga Jual") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = baseUnit, onValueChange = { baseUnit = it }, label = { Text("Satuan Dasar (pcs/kg/L)") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = stock,
                        onValueChange = { stock = it },
                        label = { Text("Stok") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = minStock,
                    onValueChange = { minStock = it },
                    label = { Text("Minimum Stok (Alert)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider()
                Text("Multi-Satuan Tambahan (Opsional)", style = MaterialTheme.typography.labelLarge)
                extraUnits.forEachIndexed { idx, u ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${u.unitName} = ${formatNumber(u.multiplier)} $baseUnit @ ${formatRupiah(u.sellPrice)}")
                        TextButton(onClick = { extraUnits.removeAt(idx) }) { Text("Hapus", color = DangerRed) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = newUnitName, onValueChange = { newUnitName = it }, label = { Text("Satuan (dus)") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = newUnitMult, onValueChange = { newUnitMult = it }, label = { Text("Isi") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(0.7f))
                    OutlinedTextField(value = newUnitPrice, onValueChange = { newUnitPrice = it.filter { c -> c.isDigit() } }, label = { Text("Harga") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedButton(onClick = {
                    val m = newUnitMult.toDoubleOrNull() ?: 0.0
                    val p = newUnitPrice.toLongOrNull() ?: 0L
                    if (newUnitName.isNotBlank() && m > 0 && p > 0) {
                        extraUnits.add(ProductUnitOption(newUnitName.trim(), m, p))
                        newUnitName = ""
                        newUnitMult = ""
                        newUnitPrice = ""
                    }
                }) { Text("+ Tambah Satuan") }

                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isBom, onCheckedChange = { isBom = it })
                    Text("Produk Resep / BOM (F&B / Rakitan)")
                }
                if (isBom) {
                    bomDrafts.forEachIndexed { idx, bom ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${bom.ingredientName}: ${formatNumber(bom.quantityNeeded)} ${bom.unit}")
                            TextButton(onClick = { bomDrafts.removeAt(idx) }) { Text("Hapus", color = DangerRed) }
                        }
                    }
                    Box {
                        OutlinedButton(onClick = { bomIngredientMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedIngredient?.name ?: "Pilih Bahan Baku")
                        }
                        DropdownMenu(expanded = bomIngredientMenu, onDismissRequest = { bomIngredientMenu = false }) {
                            allProducts.filter { it.id != existing?.id }.forEach { ing ->
                                DropdownMenuItem(
                                    text = { Text("${ing.name} (${ing.baseUnit})") },
                                    onClick = {
                                        selectedIngredient = ing
                                        bomIngredientMenu = false
                                    }
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = bomQtyText,
                            onValueChange = { bomQtyText = it },
                            label = { Text("Takaran (${selectedIngredient?.baseUnit ?: ""})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(onClick = {
                            val ing = selectedIngredient
                            val qty = bomQtyText.toDoubleOrNull() ?: 0.0
                            if (ing != null && qty > 0) {
                                bomDrafts.add(
                                    BomItemEntity(
                                        parentProductId = existing?.id ?: 0L,
                                        ingredientProductId = ing.id,
                                        ingredientName = ing.name,
                                        quantityNeeded = qty,
                                        unit = ing.baseUnit
                                    )
                                )
                            }
                        }) { Text("+ Bahan") }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cPrice = costPrice.toLongOrNull() ?: 0L
                    val sPrice = sellPrice.toLongOrNull() ?: 0L
                    val allUnits = listOf(ProductUnitOption(baseUnit.ifBlank { "pcs" }, 1.0, sPrice)) + extraUnits
                    val prod = ProductEntity(
                        id = existing?.id ?: 0L,
                        name = name.trim(),
                        sku = sku.trim(),
                        barcode = barcode.trim(),
                        category = category.trim().ifBlank { "Umum" },
                        brand = brand.trim().ifBlank { "Umum" },
                        costPrice = cPrice,
                        sellPrice = sPrice,
                        baseUnit = baseUnit.trim().ifBlank { "pcs" },
                        unitsJson = ProductEntity.encodeUnits(allUnits),
                        stock = stock.toDoubleOrNull() ?: 0.0,
                        minStock = minStock.toDoubleOrNull() ?: 5.0,
                        photoUri = photoUri,
                        outletId = existing?.outletId ?: outlets.firstOrNull()?.id ?: 1L,
                        isBom = isBom,
                        lastSoldAt = existing?.lastSoldAt ?: System.currentTimeMillis(),
                        createdAt = existing?.createdAt ?: System.currentTimeMillis()
                    )
                    onSave(prod, bomDrafts.toList())
                },
                enabled = name.isNotBlank() && sellPrice.isNotBlank()
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
private fun CustomerFormDialog(
    existing: CustomerEntity?,
    onSave: (CustomerEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var whatsapp by remember { mutableStateOf(existing?.whatsapp ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var points by remember { mutableStateOf((existing?.points ?: 0).toString()) }
    var receivable by remember { mutableStateOf((existing?.receivableBalance ?: 0L).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Pelanggan" else "Edit Pelanggan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Pelanggan") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("No. WhatsApp (628xxx)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = points, onValueChange = { points = it.filter { c -> c.isDigit() } }, label = { Text("Poin") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = receivable, onValueChange = { receivable = it.filter { c -> c.isDigit() } }, label = { Text("Piutang (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        CustomerEntity(
                            id = existing?.id ?: 0L,
                            name = name.trim(),
                            whatsapp = whatsapp.trim(),
                            address = address.trim(),
                            points = points.toIntOrNull() ?: 0,
                            receivableBalance = receivable.toLongOrNull() ?: 0L,
                            totalSpent = existing?.totalSpent ?: 0L
                        )
                    )
                },
                enabled = name.isNotBlank()
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun SupplierFormDialog(
    existing: SupplierEntity?,
    onSave: (SupplierEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Supplier" else "Edit Supplier") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Supplier") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telepon") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        SupplierEntity(
                            id = existing?.id ?: 0L,
                            name = name.trim(),
                            phone = phone.trim(),
                            address = address.trim(),
                            notes = notes.trim()
                        )
                    )
                },
                enabled = name.isNotBlank()
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun UserFormDialog(
    existing: UserEntity?,
    outlets: List<OutletEntity>,
    onSave: (Long?, String, String, String?, UserRole, Long, Boolean, (String) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var username by remember { mutableStateOf(existing?.username ?: "") }
    var fullName by remember { mutableStateOf(existing?.fullName ?: "") }
    var password by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(existing?.role ?: UserRole.KASIR) }
    var outletId by remember { mutableStateOf(existing?.outletId ?: outlets.firstOrNull()?.id ?: 1L) }
    var isActive by remember { mutableStateOf(existing?.isActive ?: true) }
    var errMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Pengguna" else "Edit Pengguna") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Nama Lengkap") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(if (existing == null) "Password" else "Password Baru (kosongkan jika tetap)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Peran / Hak Akses", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    UserRole.entries.forEach { r ->
                        FilterChip(
                            selected = role == r,
                            onClick = { role = r },
                            label = { Text(r.label) }
                        )
                    }
                }
                Text("Cabang / Outlet", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    outlets.forEach { o ->
                        FilterChip(
                            selected = outletId == o.id,
                            onClick = { outletId = o.id },
                            label = { Text(o.name) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Akun Aktif")
                    Switch(checked = isActive, onCheckedChange = { isActive = it })
                }
                if (!errMsg.isNullOrBlank()) {
                    Text(errMsg!!, color = DangerRed, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(existing?.id, username, fullName, password.ifBlank { null }, role, outletId, isActive) {
                    errMsg = it
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun LoyaltyRewardsManagerDialog(
    rewards: List<LoyaltyRewardEntity>,
    onSaveReward: (LoyaltyRewardEntity) -> Unit,
    onDeleteReward: (LoyaltyRewardEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var pointsCost by remember { mutableStateOf("100") }
    var rewardType by remember { mutableStateOf(LoyaltyRewardType.DISCOUNT) }
    var discountAmount by remember { mutableStateOf("10000") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Katalog Hadiah & Diskon Poin") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Tambah Reward Baru", style = MaterialTheme.typography.labelLarge)
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nama Hadiah / Voucher") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = rewardType == LoyaltyRewardType.DISCOUNT,
                        onClick = { rewardType = LoyaltyRewardType.DISCOUNT },
                        label = { Text("Diskon Rp") }
                    )
                    FilterChip(
                        selected = rewardType == LoyaltyRewardType.GIFT,
                        onClick = { rewardType = LoyaltyRewardType.GIFT },
                        label = { Text("Hadiah Barang") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pointsCost,
                        onValueChange = { pointsCost = it.filter { c -> c.isDigit() } },
                        label = { Text("Poin Dibutuhkan") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    if (rewardType == LoyaltyRewardType.DISCOUNT) {
                        OutlinedTextField(
                            value = discountAmount,
                            onValueChange = { discountAmount = it.filter { c -> c.isDigit() } },
                            label = { Text("Nominal Diskon (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Button(
                    onClick = {
                        val pts = pointsCost.toIntOrNull() ?: 0
                        val disc = if (rewardType == LoyaltyRewardType.DISCOUNT) (discountAmount.toLongOrNull() ?: 0L) else 0L
                        if (title.isNotBlank() && pts > 0) {
                            onSaveReward(
                                LoyaltyRewardEntity(
                                    title = title.trim(),
                                    description = if (rewardType == LoyaltyRewardType.DISCOUNT)
                                        "Diskon belanja ${formatRupiah(disc)}" else "Penukaran hadiah produk",
                                    pointsCost = pts,
                                    rewardType = rewardType,
                                    discountAmount = disc,
                                    isActive = true
                                )
                            )
                            title = ""
                        }
                    },
                    enabled = title.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("+ Simpan Reward")
                }

                HorizontalDivider()
                Text("Daftar Reward Aktif (${rewards.size})", style = MaterialTheme.typography.labelLarge)
                rewards.forEach { r ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(r.title, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${r.pointsCost} poin · ${r.rewardType.label}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onDeleteReward(r) }) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus", tint = DangerRed)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Selesai") }
        }
    )
}

