package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BakeryDining
import androidx.compose.material.icons.outlined.Coffee
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LocalGroceryStore
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionItemEntity
import com.example.data.model.PaperWidth
import com.example.ui.theme.TabularNumericStyle
import com.example.util.ThermalPrinterHelper

@Composable
fun ProductThumbnail(
    photoUri: String?,
    category: String,
    productName: String,
    size: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    val bgColor = when (category.lowercase()) {
        "minuman" -> Color(0xFF0F766E).copy(alpha = 0.14f)
        "bakery" -> Color(0xFFB45309).copy(alpha = 0.14f)
        "sembako" -> Color(0xFF2563EB).copy(alpha = 0.14f)
        "bahan baku" -> Color(0xFF475569).copy(alpha = 0.14f)
        else -> Color(0xFF7C3AED).copy(alpha = 0.14f)
    }
    val tintColor = when (category.lowercase()) {
        "minuman" -> Color(0xFF0F766E)
        "bakery" -> Color(0xFFB45309)
        "sembako" -> Color(0xFF2563EB)
        "bahan baku" -> Color(0xFF475569)
        else -> Color(0xFF7C3AED)
    }
    val icon = when (category.lowercase()) {
        "minuman" -> Icons.Outlined.Coffee
        "bakery" -> Icons.Outlined.BakeryDining
        "sembako" -> Icons.Outlined.LocalGroceryStore
        "bahan baku" -> Icons.Outlined.Inventory2
        else -> Icons.Outlined.ShoppingBag
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        if (!photoUri.isNullOrBlank()) {
            AsyncImage(
                model = Uri.parse(photoUri),
                contentDescription = productName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(10.dp))
            )
        } else {
            Icon(
                imageVector = icon,
                contentDescription = productName,
                tint = tintColor,
                modifier = Modifier.size(size * 0.48f)
            )
        }
    }
}

@Composable
fun KpiMetricCard(
    label: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.merge(TabularNumericStyle),
                color = valueColor,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ReceiptPreviewDialog(
    tx: TransactionEntity,
    items: List<TransactionItemEntity>,
    settings: StoreSettingsEntity,
    onPaperWidthChange: (PaperWidth) -> Unit,
    onPrintBluetooth: () -> Unit,
    onShareWhatsApp: (String) -> Unit,
    onDownloadPdf: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var waNumber by remember(tx.id) { mutableStateOf(tx.customerWhatsapp) }
    val receiptLines = remember(tx, items, settings) {
        ThermalPrinterHelper.buildReceiptPreviewLines(tx, items, settings)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Struk & Invoice", style = MaterialTheme.typography.titleLarge)
                        Text(
                            tx.invoiceNumber,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = onDismiss) {
                        Text("Tutup")
                    }
                }

                // Paper Width Selector
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Kertas:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    PaperWidth.entries.forEach { width ->
                        FilterChip(
                            selected = settings.paperWidth == width,
                            onClick = { onPaperWidthChange(width) },
                            label = { Text(width.label) }
                        )
                    }
                }

                // Thermal Paper Preview
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFFDF7),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text(
                            text = receiptLines.joinToString("\n"),
                            fontFamily = FontFamily.Monospace,
                            fontSize = if (settings.paperWidth == PaperWidth.MM_58) 11.sp else 10.sp,
                            lineHeight = 14.sp,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                HorizontalDivider()

                // Bluetooth Thermal Print
                Button(
                    onClick = onPrintBluetooth,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Cetak Struk Thermal (${settings.paperWidth.mm}mm)")
                }

                // PDF Download & Share
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onDownloadPdf(false) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Outlined.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("PDF Invoice", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { onDownloadPdf(true) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Outlined.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Kirim PDF", maxLines = 1)
                    }
                }

                // WhatsApp Share
                OutlinedTextField(
                    value = waNumber,
                    onValueChange = { waNumber = it },
                    label = { Text("No. WhatsApp Pelanggan (opsional)") },
                    placeholder = { Text("62812xxxx") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { onShareWhatsApp(waNumber) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Kirim Struk via WhatsApp")
                }
            }
        }
    }
}
