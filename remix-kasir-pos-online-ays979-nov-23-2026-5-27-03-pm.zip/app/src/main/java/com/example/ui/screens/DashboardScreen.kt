package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.OutletEntity
import com.example.data.local.PettyCashEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.StockMovementEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionItemEntity
import com.example.data.model.TransactionStatus
import com.example.ui.components.KpiMetricCard
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TabularNumericStyle
import com.example.ui.theme.WarningAmber
import com.example.util.formatDateTime
import com.example.util.formatNumber
import com.example.util.formatRupiah
import java.util.Calendar

private enum class DashboardPeriod(val label: String) {
    TODAY("Hari Ini"),
    MONTH("Bulan Ini"),
    ALL("Semua")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    transactions: List<TransactionEntity>,
    transactionItems: List<TransactionItemEntity>,
    products: List<ProductEntity>,
    purchaseOrders: List<PurchaseOrderEntity>,
    stockMovements: List<StockMovementEntity>,
    pettyCashList: List<PettyCashEntity>,
    outlets: List<OutletEntity>,
    onOpenReceipt: (TransactionEntity) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var period by remember { mutableStateOf(DashboardPeriod.MONTH) }
    var selectedOutletId by remember { mutableStateOf<Long?>(null) }

    val startOfDay = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val startOfMonth = remember {
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val completedAll = remember(transactions, selectedOutletId) {
        transactions.filter { tx ->
            tx.status == TransactionStatus.COMPLETED &&
                (selectedOutletId == null || tx.outletId == selectedOutletId)
        }
    }

    val filteredTx = remember(transactions, period, selectedOutletId) {
        transactions.filter { tx ->
            val outletOk = selectedOutletId == null || tx.outletId == selectedOutletId
            val timeOk = when (period) {
                DashboardPeriod.TODAY -> tx.createdAt >= startOfDay
                DashboardPeriod.MONTH -> tx.createdAt >= startOfMonth
                DashboardPeriod.ALL -> true
            }
            outletOk && timeOk
        }
    }

    val dailyRevenue = remember(completedAll) {
        completedAll.filter { it.createdAt >= startOfDay }.sumOf { it.totalAmount }
    }
    val monthlyRevenue = remember(completedAll) {
        completedAll.filter { it.createdAt >= startOfMonth }.sumOf { it.totalAmount }
    }
    val inventoryValuation = remember(products) {
        products.sumOf { Math.round(it.stock * it.costPrice) }
    }
    val lowStockProducts = remember(products) {
        products.filter { it.stock <= it.minStock }
    }

    val tabs = listOf("Ringkasan", "Laporan Penjualan", "Pembelian & Stok")

    Column(modifier = Modifier.fillMaxSize()) {
        PrimaryTabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                )
            }
        }

        // Filter Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DashboardPeriod.entries.forEach { p ->
                FilterChip(
                    selected = period == p,
                    onClick = { period = p },
                    label = { Text(p.label) }
                )
            }
            Spacer(Modifier.width(4.dp))
            FilterChip(
                selected = selectedOutletId == null,
                onClick = { selectedOutletId = null },
                label = { Text("Semua Outlet") }
            )
            outlets.forEach { outlet ->
                FilterChip(
                    selected = selectedOutletId == outlet.id,
                    onClick = { selectedOutletId = outlet.id },
                    label = { Text(outlet.name) }
                )
            }
        }

        when (selectedTab) {
            0 -> DashboardOverviewTab(
                dailyRevenue = dailyRevenue,
                monthlyRevenue = monthlyRevenue,
                txCount = filteredTx.count { it.status == TransactionStatus.COMPLETED },
                inventoryValuation = inventoryValuation,
                filteredTx = filteredTx,
                transactionItems = transactionItems,
                lowStockProducts = lowStockProducts,
                onOpenReceipt = onOpenReceipt
            )
            1 -> SalesReportTab(
                filteredTx = filteredTx,
                pettyCashList = pettyCashList,
                onOpenReceipt = onOpenReceipt
            )
            2 -> PurchaseAndStockReportTab(
                purchaseOrders = purchaseOrders,
                stockMovements = stockMovements,
                products = products
            )
        }
    }
}

@Composable
private fun DashboardOverviewTab(
    dailyRevenue: Long,
    monthlyRevenue: Long,
    txCount: Int,
    inventoryValuation: Long,
    filteredTx: List<TransactionEntity>,
    transactionItems: List<TransactionItemEntity>,
    lowStockProducts: List<ProductEntity>,
    onOpenReceipt: (TransactionEntity) -> Unit
) {
    val completedIds = remember(filteredTx) {
        filteredTx.filter { it.status == TransactionStatus.COMPLETED }.map { it.id }.toSet()
    }
    val topProducts = remember(transactionItems, completedIds) {
        transactionItems
            .filter { it.transactionId in completedIds }
            .groupBy { it.productName }
            .map { (name, items) ->
                Triple(name, items.sumOf { it.quantity }, items.sumOf { it.subtotal })
            }
            .sortedByDescending { it.third }
            .take(5)
    }
    val maxTopRevenue = topProducts.maxOfOrNull { it.third }?.coerceAtLeast(1L) ?: 1L

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiMetricCard(
                    label = "Omzet Hari Ini",
                    value = formatRupiah(dailyRevenue),
                    subtitle = "Transaksi selesai hari ini",
                    valueColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    label = "Omzet Bulan Ini",
                    value = formatRupiah(monthlyRevenue),
                    subtitle = "Akumulasi bulan berjalan",
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiMetricCard(
                    label = "Jumlah Transaksi",
                    value = "$txCount Nota",
                    subtitle = "Sesuai filter periode",
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    label = "Nilai Persediaan",
                    value = formatRupiah(inventoryValuation),
                    subtitle = "Total stok x harga beli",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Top Selling Products
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Produk Terlaris", style = MaterialTheme.typography.titleMedium)
                    if (topProducts.isEmpty()) {
                        Text(
                            "Belum ada penjualan pada periode ini.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        topProducts.forEach { (name, qty, rev) ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "$qty terjual · ${formatRupiah(rev)}",
                                        style = MaterialTheme.typography.bodyMedium.merge(TabularNumericStyle),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { (rev.toFloat() / maxTopRevenue.toFloat()).coerceIn(0.05f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp),
                                )
                            }
                        }
                    }
                }
            }
        }

        // Low Stock Alerts
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Outlined.WarningAmber,
                            contentDescription = null,
                            tint = if (lowStockProducts.isEmpty()) SuccessGreen else WarningAmber
                        )
                        Text(
                            "Peringatan Stok Menipis (${lowStockProducts.size})",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    if (lowStockProducts.isEmpty()) {
                        Text(
                            "Semua stok produk dalam kondisi aman.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        lowStockProducts.forEach { prod ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, fontWeight = FontWeight.Medium)
                                    Text(
                                        "${prod.sku} · Min: ${formatNumber(prod.minStock)} ${prod.baseUnit}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "Sisa ${formatNumber(prod.stock)} ${prod.baseUnit}",
                                    style = MaterialTheme.typography.labelLarge.merge(TabularNumericStyle),
                                    color = DangerRed
                                )
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }

        // Recent Invoices
        item {
            Text("Transaksi Terbaru", style = MaterialTheme.typography.titleMedium)
        }
        items(filteredTx.take(5), key = { it.id }) { tx ->
            TransactionSummaryRow(tx = tx, onClick = { onOpenReceipt(tx) })
        }
    }
}

@Composable
private fun SalesReportTab(
    filteredTx: List<TransactionEntity>,
    pettyCashList: List<PettyCashEntity>,
    onOpenReceipt: (TransactionEntity) -> Unit
) {
    val completed = remember(filteredTx) {
        filteredTx.filter { it.status == TransactionStatus.COMPLETED }
    }
    val grossSales = completed.sumOf { it.subtotal }
    val totalDiscount = completed.sumOf { it.discountAmount }
    val totalTax = completed.sumOf { it.taxAmount }
    val netSales = completed.sumOf { it.totalAmount }
    val totalCogs = completed.sumOf { it.totalCost }
    val totalPettyOut = pettyCashList.sumOf { it.amount }
    val netProfit = (netSales - totalTax) - totalCogs - totalPettyOut

    val byCashier = remember(completed) {
        completed.groupBy { it.cashierName }.mapValues { (_, list) ->
            Pair(list.size, list.sumOf { it.totalAmount })
        }
    }
    val byOutlet = remember(completed) {
        completed.groupBy { it.outletName }.mapValues { (_, list) ->
            Pair(list.size, list.sumOf { it.totalAmount })
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Laba Rugi Summary
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Laporan Laba Rugi", style = MaterialTheme.typography.titleMedium)
                    HorizontalDivider()
                    ReportKeyValueRow("Penjualan Kotor (Subtotal)", formatRupiah(grossSales))
                    ReportKeyValueRow("Total Diskon", "-${formatRupiah(totalDiscount)}")
                    ReportKeyValueRow("Total PPN Terkumpul", formatRupiah(totalTax))
                    ReportKeyValueRow("Total Penjualan (Omzet)", formatRupiah(netSales), bold = true)
                    ReportKeyValueRow("Harga Pokok Penjualan (HPP)", "-${formatRupiah(totalCogs)}")
                    ReportKeyValueRow("Pengeluaran Kas Kecil", "-${formatRupiah(totalPettyOut)}")
                    HorizontalDivider()
                    ReportKeyValueRow(
                        "Estimasi Laba Bersih",
                        formatRupiah(netProfit),
                        bold = true,
                        valueColor = if (netProfit >= 0) SuccessGreen else DangerRed
                    )
                }
            }
        }

        // Performa per Kasir & Outlet
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Performa per Kasir", style = MaterialTheme.typography.titleMedium)
                    if (byCashier.isEmpty()) {
                        Text("Belum ada data", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        byCashier.forEach { (name, pair) ->
                            ReportKeyValueRow("$name (${pair.first} nota)", formatRupiah(pair.second))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Performa per Outlet", style = MaterialTheme.typography.titleMedium)
                    if (byOutlet.isEmpty()) {
                        Text("Belum ada data", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        byOutlet.forEach { (name, pair) ->
                            ReportKeyValueRow("$name (${pair.first} nota)", formatRupiah(pair.second))
                        }
                    }
                }
            }
        }

        item {
            Text("Rekap Nota / Transaksi (${filteredTx.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(filteredTx, key = { it.id }) { tx ->
            TransactionSummaryRow(tx = tx, onClick = { onOpenReceipt(tx) })
        }
    }
}

@Composable
private fun PurchaseAndStockReportTab(
    purchaseOrders: List<PurchaseOrderEntity>,
    stockMovements: List<StockMovementEntity>,
    products: List<ProductEntity>
) {
    val categoryValuation = remember(products) {
        products.groupBy { it.category }.mapValues { (_, list) ->
            Pair(list.sumOf { it.stock }, list.sumOf { Math.round(it.stock * it.costPrice) })
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Inventory Valuation by Category
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Valuasi Inventaris per Kategori", style = MaterialTheme.typography.titleMedium)
                    HorizontalDivider()
                    categoryValuation.forEach { (cat, pair) ->
                        ReportKeyValueRow(
                            "$cat (${formatNumber(pair.first)} unit)",
                            formatRupiah(pair.second)
                        )
                    }
                }
            }
        }

        // Purchase Orders History
        item {
            Text("Riwayat Belanja ke Supplier (${purchaseOrders.size})", style = MaterialTheme.typography.titleMedium)
        }
        if (purchaseOrders.isEmpty()) {
            item {
                Text(
                    "Belum ada riwayat pembelian PO.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(purchaseOrders, key = { it.id }) { po ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${po.poNumber} · ${po.supplierName}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${po.outletName} · ${formatDateTime(po.createdAt)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            formatRupiah(po.totalAmount),
                            style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // Stock Card (Kartu Stok)
        item {
            Text("Kartu Stok (Masuk & Keluar)", style = MaterialTheme.typography.titleMedium)
        }
        items(stockMovements.take(40), key = { it.id }) { move ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(move.productName, fontWeight = FontWeight.Medium)
                        Text(
                            "${move.type.label} · ${move.referenceId} · ${formatDateTime(move.createdAt)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (move.note.isNotBlank()) {
                            Text(
                                move.note,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        val prefix = if (move.quantityDelta >= 0) "+" else ""
                        Text(
                            "$prefix${formatNumber(move.quantityDelta)}",
                            style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                            color = if (move.quantityDelta >= 0) SuccessGreen else DangerRed
                        )
                        Text(
                            "Saldo: ${formatNumber(move.balanceAfter)}",
                            style = MaterialTheme.typography.labelMedium.merge(TabularNumericStyle),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportKeyValueRow(
    label: String,
    value: String,
    bold: Boolean = false,
    valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium.merge(TabularNumericStyle),
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
            color = valueColor
        )
    }
}

@Composable
fun TransactionSummaryRow(
    tx: TransactionEntity,
    onClick: () -> Unit
) {
    val statusColor = when (tx.status) {
        TransactionStatus.COMPLETED -> SuccessGreen
        TransactionStatus.VOID -> DangerRed
        TransactionStatus.RETURNED -> WarningAmber
    }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.ReceiptLong,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column {
                    Text(tx.invoiceNumber, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${tx.customerName} · ${tx.paymentMethod.label} · ${formatDateTime(tx.createdAt)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "Kasir: ${tx.cashierName} · ${tx.status.label}",
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor
                    )
                }
            }
            Text(
                formatRupiah(tx.totalAmount),
                style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                fontWeight = FontWeight.Bold
            )
        }
    }
}
