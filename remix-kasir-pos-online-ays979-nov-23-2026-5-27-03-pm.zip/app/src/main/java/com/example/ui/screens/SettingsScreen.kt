package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.LockReset
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Store
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.OutletEntity
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.UserEntity
import com.example.data.model.PaperWidth
import com.example.data.model.ThemeMode
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.util.PairedBluetoothDevice
import com.example.util.ThermalPrinterHelper
import com.example.util.formatDateTime

@Composable
fun SettingsScreen(
    currentUser: UserEntity,
    settings: StoreSettingsEntity,
    outlets: List<OutletEntity>,
    pairedDevices: List<PairedBluetoothDevice>,
    onUpdateSettings: (StoreSettingsEntity) -> Unit,
    onSaveOutlet: (OutletEntity) -> Unit,
    onRefreshPairedPrinters: () -> Unit,
    onTestPrint: () -> Unit,
    onChangePassword: (String, String, (Boolean, String) -> Unit) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current

    var storeName by remember(settings.storeName) { mutableStateOf(settings.storeName) }
    var storeAddress by remember(settings.storeAddress) { mutableStateOf(settings.storeAddress) }
    var storePhone by remember(settings.storePhone) { mutableStateOf(settings.storePhone) }
    var taxPercent by remember(settings.taxPercent) { mutableStateOf(settings.taxPercent.toString()) }
    var pointsPerAmount by remember(settings.pointsPerAmount) { mutableStateOf(settings.pointsPerAmount.toString()) }
    var receiptFooter by remember(settings.receiptFooter) { mutableStateOf(settings.receiptFooter) }

    var showOutletDialog by remember { mutableStateOf(false) }
    var editingOutlet by remember { mutableStateOf<OutletEntity?>(null) }

    var oldPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var passFeedback by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            onUpdateSettings(settings.copy(logoUri = uri.toString()))
        }
    }

    val btPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.values.all { it }) {
            onRefreshPairedPrinters()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Account & Logout
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(currentUser.fullName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "@${currentUser.username} · Peran: ${currentUser.role.label}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(onClick = onLogout) {
                        Icon(Icons.Outlined.Logout, contentDescription = null, tint = DangerRed, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Keluar", color = DangerRed)
                    }
                }
            }
        }

        // Theme (Dark / Light)
        item {
            SettingsSectionCard(title = "Tampilan (Gelap / Cerah)", icon = Icons.Outlined.DarkMode) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onUpdateSettings(settings.copy(themeMode = mode)) },
                            label = { Text(mode.label) }
                        )
                    }
                }
            }
        }

        // Store Profile & Multi-Cabang
        item {
            SettingsSectionCard(title = "Profil Usaha & Outlet", icon = Icons.Outlined.Store) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (!settings.logoUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = Uri.parse(settings.logoUri),
                                    contentDescription = "Logo Toko",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                            } else {
                                Icon(Icons.Outlined.Store, contentDescription = null)
                            }
                        }
                    }
                    OutlinedButton(onClick = {
                        logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Outlined.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Unggah Logo Usaha")
                    }
                }

                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Nama Toko / Usaha") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = storeAddress,
                    onValueChange = { storeAddress = it },
                    label = { Text("Alamat Usaha (Tampil di Struk)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = storePhone,
                    onValueChange = { storePhone = it },
                    label = { Text("Nomor Telepon") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        onUpdateSettings(
                            settings.copy(
                                storeName = storeName.trim(),
                                storeAddress = storeAddress.trim(),
                                storePhone = storePhone.trim()
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Simpan Profil Usaha")
                }

                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Cabang / Outlet (${outlets.size})", style = MaterialTheme.typography.labelLarge)
                    TextButton(onClick = {
                        editingOutlet = null
                        showOutletDialog = true
                    }) {
                        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Tambah Cabang")
                    }
                }
                outlets.forEach { o ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                editingOutlet = o
                                showOutletDialog = true
                            }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                o.name + if (o.isMain) " (Utama)" else "",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text("${o.address} · ${o.phone}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // Tax PPN & Loyalty Points Rule
        item {
            SettingsSectionCard(title = "Pajak PPN (%) & Aturan Poin Loyalitas", icon = Icons.Outlined.Store) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Aktifkan Pajak PPN di POS")
                    Switch(
                        checked = settings.taxEnabled,
                        onCheckedChange = { onUpdateSettings(settings.copy(taxEnabled = it)) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Harga Jual Sudah Termasuk PPN")
                    Switch(
                        checked = settings.taxInclusive,
                        onCheckedChange = { onUpdateSettings(settings.copy(taxInclusive = it)) }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = taxPercent,
                        onValueChange = { taxPercent = it },
                        label = { Text("Tarif PPN (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = pointsPerAmount,
                        onValueChange = { pointsPerAmount = it.filter { c -> c.isDigit() } },
                        label = { Text("1 Poin / Rp Belanja") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1.2f)
                    )
                }
                Button(
                    onClick = {
                        onUpdateSettings(
                            settings.copy(
                                taxPercent = taxPercent.toDoubleOrNull() ?: 11.0,
                                pointsPerAmount = (pointsPerAmount.toLongOrNull() ?: 10_000L).coerceAtLeast(1000L)
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Simpan Pajak & Aturan Poin")
                }
            }
        }

        // Thermal Printer Bluetooth Settings
        item {
            SettingsSectionCard(title = "Printer Thermal Bluetooth (58mm & 80mm)", icon = Icons.Outlined.Print) {
                Text("Ukuran Kertas Thermal", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaperWidth.entries.forEach { pw ->
                        FilterChip(
                            selected = settings.paperWidth == pw,
                            onClick = { onUpdateSettings(settings.copy(paperWidth = pw)) },
                            label = { Text(pw.label) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Cetak Logo & Header Toko di Struk")
                    Switch(
                        checked = settings.printLogo,
                        onCheckedChange = { onUpdateSettings(settings.copy(printLogo = it)) }
                    )
                }
                OutlinedTextField(
                    value = receiptFooter,
                    onValueChange = { receiptFooter = it },
                    label = { Text("Catatan Kaki (Footer Struk)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onUpdateSettings(settings.copy(receiptFooter = receiptFooter.trim())) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Simpan Teks Struk")
                }

                HorizontalDivider()
                Text(
                    "Printer Terpilih: " +
                        if (settings.printerName.isBlank()) "Belum dipilih"
                        else "${settings.printerName} (${settings.printerAddress})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (ThermalPrinterHelper.hasBluetoothPermission(context)) {
                                onRefreshPairedPrinters()
                            } else {
                                val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                                } else {
                                    arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN)
                                }
                                btPermissionLauncher.launch(perms)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Outlined.Bluetooth, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Cari Printer Paired")
                    }
                    Button(
                        onClick = onTestPrint,
                        enabled = settings.printerAddress.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Test Print")
                    }
                }

                pairedDevices.forEach { dev ->
                    val isSelected = dev.address == settings.printerAddress
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onUpdateSettings(
                                    settings.copy(printerName = dev.name, printerAddress = dev.address)
                                )
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(dev.name, fontWeight = FontWeight.SemiBold)
                                Text(dev.address, style = MaterialTheme.typography.labelSmall)
                            }
                            if (isSelected) {
                                Text("Aktif", color = SuccessGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Perangkat & Integrasi E-Commerce
        item {
            SettingsSectionCard(title = "Perangkat, Pembayaran & Integrasi E-Commerce", icon = Icons.Outlined.Sync) {
                SettingToggleRow("Barcode Scanner HID (USB / Bluetooth)", settings.scannerHidEnabled) {
                    onUpdateSettings(settings.copy(scannerHidEnabled = it))
                }
                SettingToggleRow("Metode Pembayaran QRIS", settings.qrisEnabled) {
                    onUpdateSettings(settings.copy(qrisEnabled = it))
                }
                SettingToggleRow("Metode Pembayaran Transfer / Kartu", settings.transferEnabled) {
                    onUpdateSettings(settings.copy(transferEnabled = it))
                }
                SettingToggleRow("Metode Pembayaran Piutang / Tempo", settings.piutangEnabled) {
                    onUpdateSettings(settings.copy(piutangEnabled = it))
                }
                HorizontalDivider()
                SettingToggleRow("Sinkronisasi Katalog & Stok Shopee", settings.ecommerceShopeeSync) {
                    onUpdateSettings(settings.copy(ecommerceShopeeSync = it))
                }
                SettingToggleRow("Sinkronisasi Katalog & Stok Tokopedia", settings.ecommerceTokopediaSync) {
                    onUpdateSettings(settings.copy(ecommerceTokopediaSync = it))
                }
                OutlinedButton(
                    onClick = { onUpdateSettings(settings.copy(lastSyncAt = System.currentTimeMillis())) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Sinkronkan Stok E-Commerce Sekarang")
                }
                settings.lastSyncAt?.let {
                    Text(
                        "Sinkronisasi terakhir: ${formatDateTime(it)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Change Password
        item {
            SettingsSectionCard(title = "Ganti Password Akun", icon = Icons.Outlined.LockReset) {
                OutlinedTextField(
                    value = oldPass,
                    onValueChange = { oldPass = it },
                    label = { Text("Password Lama") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPass,
                    onValueChange = { newPass = it },
                    label = { Text("Password Baru (min. 4 karakter)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                passFeedback?.let { (ok, msg) ->
                    Text(msg, color = if (ok) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodyMedium)
                }
                Button(
                    onClick = {
                        onChangePassword(oldPass, newPass) { ok, msg ->
                            passFeedback = Pair(ok, msg)
                            if (ok) {
                                oldPass = ""
                                newPass = ""
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Simpan Password Baru")
                }
            }
        }
    }

    if (showOutletDialog) {
        var oName by remember { mutableStateOf(editingOutlet?.name ?: "") }
        var oAddr by remember { mutableStateOf(editingOutlet?.address ?: "") }
        var oPhone by remember { mutableStateOf(editingOutlet?.phone ?: "") }
        var oMain by remember { mutableStateOf(editingOutlet?.isMain ?: false) }

        AlertDialog(
            onDismissRequest = { showOutletDialog = false },
            title = { Text(if (editingOutlet == null) "Tambah Cabang / Outlet" else "Edit Cabang") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = oName, onValueChange = { oName = it }, label = { Text("Nama Cabang") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = oAddr, onValueChange = { oAddr = it }, label = { Text("Alamat") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = oPhone, onValueChange = { oPhone = it }, label = { Text("Telepon") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    SettingToggleRow("Cabang Utama", oMain) { oMain = it }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveOutlet(
                            OutletEntity(
                                id = editingOutlet?.id ?: 0L,
                                name = oName.trim(),
                                address = oAddr.trim(),
                                phone = oPhone.trim(),
                                isMain = oMain
                            )
                        )
                        showOutletDialog = false
                    },
                    enabled = oName.isNotBlank()
                ) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { showOutletDialog = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

@Composable
private fun SettingToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
