package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.BomItemEntity
import com.example.data.local.OutletEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderDraftItem
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.StockTransferEntity
import com.example.data.local.SupplierEntity
import com.example.data.model.TransferStatus
import com.example.ui.components.KpiMetricCard
import com.example.ui.components.ProductThumbnail
import com.example.ui.theme.DangerRed
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TabularNumericStyle
import com.example.ui.theme.WarningAmber
import com.example.util.formatDateTime
import com.example.util.formatNumber
import com.example.util.formatRupiah

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    products: List<ProductEntity>,
    bomItems: List<BomItemEntity>,
    suppliers: List<SupplierEntity>,
    outlets: List<OutletEntity>,
    purchaseOrders: List<PurchaseOrderEntity>,
    stockTransfers: List<StockTransferEntity>,
    onCreatePurchaseOrder: (SupplierEntity, OutletEntity, List<PurchaseOrderDraftItem>, String) -> Unit,
    onPerformOpname: (ProductEntity, Double, String) -> Unit,
    onCreateTransfer: (OutletEntity, OutletEntity, ProductEntity, Double, String) -> Unit,
    onReceiveTransfer: (StockTransferEntity) -> Unit
) {
    val tabs = listOf("Daftar Stok", "Stok Masuk (PO)", "Stok Opname", "Transfer Outlet", "Analisis & BOM")
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        PrimaryScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 12.dp) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                )
            }
        }

        when (selectedTab) {
            0 -> StockValuationTab(products = products)
            1 -> PurchaseOrderTab(
                products = products,
                suppliers = suppliers,
                outlets = outlets,
                purchaseOrders = purchaseOrders,
                onCreatePurchaseOrder = onCreatePurchaseOrder
            )
            2 -> StockOpnameTab(products = products, onPerformOpname = onPerformOpname)
            3 -> StockTransferTab(
                outlets = outlets,
                products = products,
                transfers = stockTransfers,
                onCreateTransfer = onCreateTransfer,
                onReceiveTransfer = onReceiveTransfer
            )
            4 -> StockAnalysisBomTab(products = products, bomItems = bomItems)
        }
    }
}

@Composable
private fun StockValuationTab(products: List<ProductEntity>) {
    var selectedCategory by remember { mutableStateOf("Semua") }
    val categories = remember(products) {
        listOf("Semua") + products.map { it.category }.distinct().sorted()
    }
    val filtered = remember(products, selectedCategory) {
        if (selectedCategory == "Semua") products else products.filter { it.category == selectedCategory }
    }
    val totalVal = filtered.sumOf { Math.round(it.stock * it.costPrice) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiMetricCard(
                    label = "Total SKU Ditampilkan",
                    value = "${filtered.size} Item",
                    subtitle = "Real-time stok",
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    label = "Nilai Persediaan",
                    value = formatRupiah(totalVal),
                    subtitle = "Valuasi harga beli",
                    valueColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) }
                    )
                }
            }
        }
        items(filtered, key = { it.id }) { prod ->
            val valuation = Math.round(prod.stock * prod.costPrice)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ProductThumbnail(prod.photoUri, prod.category, prod.name, size = 46.dp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(prod.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${prod.sku} · ${prod.category}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "${formatNumber(prod.stock)} ${prod.baseUnit}",
                            style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                            color = if (prod.stock <= prod.minStock) DangerRed else SuccessGreen
                        )
                        Text(
                            formatRupiah(valuation),
                            style = MaterialTheme.typography.labelMedium.merge(TabularNumericStyle),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PurchaseOrderTab(
    products: List<ProductEntity>,
    suppliers: List<SupplierEntity>,
    outlets: List<OutletEntity>,
    purchaseOrders: List<PurchaseOrderEntity>,
    onCreatePurchaseOrder: (SupplierEntity, OutletEntity, List<PurchaseOrderDraftItem>, String) -> Unit
) {
    var selectedSupplier by remember(suppliers) { mutableStateOf(suppliers.firstOrNull()) }
    var selectedOutlet by remember(outlets) { mutableStateOf(outlets.firstOrNull()) }
    var selectedProduct by remember(products) { mutableStateOf(products.firstOrNull()) }
    var qtyText by remember { mutableStateOf("10") }
    var costText by remember(selectedProduct) { mutableStateOf((selectedProduct?.costPrice ?: 0L).toString()) }
    var notes by remember { mutableStateOf("") }
    val draftItems = remember { mutableStateListOf<PurchaseOrderDraftItem>() }

    var supMenu by remember { mutableStateOf(false) }
    var outMenu by remember { mutableStateOf(false) }
    var prodMenu by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Buat Pembelian (Purchase Order / Stok Masuk)", style = MaterialTheme.typography.titleMedium)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(onClick = { supMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(selectedSupplier?.name ?: "Pilih Supplier", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = supMenu, onDismissRequest = { supMenu = false }) {
                                suppliers.forEach { s ->
                                    DropdownMenuItem(text = { Text(s.name) }, onClick = {
                                        selectedSupplier = s
                                        supMenu = false
                                    })
                                }
                            }
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(onClick = { outMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(selectedOutlet?.name ?: "Pilih Outlet", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = outMenu, onDismissRequest = { outMenu = false }) {
                                outlets.forEach { o ->
                                    DropdownMenuItem(text = { Text(o.name) }, onClick = {
                                        selectedOutlet = o
                                        outMenu = false
                                    })
                                }
                            }
                        }
                    }

                    Box {
                        OutlinedButton(onClick = { prodMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedProduct?.let { "${it.name} (${it.baseUnit})" } ?: "Pilih Produk")
                        }
                        DropdownMenu(expanded = prodMenu, onDismissRequest = { prodMenu = false }) {
                            products.forEach { p ->
                                DropdownMenuItem(text = { Text("${p.name} · Stok ${formatNumber(p.stock)}") }, onClick = {
                                    selectedProduct = p
                                    costText = p.costPrice.toString()
                                    prodMenu = false
                                })
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = qtyText,
                            onValueChange = { qtyText = it },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = costText,
                            onValueChange = { costText = it.filter { c -> c.isDigit() } },
                            label = { Text("Harga Beli/Unit") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1.3f)
                        )
                        OutlinedButton(onClick = {
                            val prod = selectedProduct
                            val q = qtyText.toDoubleOrNull() ?: 0.0
                            val c = costText.toLongOrNull() ?: 0L
                            if (prod != null && q > 0) {
                                draftItems.add(PurchaseOrderDraftItem(prod, q, c))
                            }
                        }) {
                            Icon(Icons.Outlined.Add, contentDescription = null)
                        }
                    }

                    if (draftItems.isNotEmpty()) {
                        HorizontalDivider()
                        draftItems.forEachIndexed { idx, item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${item.product.name} (${formatNumber(item.quantity)} ${item.product.baseUnit})")
                                Text(formatRupiah(Math.round(item.quantity * item.costPrice)), style = TabularNumericStyle)
                            }
                        }
                        val totalPo = draftItems.sumOf { Math.round(it.quantity * it.costPrice) }
                        Text(
                            "Total PO: ${formatRupiah(totalPo)}",
                            style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan PO") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val s = selectedSupplier
                            val o = selectedOutlet
                            if (s != null && o != null && draftItems.isNotEmpty()) {
                                onCreatePurchaseOrder(s, o, draftItems.toList(), notes)
                                draftItems.clear()
                                notes = ""
                            }
                        },
                        enabled = selectedSupplier != null && selectedOutlet != null && draftItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simpan PO & Tambah Stok Otomatis")
                    }
                }
            }
        }

        item {
            Text("Riwayat PO (${purchaseOrders.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(purchaseOrders, key = { it.id }) { po ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${po.poNumber} · ${po.supplierName}", fontWeight = FontWeight.SemiBold)
                        Text("${po.outletName} · ${formatDateTime(po.createdAt)}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(formatRupiah(po.totalAmount), style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle))
                }
            }
        }
    }
}

@Composable
private fun StockOpnameTab(
    products: List<ProductEntity>,
    onPerformOpname: (ProductEntity, Double, String) -> Unit
) {
    var selectedProd by remember(products) { mutableStateOf(products.firstOrNull()) }
    var physicalText by remember(selectedProd) { mutableStateOf((selectedProd?.stock ?: 0.0).toString()) }
    var note by remember { mutableStateOf("") }
    var prodMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Stok Opname (Penyesuaian Fisik)", style = MaterialTheme.typography.titleMedium)

                Box {
                    OutlinedButton(onClick = { prodMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedProd?.let { "${it.name} (Sistem: ${formatNumber(it.stock)} ${it.baseUnit})" } ?: "Pilih Produk")
                    }
                    DropdownMenu(expanded = prodMenu, onDismissRequest = { prodMenu = false }) {
                        products.forEach { p ->
                            DropdownMenuItem(
                                text = { Text("${p.name} · Sistem: ${formatNumber(p.stock)} ${p.baseUnit}") },
                                onClick = {
                                    selectedProd = p
                                    physicalText = p.stock.toString()
                                    prodMenu = false
                                }
                            )
                        }
                    }
                }

                selectedProd?.let { prod ->
                    val physical = physicalText.toDoubleOrNull() ?: prod.stock
                    val variance = physical - prod.stock
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Stok Tercatat di Sistem:")
                        Text("${formatNumber(prod.stock)} ${prod.baseUnit}", style = TabularNumericStyle, fontWeight = FontWeight.SemiBold)
                    }
                    OutlinedTextField(
                        value = physicalText,
                        onValueChange = { physicalText = it },
                        label = { Text("Jumlah Stok Fisik Lapangan (${prod.baseUnit})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Selisih Penyesuaian:")
                        Text(
                            "${if (variance >= 0) "+" else ""}${formatNumber(variance)} ${prod.baseUnit}",
                            style = TabularNumericStyle,
                            fontWeight = FontWeight.Bold,
                            color = if (variance == 0.0) SuccessGreen else WarningAmber
                        )
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Keterangan / Alasan Selisih") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            onPerformOpname(prod, physical, note)
                            note = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simpan Hasil Opname")
                    }
                }
            }
        }
    }
}

@Composable
private fun StockTransferTab(
    outlets: List<OutletEntity>,
    products: List<ProductEntity>,
    transfers: List<StockTransferEntity>,
    onCreateTransfer: (OutletEntity, OutletEntity, ProductEntity, Double, String) -> Unit,
    onReceiveTransfer: (StockTransferEntity) -> Unit
) {
    var fromOutlet by remember(outlets) { mutableStateOf(outlets.firstOrNull()) }
    var toOutlet by remember(outlets) { mutableStateOf(outlets.getOrNull(1) ?: outlets.firstOrNull()) }
    var selectedProd by remember(products) { mutableStateOf(products.firstOrNull()) }
    var qtyText by remember { mutableStateOf("5") }
    var note by remember { mutableStateOf("") }

    var fromMenu by remember { mutableStateOf(false) }
    var toMenu by remember { mutableStateOf(false) }
    var prodMenu by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Transfer Stok Antar Cabang / Gudang", style = MaterialTheme.typography.titleMedium)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(onClick = { fromMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Dari: ${fromOutlet?.name ?: "-"}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = fromMenu, onDismissRequest = { fromMenu = false }) {
                                outlets.forEach { o ->
                                    DropdownMenuItem(text = { Text(o.name) }, onClick = { fromOutlet = o; fromMenu = false })
                                }
                            }
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(onClick = { toMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Ke: ${toOutlet?.name ?: "-"}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = toMenu, onDismissRequest = { toMenu = false }) {
                                outlets.forEach { o ->
                                    DropdownMenuItem(text = { Text(o.name) }, onClick = { toOutlet = o; toMenu = false })
                                }
                            }
                        }
                    }

                    Box {
                        OutlinedButton(onClick = { prodMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedProd?.let { "${it.name} (Stok: ${formatNumber(it.stock)} ${it.baseUnit})" } ?: "Pilih Produk")
                        }
                        DropdownMenu(expanded = prodMenu, onDismissRequest = { prodMenu = false }) {
                            products.forEach { p ->
                                DropdownMenuItem(text = { Text("${p.name} (${formatNumber(p.stock)} ${p.baseUnit})") }, onClick = {
                                    selectedProd = p
                                    prodMenu = false
                                })
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qtyText,
                            onValueChange = { qtyText = it },
                            label = { Text("Jumlah") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Catatan") },
                            singleLine = true,
                            modifier = Modifier.weight(1.5f)
                        )
                    }

                    Button(
                        onClick = {
                            val f = fromOutlet
                            val t = toOutlet
                            val p = selectedProd
                            val q = qtyText.toDoubleOrNull() ?: 0.0
                            if (f != null && t != null && p != null) {
                                onCreateTransfer(f, t, p, q, note)
                                note = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.LocalShipping, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Kirim Transfer Stok")
                    }
                }
            }
        }

        item {
            Text("Status Barang In Transit & Riwayat (${transfers.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(transfers, key = { it.id }) { trf ->
            val inTransit = trf.status == TransferStatus.IN_TRANSIT
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${trf.transferNumber} · ${trf.productName}", fontWeight = FontWeight.SemiBold)
                        Text(
                            "${trf.fromOutletName} -> ${trf.toOutletName} · ${formatNumber(trf.quantity)}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            trf.status.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (inTransit) InfoBlue else SuccessGreen
                        )
                    }
                    if (inTransit) {
                        OutlinedButton(onClick = { onReceiveTransfer(trf) }) {
                            Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Terima")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StockAnalysisBomTab(
    products: List<ProductEntity>,
    bomItems: List<BomItemEntity>
) {
    val thirtyDaysAgo = remember { System.currentTimeMillis() - 30L * 24 * 3600 * 1000 }
    val lowStock = remember(products) { products.filter { it.stock <= it.minStock } }
    val deadStock = remember(products) {
        products.filter { it.stock > 0 && it.lastSoldAt < thirtyDaysAgo }
    }
    val bomProducts = remember(products) { products.filter { it.isBom } }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.WarningAmber, contentDescription = null, tint = WarningAmber)
                        Text("Stok Menipis (${lowStock.size})", style = MaterialTheme.typography.titleMedium)
                    }
                    if (lowStock.isEmpty()) {
                        Text("Tidak ada produk di bawah stok minimum.")
                    } else {
                        lowStock.forEach { p ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(p.name)
                                Text(
                                    "${formatNumber(p.stock)} / min ${formatNumber(p.minStock)} ${p.baseUnit}",
                                    style = TabularNumericStyle,
                                    color = DangerRed
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dead Stock (>30 Hari Tidak Terjual) · ${deadStock.size}", style = MaterialTheme.typography.titleMedium)
                    if (deadStock.isEmpty()) {
                        Text("Semua produk aktif terjual dalam 30 hari terakhir.")
                    } else {
                        deadStock.forEach { p ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(p.name, fontWeight = FontWeight.Medium)
                                    Text("Terakhir terjual: ${formatDateTime(p.lastSoldAt)}", style = MaterialTheme.typography.labelSmall)
                                }
                                Text(
                                    "${formatNumber(p.stock)} ${p.baseUnit}",
                                    style = TabularNumericStyle,
                                    color = WarningAmber
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Resep / Bill of Materials (F&B) · ${bomProducts.size}", style = MaterialTheme.typography.titleMedium)
                    if (bomProducts.isEmpty()) {
                        Text("Belum ada produk dengan resep BOM.")
                    } else {
                        bomProducts.forEach { prod ->
                            val ings = bomItems.filter { it.parentProductId == prod.id }
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${prod.name} (per 1 ${prod.baseUnit})", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                                ings.forEach { ing ->
                                    Text(
                                        "  • ${ing.ingredientName}: ${formatNumber(ing.quantityNeeded)} ${ing.unit}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }
    }
}
