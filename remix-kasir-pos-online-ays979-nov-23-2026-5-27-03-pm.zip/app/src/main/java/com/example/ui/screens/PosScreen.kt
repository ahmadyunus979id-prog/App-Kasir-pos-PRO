package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.LockClock
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CustomerEntity
import com.example.data.local.LoyaltyRewardEntity
import com.example.data.local.PettyCashEntity
import com.example.data.local.ProductEntity
import com.example.data.local.ShiftEntity
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.data.model.CartItem
import com.example.data.model.PaymentMethod
import com.example.data.model.ProductUnitOption
import com.example.data.model.TransactionStatus
import com.example.ui.components.ProductThumbnail
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TabularNumericStyle
import com.example.ui.theme.WarningAmber
import com.example.util.formatDateTime
import com.example.util.formatNumber
import com.example.util.formatRupiah

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    currentUser: UserEntity,
    products: List<ProductEntity>,
    customers: List<CustomerEntity>,
    transactions: List<TransactionEntity>,
    openShift: ShiftEntity?,
    pettyCashList: List<PettyCashEntity>,
    settings: StoreSettingsEntity,
    cartItems: List<CartItem>,
    selectedCustomer: CustomerEntity?,
    loyaltyRewards: List<LoyaltyRewardEntity>,
    selectedReward: LoyaltyRewardEntity?,
    orderDiscount: Long,
    applyTax: Boolean,
    onAddProduct: (ProductEntity, ProductUnitOption?) -> Unit,
    onScanBarcode: (String) -> Boolean,
    onUpdateQty: (Long, String, Int) -> Unit,
    onUpdateItemDiscount: (Long, String, Long) -> Unit,
    onChangeItemUnit: (Long, String, ProductUnitOption) -> Unit,
    onClearCart: () -> Unit,
    onSelectCustomer: (CustomerEntity?) -> Unit,
    onSelectReward: (LoyaltyRewardEntity?) -> Unit,
    onSetOrderDiscount: (Long) -> Unit,
    onSetApplyTax: (Boolean) -> Unit,
    onCheckout: (PaymentMethod, Long) -> Unit,
    onOpenShift: (Long) -> Unit,
    onAddPettyCash: (String, Long) -> Unit,
    onCloseShift: (Long, (ShiftEntity) -> Unit) -> Unit,
    onPrintShift: (ShiftEntity) -> Unit,
    onOpenReceipt: (TransactionEntity) -> Unit,
    onAuthorizeVoidOrReturn: (TransactionEntity, Boolean, String, String, (Boolean, String) -> Unit) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Semua") }
    var showMobileCartSheet by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var showShiftDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showScannerDialog by remember { mutableStateOf(false) }
    var unitPickerProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var closedShiftSummary by remember { mutableStateOf<ShiftEntity?>(null) }

    val categories = remember(products) {
        listOf("Semua") + products.map { it.category }.distinct().sorted()
    }
    val filteredProducts = remember(products, searchQuery, selectedCategory) {
        products.filter { prod ->
            val catOk = selectedCategory == "Semua" || prod.category == selectedCategory
            val q = searchQuery.trim()
            val qOk = q.isEmpty() ||
                prod.name.contains(q, ignoreCase = true) ||
                prod.sku.contains(q, ignoreCase = true) ||
                prod.barcode.contains(q, ignoreCase = true)
            catOk && qOk
        }
    }

    val subtotal = cartItems.sumOf { it.lineNet }
    val rewardDiscount = selectedReward?.discountAmount ?: 0L
    val discountCapped = (orderDiscount + rewardDiscount).coerceIn(0L, subtotal)
    val afterDiscount = subtotal - discountCapped
    val taxAmount = if (!applyTax || settings.taxPercent <= 0.0) {
        0L
    } else if (settings.taxInclusive) {
        Math.round(afterDiscount - (afterDiscount / (1.0 + settings.taxPercent / 100.0)))
    } else {
        Math.round(afterDiscount * (settings.taxPercent / 100.0))
    }
    val grandTotal = if (settings.taxInclusive) afterDiscount else afterDiscount + taxAmount

    Column(modifier = Modifier.fillMaxSize()) {
        // Shift & Action Top Strip
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { showShiftDialog = true }) {
                    Icon(Icons.Outlined.LockClock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (openShift != null) "Shift Aktif · Kas: ${formatRupiah(openShift.expectedCash)}"
                        else "Buka Shift Kasir",
                        maxLines = 1
                    )
                }
                OutlinedButton(onClick = { showHistoryDialog = true }) {
                    Icon(Icons.Outlined.History, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Nota / Void / Retur", maxLines = 1)
                }
            }
        }

        BoxWithConstraints(modifier = Modifier.weight(1f)) {
            val isWide = maxWidth >= 720.dp

            Row(modifier = Modifier.fillMaxSize()) {
                // Left Pane: Search + Categories + Product Grid
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Cari nama, SKU, atau scan barcode...") },
                            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Outlined.Close, contentDescription = "Hapus")
                                    }
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(
                                onSearch = {
                                    if (onScanBarcode(searchQuery)) {
                                        searchQuery = ""
                                    }
                                }
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { showScannerDialog = true },
                            modifier = Modifier.height(54.dp)
                        ) {
                            Icon(Icons.Outlined.QrCodeScanner, contentDescription = "Scan Barcode")
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat) }
                            )
                        }
                    }

                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 152.dp),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(filteredProducts, key = { it.id }) { prod ->
                            val units = remember(prod.unitsJson, prod.sellPrice, prod.baseUnit) {
                                prod.getUnitOptions()
                            }
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (units.size > 1) {
                                            unitPickerProduct = prod
                                        } else {
                                            onAddProduct(prod, units.first())
                                        }
                                    },
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        ProductThumbnail(
                                            photoUri = prod.photoUri,
                                            category = prod.category,
                                            productName = prod.name,
                                            size = 48.dp
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                prod.sku,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                "Stok: ${formatNumber(prod.stock)} ${prod.baseUnit}",
                                                style = MaterialTheme.typography.labelSmall.merge(TabularNumericStyle),
                                                color = if (prod.stock <= prod.minStock) DangerRed else SuccessGreen
                                            )
                                        }
                                    }
                                    Text(
                                        prod.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            formatRupiah(prod.sellPrice),
                                            style = MaterialTheme.typography.labelLarge.merge(TabularNumericStyle),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            if (units.size > 1) "+ Satuan" else "/${prod.baseUnit}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Mobile Bottom Cart Bar
                    if (!isWide) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { showMobileCartSheet = true }
                                ) {
                                    Text(
                                        "${cartItems.sumOf { it.quantity }} item di keranjang",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        formatRupiah(grandTotal),
                                        style = MaterialTheme.typography.titleLarge.merge(TabularNumericStyle),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { showMobileCartSheet = true }) {
                                        Icon(Icons.Outlined.ShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Keranjang")
                                    }
                                    Button(
                                        onClick = { showCheckoutDialog = true },
                                        enabled = cartItems.isNotEmpty()
                                    ) {
                                        Text("Bayar")
                                    }
                                }
                            }
                        }
                    }
                }

                // Wide Pane: Always-visible Cart
                if (isWide) {
                    Surface(
                        modifier = Modifier
                            .width(360.dp)
                            .fillMaxHeight(),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        CartPanelContent(
                            products = products,
                            customers = customers,
                            cartItems = cartItems,
                            selectedCustomer = selectedCustomer,
                            loyaltyRewards = loyaltyRewards,
                            selectedReward = selectedReward,
                            orderDiscount = orderDiscount,
                            applyTax = applyTax,
                            taxPercent = settings.taxPercent,
                            subtotal = subtotal,
                            taxAmount = taxAmount,
                            grandTotal = grandTotal,
                            onSelectCustomer = onSelectCustomer,
                            onSelectReward = onSelectReward,
                            onUpdateQty = onUpdateQty,
                            onUpdateItemDiscount = onUpdateItemDiscount,
                            onChangeItemUnit = onChangeItemUnit,
                            onSetOrderDiscount = onSetOrderDiscount,
                            onSetApplyTax = onSetApplyTax,
                            onClearCart = onClearCart,
                            onProceedPayment = { showCheckoutDialog = true }
                        )
                    }
                }
            }
        }
    }

    // Mobile Cart Sheet
    if (showMobileCartSheet) {
        ModalBottomSheet(onDismissRequest = { showMobileCartSheet = false }) {
            Box(modifier = Modifier.height(520.dp)) {
                CartPanelContent(
                    products = products,
                    customers = customers,
                    cartItems = cartItems,
                    selectedCustomer = selectedCustomer,
                    loyaltyRewards = loyaltyRewards,
                    selectedReward = selectedReward,
                    orderDiscount = orderDiscount,
                    applyTax = applyTax,
                    taxPercent = settings.taxPercent,
                    subtotal = subtotal,
                    taxAmount = taxAmount,
                    grandTotal = grandTotal,
                    onSelectCustomer = onSelectCustomer,
                    onSelectReward = onSelectReward,
                    onUpdateQty = onUpdateQty,
                    onUpdateItemDiscount = onUpdateItemDiscount,
                    onChangeItemUnit = onChangeItemUnit,
                    onSetOrderDiscount = onSetOrderDiscount,
                    onSetApplyTax = onSetApplyTax,
                    onClearCart = onClearCart,
                    onProceedPayment = {
                        showMobileCartSheet = false
                        showCheckoutDialog = true
                    }
                )
            }
        }
    }

    // Unit Picker Dialog
    unitPickerProduct?.let { prod ->
        val units = prod.getUnitOptions()
        AlertDialog(
            onDismissRequest = { unitPickerProduct = null },
            title = { Text("Pilih Satuan · ${prod.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    units.forEach { u ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onAddProduct(prod, u)
                                    unitPickerProduct = null
                                },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${u.unitName} (${formatNumber(u.multiplier)} ${prod.baseUnit})")
                                Text(
                                    formatRupiah(u.sellPrice),
                                    style = TabularNumericStyle,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { unitPickerProduct = null }) { Text("Batal") }
            }
        )
    }

    // Barcode Quick Scan Dialog
    if (showScannerDialog) {
        var codeInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showScannerDialog = false },
            title = { Text("Input / Scan Barcode") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Arahkan barcode scanner USB/Bluetooth atau ketik nomor barcode / SKU produk:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it },
                        label = { Text("Barcode / SKU") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Barcode Cepat (Sampel):", style = MaterialTheme.typography.labelLarge)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        products.take(4).forEach { p ->
                            OutlinedButton(
                                onClick = {
                                    onScanBarcode(p.barcode)
                                    showScannerDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("${p.barcode} · ${p.name}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (onScanBarcode(codeInput)) showScannerDialog = false
                }) { Text("Cari & Tambah") }
            },
            dismissButton = {
                TextButton(onClick = { showScannerDialog = false }) { Text("Tutup") }
            }
        )
    }

    // Checkout Payment Dialog
    if (showCheckoutDialog) {
        CheckoutPaymentDialog(
            totalAmount = grandTotal,
            selectedCustomer = selectedCustomer,
            settings = settings,
            hasOpenShift = openShift != null,
            onOpenShiftFirst = {
                showCheckoutDialog = false
                showShiftDialog = true
            },
            onConfirmPayment = { method, paid ->
                onCheckout(method, paid)
                showCheckoutDialog = false
            },
            onDismiss = { showCheckoutDialog = false }
        )
    }

    // Shift Open / Petty Cash / Close Dialog
    if (showShiftDialog) {
        ShiftManagementDialog(
            openShift = openShift,
            pettyCashList = pettyCashList.filter { it.shiftId == openShift?.id },
            onOpenShift = { openingCash ->
                onOpenShift(openingCash)
                showShiftDialog = false
            },
            onAddPettyCash = onAddPettyCash,
            onCloseShift = { actualCash ->
                onCloseShift(actualCash) { closed ->
                    showShiftDialog = false
                    closedShiftSummary = closed
                }
            },
            onDismiss = { showShiftDialog = false }
        )
    }

    closedShiftSummary?.let { closed ->
        val diff = (closed.actualCash ?: closed.expectedCash) - closed.expectedCash
        AlertDialog(
            onDismissRequest = { closedShiftSummary = null },
            title = { Text("Rekap Tutup Shift") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Kasir: ${closed.userName}")
                    Text("Outlet: ${closed.outletName}")
                    HorizontalDivider()
                    Text("Modal Awal: ${formatRupiah(closed.openingCash)}", style = TabularNumericStyle)
                    Text("Penjualan Tunai: ${formatRupiah(closed.cashSales)}", style = TabularNumericStyle)
                    Text("Non-Tunai: ${formatRupiah(closed.nonCashSales)}", style = TabularNumericStyle)
                    Text("Kas Kecil Keluar: -${formatRupiah(closed.pettyCashOut)}", style = TabularNumericStyle)
                    Text("Kas Seharusnya: ${formatRupiah(closed.expectedCash)}", style = TabularNumericStyle, fontWeight = FontWeight.Bold)
                    Text("Kas Fisik Aktual: ${formatRupiah(closed.actualCash ?: 0L)}", style = TabularNumericStyle)
                    Text(
                        "Selisih: ${formatRupiah(diff)}",
                        style = TabularNumericStyle,
                        fontWeight = FontWeight.Bold,
                        color = if (diff == 0L) SuccessGreen else DangerRed
                    )
                }
            },
            confirmButton = {
                Button(onClick = { onPrintShift(closed) }) { Text("Cetak Shift") }
            },
            dismissButton = {
                TextButton(onClick = { closedShiftSummary = null }) { Text("Tutup") }
            }
        )
    }

    // History, Void & Retur Dialog
    if (showHistoryDialog) {
        TransactionHistoryVoidDialog(
            currentUser = currentUser,
            transactions = transactions,
            onOpenReceipt = {
                showHistoryDialog = false
                onOpenReceipt(it)
            },
            onAuthorizeVoidOrReturn = onAuthorizeVoidOrReturn,
            onDismiss = { showHistoryDialog = false }
        )
    }
}

@Composable
private fun CartPanelContent(
    products: List<ProductEntity>,
    customers: List<CustomerEntity>,
    cartItems: List<CartItem>,
    selectedCustomer: CustomerEntity?,
    loyaltyRewards: List<LoyaltyRewardEntity>,
    selectedReward: LoyaltyRewardEntity?,
    orderDiscount: Long,
    applyTax: Boolean,
    taxPercent: Double,
    subtotal: Long,
    taxAmount: Long,
    grandTotal: Long,
    onSelectCustomer: (CustomerEntity?) -> Unit,
    onSelectReward: (LoyaltyRewardEntity?) -> Unit,
    onUpdateQty: (Long, String, Int) -> Unit,
    onUpdateItemDiscount: (Long, String, Long) -> Unit,
    onChangeItemUnit: (Long, String, ProductUnitOption) -> Unit,
    onSetOrderDiscount: (Long) -> Unit,
    onSetApplyTax: (Boolean) -> Unit,
    onClearCart: () -> Unit,
    onProceedPayment: () -> Unit
) {
    var showCustomerMenu by remember { mutableStateOf(false) }
    var showRewardMenu by remember { mutableStateOf(false) }
    var editingDiscountItem by remember { mutableStateOf<CartItem?>(null) }
    var orderDiscountText by remember(orderDiscount) {
        mutableStateOf(if (orderDiscount > 0) orderDiscount.toString() else "")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Keranjang (${cartItems.sumOf { it.quantity }})", style = MaterialTheme.typography.titleMedium)
            if (cartItems.isNotEmpty()) {
                TextButton(onClick = onClearCart) {
                    Text("Kosongkan", color = DangerRed)
                }
            }
        }

        // Customer selector
        Box {
            OutlinedButton(
                onClick = { showCustomerMenu = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    selectedCustomer?.let { "${it.name} (${it.points} poin)" } ?: "Pelanggan Umum",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
            DropdownMenu(
                expanded = showCustomerMenu,
                onDismissRequest = { showCustomerMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Pelanggan Umum") },
                    onClick = {
                        onSelectCustomer(null)
                        showCustomerMenu = false
                    }
                )
                    customers.forEach { cust ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(cust.name, fontWeight = FontWeight.Medium)
                                    Text(
                                        "${cust.whatsapp} · ${cust.points} poin",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            },
                            onClick = {
                                onSelectCustomer(cust)
                                showCustomerMenu = false
                            }
                        )
                    }
                }
            }

        if (selectedCustomer != null) {
            val eligibleRewards = loyaltyRewards.filter {
                it.isActive && it.pointsCost <= selectedCustomer.points
            }
            Box {
                OutlinedButton(
                    onClick = { showRewardMenu = true },
                    enabled = eligibleRewards.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        selectedReward?.let { "Ditukar: ${it.title} (-${it.pointsCost} poin)" }
                            ?: if (eligibleRewards.isNotEmpty()) "Tukar Poin (${selectedCustomer.points} poin tersedia)"
                            else "Poin Pelanggan: ${selectedCustomer.points} (belum cukup reward)",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                DropdownMenu(
                    expanded = showRewardMenu,
                    onDismissRequest = { showRewardMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Tidak Tukar Poin") },
                        onClick = {
                            onSelectReward(null)
                            showRewardMenu = false
                        }
                    )
                    eligibleRewards.forEach { r ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(r.title, fontWeight = FontWeight.Medium)
                                    Text("${r.pointsCost} poin · ${r.rewardType.label}", style = MaterialTheme.typography.labelSmall)
                                }
                            },
                            onClick = {
                                onSelectReward(r)
                                showRewardMenu = false
                            }
                        )
                    }
                }
            }
        }

        HorizontalDivider()

        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Pilih produk atau scan barcode untuk memulai transaksi.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartItems, key = { "${it.productId}_${it.selectedUnit}" }) { item ->
                    val prodUnits = products.firstOrNull { it.id == item.productId }?.getUnitOptions().orEmpty()
                    var showUnitDrop by remember { mutableStateOf(false) }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    item.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                IconButton(
                                    onClick = { onUpdateQty(item.productId, item.selectedUnit, 0) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus", tint = DangerRed, modifier = Modifier.size(18.dp))
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box {
                                    TextButton(
                                        onClick = { if (prodUnits.size > 1) showUnitDrop = true },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("${formatRupiah(item.unitPrice)} / ${item.selectedUnit}")
                                    }
                                    DropdownMenu(
                                        expanded = showUnitDrop,
                                        onDismissRequest = { showUnitDrop = false }
                                    ) {
                                        prodUnits.forEach { u ->
                                            DropdownMenuItem(
                                                text = { Text("${u.unitName} - ${formatRupiah(u.sellPrice)}") },
                                                onClick = {
                                                    onChangeItemUnit(item.productId, item.selectedUnit, u)
                                                    showUnitDrop = false
                                                }
                                            )
                                        }
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onUpdateQty(item.productId, item.selectedUnit, item.quantity - 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Outlined.Remove, contentDescription = "Kurangi", modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        "${item.quantity}",
                                        style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    )
                                    IconButton(
                                        onClick = { onUpdateQty(item.productId, item.selectedUnit, item.quantity + 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Outlined.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { editingDiscountItem = item },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Text(
                                        if (item.itemDiscount > 0) "Diskon: -${formatRupiah(item.itemDiscount)}"
                                        else "+ Diskon Item",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                                Text(
                                    formatRupiah(item.lineNet),
                                    style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider()

        // Order Discount & Tax
        OutlinedTextField(
            value = orderDiscountText,
            onValueChange = { txt ->
                orderDiscountText = txt.filter { it.isDigit() }
                onSetOrderDiscount(orderDiscountText.toLongOrNull() ?: 0L)
            },
            label = { Text("Diskon Nota (Rp)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = applyTax, onCheckedChange = onSetApplyTax)
                Text("PPN (${formatNumber(taxPercent)}%)", style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                formatRupiah(taxAmount),
                style = MaterialTheme.typography.bodyMedium.merge(TabularNumericStyle)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
            Text(formatRupiah(subtotal), style = MaterialTheme.typography.bodyMedium.merge(TabularNumericStyle))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Total Tagihan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                formatRupiah(grandTotal),
                style = MaterialTheme.typography.titleLarge.merge(TabularNumericStyle),
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }

        Button(
            onClick = onProceedPayment,
            enabled = cartItems.isNotEmpty(),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Outlined.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Proses Pembayaran")
        }
    }

    editingDiscountItem?.let { target ->
        var discInput by remember(target) {
            mutableStateOf(if (target.itemDiscount > 0) target.itemDiscount.toString() else "")
        }
        AlertDialog(
            onDismissRequest = { editingDiscountItem = null },
            title = { Text("Diskon Item · ${target.name}") },
            text = {
                OutlinedTextField(
                    value = discInput,
                    onValueChange = { discInput = it.filter { c -> c.isDigit() } },
                    label = { Text("Nominal Diskon (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateItemDiscount(target.productId, target.selectedUnit, discInput.toLongOrNull() ?: 0L)
                    editingDiscountItem = null
                }) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { editingDiscountItem = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun CheckoutPaymentDialog(
    totalAmount: Long,
    selectedCustomer: CustomerEntity?,
    settings: StoreSettingsEntity,
    hasOpenShift: Boolean,
    onOpenShiftFirst: () -> Unit,
    onConfirmPayment: (PaymentMethod, Long) -> Unit,
    onDismiss: () -> Unit
) {
    val allowedMethods = buildList {
        add(PaymentMethod.TUNAI)
        if (settings.qrisEnabled) add(PaymentMethod.QRIS)
        if (settings.transferEnabled) add(PaymentMethod.TRANSFER)
        if (settings.piutangEnabled) add(PaymentMethod.PIUTANG)
    }
    var method by remember { mutableStateOf(PaymentMethod.TUNAI) }
    var paidInput by remember { mutableStateOf(totalAmount.toString()) }
    val paidAmount = paidInput.toLongOrNull() ?: 0L
    val change = (paidAmount - totalAmount).coerceAtLeast(0L)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pembayaran") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!hasOpenShift) {
                    Surface(
                        color = WarningAmber.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "Shift kasir belum dibuka. Buka shift dulu untuk mencatat laci kas.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarningAmber
                            )
                            OutlinedButton(onClick = onOpenShiftFirst) {
                                Text("Buka Shift Sekarang")
                            }
                        }
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Total Tagihan", style = MaterialTheme.typography.labelMedium)
                        Text(
                            formatRupiah(totalAmount),
                            style = MaterialTheme.typography.headlineMedium.merge(TabularNumericStyle),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Text("Metode Pembayaran", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allowedMethods.forEach { m ->
                        FilterChip(
                            selected = method == m,
                            onClick = { method = m },
                            label = { Text(m.label) }
                        )
                    }
                }

                when (method) {
                    PaymentMethod.TUNAI -> {
                        OutlinedTextField(
                            value = paidInput,
                            onValueChange = { paidInput = it.filter { c -> c.isDigit() } },
                            label = { Text("Nominal Uang Diterima (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(totalAmount, 50_000L, 100_000L, 200_000L).distinct().forEach { preset ->
                                OutlinedButton(onClick = { paidInput = preset.toString() }) {
                                    Text(if (preset == totalAmount) "Uang Pas" else formatRupiah(preset))
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Kembalian", style = MaterialTheme.typography.titleMedium)
                            Text(
                                formatRupiah(change),
                                style = MaterialTheme.typography.titleMedium.merge(TabularNumericStyle),
                                color = if (paidAmount >= totalAmount) SuccessGreen else DangerRed,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    PaymentMethod.QRIS -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.QrCode2,
                                    contentDescription = "QRIS",
                                    modifier = Modifier.size(96.dp),
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                                Text("QRIS Dinamis · ${settings.storeName}", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Nominal: ${formatRupiah(totalAmount)}",
                                    style = TabularNumericStyle,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                    PaymentMethod.TRANSFER -> {
                        Text(
                            "Pastikan pembayaran transfer bank / mesin EDC kartu sebesar ${formatRupiah(totalAmount)} telah berhasil masuk.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    PaymentMethod.PIUTANG -> {
                        if (selectedCustomer == null) {
                            Text(
                                "Pilih pelanggan terdaftar di keranjang sebelum menggunakan metode Piutang / Tempo.",
                                color = DangerRed,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            Text(
                                "Tagihan sebesar ${formatRupiah(totalAmount)} akan ditambahkan ke saldo piutang ${selectedCustomer.name}.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            val valid = hasOpenShift && when (method) {
                PaymentMethod.TUNAI -> paidAmount >= totalAmount
                PaymentMethod.PIUTANG -> selectedCustomer != null
                else -> true
            }
            Button(
                onClick = { onConfirmPayment(method, paidAmount) },
                enabled = valid
            ) {
                Text("Selesaikan & Cetak")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
private fun ShiftManagementDialog(
    openShift: ShiftEntity?,
    pettyCashList: List<PettyCashEntity>,
    onOpenShift: (Long) -> Unit,
    onAddPettyCash: (String, Long) -> Unit,
    onCloseShift: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var openingCashText by remember { mutableStateOf("500000") }
    var actualCashText by remember(openShift?.expectedCash) {
        mutableStateOf((openShift?.expectedCash ?: 0L).toString())
    }
    var pettyDesc by remember { mutableStateOf("") }
    var pettyAmount by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (openShift == null) "Buka Shift Kasir" else "Manajemen Shift Kasir") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (openShift == null) {
                    Text("Catat modal awal kas laci sebelum memulai transaksi.")
                    OutlinedTextField(
                        value = openingCashText,
                        onValueChange = { openingCashText = it.filter { c -> c.isDigit() } },
                        label = { Text("Modal Awal Kas (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Text("Kasir: ${openShift.userName} · ${openShift.outletName}", fontWeight = FontWeight.SemiBold)
                    Text("Buka: ${formatDateTime(openShift.openedAt)}", style = MaterialTheme.typography.bodyMedium)
                    HorizontalDivider()
                    Text("Modal Awal: ${formatRupiah(openShift.openingCash)}", style = TabularNumericStyle)
                    Text("Penjualan Tunai: ${formatRupiah(openShift.cashSales)}", style = TabularNumericStyle)
                    Text("Penjualan Non-Tunai: ${formatRupiah(openShift.nonCashSales)}", style = TabularNumericStyle)
                    Text("Kas Kecil Keluar: -${formatRupiah(openShift.pettyCashOut)}", style = TabularNumericStyle)
                    Text(
                        "Ekspektasi Kas Laci: ${formatRupiah(openShift.expectedCash)}",
                        style = TabularNumericStyle,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    HorizontalDivider()
                    Text("Catat Pengeluaran Kas Kecil", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(
                        value = pettyDesc,
                        onValueChange = { pettyDesc = it },
                        label = { Text("Keterangan (mis. Beli plastik/es)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = pettyAmount,
                            onValueChange = { pettyAmount = it.filter { c -> c.isDigit() } },
                            label = { Text("Nominal (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(onClick = {
                            onAddPettyCash(pettyDesc, pettyAmount.toLongOrNull() ?: 0L)
                            pettyDesc = ""
                            pettyAmount = ""
                        }) { Text("Catat") }
                    }
                    if (pettyCashList.isNotEmpty()) {
                        pettyCashList.forEach { pc ->
                            Text(
                                "• ${pc.description}: ${formatRupiah(pc.amount)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    HorizontalDivider()
                    Text("Tutup Shift Kasir", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(
                        value = actualCashText,
                        onValueChange = { actualCashText = it.filter { c -> c.isDigit() } },
                        label = { Text("Kas Fisik Aktual di Laci (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            if (openShift == null) {
                Button(onClick = { onOpenShift(openingCashText.toLongOrNull() ?: 0L) }) {
                    Text("Buka Kasir")
                }
            } else {
                Button(onClick = { onCloseShift(actualCashText.toLongOrNull() ?: openShift.expectedCash) }) {
                    Text("Tutup Shift")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
private fun TransactionHistoryVoidDialog(
    currentUser: UserEntity,
    transactions: List<TransactionEntity>,
    onOpenReceipt: (TransactionEntity) -> Unit,
    onAuthorizeVoidOrReturn: (TransactionEntity, Boolean, String, String, (Boolean, String) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var targetTx by remember { mutableStateOf<TransactionEntity?>(null) }
    var isFullVoid by remember { mutableStateOf(true) }
    var reason by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Riwayat Nota, Void & Retur") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (targetTx == null) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(transactions.take(30), key = { it.id }) { tx ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(tx.invoiceNumber, fontWeight = FontWeight.Bold)
                                        Text(
                                            formatRupiah(tx.totalAmount),
                                            style = TabularNumericStyle,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        "${tx.customerName} · ${tx.paymentMethod.label} · ${tx.status.label}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (tx.status == TransactionStatus.COMPLETED)
                                            MaterialTheme.colorScheme.onSurfaceVariant else DangerRed
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { onOpenReceipt(tx) }) {
                                            Text("Struk / PDF / WA")
                                        }
                                        if (tx.status == TransactionStatus.COMPLETED) {
                                            TextButton(onClick = {
                                                targetTx = tx
                                                isFullVoid = true
                                                feedback = null
                                            }) {
                                                Text("Void / Retur", color = DangerRed)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    val tx = targetTx!!
                    Text("Nota: ${tx.invoiceNumber} (${formatRupiah(tx.totalAmount)})", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = isFullVoid,
                            onClick = { isFullVoid = true },
                            label = { Text("Void Transaksi") }
                        )
                        FilterChip(
                            selected = !isFullVoid,
                            onClick = { isFullVoid = false },
                            label = { Text("Retur Penjualan") }
                        )
                    }
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Alasan Void / Retur") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!currentUser.role.canAuthorizeVoid) {
                        OutlinedTextField(
                            value = adminPassword,
                            onValueChange = { adminPassword = it },
                            label = { Text("Password Otorisasi Admin") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text(
                            "Terotorisasi sebagai ${currentUser.role.label} (${currentUser.fullName})",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SuccessGreen
                        )
                    }
                    if (!feedback.isNullOrBlank()) {
                        Text(feedback!!, color = DangerRed, style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { targetTx = null }) { Text("Kembali") }
                        Button(onClick = {
                            onAuthorizeVoidOrReturn(tx, isFullVoid, reason, adminPassword) { ok, msg ->
                                if (ok) {
                                    targetTx = null
                                    reason = ""
                                    adminPassword = ""
                                } else {
                                    feedback = msg
                                }
                            }
                        }) { Text("Proses") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}
