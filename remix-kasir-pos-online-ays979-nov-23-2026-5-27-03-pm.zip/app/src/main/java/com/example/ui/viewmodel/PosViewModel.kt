package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BomItemEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.LoyaltyRewardEntity
import com.example.data.local.OutletEntity
import com.example.data.local.PettyCashEntity
import com.example.data.local.PointHistoryEntity
import com.example.data.local.PosDatabase
import com.example.data.local.PosRepository
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderDraftItem
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.PurchaseOrderItemEntity
import com.example.data.local.ShiftEntity
import com.example.data.local.StockMovementEntity
import com.example.data.local.StockTransferEntity
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.SupplierEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionItemEntity
import com.example.data.local.UserEntity
import com.example.data.model.CartItem
import com.example.data.model.PaperWidth
import com.example.data.model.PaymentMethod
import com.example.data.model.ProductUnitOption
import com.example.data.model.ThemeMode
import com.example.data.model.UserRole
import com.example.util.PairedBluetoothDevice
import com.example.util.PdfInvoiceHelper
import com.example.util.ThermalPrinterHelper
import com.example.util.WhatsAppShareHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PosViewModel(application: Application) : AndroidViewModel(application) {
    private val db = PosDatabase.getInstance(application)
    private val repo = PosRepository(db)

    val settings: StateFlow<StoreSettingsEntity> = repo.settingsFlow
        .filterNotNull()
        .stateIn(viewModelScope, SharingStarted.Eagerly, StoreSettingsEntity())

    val outlets = repo.outletsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val users = repo.usersFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val products = repo.productsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bomItems = repo.bomItemsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val customers = repo.customersFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val suppliers = repo.suppliersFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val shifts = repo.shiftsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val openShift = repo.openShiftFlow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val pettyCashList = repo.pettyCashFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val transactions = repo.transactionsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val transactionItems = repo.transactionItemsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val purchaseOrders = repo.purchaseOrdersFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val poItems = repo.poItemsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val stockMovements = repo.stockMovementsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val stockTransfers = repo.stockTransfersFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val loyaltyRewards = repo.loyaltyRewardsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val pointHistory = repo.pointHistoryFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _activeOutletId = MutableStateFlow(1L)
    val activeOutletId: StateFlow<Long> = _activeOutletId.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // POS Cart State
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<CustomerEntity?>(null)
    val selectedCustomer: StateFlow<CustomerEntity?> = _selectedCustomer.asStateFlow()

    private val _orderDiscount = MutableStateFlow(0L)
    val orderDiscount: StateFlow<Long> = _orderDiscount.asStateFlow()

    private val _applyTax = MutableStateFlow(true)
    val applyTax: StateFlow<Boolean> = _applyTax.asStateFlow()

    private val _selectedReward = MutableStateFlow<LoyaltyRewardEntity?>(null)
    val selectedReward: StateFlow<LoyaltyRewardEntity?> = _selectedReward.asStateFlow()

    private val _receiptTx = MutableStateFlow<TransactionEntity?>(null)
    val receiptTx: StateFlow<TransactionEntity?> = _receiptTx.asStateFlow()

    private val _pairedDevices = MutableStateFlow<List<PairedBluetoothDevice>>(emptyList())
    val pairedDevices: StateFlow<List<PairedBluetoothDevice>> = _pairedDevices.asStateFlow()

    init {
        viewModelScope.launch {
            repo.ensureSeeded()
            settings.collect { s ->
                _applyTax.value = s.taxEnabled
            }
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearLoginError() {
        _loginError.value = null
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val res = repo.authenticate(username, password)
            res.onSuccess { user ->
                _loginError.value = null
                _currentUser.value = user
                _activeOutletId.value = user.outletId
            }.onFailure { err ->
                _loginError.value = err.message ?: "Login gagal"
            }
        }
    }

    fun logout() {
        _currentUser.value = null
        _cartItems.value = emptyList()
        _selectedCustomer.value = null
        _orderDiscount.value = 0L
    }

    fun setActiveOutlet(outletId: Long) {
        _activeOutletId.value = outletId
    }

    fun activeOutlet(): OutletEntity {
        val all = outlets.value
        return all.firstOrNull { it.id == _activeOutletId.value }
            ?: all.firstOrNull()
            ?: OutletEntity(id = 1L, name = "Outlet Pusat Jakarta", address = "", phone = "", isMain = true)
    }

    // POS Cart Operations
    fun addToCart(product: ProductEntity, unitOption: ProductUnitOption? = null) {
        val unit = unitOption ?: product.getUnitOptions().first()
        val current = _cartItems.value.toMutableList()
        val existingIdx = current.indexOfFirst {
            it.productId == product.id && it.selectedUnit == unit.unitName
        }
        if (existingIdx >= 0) {
            val existing = current[existingIdx]
            current[existingIdx] = existing.copy(quantity = existing.quantity + 1)
        } else {
            current.add(
                CartItem(
                    productId = product.id,
                    name = product.name,
                    sku = product.sku,
                    photoUri = product.photoUri,
                    category = product.category,
                    selectedUnit = unit.unitName,
                    unitMultiplier = unit.multiplier,
                    unitPrice = unit.sellPrice,
                    costPrice = product.costPrice,
                    quantity = 1,
                    itemDiscount = 0L,
                    availableStock = product.stock
                )
            )
        }
        _cartItems.value = current
    }

    fun scanBarcodeOrSku(query: String): Boolean {
        val clean = query.trim()
        if (clean.isEmpty()) return false
        val matched = products.value.firstOrNull {
            it.barcode.equals(clean, ignoreCase = true) || it.sku.equals(clean, ignoreCase = true)
        }
        return if (matched != null) {
            addToCart(matched)
            showMessage("Ditambahkan: ${matched.name}")
            true
        } else {
            showMessage("Barcode / SKU '$clean' tidak ditemukan")
            false
        }
    }

    fun updateCartItemQuantity(productId: Long, unitName: String, newQty: Int) {
        val current = _cartItems.value.toMutableList()
        val idx = current.indexOfFirst { it.productId == productId && it.selectedUnit == unitName }
        if (idx >= 0) {
            if (newQty <= 0) {
                current.removeAt(idx)
            } else {
                current[idx] = current[idx].copy(quantity = newQty)
            }
            _cartItems.value = current
        }
    }

    fun updateCartItemDiscount(productId: Long, unitName: String, discount: Long) {
        val current = _cartItems.value.toMutableList()
        val idx = current.indexOfFirst { it.productId == productId && it.selectedUnit == unitName }
        if (idx >= 0) {
            val item = current[idx]
            current[idx] = item.copy(itemDiscount = discount.coerceIn(0L, item.lineGross))
            _cartItems.value = current
        }
    }

    fun changeCartItemUnit(productId: Long, oldUnitName: String, newUnit: ProductUnitOption) {
        val current = _cartItems.value.toMutableList()
        val idx = current.indexOfFirst { it.productId == productId && it.selectedUnit == oldUnitName }
        if (idx >= 0) {
            val item = current[idx]
            current[idx] = item.copy(
                selectedUnit = newUnit.unitName,
                unitMultiplier = newUnit.multiplier,
                unitPrice = newUnit.sellPrice
            )
            _cartItems.value = current
        }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _selectedCustomer.value = null
        _selectedReward.value = null
        _orderDiscount.value = 0L
    }

    fun selectCustomer(customer: CustomerEntity?) {
        _selectedCustomer.value = customer
        _selectedReward.value = null
    }

    fun selectLoyaltyReward(reward: LoyaltyRewardEntity?) {
        _selectedReward.value = reward
    }

    fun setOrderDiscount(amount: Long) {
        _orderDiscount.value = amount.coerceAtLeast(0L)
    }

    fun setApplyTax(enabled: Boolean) {
        _applyTax.value = enabled
    }

    fun dismissReceiptModal() {
        _receiptTx.value = null
    }

    fun showReceiptForTransaction(tx: TransactionEntity) {
        _receiptTx.value = tx
    }

    // Shift operations
    fun openShift(openingCash: Long) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repo.openShift(user, activeOutlet(), openingCash)
            showMessage("Shift kasir berhasil dibuka")
        }
    }

    fun addPettyCash(description: String, amount: Long) {
        val shift = openShift.value ?: run {
            showMessage("Buka shift kasir terlebih dahulu")
            return
        }
        if (description.isBlank() || amount <= 0L) {
            showMessage("Isi keterangan dan nominal pengeluaran")
            return
        }
        viewModelScope.launch {
            repo.addPettyCash(shift, description, amount)
            showMessage("Pengeluaran kas kecil dicatat")
        }
    }

    fun closeShift(actualCash: Long, onClosed: (ShiftEntity) -> Unit) {
        val shift = openShift.value ?: return
        viewModelScope.launch {
            val closed = repo.closeShift(shift, actualCash)
            showMessage("Shift berhasil ditutup")
            onClosed(closed)
        }
    }

    // Checkout
    fun checkout(paymentMethod: PaymentMethod, paidAmount: Long) {
        val user = _currentUser.value ?: return
        val shift = openShift.value ?: run {
            showMessage("Buka shift kasir terlebih dahulu sebelum bertransaksi")
            return
        }
        val currentSettings = settings.value
        viewModelScope.launch {
            val res = repo.completeSale(
                shift = shift,
                cashier = user,
                outlet = activeOutlet(),
                cartItems = _cartItems.value,
                customer = _selectedCustomer.value,
                orderDiscount = _orderDiscount.value,
                applyTax = _applyTax.value,
                taxPercent = currentSettings.taxPercent,
                taxInclusive = currentSettings.taxInclusive,
                paymentMethod = paymentMethod,
                paidAmount = paidAmount,
                redeemedReward = _selectedReward.value
            )
            res.onSuccess { tx ->
                clearCart()
                _receiptTx.value = tx
                showMessage("Transaksi ${tx.invoiceNumber} berhasil")
            }.onFailure { err ->
                showMessage(err.message ?: "Gagal memproses transaksi")
            }
        }
    }

    // Void & Retur
    fun authorizeAndVoidOrReturn(
        tx: TransactionEntity,
        isFullVoid: Boolean,
        reason: String,
        adminPassword: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val authUser = if (user.role.canAuthorizeVoid && adminPassword.isBlank()) {
                user
            } else {
                repo.verifyAdminAuthorization("", adminPassword)
            }
            if (authUser == null) {
                onResult(false, "Otorisasi gagal: password Admin/Pemilik tidak valid")
                return@launch
            }
            val res = repo.voidOrReturnTransaction(
                tx = tx,
                isFullVoid = isFullVoid,
                reason = reason.ifBlank { if (isFullVoid) "Pembatalan nota" else "Retur barang" },
                authorizedBy = authUser.fullName
            )
            res.onSuccess {
                onResult(true, if (isFullVoid) "Transaksi di-Void & stok dikembalikan" else "Retur berhasil dicatat")
            }.onFailure { err ->
                onResult(false, err.message ?: "Gagal memproses void/retur")
            }
        }
    }

    // Master Data
    fun saveProduct(product: ProductEntity, bomItems: List<BomItemEntity>) {
        viewModelScope.launch {
            repo.saveProduct(product, bomItems)
            showMessage("Produk ${product.name} disimpan")
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repo.deleteProduct(product)
            showMessage("Produk dihapus")
        }
    }

    fun saveCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repo.saveCustomer(customer)
            showMessage("Data pelanggan disimpan")
        }
    }

    fun payCustomerReceivable(customer: CustomerEntity, amount: Long) {
        viewModelScope.launch {
            repo.payCustomerReceivable(customer, amount)
            showMessage("Pembayaran piutang dicatat")
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repo.deleteCustomer(customer)
            showMessage("Pelanggan dihapus")
        }
    }

    fun saveSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repo.saveSupplier(supplier)
            showMessage("Data supplier disimpan")
        }
    }

    fun deleteSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repo.deleteSupplier(supplier)
            showMessage("Supplier dihapus")
        }
    }

    fun saveUser(
        existingId: Long?,
        username: String,
        fullName: String,
        rawPassword: String?,
        role: UserRole,
        outletId: Long,
        isActive: Boolean,
        onDone: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val res = repo.saveUser(existingId, username, fullName, rawPassword, role, outletId, isActive)
            res.onSuccess {
                showMessage("Pengguna berhasil disimpan")
                onDone(true, null)
            }.onFailure { err ->
                onDone(false, err.message)
            }
        }
    }

    // Inventory
    fun createPurchaseOrder(
        supplier: SupplierEntity,
        outlet: OutletEntity,
        items: List<PurchaseOrderDraftItem>,
        notes: String
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val res = repo.createPurchaseOrder(supplier, outlet, items, notes, user.fullName)
            res.onSuccess {
                showMessage("Pembelian (PO) berhasil & stok bertambah")
            }.onFailure { err ->
                showMessage(err.message ?: "Gagal menyimpan PO")
            }
        }
    }

    fun performStockOpname(product: ProductEntity, physicalQty: Double, note: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repo.performStockOpname(product, activeOutlet().id, physicalQty, note, user.fullName)
            showMessage("Stok opname ${product.name} tersimpan")
        }
    }

    fun createStockTransfer(
        fromOutlet: OutletEntity,
        toOutlet: OutletEntity,
        product: ProductEntity,
        quantity: Double,
        note: String
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val res = repo.createStockTransfer(fromOutlet, toOutlet, product, quantity, note, user.fullName)
            res.onSuccess {
                showMessage("Transfer stok dikirim (In Transit)")
            }.onFailure { err ->
                showMessage(err.message ?: "Gagal membuat transfer stok")
            }
        }
    }

    fun receiveStockTransfer(transfer: StockTransferEntity) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repo.receiveStockTransfer(transfer, user.fullName)
            showMessage("Transfer ${transfer.transferNumber} diterima")
        }
    }

    // Settings & Password
    fun updateSettings(updated: StoreSettingsEntity) {
        viewModelScope.launch {
            repo.updateSettings(updated)
            showMessage("Pengaturan disimpan")
        }
    }

    fun toggleThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repo.updateSettings(settings.value.copy(themeMode = mode))
        }
    }

    fun saveOutlet(outlet: OutletEntity) {
        viewModelScope.launch {
            repo.saveOutlet(outlet)
            showMessage("Data cabang disimpan")
        }
    }

    fun changePassword(oldPass: String, newPass: String, onResult: (Boolean, String) -> Unit) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val res = repo.changePassword(user.id, oldPass, newPass)
            res.onSuccess {
                onResult(true, "Password berhasil diubah")
            }.onFailure { err ->
                onResult(false, err.message ?: "Gagal mengganti password")
            }
        }
    }

    // Hardware: Bluetooth Printer, PDF, WhatsApp
    fun refreshPairedPrinters(context: Context) {
        val res = ThermalPrinterHelper.getPairedDevices(context)
        res.onSuccess { list ->
            _pairedDevices.value = list
            if (list.isEmpty()) showMessage("Tidak ada printer Bluetooth ter-pair di perangkat ini")
        }.onFailure { err ->
            showMessage(err.message ?: "Gagal membaca perangkat Bluetooth")
        }
    }

    fun printReceiptBluetooth(context: Context, tx: TransactionEntity) {
        val items = transactionItems.value.filter { it.transactionId == tx.id }
        val currentSettings = settings.value
        val lines = ThermalPrinterHelper.buildReceiptPreviewLines(tx, items, currentSettings)
        viewModelScope.launch {
            val res = ThermalPrinterHelper.printLinesBluetooth(
                context = context,
                printerAddress = currentSettings.printerAddress,
                lines = lines,
                paperWidth = currentSettings.paperWidth
            )
            res.onSuccess {
                showMessage("Struk dikirim ke ${currentSettings.printerName.ifBlank { "Printer Thermal" }}")
            }.onFailure { err ->
                showMessage(err.message ?: "Gagal mencetak struk")
            }
        }
    }

    fun printShiftReportBluetooth(context: Context, shift: ShiftEntity) {
        val currentSettings = settings.value
        val lines = ThermalPrinterHelper.buildShiftPreviewLines(shift, currentSettings)
        viewModelScope.launch {
            val res = ThermalPrinterHelper.printLinesBluetooth(
                context = context,
                printerAddress = currentSettings.printerAddress,
                lines = lines,
                paperWidth = currentSettings.paperWidth
            )
            res.onSuccess {
                showMessage("Laporan shift dikirim ke printer")
            }.onFailure { err ->
                showMessage(err.message ?: "Gagal mencetak laporan shift")
            }
        }
    }

    fun testPrintBluetooth(context: Context) {
        val s = settings.value
        val w = s.paperWidth.charWidth
        val testLines = listOf(
            s.storeName.uppercase().take(w),
            s.storeAddress.take(w),
            "-".repeat(w),
            "TEST PRINT ${s.paperWidth.label}",
            "Koneksi Bluetooth Berhasil!",
            "-".repeat(w),
            "Terima kasih menggunakan AysPOS"
        )
        viewModelScope.launch {
            val res = ThermalPrinterHelper.printLinesBluetooth(
                context = context,
                printerAddress = s.printerAddress,
                lines = testLines,
                paperWidth = s.paperWidth
            )
            res.onSuccess {
                showMessage("Test print berhasil dikirim")
            }.onFailure { err ->
                showMessage(err.message ?: "Test print gagal")
            }
        }
    }

    fun exportPdfInvoice(context: Context, tx: TransactionEntity, share: Boolean) {
        val items = transactionItems.value.filter { it.transactionId == tx.id }
        val res = PdfInvoiceHelper.generateAndShareOrOpenPdf(
            context = context,
            tx = tx,
            items = items,
            settings = settings.value,
            shareAction = share
        )
        res.onSuccess {
            showMessage("Invoice PDF siap (${it.name})")
        }.onFailure { err ->
            showMessage("Gagal membuat PDF: ${err.message}")
        }
    }

    fun shareReceiptWhatsApp(context: Context, tx: TransactionEntity, phoneOverride: String = tx.customerWhatsapp) {
        val items = transactionItems.value.filter { it.transactionId == tx.id }
        WhatsAppShareHelper.shareToWhatsApp(context, tx, items, settings.value, phoneOverride)
    }

    fun setPaperWidth(width: PaperWidth) {
        viewModelScope.launch {
            repo.updateSettings(settings.value.copy(paperWidth = width))
        }
    }

    fun saveLoyaltyReward(reward: LoyaltyRewardEntity) {
        viewModelScope.launch {
            repo.saveLoyaltyReward(reward)
            showMessage("Hadiah poin '${reward.title}' disimpan")
        }
    }

    fun deleteLoyaltyReward(reward: LoyaltyRewardEntity) {
        viewModelScope.launch {
            repo.deleteLoyaltyReward(reward)
            showMessage("Hadiah poin dihapus")
        }
    }

    fun redeemRewardForCustomer(customer: CustomerEntity, reward: LoyaltyRewardEntity) {
        viewModelScope.launch {
            val res = repo.redeemRewardForCustomer(customer, reward)
            res.onSuccess {
                showMessage("Berhasil menukar ${reward.pointsCost} poin untuk ${reward.title}")
            }.onFailure { err ->
                showMessage(err.message ?: "Gagal menukar poin")
            }
        }
    }
}
