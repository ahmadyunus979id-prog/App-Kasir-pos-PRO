package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val TealPrimaryLight = Color(0xFF0F766E)
val TealOnPrimaryLight = Color(0xFFFFFFFF)
val TealContainerLight = Color(0xFFCCFBF1)
val TealOnContainerLight = Color(0xFF134E4A)

val SlateSecondaryLight = Color(0xFF334155)
val SlateOnSecondaryLight = Color(0xFFFFFFFF)
val SlateContainerLight = Color(0xFFE2E8F0)
val SlateOnContainerLight = Color(0xFF0F172A)

val AmberTertiaryLight = Color(0xFFB45309)
val AmberContainerLight = Color(0xFFFEF3C7)
val AmberOnContainerLight = Color(0xFF78350F)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnBackgroundLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)
val OutlineVariantLight = Color(0xFFE2E8F0)

// Dark Palette
val TealPrimaryDark = Color(0xFF2DD4BF)
val TealOnPrimaryDark = Color(0xFF042F2E)
val TealContainerDark = Color(0xFF115E59)
val TealOnContainerDark = Color(0xFFCCFBF1)

val SlateSecondaryDark = Color(0xFF94A3B8)
val SlateOnSecondaryDark = Color(0xFF0F172A)
val SlateContainerDark = Color(0xFF1E293B)
val SlateOnContainerDark = Color(0xFFE2E8F0)

val AmberTertiaryDark = Color(0xFFFBBF24)
val AmberContainerDark = Color(0xFF78350F)
val AmberOnContainerDark = Color(0xFFFEF3C7)

val BackgroundDark = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF111827)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnBackgroundDark = Color(0xFFF1F5F9)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)
val OutlineVariantDark = Color(0xFF1E293B)

// Semantic Colors
val SuccessGreen = Color(0xFF16A34A)
val WarningAmber = Color(0xFFD97706)
val DangerRed = Color(0xFFDC2626)
val InfoBlue = Color(0xFF2563EB)
