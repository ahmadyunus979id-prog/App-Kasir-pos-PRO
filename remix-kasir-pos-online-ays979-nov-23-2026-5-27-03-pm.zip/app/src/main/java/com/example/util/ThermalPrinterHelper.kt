package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.data.local.ShiftEntity
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionItemEntity
import com.example.data.model.PaperWidth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

data class PairedBluetoothDevice(
    val name: String,
    val address: String
)

object ThermalPrinterHelper {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun hasBluetoothPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(context: Context): Result<List<PairedBluetoothDevice>> {
        if (!hasBluetoothPermission(context)) {
            return Result.failure(SecurityException("Izin Bluetooth belum diberikan"))
        }
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter: BluetoothAdapter? = manager?.adapter
        if (adapter == null) {
            return Result.failure(IllegalStateException("Perangkat tidak mendukung Bluetooth"))
        }
        if (!adapter.isEnabled) {
            return Result.failure(IllegalStateException("Aktifkan Bluetooth terlebih dahulu"))
        }
        val devices = adapter.bondedDevices.orEmpty().map { dev ->
            PairedBluetoothDevice(
                name = dev.name ?: "Printer Bluetooth",
                address = dev.address
            )
        }.sortedBy { it.name }
        return Result.success(devices)
    }

    fun buildReceiptPreviewLines(
        tx: TransactionEntity,
        items: List<TransactionItemEntity>,
        settings: StoreSettingsEntity
    ): List<String> {
        val w = settings.paperWidth.charWidth
        val sep = "-".repeat(w)
        val lines = mutableListOf<String>()

        fun center(text: String): String {
            val trimmed = text.take(w)
            val pad = ((w - trimmed.length) / 2).coerceAtLeast(0)
            return " ".repeat(pad) + trimmed
        }

        fun leftRight(left: String, right: String): String {
            val maxLeft = (w - right.length - 1).coerceAtLeast(1)
            val l = left.take(maxLeft)
            val spaces = (w - l.length - right.length).coerceAtLeast(1)
            return l + " ".repeat(spaces) + right
        }

        lines += center(settings.storeName.uppercase())
        if (settings.storeAddress.isNotBlank()) {
            settings.storeAddress.chunked(w).forEach { lines += center(it) }
        }
        if (settings.storePhone.isNotBlank()) {
            lines += center("Telp: ${settings.storePhone}")
        }
        lines += sep
        lines += leftRight("Nota", tx.invoiceNumber)
        lines += leftRight("Tgl", formatDateTime(tx.createdAt))
        lines += leftRight("Outlet", tx.outletName)
        lines += leftRight("Kasir", tx.cashierName)
        lines += leftRight("Plg", tx.customerName)
        lines += sep

        items.forEach { item ->
            lines += item.productName.take(w)
            val qtyStr = "${item.quantity} ${item.unitName} x ${formatRupiah(item.unitPrice)}"
            val subStr = formatRupiah(item.subtotal)
            lines += leftRight(qtyStr, subStr)
            if (item.discountAmount > 0) {
                lines += leftRight("  Diskon Item", "-${formatRupiah(item.discountAmount)}")
            }
        }

        lines += sep
        lines += leftRight("Subtotal", formatRupiah(tx.subtotal))
        if (tx.discountAmount > 0) {
            lines += leftRight("Diskon Nota", "-${formatRupiah(tx.discountAmount)}")
        }
        if (tx.taxAmount > 0) {
            val taxLabel = "PPN (${formatNumber(tx.taxPercent)}%)"
            lines += leftRight(taxLabel, formatRupiah(tx.taxAmount))
        }
        lines += leftRight("TOTAL", formatRupiah(tx.totalAmount))
        lines += leftRight("Bayar (${tx.paymentMethod.label})", formatRupiah(tx.paidAmount))
        if (tx.changeAmount > 0) {
            lines += leftRight("Kembali", formatRupiah(tx.changeAmount))
        }
        lines += sep
        if (settings.receiptFooter.isNotBlank()) {
            settings.receiptFooter.chunked(w).forEach { lines += center(it) }
        }
        lines += center("=== ${settings.paperWidth.label} ===")
        return lines
    }

    fun buildShiftPreviewLines(shift: ShiftEntity, settings: StoreSettingsEntity): List<String> {
        val w = settings.paperWidth.charWidth
        val sep = "-".repeat(w)
        fun leftRight(left: String, right: String): String {
            val l = left.take((w - right.length - 1).coerceAtLeast(1))
            val spaces = (w - l.length - right.length).coerceAtLeast(1)
            return l + " ".repeat(spaces) + right
        }
        return listOf(
            settings.storeName.uppercase().take(w),
            "LAPORAN TUTUP SHIFT",
            sep,
            leftRight("Kasir", shift.userName),
            leftRight("Outlet", shift.outletName),
            leftRight("Buka", formatDateTime(shift.openedAt)),
            leftRight("Tutup", formatDateTime(shift.closedAt ?: System.currentTimeMillis())),
            sep,
            leftRight("Modal Awal", formatRupiah(shift.openingCash)),
            leftRight("Penjualan Tunai", formatRupiah(shift.cashSales)),
            leftRight("Non-Tunai", formatRupiah(shift.nonCashSales)),
            leftRight("Kas Kecil Keluar", "-${formatRupiah(shift.pettyCashOut)}"),
            leftRight("Retur Tunai", "-${formatRupiah(shift.cashRefunds)}"),
            sep,
            leftRight("Kas Seharusnya", formatRupiah(shift.expectedCash)),
            leftRight("Kas Fisik", formatRupiah(shift.actualCash ?: shift.expectedCash)),
            leftRight(
                "Selisih",
                formatRupiah((shift.actualCash ?: shift.expectedCash) - shift.expectedCash)
            ),
            sep
        )
    }

    private fun encodeEscPosBytes(
        lines: List<String>,
        paperWidth: PaperWidth
    ): ByteArray {
        val out = ByteArrayOutputStream()
        // ESC @ Initialize printer
        out.write(byteArrayOf(0x1B, 0x40))
        // Font A for 80mm or Font A/B fit
        out.write(byteArrayOf(0x1B, 0x4D, if (paperWidth == PaperWidth.MM_58) 0x00 else 0x00))
        lines.forEach { line ->
            out.write(line.toByteArray(Charsets.UTF_8))
            out.write(0x0A)
        }
        // Feed 3 lines & partial cut
        out.write(byteArrayOf(0x1B, 0x64, 0x03))
        out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
        return out.toByteArray()
    }

    @SuppressLint("MissingPermission")
    suspend fun printLinesBluetooth(
        context: Context,
        printerAddress: String,
        lines: List<String>,
        paperWidth: PaperWidth
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (printerAddress.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Printer Bluetooth belum dipilih di Pengaturan"))
        }
        if (!hasBluetoothPermission(context)) {
            return@withContext Result.failure(SecurityException("Izin Bluetooth diperlukan untuk mencetak"))
        }
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = manager?.adapter
            ?: return@withContext Result.failure(IllegalStateException("Bluetooth tidak tersedia"))
        if (!adapter.isEnabled) {
            return@withContext Result.failure(IllegalStateException("Bluetooth dalam keadaan mati"))
        }
        return@withContext try {
            val device: BluetoothDevice = adapter.getRemoteDevice(printerAddress)
            val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.use { s ->
                s.connect()
                val bytes = encodeEscPosBytes(lines, paperWidth)
                s.outputStream.write(bytes)
                s.outputStream.flush()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Gagal terhubung ke printer: ${e.message}"))
        }
    }
}
