package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionItemEntity

object WhatsAppShareHelper {

    fun formatReceiptText(
        tx: TransactionEntity,
        items: List<TransactionItemEntity>,
        settings: StoreSettingsEntity
    ): String {
        val sb = StringBuilder()
        sb.appendLine("*${settings.storeName}*")
        if (settings.storeAddress.isNotBlank()) sb.appendLine(settings.storeAddress)
        sb.appendLine("------------------------------")
        sb.appendLine("No. Nota : ${tx.invoiceNumber}")
        sb.appendLine("Tanggal  : ${formatDateTime(tx.createdAt)}")
        sb.appendLine("Outlet   : ${tx.outletName}")
        sb.appendLine("Kasir    : ${tx.cashierName}")
        sb.appendLine("Pelanggan: ${tx.customerName}")
        sb.appendLine("------------------------------")
        items.forEach { item ->
            sb.appendLine("${item.productName}")
            sb.appendLine("  ${item.quantity} ${item.unitName} x ${formatRupiah(item.unitPrice)} = ${formatRupiah(item.subtotal)}")
        }
        sb.appendLine("------------------------------")
        sb.appendLine("Subtotal : ${formatRupiah(tx.subtotal)}")
        if (tx.discountAmount > 0) sb.appendLine("Diskon   : -${formatRupiah(tx.discountAmount)}")
        if (tx.taxAmount > 0) sb.appendLine("PPN (${formatNumber(tx.taxPercent)}%) : ${formatRupiah(tx.taxAmount)}")
        sb.appendLine("*TOTAL   : ${formatRupiah(tx.totalAmount)}*")
        sb.appendLine("Bayar (${tx.paymentMethod.label}): ${formatRupiah(tx.paidAmount)}")
        if (tx.changeAmount > 0) sb.appendLine("Kembali  : ${formatRupiah(tx.changeAmount)}")
        sb.appendLine("------------------------------")
        sb.appendLine(settings.receiptFooter)
        return sb.toString()
    }

    fun shareToWhatsApp(
        context: Context,
        tx: TransactionEntity,
        items: List<TransactionItemEntity>,
        settings: StoreSettingsEntity,
        phoneOverride: String = tx.customerWhatsapp
    ) {
        val text = formatReceiptText(tx, items, settings)
        val cleanPhone = phoneOverride.filter { it.isDigit() }.let { digits ->
            when {
                digits.startsWith("0") -> "62" + digits.drop(1)
                else -> digits
            }
        }
        if (cleanPhone.length >= 9) {
            val uri = Uri.parse("https://wa.me/$cleanPhone?text=${Uri.encode(text)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
                return
            } catch (_: Exception) {
                // Fallback to share sheet
            }
        }
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(
            Intent.createChooser(shareIntent, "Bagikan Struk ke WhatsApp").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )
    }
}
