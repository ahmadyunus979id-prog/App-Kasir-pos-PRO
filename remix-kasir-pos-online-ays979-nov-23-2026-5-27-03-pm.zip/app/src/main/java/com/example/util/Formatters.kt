package com.example.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val indoLocale = Locale.forLanguageTag("id-ID")

fun formatRupiah(amount: Long): String {
    val nf = NumberFormat.getNumberInstance(indoLocale)
    return "Rp ${nf.format(amount)}"
}

fun formatNumber(value: Double): String {
    return if (value % 1.0 == 0.0) {
        NumberFormat.getNumberInstance(indoLocale).format(value.toLong())
    } else {
        String.format(indoLocale, "%.2f", value)
    }
}

fun formatDateTime(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", indoLocale)
    return sdf.format(Date(millis))
}

fun formatDateShort(millis: Long): String {
    val sdf = SimpleDateFormat("dd/MM/yy", indoLocale)
    return sdf.format(Date(millis))
}

fun formatTimeOnly(millis: Long): String {
    val sdf = SimpleDateFormat("HH:mm", indoLocale)
    return sdf.format(Date(millis))
}
