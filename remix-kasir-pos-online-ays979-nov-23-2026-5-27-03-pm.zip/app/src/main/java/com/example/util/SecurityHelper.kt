package com.example.util

import java.security.MessageDigest
import java.security.SecureRandom

object SecurityHelper {
    private val random = SecureRandom()

    fun hashPassword(password: String, existingSalt: String? = null): String {
        val salt = existingSalt ?: ByteArray(16).apply { random.nextBytes(this) }
            .joinToString("") { "%02x".format(it) }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$salt:$password".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "$salt:$digest"
    }

    fun verifyPassword(password: String, storedHash: String): Boolean {
        val parts = storedHash.split(":")
        if (parts.size != 2) return false
        val salt = parts[0]
        return hashPassword(password, salt) == storedHash
    }
}
