package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionItemEntity
import java.io.File
import java.io.FileOutputStream

object PdfInvoiceHelper {

    fun generateAndShareOrOpenPdf(
        context: Context,
        tx: TransactionEntity,
        items: List<TransactionItemEntity>,
        settings: StoreSettingsEntity,
        shareAction: Boolean
    ): Result<File> {
        return try {
            val dir = File(context.filesDir, "invoices").apply { mkdirs() }
            val pdfFile = File(dir, "${tx.invoiceNumber}.pdf")

            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.parseColor("#0F766E")
                textSize = 20f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val headerPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val bodyPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 11f
            }
            val mutedPaint = Paint().apply {
                color = Color.parseColor("#64748B")
                textSize = 10f
            }
            val rightPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 11f
                textAlign = Paint.Align.RIGHT
            }
            val rightBoldPaint = Paint().apply {
                color = Color.parseColor("#0F766E")
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.RIGHT
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1f
            }

            var y = 48f
            val left = 40f
            val right = 555f

            canvas.drawText(settings.storeName, left, y, titlePaint)
            canvas.drawText("INVOICE", right, y, rightBoldPaint)
            y += 18f
            canvas.drawText(settings.storeAddress, left, y, mutedPaint)
            canvas.drawText(tx.invoiceNumber, right, y, rightPaint)
            y += 14f
            canvas.drawText("Telp: ${settings.storePhone}", left, y, mutedPaint)
            canvas.drawText(formatDateTime(tx.createdAt), right, y, rightPaint)
            y += 22f
            canvas.drawLine(left, y, right, y, linePaint)
            y += 20f

            canvas.drawText("Outlet: ${tx.outletName}", left, y, bodyPaint)
            canvas.drawText("Kasir: ${tx.cashierName}", 320f, y, bodyPaint)
            y += 16f
            canvas.drawText("Pelanggan: ${tx.customerName}", left, y, bodyPaint)
            canvas.drawText("Metode: ${tx.paymentMethod.label}", 320f, y, bodyPaint)
            y += 22f

            // Table header
            canvas.drawLine(left, y, right, y, linePaint)
            y += 16f
            canvas.drawText("Produk", left, y, headerPaint)
            canvas.drawText("Qty", 310f, y, headerPaint)
            canvas.drawText("Harga", 415f, y, headerPaint)
            canvas.drawText("Subtotal", right, y, Paint(headerPaint).apply { textAlign = Paint.Align.RIGHT })
            y += 8f
            canvas.drawLine(left, y, right, y, linePaint)
            y += 18f

            items.forEach { item ->
                canvas.drawText(item.productName.take(36), left, y, bodyPaint)
                canvas.drawText("${item.quantity} ${item.unitName}", 310f, y, bodyPaint)
                canvas.drawText(formatRupiah(item.unitPrice), 415f, y, bodyPaint)
                canvas.drawText(formatRupiah(item.subtotal), right, y, rightPaint)
                y += 18f
                if (item.discountAmount > 0) {
                    canvas.drawText("  Diskon item: -${formatRupiah(item.discountAmount)}", left, y, mutedPaint)
                    y += 14f
                }
            }

            y += 8f
            canvas.drawLine(left, y, right, y, linePaint)
            y += 20f

            canvas.drawText("Subtotal", 360f, y, bodyPaint)
            canvas.drawText(formatRupiah(tx.subtotal), right, y, rightPaint)
            y += 16f

            if (tx.discountAmount > 0) {
                canvas.drawText("Diskon Nota", 360f, y, bodyPaint)
                canvas.drawText("-${formatRupiah(tx.discountAmount)}", right, y, rightPaint)
                y += 16f
            }
            if (tx.taxAmount > 0) {
                canvas.drawText("PPN (${formatNumber(tx.taxPercent)}%)", 360f, y, bodyPaint)
                canvas.drawText(formatRupiah(tx.taxAmount), right, y, rightPaint)
                y += 16f
            }

            y += 4f
            canvas.drawText("TOTAL", 360f, y, headerPaint)
            canvas.drawText(formatRupiah(tx.totalAmount), right, y, rightBoldPaint)
            y += 18f
            canvas.drawText("Dibayar (${tx.paymentMethod.label})", 360f, y, bodyPaint)
            canvas.drawText(formatRupiah(tx.paidAmount), right, y, rightPaint)
            y += 16f
            if (tx.changeAmount > 0) {
                canvas.drawText("Kembali", 360f, y, bodyPaint)
                canvas.drawText(formatRupiah(tx.changeAmount), right, y, rightPaint)
                y += 16f
            }

            y += 28f
            canvas.drawLine(left, y, right, y, linePaint)
            y += 18f
            canvas.drawText(settings.receiptFooter, left, y, mutedPaint)

            doc.finishPage(page)
            FileOutputStream(pdfFile).use { out ->
                doc.writeTo(out)
            }
            doc.close()

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = if (shareAction) {
                Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Invoice ${tx.invoiceNumber}")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            val chooser = Intent.createChooser(
                intent,
                if (shareAction) "Bagikan Invoice PDF" else "Buka Invoice PDF"
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Result.success(pdfFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
