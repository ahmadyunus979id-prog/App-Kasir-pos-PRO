import express from 'express';
import type { Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';

interface PublicReceiptItemTuple {
  0: string;
  1: string;
  2: number;
  3: number;
  4: number;
  5: number;
}

interface StoredPublicReceipt {
  storeSlug: string;
  invoiceNumber: string;
  updatedAt: number;
  sn: string;
  sa: string;
  sp: string;
  ft: string;
  inv: string;
  dt: number;
  out: string;
  ks: string;
  plg: string;
  sub: number;
  dsc: number;
  txp: number;
  txa: number;
  tot: number;
  pm: 'TUNAI' | 'QRIS' | 'TRANSFER' | 'PIUTANG';
  pd: number;
  ch: number;
  st: 'COMPLETED' | 'VOID' | 'RETURNED';
  vr?: string;
  it: PublicReceiptItemTuple[];
}

const VALID_PAYMENT_METHODS = ['TUNAI', 'QRIS', 'TRANSFER', 'PIUTANG'] as const;
const VALID_TX_STATUSES = ['COMPLETED', 'VOID', 'RETURNED'] as const;

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const RECEIPTS_FILE = path.resolve(DATA_DIR, 'receipts.json');
const DIST_DIR = path.resolve(process.cwd(), 'dist');

if (!RECEIPTS_FILE.startsWith(DATA_DIR + path.sep)) {
  throw new Error('Invalid receipts storage path configuration');
}

function toStoreSlug(input: string): string {
  const cleaned = String(input || '')
    .trim()
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return cleaned || 'Toko';
}

function toSafeInvoiceKey(input: string): string {
  return String(input || '')
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
}

function makeReceiptKey(storeSlug: string, invoiceNumber: string): string {
  return `${toStoreSlug(storeSlug).toLowerCase()}::${toSafeInvoiceKey(invoiceNumber).toLowerCase()}`;
}

function safeFinite(val: unknown, fallback = 0): number {
  const num = typeof val === 'number' ? val : Number(val);
  return Number.isFinite(num) ? num : fallback;
}

function loadReceiptsFromDisk(): Map<string, StoredPublicReceipt> {
  const map = new Map<string, StoredPublicReceipt>();
  try {
    if (!fs.existsSync(RECEIPTS_FILE)) return map;
    const raw = fs.readFileSync(RECEIPTS_FILE, 'utf8');
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return map;
    for (const entry of parsed) {
      if (
        entry &&
        typeof entry === 'object' &&
        typeof (entry as StoredPublicReceipt).storeSlug === 'string' &&
        typeof (entry as StoredPublicReceipt).invoiceNumber === 'string'
      ) {
        const rec = entry as StoredPublicReceipt;
        map.set(makeReceiptKey(rec.storeSlug, rec.invoiceNumber), rec);
      }
    }
  } catch {
    // start with empty store if unreadable
  }
  return map;
}

const receiptStore = loadReceiptsFromDisk();
let writePending = false;

function persistReceiptsToDisk(): void {
  if (writePending) return;
  writePending = true;
  setImmediate(() => {
    writePending = false;
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmpFile = path.resolve(DATA_DIR, 'receipts.json.tmp');
      if (!tmpFile.startsWith(DATA_DIR + path.sep)) return;
      const items = Array.from(receiptStore.values()).slice(-5000);
      fs.writeFileSync(tmpFile, JSON.stringify(items), 'utf8');
      fs.renameSync(tmpFile, RECEIPTS_FILE);
    } catch {
      // ignore non-fatal disk flush errors
    }
  });
}

function validateAndSanitizeReceiptBody(body: unknown): StoredPublicReceipt | null {
  if (!body || typeof body !== 'object') return null;
  const raw = body as Record<string, unknown>;
  const sn = typeof raw.sn === 'string' ? raw.sn.trim().slice(0, 120) : '';
  const inv = typeof raw.inv === 'string' ? raw.inv.trim().slice(0, 64) : '';
  if (!sn || !inv) return null;

  const pm = raw.pm as StoredPublicReceipt['pm'];
  const st = raw.st as StoredPublicReceipt['st'];
  if (!VALID_PAYMENT_METHODS.includes(pm) || !VALID_TX_STATUSES.includes(st)) {
    return null;
  }

  if (!Array.isArray(raw.it) || raw.it.length > 500) return null;
  const items: PublicReceiptItemTuple[] = [];
  for (const row of raw.it) {
    if (!Array.isArray(row) || row.length < 6) return null;
    items.push([
      String(row[0] || '').slice(0, 140),
      String(row[1] || 'pcs').slice(0, 32),
      safeFinite(row[2], 1),
      safeFinite(row[3], 0),
      safeFinite(row[4], 0),
      safeFinite(row[5], 0),
    ]);
  }

  const storeSlug = toStoreSlug(
    typeof raw.storeSlug === 'string' && raw.storeSlug.trim() ? raw.storeSlug : sn
  );
  const invoiceNumber = toSafeInvoiceKey(inv);
  if (!invoiceNumber) return null;

  return {
    storeSlug,
    invoiceNumber,
    updatedAt: Date.now(),
    sn,
    sa: typeof raw.sa === 'string' ? raw.sa.slice(0, 240) : '',
    sp: typeof raw.sp === 'string' ? raw.sp.slice(0, 48) : '',
    ft: typeof raw.ft === 'string' ? raw.ft.slice(0, 240) : '',
    inv,
    dt: safeFinite(raw.dt, Date.now()),
    out: typeof raw.out === 'string' ? raw.out.slice(0, 100) : '',
    ks: typeof raw.ks === 'string' ? raw.ks.slice(0, 100) : '',
    plg: typeof raw.plg === 'string' ? raw.plg.slice(0, 100) : 'Pelanggan Umum',
    sub: safeFinite(raw.sub, 0),
    dsc: safeFinite(raw.dsc, 0),
    txp: safeFinite(raw.txp, 0),
    txa: safeFinite(raw.txa, 0),
    tot: safeFinite(raw.tot, 0),
    pm,
    pd: safeFinite(raw.pd, 0),
    ch: safeFinite(raw.ch, 0),
    st,
    ...(typeof raw.vr === 'string' && raw.vr.trim() ? { vr: raw.vr.trim().slice(0, 200) } : {}),
    it: items,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '256kb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.post('/api/receipts', (req: Request, res: Response) => {
    const clean = validateAndSanitizeReceiptBody(req.body);
    if (!clean) {
      res.status(400).json({ ok: false, error: 'Payload nota tidak valid' });
      return;
    }
    const key = makeReceiptKey(clean.storeSlug, clean.invoiceNumber);
    receiptStore.set(key, clean);
    persistReceiptsToDisk();
    res.status(201).json({
      ok: true,
      storeSlug: clean.storeSlug,
      invoiceNumber: clean.invoiceNumber,
      shortPath: `/${clean.storeSlug}/${clean.invoiceNumber}`,
    });
  });

  app.get('/api/receipts/:storeSlug/:invoiceNumber', (req: Request, res: Response) => {
    const rawSlug = String(req.params.storeSlug || '');
    const rawInv = String(req.params.invoiceNumber || '');
    const exactKey = makeReceiptKey(rawSlug, rawInv);
    let found = receiptStore.get(exactKey);

    if (!found) {
      const safeInvLower = toSafeInvoiceKey(rawInv).toLowerCase();
      for (const candidate of receiptStore.values()) {
        if (candidate.invoiceNumber.toLowerCase() === safeInvLower) {
          found = candidate;
          break;
        }
      }
    }

    if (!found) {
      res.status(404).json({ ok: false, error: 'Nota tidak ditemukan' });
      return;
    }

    res.json({ ok: true, receipt: found });
  });

  if (process.env.NODE_ENV === 'production' && fs.existsSync(DIST_DIR)) {
    app.use(express.static(DIST_DIR));
    app.use((req: Request, res: Response, next) => {
      if (req.method !== 'GET' || req.path.startsWith('/api/')) {
        next();
        return;
      }
      res.sendFile(path.join(DIST_DIR, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AysPOS server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
